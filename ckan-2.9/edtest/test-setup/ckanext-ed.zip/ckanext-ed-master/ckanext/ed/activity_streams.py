#from webhelpers.html import literal

import ckan.lib.dictization
import ckan.model as model
import ckan.lib.helpers as h

from ckan.common import c
from ckan.plugins import toolkit
from ckanext.ed import helpers as ed_helpers

import logging
log = logging.getLogger(__name__)

def workflow_activity_create(
                    activity, object_type, dict_object, 
                    user, feedback=None):
    '''Creates activity for approval feedback
    '''

    controller_type = object_type
    if object_type in ['category', 'publisher','collection', 
                    'master_collection', 'data_explorer']:
        object_type = 'group'

    context = {'model': model, 'session': model.Session,
                        'user': c.user, 'auth_user_obj': c.userobj,
                        'ignore_auth' : True}
    
    if type(dict_object) is not dict:
        dict_object = ckan.lib.dictization.table_dictize(dict_object, context)
    
    data_dict = {
        'user_id': user,
        'object_id': dict_object.get('id',''),
        'activity_type': 'changed ' + object_type,
        'data': {
            'workflow_activity': activity,
            str(object_type) : dict_object,
            'object_type' : controller_type,
            'feedback': feedback
        }
    }
    toolkit.get_action('activity_create')(context, data_dict)

    ## TODO also manage the Activity Detail
    ## Activity Details have to be created from the model

def custom_activity_renderer_group(context, activity):
    if 'workflow_activity' not in activity.get('data', {}):
        # Default core one
        return toolkit._("{actor} updated the group {group}")

    activity_name = activity['data']['workflow_activity']
    object_type = activity['data']['object_type']

    if activity_name == 'submitted_for_review':
        return toolkit._("{actor} requested a review for a new " + object_type + " {group}")
    elif activity_name == 'resubmitted_for_review':
        return toolkit._("{actor} made changes and requested a review for the " + object_type + " {group}")
    elif activity_name == object_type + "_approved":
        return toolkit._("{actor} approved the " + object_type + " {group} for publication")
    elif activity_name == object_type + "_rejected":
        if activity['data'].get('feedback'):
            return toolkit._(
                "{actor} rejected the " + object_type + " {group} for publication " +
                "with the following feedback: %s" % activity['data']['feedback'])
        else:
            return toolkit._("{actor} rejected the " + object_type + " {group} for publication")

    return toolkit._("{actor} updated the " + object_type + " {group}")

def custom_activity_renderer_package(context, activity):
    '''Returns the custom string for activity stream

    :param context: context
    :type context: dict
    :activity: Activity name Eg reject
    :type activity: string

    :returns: Fromated activity string
    :rtype: string
    '''
    if 'workflow_activity' not in activity.get('data', {}):
        # Default core one
        # TODO write default core for create dataset
        return toolkit._("{actor} updated the dataset {dataset}")

    activity_name = activity['data']['workflow_activity']
    object_type = activity['data']['object_type']

    if activity_name == 'submitted_for_review':
        return toolkit._("{actor} requested a review for new dataset {dataset}")
    elif activity_name == 'resubmitted_for_review':
        return toolkit._("{actor} made changes and requested a review for dataset {dataset}")
    elif activity_name == 'dataset_approved':
        return toolkit._("{actor} approved dataset {dataset} for publication")
    elif activity_name == 'dataset_rejected':
        if activity['data'].get('feedback'):
            return toolkit._(
                "{actor} rejected dataset {dataset} for publication " +
                "with the following feedback: %s" % activity['data']['feedback'])
        else:
            return toolkit._("{actor} rejected dataset {dataset} for publication")

    return toolkit._("{actor} updated the dataset {dataset}")

def custom_activity_renderer_resource(context, activity):
    '''Returns the custom string for activity stream

    :param context: context
    :type context: dict
    :activity: Activity name Eg reject
    :type activity: string

    :returns: Formated activity string
    :rtype: string
    '''
    if 'workflow_activity' not in activity.get('data', {}):
        # Default core one
        # TODO write default core for create resource
        return toolkit._("{actor} updated the resource {resource}")

    activity_name = activity['data']['workflow_activity']
    object_type = activity['data']['object_type']

    if activity_name == 'submitted_for_review':
        return toolkit._("{actor} requested a review for new resource {resource}")
    elif activity_name == 'resubmitted_for_review':
        return toolkit._("{actor} made changes and requested a review for resource {resource}")
    elif activity_name == 'resource_approved':
        return toolkit._("{actor} approved resource {resource} for publication")
    elif activity_name == 'resource_rejected':
        if activity['data'].get('feedback'):
            return toolkit._(
                "{actor} rejected resource {resource} for publication " +
                "with the following feedback: %s" % activity['data']['feedback'])
        else:
            return toolkit._("{actor} rejected resource {resource} for publication")

    return toolkit._("{actor} updated the resource {resource}")

def get_latest_rejection_feedback(pkg_id):
    '''Returns the latest rejection feedback for dataset

    :param pkg_id: id of the dataset
    :type pkg_id: string

    :returns: Rejected feedback
    :rtype: string
    '''
    context = {'ignore_auth': True}
    data_dict = {
        'id': pkg_id,
        'get_workflow_activities': True
    }

    activities = toolkit.get_action('package_activity_list')(
        context, data_dict)

    for activity in activities:
        if (activity['data']['workflow_activity'] == 'dataset_rejected' and
                activity['data'].get('feedback')):
            return activity['data']['feedback']


def get_snippet_group(activity, detail):
    link = ed_helpers.group_link(activity['data']['group'])
    return toolkit.literal('''<span>%s</span>'''
        % (link)
        )

def get_snippet_resource(activity, detail):
    if activity['data'].get('workflow_activity'):
        return h.resource_link(activity['data']['resource'],
                            activity['data']['resource']['package_id'])
    else:
        return h.resource_link(detail['data']['resource'],
                            activity['data']['package']['id'])