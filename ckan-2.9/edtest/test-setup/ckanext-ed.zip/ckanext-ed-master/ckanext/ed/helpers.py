import ast
from json import tool
import os
import json
import inspect
import logging
import mimetypes
import re
import distutils.util
from datetime import datetime
# from webhelpers.html import tags
from sqlalchemy.sql import select, text

try:
    from collections import OrderedDict  # 2.7
except ImportError:
    from sqlalchemy.util import OrderedDict

import ckan.plugins as p
import ckan.logic as logic
import ckan.model as model
import ckan.lib.dictization
import ckan.logic.auth as logic_auth
from ckan.lib.munge import munge_title_to_name

from ckan.lib import helpers as h, base
from ckan.plugins import toolkit
from ckan.common import config, is_flask_request, c, request, _
import ckan.authz as authz

from ckanext.harvest.helpers import get_harvest_source
from ckanext.ed.accrual_periodicity.accrual_periodicity import UPDATE_FREQUENCIES
import ckanext.ed.model as ed_model
from ckanext.ed import actions as ed_action
# WARNING circular dependency!!!
# import actions as ed_actions

log = logging.getLogger()

ACCESS_LEVEL = [
    {"name": "public", "label": "Public"},
    {"name": "restricted-public", "label": "Restricted Public"},
    {"name": "non-public", "label": "Non-public"},
]
DATA_LEVEL = ['national', 'state', 'district', 'school', 'individual',
              'Institution of Higher Education', 'Accreditor', 'Grantee',
              'Zip Code', 'Census Block', 'Census Tract']


def _get_action(action, context_dict, data_dict):
    return toolkit.get_action(action)(context_dict, data_dict)


def get_groups():
    '''
    Returns list of groups

    :returns: a list of grousp
    :rtype: list
    '''
    data_dict = {
        'all_fields': True
    }
    groups = _get_action('group_list', {}, data_dict)

    return groups


def get_recently_updated_datasets(limit=5):
    '''
     Returns recent created or updated datasets.
    :param limit: Limit of the datasets to be returned. Default is 5.
    :type limit: integer
    :param user: user name
    :type user: string

    :returns: a list of recently created or updated datasets
    :rtype: list
    '''
    try:
        pkg_search_results = toolkit.get_action('package_search')(
            data_dict={
                'sort': 'metadata_modified desc',
                'rows': limit
            })['results']
        return pkg_search_results

    except toolkit.ValidationError:
        return []
    # except search.SearchError:
    #     return []
    else:
        log.warning('Unexpected Error occured while searching')
        return []


def get_most_popular_datasets(limit=5):
    '''
     Returns most popular datasets based on total views.
    :param limit: Limit of the datasets to be returned. Default is 5.
    :type limit: integer
    :param user: user name
    :type user: string

    :returns: a list of most popular datasets
    :rtype: list
    '''
    data = pkg_search_results = toolkit.get_action('package_search')(
        data_dict={
            'sort': 'views_total desc',
            'rows': limit,
        })['results']

    return data


def get_storage_path_for(dirname):
    """Returns the full path for the specified directory name within
    CKAN's storage path. If the target directory does not exists, it
    gets created.

    :param dirname: the directory name
    :type dirname: string

    :returns: a full path for the specified directory name within CKAN's storage path
    :rtype: string
    """
    storage_path = config.get('ckan.storage_path')
    target_path = os.path.join(storage_path, 'storage', dirname)
    if not os.path.exists(target_path):
        try:
            os.makedirs(target_path)
        except OSError as exc:
            log.error('Storage directory creation failed. Error: %s' % exc)
            target_path = os.path.join(storage_path, 'storage')
            if not os.path.exists(target_path):
                log.info('CKAN storage directory not found also')
                raise

    return target_path


def get_total_views_for_dataset(id):
    '''Returns totoal number of unique views for the dataset

    :param id: dataset id
    :type id: string

    :returns: number of unique views
    :rtype: integer
    '''
    data_dict = {
        'id': id,
        'include_tracking': True
    }

    try:
        dataset = _get_action('package_show', {}, data_dict)
        return dataset.get('tracking_summary').get('total')
    except Exception:
        return 0


def is_admin(user, office=None):
    """
    Returns True if user is admin of given organisation.
    If office param is not provided checks if user is admin of any organisation

    :param user: user name
    :type user: string
    :param office: office id
    :type office: string

    :returns: True/False
    :rtype: boolean
    """
    user_orgs = _get_action(
                'organization_list_for_user', {'user': user}, {'user': user})
    if office is not None:
        return any([i.get('capacity') == 'admin' \
                and i.get('id') == office for i in user_orgs])
    return any([i.get('capacity') == 'admin' for i in user_orgs])


def is_editor(user, office=None):
    """
    Returns True if user is editor of given organisation.
    If office param is not provided checks if user is editor of any organisation

    :param user: user name
    :type user: string
    :param office: office id
    :type office: string

    :returns: True/False
    :rtype: boolean
    """
    user_orgs = _get_action(
                'organization_list_for_user', {'user': user}, {'user': user})
    if office is not None:
        return any([i.get('capacity') == 'editor' \
                and i.get('id') == office for i in user_orgs])
    return any([i.get('capacity') == 'editor' for i in user_orgs])


def get_pending_datasets(user, include_rejected=False):
    """
    Returns List of datasets requested for approval.
    Includes rejecred datasets if include_rejected is set to True.

    :param user: username
    :type user: string
    :include_rejected: Flag to include rejecte datasets or not
    :type include_rejected: boolean

    :returns: List of matching datasets
    :rtype: list
    """
    role = 'editor' if include_rejected else 'admin'
    user_orgs = _get_action(
        'organization_list_for_user', {'id': user}, {'id': user})
    user_org_pemrs = [
        'owner_org:' + i['id'] for i in user_orgs if i.get('capacity') == role
    ]
    fq_string = '(approval_state:approval_pending{0}){1}{2}'.format(
        # Include rejected datasets if needed
        ' OR approval_state:rejected' if include_rejected else '',
        # Filter datasets by orgs user is admin of
        ' AND (%s)' % ' OR '.join(user_org_pemrs) if len(user_org_pemrs) else '',
        # Filter datasets not belonging to ediotr
        ' AND creator_user_id:%s' % (user) if include_rejected else ''
    )
    pending_dataset = toolkit.get_action('package_search')(
        data_dict={
            'fq': fq_string,
            'include_private': True,
            'extras': {'from_dashboard': True},
        })['results']
    return pending_dataset

def quality_mark(package):
    """Returns flag for quality about dataset
    :param pacakge: Package dictionary
    :return: dict
         ['machine'] - True if there's at least one machine readable resource.
         ['doc'] - True if there's at least one document resource.
    """
    if 'resources' not in package.keys():
        return {
            'machine': False,
            'doc': False
        }

    at_least_one_machine_resource = \
        any([True for r in package['resources'] if r['format']=='CSV' or
                                            r['format'] == 'XML' or
                                            r['mimetype'] == 'text/csv' or
                                            r['mimetype'] == 'text/json' or
                                            r['mimetype'] == 'application/json' or
                                            r['url_type'] != 'upload' and r['format'] != 'TXT' and r['url'] != ''])



    at_least_one_document_resource = \
        any([True for r in package['resources'] if r.get('resource_type')=='doc'])

    return { 'machine' : at_least_one_machine_resource,
             'doc' : at_least_one_document_resource }


def get_org_for_package(package):
    """Returns organization name for the dataset
    :param package: package dict
    :type package: dictionary

    :return: organization name
    :rtype: string
    """
    return (
        package['organization']['title']
    )


def alphabetize_dict(items, sort_by='display_name'):
    """
    Aplbetically sort a dictionary. `sort_by` can be provided
    to determine the value by which key to sort the dictionary.

    :param items: list of items to be sorted
    :type items: list
    :param sort_by: dictionary key the dictionary should be sorted on
    :type sort_by: string

    :return: list of sorted data
    :rtype: list
    """
    sorted_dict = sorted(items, key=lambda x: str(x[sort_by]).lower())
    return sorted_dict


def get_any(list_, key=None):
    """Teturns true if list contains at least one True. List can also may be
    the list of objects Eg: [{"a": True, "b": False}]. "key" parameter is required in that case

    :param list_: list of items
    :type list_: list
    :param key: dictionary key that should contain True or False value
    :type key: string

    :return: True or False
    :rtype: boolean
    """
    if key is not None:
        return any(i[key] for i in list_)
    return any(list_)


def get_facet_items_dict(facet, search_facets=None, limit=None, exclude_active=False):
    '''Return the list of unselected facet items for the given facet, sorted
    by count.

    Returns the list of unselected facet contraints or facet items (e.g. tag
    names like "russian" or "tolstoy") for the given search facet (e.g.
    "tags"), sorted by facet item count (i.e. the number of search results that
    match each facet item).

    Reads the complete list of facet items for the given facet from
    c.search_facets, and filters out the facet items that the user has already
    selected.

    Arguments:
    facet -- the name of the facet to filter.
    limit -- the max. number of facet items to return.
    exclude_active -- only return unselected facets.

    '''
    if not hasattr(c, u'search_facets') or not c.search_facets.get(
                                               facet, {}).get(u'items'):
        return []
    facets = []

    if facet == 'groups':
        facet_name = 'topics'
    else:
        facet_name = facet

    for facet_item in c.search_facets.get(facet)['items']:
        if not len(facet_item['name'].strip()):
            continue
        if not (facet_name, facet_item['name']) in request.params.items():
            facets.append(dict(active=False, **facet_item))
        elif not exclude_active:
            facets.append(dict(active=True, **facet_item))
    # Sort descendingly by count and ascendingly by case-sensitive display name
    facets.sort(key=lambda it: (-it['active'], -it['count'], it['display_name'].lower()))
    if hasattr(c, 'search_facets_limits'):
        if c.search_facets_limits and limit is None:
            limit = c.search_facets_limits.get(facet)
    # zero treated as infinite for hysterical raisins
    if limit is not None and limit > 0:
        return facets[:limit]
    return facets


def get_facet_all_items_dict(facet, data_dict=None):
    """ Helper function to get all the possible values of a facet,
    together with the package counts.
    This is a fork of `get_facet_items_dict` helper.
    """

    if not data_dict:
        data_dict = {
            'facet.mincount': 0,
            'facet.limit': -1,
            'facet.field': '["%s"]' % facet
        }

    if type(data_dict['fq']) == list:
        data_dict['fq'] = data_dict['fq'][0]

    search_facets = logic.get_action('package_search')({}, data_dict)['search_facets']

    facets = []

    if facet == 'groups':
        facet_name = 'topics'
    else:
        facet_name = facet

    for facet_item in search_facets[facet]['items']:
        if not len(facet_item['name'].strip()):
            continue
        if not (facet_name, facet_item['name']) in request.params.items():
            facets.append(dict(active=False, **facet_item))
    # Sort descendingly by count and ascendingly by case-sensitive display name
    facets.sort(key=lambda it: (-it['active'], -it['count'], it['display_name'].lower()))
    return facets


def get_dataset_collections(pkg_name):

    if not pkg_name:
        return []

    context = {'model': model, 'session': model.Session}
    fq = '+groups:"{0}"'.format(id)
    search_dict = {
        'q': pkg_name,
        'include_private' : True,
        'include_drafts' : True
        # 'fq': fq,
    }

    collection_data = logic.get_action('package_search')(context, search_dict)['results']
    collection_data = [
        collection for collection
        in collection_data
        if collection['name'] == pkg_name
    ]
    collections = []

    if collection_data:
        s = [c['name'] for c in collection_data[0]['groups']]

        for name in s:
            group = get_group_dict({'id': name})
            group_type = group.get('type')

            if group_type == 'collection':
                collections.append(name)

    return collections


def get_collections():
    context = {'model': model, 'session': model.Session}
    return  logic.get_action('group_list')(context, {'type': 'collection'})

def get_programs_list():

    module = __import__('ckanext.ed.seeds', fromlist=[''])
    seed_file = os.path.join(os.path.dirname(inspect.getfile(module)),
                             'programs.json')

    try:
        with open(seed_file, 'r') as f:
            programs_list = json.loads(f.read())
    except:
        programs_list = []
    return programs_list


def get_access_level():
	return ACCESS_LEVEL


def get_collections_list(group_id=None):
    if group_id:
        group = model.Group.get(group_id)
        collections = group.groups_allowed_to_be_its_parent(type='collection')
    else:
        collections = model.Group.all(group_type='collection')
    return collections

def filter_categories(groups):
    # for a list of groups, return a list of categories only
    if not groups:
        return None

    not_categories = ['collection', 'ed_source', 'data_explorer']
    categories = []

    for group in groups:
        group = model.Group.get(group.get('id'))
        if group.type not in not_categories:
            categories.append(group)

    return categories

# WARNING moving this to the actions (even if it should be here by naming) due to circular dependency
# def collection_datasets_string(collection_id):
#     context = { 'model': model, 'session': model.Session }
#     fq = '+groups:"{0}"'.format(collection_id)
#     search_dict = {
#         'q': '',
#         'type': 'dataset',
#         'fq': fq,
#     }
#     collection_data = ed_actions.package_search(context, search_dict)['results']

#     collection_datasets = [package['name'] for package in collection_data]
#     return ','.join(collection_datasets)


def get_publisher(id):
    context = { 'model': model, 'session': model.Session }
    try:
        return logic.get_action('organization_show')(context, {'id': id})
    except:
        return {}


def filter_collections(groups):
    all_collections = get_collections()
    return [value for value in groups if value['name'] in all_collections]

def filter_attribute(attr, dicts):
    return [d[attr] for d in dicts]


def get_package_documentation(package_id, doc_type='documentation'):
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': package_id}
    dataset_dict = logic.get_action('package_show')(context, data_dict)

    try:
        relationships = logic.get_action('package_relationships_list')(context, data_dict)
        documentation = [r['object'] for r in relationships if r['type'] == 'parent_of']

        for documentation_id in documentation:
            try:
                doc_data_dict = logic.get_action('package_show')(context, {'id': documentation_id})

                if doc_data_dict.get('type') != doc_type:
                    continue
                if doc_data_dict['state'] == 'active':
                    result = {'id': documentation_id, 'include_tracking': True}
                    return result
            except:
                continue
    except:
        return None


def get_dataset_for_documentation(documentation_id):
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': documentation_id}
    documentation_dict = logic.get_action('package_show')(context, data_dict)

    try:
        relationships = logic.get_action('package_relationships_list')(context, data_dict)
        dataset = [r['object'] for r in relationships if r['type'] == 'child_of']
        return {'id': dataset[0], 'include_tracking': True}
    except:
        return None


def get_collection_for_documentation(documentation_id):
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': documentation_id}
    documentation_dict = logic.get_action('package_show')(context, data_dict)

    try:
        for g in documentation_dict['groups']:
            group_dict = logic.get_action('group_show')(context, {'id': g})
            if group_dict.get('type', 'group') == 'collection':
                return {'id': group_dict, 'include_tracking': True}
    except:
        return None


def get_documentation_parent(documentation_id):
    dataset = get_dataset_for_documentation(documentation_id)
    collection = get_collection_for_documentation(documentation_id)
    if dataset:
        return {'type': 'dataset', 'result': dataset}
    elif collection:
        return {'type': 'collection', 'result': collection}
    else:
        return None


def get_package_extra_field(pkg_dict, field):
    # return the extra field --modified-- of the package
    extras = pkg_dict.get('extras',{})
    for extra_dict in extras:
        if extra_dict.get('key') == field:
            return extra_dict.get('value')

    return None


def get_export_map_json(map_filename):
    """
    Reading json export map from file
    :param map_filename: str
    :return: obj
    """

    map_path = os.path.join(os.path.dirname(__file__), 'export_map', map_filename)

    if not os.path.isfile(map_path):
        log.warn("Could not find %s ! Please create it. Use samples from same folder", map_path)
        map_path = os.path.join(os.path.dirname(__file__), 'export_map', 'export.catalog.map.sample.json')

    with open(map_path, 'r') as export_map_json:
        json_export_map = json.load(export_map_json, object_pairs_hook=OrderedDict)

    return json_export_map


def get_level_of_data_json():
    """
    Reading json level of data vocabulary file
    :return: obj
    """

    json_dir = "seeds/tags/level_of_data.json"
    path = os.path.join(os.path.dirname(__file__), json_dir)

    if not os.path.isfile(path):
        return None

    with open(path, 'r') as map_path:
        level_of_data_json = json.load(map_path, object_pairs_hook=OrderedDict)

    return level_of_data_json


def get_level_of_data_label(level_of_data_json, name):

    if level_of_data_json is None:
        return name

    for level_of_data in level_of_data_json:
        if level_of_data.get('name') == name:
            return level_of_data.get('label')


def get_level_of_data_values():

    level_of_data_json = get_level_of_data_json()

    values = toolkit.get_action('vocabulary_show')({}, {'id': 'level_of_data'})['tags']
    return [{'name': v['name'], 'label': get_level_of_data_label(level_of_data_json, v['display_name']) } for v in values]


def get_organization(origin_type, origin_id):

    '''
    returns the organization for datasets or collections
    the origin_type can be a dataset or a collection

    :param origin: str
    :param origin_id: str
    :return: dict
    '''

    organization = {}

    context = {'model': model, 'session': model.Session}
    data_dict = {'id': origin_id}

    if origin_type == 'dataset':
        
        try:
            package_dict = logic.get_action('package_show')(context, data_dict)
            organization = package_dict.get('organization', None)
        except:
            return None

    elif origin_type == 'collection':

        try:
            collection_dict = logic.get_action('group_show')(context, data_dict)
            owner_org = collection_dict.get('owner_org', None)
            organization = get_publisher(owner_org)
        except:
            return None

    elif origin_type == 'data_explorer':

        try:
            data_explorer = logic.get_action('group_show')(context, data_dict)
            owner_org = data_explorer.get('owner_org', None)
            organization = get_publisher(owner_org)
        except:
            return None

    return organization


def get_dataset_collections_json(datasets):

    dict_lst = []

    for dataset in datasets:
        dict_lst.append( { 'id': dataset.get('name'), 'text': dataset.get('title')} )

    return json.dumps(dict_lst)


def access_to_link_resources(publisher_id):

    if is_admin(c.user):
        return True
    
    publishers_allowed = config.get('ckanext.ed.publishers_allowed_linking_res')
    if not publishers_allowed:
        return False

    publishers_allowed = publishers_allowed.split(',')

    if publisher_id in publishers_allowed:
        return True

    return False


def get_organizations(all_fields=True, include_groups=True):
    '''
    returns all of the organizations
    including organizations (publishers) and suborganizations

    :param all_fields: boolean
    :param origin_id: boolean
    :return: list
    '''

    context = {'model': model, 'session': model.Session}
    data_dict = {
        'all_fields': all_fields,
        'include_groups': include_groups
    }

    organizations = logic.get_action('organization_list')(context, data_dict)
    return organizations


def get_publishers():
    '''
    returns all of the publishers (parent organizations)
    and the sub-organizations as values of the children key in the dict

    :return: list
    '''

    context = {'model': model, 'session': model.Session}
    data_dict = {
        'all_fields': 'true'
    }

    publishers = logic.get_action('organization_list')(context, data_dict)
    return publishers


def get_suborganizations(publisher_id):
    '''
    returns all of the sub-organizations under the parent organization(publisher)
    passed by the parameter publisher_id

    :param publisher_id: str
        - the id or the name of the organization (publisher)
    :return: list
    '''
    
    publisher = get_publisher(publisher_id)
    publisher_name = publisher.get('name', None)
    if not publisher_name:
        return []

    context = {'model': model, 'session': model.Session}
    data_dict = {
        'type': 'organization'
    }

    organizations = logic.get_action('group_tree')(context, data_dict)
    for organization in organizations:
        if organization.get('name', '') == publisher_name:
            return organization.get('children', [])

    return []

def get_org_list():
    
    context = {'model': model, 'session': model.Session}
    data_dict = {
        'all_fields': 'true',
        'include_extras':'true',
        'include_groups':'true'
    }
    return logic.get_action('organization_list')(context, data_dict)

def publishers_available_to_the_user(permission='manage_group'):

    '''
    returns only available publishers to the current user
    for a given permission type. Publishers are organizations
    without any suborganization.

    :param permission: str
    :return: list
    '''

    user_organizations = h.organizations_available(permission)

    publishers = get_publishers()
    dict_publisher = { publisher.get('name') : publisher for publisher in publishers }

    user_publishers = []

    for user_organization in user_organizations:
        publisher = dict_publisher.get(user_organization.get('name'), None)
        if publisher:
            user_publishers.append(publisher)

    return user_publishers

def check_access_to_create_collections():

    '''
    This helper is checking if the logged user has any
    role allowed to create collections or master_collections (groups).
    It's necessary because the core helper h.check_access('group_create')
    takes the value of the config var ckan.auth.user_create_groups and 
    we want to override this behaviour.

    :return: boolean
    '''

    if is_admin(c.user):
        return True

    context = {'model': model, 'session': model.Session}
    data_dict = {'id': c.user}

    organization_list = logic.get_action('organization_list_for_user')(context, data_dict)
    for organization in organization_list:
        if organization.get('capacity') in ['editor', 'admin']:
            return True

    return False

def group_list_for_harvest_source(source_id, group_type):
    '''
    Creates a group_type list with the ones belonging to a particular harvest
    source.
    '''

    sql = '''select g.name from group_extra e join "group" g on (e.group_id = g.id)
                where g.type = :grouptype
                and e.key = 'harvest_source_id'
                and e.value = :harvestsourceid;'''
    result = model.Session.execute(sql, { "grouptype": group_type, "harvestsourceid": source_id })
    group_names = []
    for row in result:
        group_names.append(row[0])

    limit = 20
    page = int(request.params.get('page', 1))

    list_dict = {
        'limit': limit,
        'offset': (page - 1) * limit,
        'groups': group_names,
        'all_fields': True,
        'include_extras': True,
    }

    context = {'model': model, 'session': model.Session}
    harvest_source = get_harvest_source(source_id)

    query = logic.get_action('{}_list'.format(group_type))(context, list_dict)

    if group_type == 'collection':
        base_url = h.url_for(
            'ed_harvest.collection_index',
            id=source_id
        )
    else:
        base_url = h.url_for(
            'harvest_{}_index'.format(group_type),
            id=source_id,
            group_type=group_type
        )

    def pager_url(q=None, page=None):
        url = base_url
        if page:
            url += '?page={0}'.format(page)
        return url

    pager = h.Page(
        collection=query,
        page=page,
        url=pager_url,
        item_count=len(query),
        items_per_page=limit
    )
    pager.items = query

    if group_names and query:
        out = h.snippet('collection/snippets/group_list.html', groups=query)
        out += pager.pager()
    else:
        out = h.snippet('snippets/group_list_empty.html', group_type=group_type)

    return out


def group_count_for_harvest_source(source_id, group_type):
    '''
    Returns the current group_type count for the given source id
    '''
    sql = text('''select count(*) from group_extra e join "group" g on (e.group_id = g.id)
                where g.type = :grouptype
                and e.key = 'harvest_source_id'
                and e.value = :sourceid;''')
    result = model.Session.execute(sql, { "grouptype": group_type, "sourceid": source_id })
    for row in result:
        count = row[0]
    return count


def get_config_value(key):
    if config.get(key):
        if config.get(key).lower() in ['true', 'false']:
            return bool(distutils.util.strtobool(config.get(key)))
        else:
            return config.get(key)
    else:
        return ''


def get_collections_child(group_id):
    if group_id is not None:
        group = model.Group.get(group_id)
        allowable_parent_groups = \
            group.groups_allowed_to_be_its_parent(type='collection')
        print('IN if', allowable_parent_groups)
    else:
        allowable_parent_groups = model.Group.all(
            group_type='collection')
        print(allowable_parent_groups)
    return allowable_parent_groups


def update_frequencies():
    freq_list = [{'text': ' ', 'value': None}] \
        + [{'text': key, 'value': value}
            for key, value in UPDATE_FREQUENCIES.items()]
    
    # Manually add annual object after the empty object
    try:
        freq_list.insert(1, freq_list.pop(freq_list.index(
            {'text': 'Annual', 'value': 'R/P1Y'}
        )))
    except:
        pass
    return freq_list


def get_current_frequency_name(data_dict):
    for key, value in UPDATE_FREQUENCIES.items():
        if value == data_dict.get('update_frequency'):
            return key


def data_level():
	return DATA_LEVEL


def collection_datasets(collection_id):
    context = { 'model': model, 'session': model.Session }
    fq = '+groups:"{0}"'.format(collection_id)
    search_dict = {
        'type' : 'dataset',
        'fq': fq,
        'rows': 1000,
        'include_private' : True
    }
    collection_data = logic.get_action('package_search')(context, search_dict)['results']

    collection_datasets = [ { 'name' : package['name'], 'title' : package['title'] } for package in collection_data]
    return collection_datasets


def unassociated_datasets(collection_id):
    context = { 'model': model, 'session': model.Session }

    search_dict = {
        'type' : 'dataset',
        'rows' : 1000,
        'include_private' : True
    }

    collection_data = logic.get_action('package_search')(context, search_dict)['results']
    collection_datasets = [ { 'name' : package['name'], 'title' : package['title'] } for package in collection_data]

    return collection_datasets

def get_spatial_tags():
    try:
        tag_list = p.toolkit.get_action('tag_list')
        spatial_tags = tag_list(data_dict={'vocabulary_id': 'spatial'})
        return spatial_tags
    except toolkit.ObjectNotFound:
        return None


def get_programs_list():
    try:
        with open('src_extensions/ckanext-ed/ckanext/ed/seeds/programs.json', 'r') as f:
            programs_list = json.loads(f.read())
    except:
        programs_list = []
    return programs_list

def package_list_for_source(source_id):
    '''
    Creates a dataset list with the ones belonging to a particular harvest
    source.

    It calls the package_list snippet and the pager.
    '''
    limit = 20
    page = int(request.params.get('page', 1))
    fq = '+harvest_source_id:"{0}"'.format(source_id)
    search_dict = {
        'fq': fq,
        'rows': limit,
        'sort': 'metadata_modified desc',
        'start': (page - 1) * limit,
        'include_private': True
    }

    context = {'model': model, 'session': model.Session}
    harvest_source = get_harvest_source(source_id)
    owner_org = harvest_source.get('owner_org', '')
    if owner_org:
        user_member_of_orgs = [org['id'] for org
                               in h.organizations_available('read')]
        if (harvest_source and owner_org in user_member_of_orgs):
            context['ignore_capacity_check'] = True

    query = logic.get_action('package_search')(context, search_dict)

    #base_url = h.url_for('dataset_read', id=source_id)
    base_url = "/harvest/{0}".format(harvest_source.get('name'))

    def pager_url(q=None, page=None):
        url = base_url
        if page:
            url += '?page={0}'.format(page)
        return url

    pager = h.Page(
        collection=query['results'],
        page=page,
        url=pager_url,
        item_count=query['count'],
        items_per_page=limit
    )
    pager.items = query['results']

    if query['results']:
        out = h.snippet('snippets/package_list.html', packages=query['results'])
        out += pager.pager()
    else:
        out = h.snippet('snippets/package_list_empty.html')

    return out

def package_count_for_source(source_id):
    '''
    Returns the current package count for datasets associated with the given
    source id
    '''
    fq = '+harvest_source_id:"{0}"'.format(source_id)
    search_dict = {'fq': fq,
        'include_private': True
                   }
    context = {'model': model, 'session': model.Session}
    result = logic.get_action('package_search')(context, search_dict)
    return result.get('count', 0)

def group_link(group):

    url = ""
    
    if group.get('type','') == 'data_explorer':
        url = h.url_for('data_explorer.read', id=group['name'])
    elif group.get('type','') == 'master_collection':
        url = h.url_for(controller='master_collection', action='read', id=group['name'])
    elif group.get('type','') == 'collection':
        url = h.url_for('collection.read', id=group['name'])
    else:    
        url = h.url_for('group.read', id=group['name'])

    # webhelper now unsupported
    # return tags.link_to(group['title'], url)
    return url


def get_relationship_parent_identifiers(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    relationship_parent_name = data_dict.get('relationship_parent')
    id = data_dict.get('id')
    parent = None

    if id and not data_dict.get('default'):
        relationships = logic.get_action('package_relationships_list')(context, {'id': id})

        for relationship in relationships:
            if relationship['type'] == 'child_of':
                parent = ed_action.get_package_from_db(name=relationship['object'])

    elif relationship_parent_name:
        parent = ed_action.get_package_from_db(name=relationship_parent_name)

    return json.dumps([{'id': parent['name'], 'text': parent['title']}]) \
        if parent else []


def get_relationship_parent(data_dict, retrieve_siblings=False, for_dcat=False):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    id = data_dict.get('id')
    parent_dict = {}

    if id:
        relationships = logic.get_action('package_relationships_list')(
           context, {'id': data_dict['id']})

        for relationship in relationships:
            parent = ed_action.get_package_from_db(name=relationship['object'])
            subject = ed_action.get_package_from_db(name=relationship['subject'])
            is_valid = (
                all(r.get('type') != 'documentation' for r in [parent, subject])
                and (retrieve_siblings or (
                    is_admin(c.user) or parent.get('private', False) is False
                ))
            )

            if is_valid:
                if for_dcat is False or relationship.get('type') == 'child_of':
                    parent_dict = parent

    return parent_dict


def get_relationship_siblings(data_dict):
    parent_dict = get_relationship_parent(data_dict, True)
    parent_id = parent_dict.get('id')
    siblings = iterate_relationships(parent_id, parent_dict)

    return [s for s in siblings if s['name'] != data_dict['name']] \
        if siblings else None


def get_relationship_children(data_dict):
    children = iterate_relationships(data_dict['id'], data_dict)

    return children if children else None


def get_sorted_relationships(relationships):
    return sorted(relationships, key=lambda k: k.get('name'))


def iterate_relationships(id, data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    results = []

    if id:
        relationships_for = model.Package.get(id).get_relationships()
        relationships = [r.as_dict() for r in relationships_for]

        if relationships:
            results = [
                relationship for relationship in relationships if relationship['type'] == 'parent_of'
                and all(r.get('type') == 'dataset' for r in relationship_package)
                and (is_admin(c.user) or relationship_package[0].get('private') is False)
                for relationship_package in [
                    (
                        ed_action.get_package_from_db(name=relationship['object']),
                        ed_action.get_package_from_db(name=relationship['subject'])
                    )
                ]
                if all(r is not None for r in relationship_package)
            ]

            return results


def find_hierarchy_cur_pkg_path(full_hierarchy, pkg_name, tmp_keys=[]):
    path = []

    if pkg_name in full_hierarchy:
        cur_keys = tmp_keys + [pkg_name]
        path += cur_keys

    for key, value in full_hierarchy.items():
        if isinstance(value, dict):
            path += find_hierarchy_cur_pkg_path(
                value, pkg_name, tmp_keys=tmp_keys + [key])

    return [k for k in path if k != 'children']


def check_hierarchy_pkg_levels(pkg_level_key, pkg_level_value):
    if pkg_level_key == 'level':
        return pkg_level_value
    elif isinstance(pkg_level_value, dict) and 'level' in pkg_level_value:
        return pkg_level_value.get('level')


def generate_html(context, full_hierarchy, pkg_name, cur_pkg_path,
                  pkg_found=False, level=True, last_level=False):
    hierarchy_html = []
    cur_pkg_html_class = ''
    cur_pkg_active = ''
    cur_pkg_caret_down = ''

    if not pkg_found:
        cur_pkg_active = ' active'
        cur_pkg_caret_down = ' caret-down'

    if hierarchy_html:
        hierarchy_html.append('<ul class="nested{}">\n'
                              .format(cur_pkg_active))

    for key, value in full_hierarchy.items():
        level = check_hierarchy_pkg_levels(key, value)
        cur_pkg_html_class = ' class="hierarchy-pkg"'

        if key == pkg_name and not pkg_found:
            pkg_found = True
            cur_pkg_html_class = ' class="hierarchy-current-pkg"'
            cur_pkg_caret_down = ' caret-down'
        elif pkg_found:
            cur_pkg_caret_down = ''

        if isinstance(value, dict):
            cur_parent = value.get('parent')
            cur_children = full_hierarchy.get('children') or {}

            if key != 'children':
                if cur_parent == pkg_name or (
                   cur_children is not None and not any(
                       v in cur_pkg_path for v in cur_children
                   )):
                    cur_pkg_active = ' active'
                    cur_pkg_caret_down = ''

                if not any(
                   k in cur_pkg_path for k in full_hierarchy
                   ) and not any(
                    k in cur_pkg_path
                    for k in cur_children
                    if cur_children
                ) and value.get('parent') != pkg_name:
                    cur_pkg_active = ''
                    cur_pkg_caret_down = ''

                if key in cur_pkg_path:
                    cur_pkg_caret_down = ' caret-down'

                if value['parent'] is not None and level != last_level:
                    hierarchy_html.append('<ul class="nested{}">\n'
                                          .format(cur_pkg_active))

                if value['children'] is not None:
                    hierarchy_html.append(
                        '<li{}><span class="caret{}"></span>'
                        '<a href="/dataset/{}">{}</a>'.format(
                            cur_pkg_html_class, cur_pkg_caret_down, key,
                            value.get('title'))
                    )
                else:
                    hierarchy_html.append(
                        '<li{}><a href="/dataset/{}">{}</a>'
                        .format(
                            cur_pkg_html_class, key,
                            value.get('title')
                        )
                    )

                hierarchy_html.append(generate_html(
                    context, value, pkg_name, cur_pkg_path,
                    pkg_found, level, last_level
                ))

            else:
                hierarchy_html.append(generate_html(
                    context, value, pkg_name, cur_pkg_path,
                    pkg_found, level, last_level
                ))

            last_level = check_hierarchy_pkg_levels(key, value)

    if 'children' in full_hierarchy and full_hierarchy.get('children'):
        hierarchy_html.append('</li>')
        hierarchy_html.append('</ul>\n')

    return '\n'.join(hierarchy_html)


def get_package_hierarchy_html(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    pkg_name = data_dict.get('name')
    full_hierarchy = ed_action.get_full_package_hierarchy(
        context, {'id': pkg_name})
    cur_pkg_path = find_hierarchy_cur_pkg_path(full_hierarchy, pkg_name)

    full_html = ('<div class="relationship-hierarchy-tree"><ul class="package-hiera'
            'rchy">{}</ul></div>'.format(generate_html(
                context, full_hierarchy, pkg_name, cur_pkg_path
            )))

    return full_html


def get_relationship_dependencies_of(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    package_id = data_dict.get('id')
    dependencies_of = []
    if package_id and not data_dict.get('default'):

        try:
            relationships_query = logic.get_action('package_relationships_list')(
                context,
                {'id': package_id})
        except logic.NotFound:
            return []

        for relationship in relationships_query:
            if relationship['type'] == 'dependency_of':
                relationship_package_name = None
                relationship_object = relationship['object']

                try:
                    relationship_package_name = ed_action.get_package_from_db(
                        name=relationship_object
                    )

                    dependencies_of.append(
                        {'text': relationship_package_name.get('title'),
                        'id': relationship_package_name.get('name')})
                except Exception as e:
                    log.error('Error retrieving package {}: {}'.format(
                        relationship_object, e)
                    )
    elif data_dict.get('relationship_dependency_of', False):
        relationship_object = data_dict.get('relationship_dependency_of')

        for relationship in relationship_object:
            try:
                relationship_package_name = ed_action.get_package_from_db(
                    name=relationship
                )

                dependencies_of.append(
                    {'text': relationship_package_name.get('title'),
                    'id': relationship_package_name.get('name')})
            except Exception as e:
                log.error('Error retrieving package {}: {}'.format(
                    relationship, e)
                )

    dependencies_of = _remove_private_relationships(dependencies_of)

    return json.dumps(dependencies_of) if dependencies_of else []


def get_relationship_depends_on(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    package_id = data_dict.get('id')

    try:
        relationships_query = logic.get_action('package_relationships_list')(
            context,
            {'id': package_id})
    except logic.NotFound:
        return []

    depends_on = []

    for relationship in relationships_query:
        if relationship['type'] == 'depends_on':
            relationship_package_name = None
            relationship_object = relationship['object']

            try:
                relationship_package_name = ed_action.get_package_from_db(
                    name=relationship_object
                )

                depends_on.append(
                    {'text': relationship_package_name.get('title'),
                     'id': relationship_package_name.get('name')})
            except Exception as e:
                log.error('Error retrieving package {}: {}'.format(
                    relationship_object, e)
                )

    depends_on = _remove_private_relationships(depends_on)

    return json.dumps(depends_on) if depends_on else []


def get_relationship_derives_from(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    package_id = data_dict.get('id')
    derives_from = []
    if package_id and not data_dict.get('default'):
        try:
            relationships_query = logic.get_action('package_relationships_list')(
                context,
                {'id': package_id})
        except logic.NotFound:
            return []


        for relationship in relationships_query:
            if relationship['type'] == 'derives_from':
                relationship_package_name = None
                relationship_object = relationship['object']

                try:
                    relationship_package_name = ed_action.get_package_from_db(
                        name=relationship_object
                    )

                    derives_from.append(
                        {'text': relationship_package_name.get('title'),
                        'id': relationship_package_name.get('name')})
                except Exception as e:
                    log.error('Error retrieving package {}: {}'.format(
                        relationship_object, e)
                    )
    elif data_dict.get('relationship_derives_from', False):
        relationship_object = data_dict.get('relationship_derives_from')
        for relationship in relationship_object:
            try:
                relationship_package_name = ed_action.get_package_from_db(
                    name=relationship
                )

                derives_from.append(
                    {'text': relationship_package_name.get('title'),
                    'id': relationship_package_name.get('name')})
            except Exception as e:
                log.error('Error retrieving package {}: {}'.format(
                    relationship, e)
                )

    derives_from = _remove_private_relationships(derives_from)

    return json.dumps(derives_from) if derives_from else []


def get_relationship_has_derivation(data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    package_id = data_dict.get('id')

    try:
        relationships_query = logic.get_action('package_relationships_list')(
            context,
            {'id': package_id})
    except logic.NotFound:
        return []

    has_derivation = []

    for relationship in relationships_query:
        if relationship['type'] == 'has_derivation':
            relationship_package_name = None
            relationship_object = relationship['object']

            try:
                relationship_package_name = ed_action.get_package_from_db(
                    name=relationship_object
                )

                has_derivation.append(
                    {'text': relationship_package_name.get('title'),
                     'id': relationship_package_name.get('name')})
            except Exception as e:
                log.error('Error retrieving package {}: {}'.format(
                    relationship_object, e)
                )

    has_derivation = _remove_private_relationships(has_derivation)

    return json.dumps(has_derivation) if has_derivation else []


def _remove_private_relationships(relationships, hierarchy=False):
    user = c.user
    context = {
        'model': model, 'session': model.Session,
        'user': user, 'auth_user_obj': c.userobj
    }
    updated_relationships = relationships.copy()
    user_orgs = _get_action(
        'organization_list_for_user', context, {'user': user}
    )
    user_orgs = [org['name'] for org in user_orgs]

    if hierarchy is False:
        updated_relationships = [
            r for r in relationships
            if has_relationship_permissions(
                user, user_orgs, hierarchy=hierarchy,
                package_id=r.get('id')
            )
        ]
    else:
        updated_relationships = [
            r for r in relationships
            if has_relationship_permissions(
                user, user_orgs, hierarchy=hierarchy,
                object=r.get('object'), subject=r.get('subject')
            )
        ]

    return updated_relationships


def has_relationship_permissions(user, user_orgs, hierarchy=False,
                                 object=None, subject=None,
                                 package_id=None):
    is_user = user is not None and len(user) > 0
    is_private = None
    is_privileged = None

    if any(r for r in [object and subject, package_id]) is False:
        return False

    if hierarchy:
        if object and subject:
            object_dict = ed_action.get_package_from_db(id=object)
            subject_dict = ed_action.get_package_from_db(id=subject)

            if not object_dict or not subject_dict:
                object_dict = ed_action.get_package_from_db(name=object)
                subject_dict = ed_action.get_package_from_db(name=subject)

            if object_dict and subject_dict:
                is_private = object_dict.get('private', False) is True \
                    or subject_dict.get('private', False) is True
                is_privileged = (
                    object_dict.get('owner_org') in user_orgs
                    and subject_dict.get('owner_org') in user_orgs
                ) or (authz.is_sysadmin(user) is True)
        else:
            return False
    else:
        if package_id:
            pkg_dict = ed_action.get_package_from_db(id=package_id)

            if not pkg_dict:
                pkg_dict = ed_action.get_package_from_db(name=package_id)

            if pkg_dict:
                is_private = pkg_dict.get('private', False) is True
                is_privileged = pkg_dict.get('owner_org') in user_orgs \
                    or (authz.is_sysadmin(user) is True)
        else:
            return False

    if is_private is True and (is_privileged is False or is_user is False):
        return False
    else:
        return True


def convert_relationship_string_to_list(relationships):
    return json.loads(relationships)


def convert_copy_dict(copy_dict):
    return ast.literal_eval(copy_dict)


def update_copy_dict(copy_dict, data):
    relationship_choice = data.get('copy-relationship-choice')
    fields_choice = data.get('copy-fields-choice', [])

    if relationship_choice:
        if relationship_choice == 'SIBLING_OF':
            copy_dict['relationship_choice'] = \
                get_relationship_parent_identifiers(copy_dict)
        if relationship_choice == 'CHILD_OF':
            copy_dict['relationship_choice'] = json.dumps([
                {'text': copy_dict['title'], 'id': copy_dict['name']}
            ])

    if 'DATA_DICTIONARY' not in fields_choice:
        copy_dict['data_dictionary_pkg'] = ''
        copy_dict['data_dictionary_pkg_mimetype'] = ''
        copy_dict['data_dictionary_pkg_format'] = ''
        copy_dict['data_dictionary_pkg_res'] = ''
        copy_dict['data_dictionary_pkg_res_format'] = ''
        copy_dict['data_dictionary_pkg_res_file'] = ''

    if fields_choice:
        if not isinstance(fields_choice, list):
            fields_choice = [fields_choice]

        for choice in fields_choice:
            if choice == 'DERIVED_FROM':
                copy_dict['derived_from'] = \
                    get_relationship_derives_from(copy_dict)

            if choice == 'DEPENDENCIES':
                copy_dict['depends_on'] = \
                    get_relationship_dependencies_of(copy_dict)

    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    last_title = False
    current_title = copy_dict.get('title')
    split_title = current_title.split(' ')
    end_of_title = split_title[-1]
    title_number = end_of_title[1:-1] \
        if end_of_title[0] == '(' and end_of_title[-1] == ')' else ''
    title_number = None if not title_number.isdigit() else int(title_number)
    i = 1

    while not last_title:
        number = '({})'.format(i)

        if title_number:
            new_title = ' '.join(split_title[:-1]) + " {}".format(number)
        else:
            new_title = copy_dict.get('title') + " {}".format(number)

        munged_name = munge_title_to_name(new_title)

        fq_dict = {'fq': '+title:"{}"'.format(
            new_title)}
        package = logic.get_action('package_search')(
            context,
            fq_dict
        )

        name_fq_dict = {'fq': '+name:"{}"'.format(
            munged_name)}
        name_package = logic.get_action('package_search')(
            context,
            name_fq_dict
        )

        if len(package.get('results')) == 0 \
           and len(name_package.get('results')) == 0:
            last_title = True
            copy_dict['title'] = new_title
            copy_dict['source_name'] = copy_dict['name']
            copy_dict['name'] = munged_name

        i += 1

    copy_dict['relationships_as_subject'] = []
    copy_dict['relationships_as_object'] = []
    copy_dict['tag_string'] = ', '.join(
        tag['name'] for tag in copy_dict.get('tags', [])
        if tag['vocabulary_id'] is None
    )

    return copy_dict


def get_translated_from(data_dict):
    if 'translated_from' in data_dict:
        dd = json.loads(data_dict['translated_from'])
        view_url = '/dataset/{}/resources?resource={}'.format(dd['package_id'], dd['id'])
        name = dd['name']
        return name, view_url


def validate_survey_data(survey_results):
    log.info('Validating survey data...')
    is_valid = True
    expected_fields = [
        'package_id',
        'question_1',
        'question_2',
        'question_3'
    ]

    if not all(field in survey_results for field in expected_fields):
        is_valid = False

    return is_valid

def guess_mimetypes(url):
    guessed_types = mimetypes.guess_type(url)
    if guessed_types:
        return guessed_types[0]
    else:
        return ''

def get_program_codes():
    extension_path = os.path.dirname(__file__)
    program_codes_path = os.path.join(
        extension_path,
        'program_codes/program_codes.txt')
    program_codes = []

    try:
        with open(program_codes_path, 'r') as f:
            raw_program_codes = f.readlines()

            for program_code in raw_program_codes:
                program_codes.append(eval(program_code))
    except Exception as e:
        log.error('There was an error retrieving the program codes. '
                  'Please make sure that program_codes.txt exists. '
                  'Error: {}'.format(e))

    return program_codes


def get_data_qualities():
    return [
        {'text': 'False', 'value': False},
        {'text': 'True', 'value': True}
    ]


def get_harvested_data_quality(pkg_dict):
    for extra in pkg_dict.get('extras', []):
        key = extra.get('key')
        value = extra.get('value')
        if key == 'dataQuality':
            return True if value == 'true' else False
    return 'None'


def get_harvested_system_of_records(data):
    for extra in data.get('extras', []):
        key = extra.get('key')
        value = extra.get('value')

        if key == 'systemOfRecords':
            return value

    return


def get_primary_it_investment_uii(data):
    for extra in data.get('extras', []):
        key = extra.get('key')
        value = extra.get('value')

        if key == 'primaryITInvestmentUII':
            return value

    return

def bureau_code_auto_lookup(org_name):
    data_dict = {
        'id' : org_name
    }
    context = {'model': model, 'session': model.Session}
    result = logic.get_action('organization_show')(context, data_dict)
    
    extras = result.get('extras', [])
    for extra in extras:
        if extra.get('key', '') == 'bureau_code':
            bureau_code = extra.get('value')
            if bureau_code:
                return bureau_code
    
    groups = result.get('groups',[])
    if groups:
        parent = groups[0]
        parent_name = parent.get('name','')
        bureau_code = bureau_code_auto_lookup(parent_name)
        if bureau_code:
            return bureau_code

    return ''

def get_dataset_data(package_name):
    '''
    returns the package data

    :param package_id: str
        - the id or the name of the organization (publisher)
    :return: dict
    '''
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': package_name}
    package_dict = logic.get_action('package_show')(context, data_dict)

    try:
        return package_dict
    except:
        return None


def get_record_schedule():
    records = _get_action('get_record_schedule', {}, {})
    return json.loads(records)

def get_bureau_codes():
    extension_path = os.path.dirname(__file__)
    program_codes_path = os.path.join(
        extension_path,
        'bureau_codes/bureau_codes.json')
    try:
        with open(program_codes_path, 'r') as f:
            bureau_codes = json.loads(f.read())
    except Exception as e:
        log.error('There was an error retrieving the burea codes. '
                  'Please make sure that bureau_codes exists. '
                  'Error: {}'.format(e))

    bureau_codes = list(set(["{0}:{1}".format(bc['OMB Agency Code'],bc['OMB Bureau Code']) for bc in bureau_codes]))
    bureau_codes = [dict(name=i, value=i) for i in bureau_codes if i != "None:None"]
    bureau_codes = [dict(name='None', value='')] + sorted(bureau_codes, key=lambda k: k['name'])
    return bureau_codes


def group_tree(organizations=[], type_='organization'):
    full_tree_list = p.toolkit.get_action('group_tree')({}, {'type': type_})

    if not organizations:
        return full_tree_list
    else:
        filtered_tree_list = group_tree_filter(organizations, full_tree_list)
        return filtered_tree_list


def group_tree_filter(organizations, group_tree_list, highlight=False):
    # this method leaves only the sections of the tree corresponding to the
    # list since it was developed for the users, all children organizations
    # from the organizations in the list are included
    def traverse_select_highlighted(group_tree, selection=[], highlight=False):
        # add highlighted branches to the filtered tree
        if group_tree['highlighted']:
            # add to the selection and remove highlighting if necessary
            if highlight:
                selection += [group_tree]
            else:
                selection += group_tree_highlight([], [group_tree])
        else:
            # check if there is any highlighted child tree
            for child in group_tree.get('children', []):
                traverse_select_highlighted(child, selection)

    filtered_tree = []
    # first highlights all the organizations from the list in the three
    for group in group_tree_highlight(organizations, group_tree_list):
        traverse_select_highlighted(group, filtered_tree, highlight)

    return filtered_tree


def group_tree_section(id_, type_='organization', include_parents=True,
                       include_siblings=True):
    return p.toolkit.get_action('group_tree_section')(
        {'include_parents': include_parents,
         'include_siblings': include_siblings},
        {'id': id_, 'type': type_, })

def group_tree_parents(id_, type_='organization'):
    tree_node = p.toolkit.get_action('organization_show')({}, {'id': id_})
    if (tree_node['groups']):
        parent_id = tree_node['groups'][0]['name']
        parent_node = \
            p.toolkit.get_action('organization_show')({}, {'id': parent_id})
        return group_tree_parents(parent_id) + [parent_node]
    else:
        return []


def group_tree_get_longname(id_, default="", type_='organization'):
    tree_node = p.toolkit.get_action('organization_show')({}, {'id': id_})
    longname = tree_node.get("longname", default)
    if not longname:
        return default
    return longname


def group_tree_highlight(organizations, group_tree_list):
    def traverse_highlight(group_tree, name_list):
        if group_tree.get('name', "") in name_list:
            group_tree['highlighted'] = True
        else:
            group_tree['highlighted'] = False
        for child in group_tree.get('children', []):
            traverse_highlight(child, name_list)

    selected_names = [o.get('name', None) for o in organizations]

    for group in group_tree_list:
        traverse_highlight(group, selected_names)
    return group_tree_list

def get_allowable_parent_groups(group_id):
    if group_id:
        group = model.Group.get(group_id)
        allowable_parent_groups = \
            group.groups_allowed_to_be_its_parent(type='organization')
    else:
        allowable_parent_groups = model.Group.all(
            group_type='organization')
    return allowable_parent_groups


def is_include_children_selected(fields):
    include_children_selected = False
    if request.params.get('include_children'):
        include_children_selected = True
    return include_children_selected


def filter_out_bureaucode(data):
    for extra in data['extras']:
        if extra['key'] == 'bureau_code':
            return extra['value']

############ Sources Helpers ##############

SOURCE_TYPES = [
    {"name": "Information System"},
    {"name": "Information Collection Instrument"},
    {"name": "Computer Matching Agreement"},
    {"name": "Data Sharing Agreement"}
]

def get_source_types():
    return SOURCE_TYPES

def get_sources():
    context = {'model': model, 'session': model.Session}
    return  logic.get_action('group_list')(context, {'type': 'ed_source'})

def get_sources_list():
    sources = model.Group.all(group_type='ed_source')
    return sources

# get list of all sources
def sources():
    context = {'model': model, 'session': model.Session}
    return logic.get_action('group_list')(context, {
        'type': 'ed_source',
        'all_fields': True,
        'include_extras': True
    })


# get list of sources parents of collection
def source_parent(collection_id):
    context = {'model': model, 'session': model.Session}
    sources = logic.get_action('group_list')(context, {'type': 'ed_source'})
    collection_src = []

    for src in sources:
        source_info = logic.get_action('group_show')(context, {'id': src, 'include_groups': True})
        for s in source_info['groups']:
            if s['name'] == collection_id and s['name'] not in collection_src:
                collection_src.append(src)

    return collection_src

def get_source_by_name(name):
    for source in get_sources_list():
        if source.name == str(name):
            return source

def get_dataset_source(pkg_name):
    """
    Returns a list with the dataset source or an empty list \
    if the dataset has no source
    """
    if not pkg_name:
        return []

    context = {'model': model, 'session': model.Session}
    search_dict = {
        'q': pkg_name,
        'include_private' : True,
        'include_drafts' : True
    }
    sources = logic.get_action('package_search')(context, search_dict)['results']
    sources = [source for source in sources if source['name'] == pkg_name]

    if sources:
        s = [c['name'] for c in sources[0]['groups']]

        for name in s:
            group = get_group_dict({'id': name})
            group_type = group.get('type')

            if group_type == 'ed_source':
                return [name]
    return []

def get_source_resources_data(data):
    resources_list = []

    if data:
        context = {'model': model, 'session': model.Session}
        res_list = data.split(',')

        for id in res_list:
            try:
                resource = logic.get_action('resource_show')({}, {'id': id})
                resources_list.append({
                    'id': resource['id'],
                    'text': resource['name']
                })
            except logic.NotFound:
                log.error('Resource {} not found while preparing Source '
                          'resource list. Skipping...'.format(id))
        return json.dumps(resources_list)

def get_resource_source(id):
    if not id:
        return []

    all_sources = sources()
    for source in all_sources:
        if source.get('source_resources', None):
            if id in source['source_resources'].split(','):
                return [source['name']]

    return []

def remove_previous_resource_source(context, resource_id):
    """
    Checks if a resource already has an ed_source and removes the resource \
    from that ed_source if it does.
    """
    source_name = get_resource_source(resource_id)
    if source_name:
        # Get source_resources object for the source
        source_obj = logic.action.get.group_show(
            context, {'id': source_name[0]})
        old_res_list = source_obj['source_resources'].split(',')
        old_res_list.remove(resource_id)
        new_res_str = ','.join(map(str, old_res_list))

        # Remove the resource from that source
        logic.get_action('group_patch')(context, {
            'id': source_name[0],
            'source_resources': new_res_str
        })


def get_source_resources_data_list(data):
    resources_list = []

    if data:
        context = {'model': model, 'session': model.Session}
        res_list = data.split(',')

        for id in res_list:
            try:
                resource = logic.get_action('resource_show')({}, {'id': id})
                resources_list.append({
                    'id': resource['id'],
                    'name': resource['name'],
                    'format': resource['format'],
                    'description': resource['description'],
                    'package_id': resource['package_id']
                })
            except logic.NotFound:
                log.error('Resource {} not found while preparing Source '
                          'resource list. Skipping...'.format(id))
        return resources_list


def get_sysadmins():
    q = model.Session.query(model.User).filter(model.User.sysadmin == True,
                                               model.User.state == 'active')
    return q.all()


def get_data_explorers(include_all=False):
    context = {'model': model, 'session': model.Session}
    all_data_explorers = logic.get_action('group_list')(context, {
        'type': 'data_explorer',
        'all_fields': True,
        'include_extras': True
    })
    if include_all:
        return all_data_explorers
    else:
        return [de for de in all_data_explorers if de['approval_status'] == 'approved']


def get_group_activity_list(group_id):
    '''Return a group's activity stream
    '''
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': group_id, 'offset': 0}
    activity_stream = logic.get_action('group_activity_list')(context, data_dict)
    # It appears ckan will never return the full group object for this as the
    # 'include_data' dict attribute is manually set to False, so we are calling
    # group_show here.
    # https://github.com/ckan/ckan/blob/ckan-2.9.4/ckan/logic/action/get.py#L2585
    group_show = logic.get_action('group_show')
    group = group_show(context, data_dict)
    for activity in activity_stream:
        activity['data']['group'] = group

    return activity_stream

def get_resource_data(resource_id):
    context = {
        'model': model, 
        'session': model.Session, 
        'ignore_auth': True
    }
    data_dict = {
        'id': resource_id,
    }
    resource = {}
    try:
        resource = logic.get_action('resource_show')({}, data_dict)
    except (logic.NotFound, logic.NotAuthorized):
        log.error('Resource {} not found or user is not authorized '
                  'to view it. Skipping...'.format(id))
    return resource

def get_package_data(id):
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': id}

    return logic.get_action('package_show')(context, data_dict)


def filter_activity_stream(activity_stream):
    user = c.user
    is_sysadmin = c.userobj.sysadmin if c.userobj else False
    context = {
        'model': model, 'session': model.Session,
        'user': user, 'auth_user_obj': c.userobj
    }

    filtered_activity_stream = []

    if is_sysadmin:
        return activity_stream

    for activity in activity_stream:
        if 'package' in activity.get('activity_type'):
            try:
                logic.check_access('package_show', context, {'id': activity['object_id']})
                filtered_activity_stream.append(activity)
            except (logic.NotAuthorized, logic.NotFound):
                continue
        elif 'organization' in activity.get('activity_type'):
            try:
                logic.check_access('organization_show', context, {'id': activity['object_id']})
                filtered_activity_stream.append(activity)
            except (logic.NotAuthorized, logic.NotFound):
                continue
        elif 'resource' in activity.get('activity_type'):
            try:
                logic.check_access('resource_show', context, {'id': activity['object_id']})
                filtered_activity_stream.append(activity)
            except (logic.NotAuthorized, logic.NotFound):
                continue
        elif 'group' in activity.get('activity_type'):
            try:
                logic.check_access('group_show', context, {'id': activity['object_id']})
                filtered_activity_stream.append(activity)
            except (logic.NotAuthorized, logic.NotFound):
                continue
        else:
            filtered_activity_stream.append(activity)

    return filtered_activity_stream


def get_announcement_values(is_announcement=True):
    connection = model.Session.connection()
    sql = """SELECT "value" FROM system_info WHERE "key" = '__extras' AND
        "state" = 'active';"""
    announcement_popup = 'Disabled'
    announcement_text = ''

    try:
        system_info = [dict(d) for d in connection.execute(sql)]

        if len(system_info) >= 1:
            system_info = system_info[0].get('value')

            if system_info is not None:
                system_info = ast.literal_eval(system_info)
                
                if is_announcement:
                    return system_info.get(
                        'ckan.announcement_popup', announcement_popup
                    ), system_info.get('ckan.announcement_text', announcement_text)
                else:
                    return system_info.get(
                        'ckan.footer_popup', announcement_popup
                    ), system_info.get('ckan.footer_text', announcement_text)

        return announcement_popup, announcement_text

    except Exception as e:
        log.error('Error retrieving the announcement values from the DB: {}'
                  .format(e))
        return announcement_popup, announcement_text


def get_child_package(childs, rtype):
    data = []
    context = {'model': model, 'session': model.Session}

    for child in childs:
        id = child['object']
        pkg = logic.get_action('package_show')(context, {'id': id})
        data.append(pkg)
    if rtype == "json":
        return json.dumps(data)

    return data


def get_roles(user):
    context = {'model': model, 'session': model.Session}
    orgs = logic.get_action('organization_list_for_user')(
        context, {'id': user}
    )
    org_roles = OrderedDict()

    for org in orgs:
        org_title = org.get('title')
        org_name = org.get('name')
        org_role = org.get('capacity')

        if org_role is None:
            log.error('Capacity missing for org: {}'.format(org))
        else:
            org_roles.update({
                org_name: {
                    'title': org_title, 'capacity': org_role
                }
            })

    return org_roles


def get_orgs_with_roles(user, orgs):
    org_roles = get_roles(user)
    updated_orgs = []

    for org in orgs:
        org_name = org['name']
        org_role = org_roles.get(org_name)

        if org_role:
            org['capacity'] = org_role['capacity']

        updated_orgs.append(org)

    return updated_orgs

def check_order(list_dict):
    orders = any([k['order'] for k in list_dict])

    if orders:
        order_list = [k for k in list_dict if k['order']]
        order_dict = sorted(order_list, key=lambda k: k['order'])
        objects = [k['object'] for k in order_dict]
        asc_dict = sorted(order_dict, key=lambda k: k['object'])
        asc_objects = [k['object'] for k in asc_dict]
        same_order = sum(k1 == k2 for (k1, k2) in zip(objects, asc_objects)) 
        if same_order == len(order_list):
            return "asc"
        
        desc_dict = sorted(order_list, key=lambda k: k['object'], reverse=True)
        desc_objects = [k['object'] for k in desc_dict]
        same_order = sum(k1 == k2 for (k1, k2) in zip(objects, desc_objects)) 
        if same_order == len(order_list):
            return "desc"

        return 'custom'
    else:
        return 'asc'

def render_markdown(data, auto_link=True, allow_html=False):
    ''' Returns the data as rendered markdown

    :param auto_link: Should ckan specific links be created e.g. `group:xxx`
    :type auto_link: bool
    :param allow_html: If True then html entities in the markdown data.
        This is dangerous if users have added malicious content.
        If False all html tags are removed.
    :type allow_html: bool
    '''
    if not data:
        return ''
    if allow_html:
        data = h.markdown(data.strip(), extensions=['toc'])
    else:
        data = h.RE_MD_HTML_TAGS.sub('', data.strip())
        # Allow header ids
        allowed_headers = {
            'h1': ['id'], 'h2': ['id'], 'h3': ['id'], 'h4': ['id'], 'h5': ['id'], 'h6': ['id'] 
        }
        h.MARKDOWN_ATTRIBUTES.update(allowed_headers)
        h.MARKDOWN_TAGS.update(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        data = h.bleach_clean(
            h.markdown(data, extensions=['toc']), strip=True,
            tags=h.MARKDOWN_TAGS, attributes=h.MARKDOWN_ATTRIBUTES)
    # tags can be added by tag:... or tag:"...." and a link will be made
    # from it
    if auto_link:
        data = h.html_auto_link(data)
    return h.literal(data)

def get_user_by_id(user_id):
    '''
    Takes the user id and returns the user dict
    '''
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': user_id}
    return logic.get_action('user_show')(context, data_dict)

def get_organization_editors(organization_id, admin_only=False):
    '''
    Returns all users with editor level permission within an organization.

    admin_only: boolean
        optional config to return only sysadmins or admins of the organiation
    '''
    context = {'model': model, 'session': model.Session}
    data_dict = {'id': organization_id, 'object_type': 'user'}
    all_users = logic.get_action('user_list')(context, {})
    org_members = logic.get_action('member_list')(context, data_dict)
    editors = []
    if admin_only:
        allowed_roles = ['Admin']
    else:
        allowed_roles = ['Admin', 'Editor']
    for member in org_members:
        if member[2] in allowed_roles:
            editors.append(member[0])

    checked_users = []
    for user in all_users:
        if user['sysadmin'] or user['id'] in editors:
            checked_users.append(user)
    return checked_users

def get_users_with_ownership_permission(package_id):
    """
    Takes a package_id and returns a list of users who have permission to own \
    the package.
    """
    checked_users = []
    context = {'model': model, 'session': model.Session}

    all_users = toolkit.get_action('user_list')(context, {})
    for user in all_users:
        context['user'] = user['id']
        try:
            logic.check_access('package_update', context, {'id': package_id})
            checked_users.append(user)
        except logic.NotAuthorized:
            pass

    return checked_users

def get_group_owner(group_id):
    """
    Returns the user dict for the current admin of a group type
    """
    context = {'model': model, 'session': model.Session, 'user': c.user}
    user_list = get_organization_editors(group_id, admin_only=True)

    data_dict = {
        'id': group_id,
        'include_datasets': False,
        'include_users': True
    }
    c.group_dict = logic.get_action('group_show')(context, data_dict)

    if c.group_dict['is_organization']:
        return None

    for m in c.group_dict['users']:
        for u in user_list:
            if m['name'] == u['name']:
                return u

    return None

def get_all_users():
    """
    Returns all users on the platform
    """
    context = {'model': model, 'session': model.Session}
    return toolkit.get_action('user_list')(context, {})

def get_all_admins(return_orgs=False):
    """
    Returns all users listed as an admin in any organizations. This doesn't \
    return sysadmins with admin permissions but not listed as a member of the \
    organization.

    return_orgs: bool
        if true, this returns a dict where the keys are user ids and the \
        values are organizations they are listed as admins in
    """
    context = {'model': model, 'session': model.Session, 'user': c.user}
    all_orgs = logic.get_action('organization_list')(context, {})
    admins = []
    admin_orgs = {}
    for org_id in all_orgs:
        org_members = logic.get_action('member_list')(context,
            {'id': org_id, 'object_type': 'user'})
        for member in org_members:
            if member[2] == 'Admin':
                if admin_orgs.get(member[0], None):
                    admin_orgs[member[0]].append(org_id)
                else:
                    admin_orgs[member[0]] = [org_id]
                if member[0] not in admins:
                    admins.append(member[0])
                
    admin_dicts = []
    for user_id in admins:
        admin_dicts.append(get_user_by_id(user_id))
    if return_orgs:
        return admin_orgs
    return admin_dicts

def get_admin_users_orgs(as_string=False):
    """
    Returns a dictionary with the key being a user's id and the value a \
    list contianing dictionary objects of all the rganizations `name`, `id`, \
    and `title` that the user is lsted as an admin of.
    """
    admin_orgs = {}
    context = {'model': model, 'session': model.Session, 'user': c.user}
    admin_orgs = get_all_admins(return_orgs=True)
    for user_id, orgs in admin_orgs.items():
        orgs_list = []
        for org_id in orgs:
            org_dict = logic.get_action('organization_show')(context, {'id': org_id})
            orgs_list.append({
                'id': org_dict['id'], 
                'name': org_dict['name'], 
                'title': org_dict['title']
            })
        admin_orgs[user_id] = orgs_list
    
    if as_string:
        return json.dumps(admin_orgs)
    return admin_orgs

def get_all_other_users(user_dict=None):
    user_list = [{'id': 'NONE_SELECTED', 'display_name': 'Select new owner...'}]

    try:
        users = get_all_users()

        if user_dict is not None:
            user_list += [u for u in users if u['name'] != user_dict['name']]

        return user_list
    except Exception as e:
        log.error(e)
        return user_list

def get_all_user_groups(user_id):
    context = {
        'ignore_auth': True
    }
    group_types = [
        'organization',
        'collection',
        'ed_source',
        'data_explorer',
        'group'
    ]

    all_groups = []

    for group_type in group_types:
        if group_type != 'organization':
            list_action = 'group_list'
            show_action = 'group_show'
            show_dict = {'type': group_type}
        else:
            list_action = 'organization_list'
            show_action = 'organization_show'
            show_dict = {}

        groups = _get_action(
            list_action, context, show_dict
        )

        for group in groups:
            try:
                group_members = _get_action(
                    'member_list', context,
                    {'id': group, 'object_type': 'user'}
                )
                if isinstance(group_members, list):
                    if len(group_members) > 0:
                        for member in group_members:
                            member_id = member[0]

                            if member_id == user_id:
                                group_dict = _get_action(
                                    show_action, context, {'id': group}
                                )
                                all_groups += [group_dict]
            except logic.NotFound:
                log.error(
                    'Unable to retrieve member list and dict for group: {}'
                    .format(group)
                )

    return all_groups


def get_group_dict(group_dict):
    context = {'model': model, 'session': model.Session}
    new_dict = {}

    try:
        new_dict = _get_action('group_show', context, group_dict)
    except Exception as e:
        log.info(
            'Unable to retrieve group dict for {}: {}'
            .format(group_dict.get('id'), e)
        )

    return new_dict

def filter_file(url):
    format = url

    try:
        format = url.split("/")[-1].split(".")[1]
    except IndexError as e:
        log.warn('Unable to convert URL to name: {}'.format(format))
        log.error(e)

    formats = ["xls", "xlsx", "csv"]

    return format.lower() in formats

def is_coordinator(user=None, organization=None, user_id=None, org_id=None):
    if user_id:
        try:
            user_dict = toolkit.get_action('user_show')(
                {'ignore_auth': True},
                {'id': user_id}
            )
            user = user_dict['name']
        except logic.NotFound:
            log.error('User not found: {}'.format(user_id))
            return False
    if org_id:
        try:
            organization = toolkit.get_action('organization_show')(
                {'ignore_auth': True},
                {'id': org_id}
            )
            organization = organization['name']
        except logic.NotFound:
            log.error('Organization not found: {}'.format(org_id))
            return False

    return ed_model.is_coordinator(user, organization)

def get_coordinator_orgs(user):
    return ed_model.get_coordinator_orgs(user)

def get_private_packages(user, organizations):
    fq = ''
    fq += ' +private:true'
    fq += ' -indraft:true'

    search_dict = {
        'type' : 'dataset',
        'fq': fq,
        'rows': 1000,
        'include_private' : True
    }

    private_packages = toolkit.get_action('package_search')(
        {'ignore_auth': True, 'ignore_capacity_check': True},
        search_dict
    )

    private_packages['results'] = [
        p for p in private_packages['results']
        if (p.get('organization', {}).get('name') in organizations or c.userobj.sysadmin)
        and p.get('private') is True and p.get('indraft') in [False, 'false']
    ]

    return private_packages.get('results', [])

def get_draft_packages(user, organizations):
    fq = ''
    fq += ' +indraft:true'

    search_dict = {
        'type' : 'dataset',
        'fq': fq,
        'rows': 1000,
        'include_private' : True
    }

    draft_packages = toolkit.get_action('package_search')(
        {'ignore_auth': True, 'ignore_capacity_check': True},
        search_dict
    )

    draft_packages['results'] = [
        p for p in draft_packages['results']
        if p.get('organization', {}).get('name') in organizations
    ]

    return draft_packages.get('results', [])

def get_notf_preferences(user_id=None):
    if user_id:
        try:
            user_dict = toolkit.get_action('user_show')(
                {'ignore_auth': True},
                {'id': user_id}
            )
        except logic.NotFound:
            log.error('User not found: {}'.format(user_id))
            return []

    return ed_model.get_notf_preferences(user_id)

def get_notf_preference(preference, user_id=None):
    if user_id:
        try:
            toolkit.get_action('user_show')(
                {'ignore_auth': True},
                {'id': user_id}
            )
        except logic.NotFound:
            log.error('User not found: {}'.format(user_id))
            return False

    return ed_model.get_notf_preference(preference, user_id)

def is_in_plugins(plugin_name):
    return plugin_name in config.get('ckan.plugins', '').split()
