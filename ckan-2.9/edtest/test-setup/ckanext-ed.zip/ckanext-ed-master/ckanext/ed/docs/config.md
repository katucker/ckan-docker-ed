# ED specific CKAN configuration options

## Allow specific offices to create resources with links

As per specifications of the ODP, resources created manually by the data
stewards should be uploads, and not links to remote files.

However, some exceptions were made from this rule, that are kept configurable so
they can be adjusted via CKAN configuration.

This option (with a sample value) ensures that the datasets belonging to CKAN
organizations in that list can have link type resources:

```
ckanext.ed.publishers_allowed_linking_res=nces,fsa,octae
```

The value needed is a comma separated list of organization names or IDs.


## Robots meta tag value

The main template has the tags `<meta name="robots">` and `<meta name="description">`, and their values are being used
by search engine in the crawling and parsing process (description will sometimes be shown as the description in the search result snippet). The values of these tags are
configurable with INI options as well:

```
ckanext.ed.robots_tag_text = Here are the contents of the robots meta tag
ckanext.ed.meta_description_text = A description of the site, e.g. The Open Data Platform is for browsing Data Profiles from the U.S. Department of Education
```

For more information on usage and acceptable values for `robots_tag_text`, see [robots meta tag](https://developers.google.com/search/docs/advanced/robots/robots_meta_tag#directives)

## Hiding / displaying template elements

Some template elements have a on/off switch triggered by CKAN configuration options:

```
ckanext.ed.announcement_banner=True
```

The Announcement **banner** at the bottom of the page is also controlled by the corresponding options in this file.
The information to be contained in the announcement banner should be set in the [templates/footer.html file](../templates/footer.html)

**Note**: This is not the Announcement **popup**. The Announcement popup has its own config options available in the UI, in the admin "Config" options found at https://`PORTAL_DOMAIN`/`ADMIN_USERNAME`/config.

## Approval Workflow email notifications

Email notifications sent by the approval workflow have a on/off switch triggered by:

```
ckanext.ed.approval_email_notifications=True
```

Setting this config variable to True will:

* send email to all sysadmin user when a Data Explorer is submitted for review
* send email to the user who created a Data Explorer when the Data Explorer is approved
* send email with a feedback to the user who created a Data Explorer when the Data Explorer is rejected 

## Resource Translation email notifications

Email notifications sent by the resource translation plugin have a on/off switch triggered by:

```
ckanext.ed.resource_translate_email_notifications=True
```

Setting this config variable to True will send an email when a translation for a resource is done.

## Enable Universal Federated Analytics

Universal Federated Analytics can be enabled by setting this configuration variable to `True`. If the variable is omitted from the configuration file, nothing will be tracked.

```
ckanext.ed.enable_ufa_analytics=True
```

## Enabling survey and feedback email notifications

These config options enable a survey to track whether data has been found useful or not by public users. The survey allows the user to provide feedback if they find it to not be useful. Survey results will only be displayed after taking the survey if the survey has been taken **3 or more times**. 

There are multiple config options for the survey. The first enables the survey itself:

```
ckanext.ed.enable_survey=true
```

The second enables email notifications for feedback from the survey:

```
ckanext.ed.survey_email_notifications=true
```

The third and final option sets the recipient email address for the feedback (**Note**: There is no default value for this option, so if this isn't set, no emails will be sent):

```
ckanext.ed.survey_feedback_email_recipient=odp@ed.gov
```

## Updating the link to the "How do I use the Open Data Platform?" page

On the FAQ page, there's a link, "How do I use the Open Data Platform". This link is configurable. To redirect to a page created with `ckanext-pages`, you only need the path. For example, let's say you've created a new page and its URL is https://data.ed.gov/pages/how-to, you only need to set this variable to `pages/how-to`:

```
ckanext.ed.help_page=pages/how-to
```

## Enabling Ed Sources

By default, Ed Sources are disabled (this will be changed in the future). You can enable them by setting this variable to `true`:

```
ckanext.ed.enable_ed_sources=true
```

## Setting the URL for the OMB Inventory Report

This variable is used to set the URL for the `omb-to-sources` `ckan` command. Rather than hard-coding the current URL, it's better to use a variable in case the URL changes later.

```
ckanext.ed.omb_inventory_url=URL_TO_OMB_XML
```

## Setting the URL for the Records Schedules

This variable is used to set the URL for the `populate-recordsdb` `ckan` command. Rather than hard-coding the current URL, it's better to use a variable in case the URL changes later.

```
ckanext.ed.record_schedule_url=https://connected.ed.gov/OCIO/imb/SitePages/Department%20of%20Education%20Retention%20Policies.aspx
```

# CKAN core configuration options

## Enabling full organization list output in API calls

CKAN 2.8.7+ introduced a new environment variable to limit the output of `organization_list` when passing the variable `all_fields=True`. As implemented, it defaults to `25` organizations. The comment in the the code mentions loading speed issues with large amounts of organizations as the reason for the implementation. `ckanext-ed` uses `all_fields=True` in many locations, so we need to increase the default or else we won't have the full list of organizations in the Data Profile form, on the Organization list page, and via the API.

**Note**: The highest value allowed is `1000`.

```
ckan.group_and_organization_list_all_fields_max = 1000
```

## Numbers of days to send approval email for stuck Data profile in approval workflow

```
ckanext.ed.stuck_dp_days = 5
```
