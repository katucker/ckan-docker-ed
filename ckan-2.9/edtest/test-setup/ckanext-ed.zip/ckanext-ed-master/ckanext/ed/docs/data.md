# US ED Scraping data.json DCAT variation

In order to accomodate a number of missing fields needed by the ODP, we had to
fork the DCAT data.json schema and add a few extra items for the scraping
output, harvested by a custom made harvester type bundled with the extension.

More info here: https://github.com/CivicActions/edscrapers
