# ED specific `ckan` CLI commands

## Download and revert download of linked resources

Note: Deprecated command. It should be removed in future realeases.
Use the `download_resources` script instead.

In the harvesting process we have set up, all resources (DCAT "distribution"
key) are links to remote files, as they were collected during the scraping
process. While this is outsourcing the responsibility for the file contents and
availability to their respective publishers, it also cannot ensure the file
stays online for its users indefinitely. For this we have designed a command that 
follows all links and transforms the resources from links into CKAN hosted files.

The process simulates a regular file upload, so if any third party storage extension 
is configured (e.g. `s3filestore`), it will follow its implementation as it normally 
would on a form based upload.

There is also a reverse operation possible. During the transformation above, the original 
URL to the file is retained, so we can always automate the deletion of files and reverting 
to the linked resources.

The command has the following synopsis:

```
ckan -c ckan.ini edcli download-resources <TYPE> <NAME> [restore]
```

The `TYPE` argument can be either `harvester` or `publisher`:

- **harvester** type selects all resources belonging to datasets harvested from
  the mentioned harvest source
- **publisher** means that the resources are selected based on the `owner_org`
  attribute of all datasets, thus downloading the resources for all datasets
  belonging to the mentioned publisher name
  
The `NAME` argument is the selector for the selected `TYPE`. This could be
either a `name` or an `id` of a harvest source or publisher.

The optional argument `restore` triggers the reverse operation of deleting the
downloaded files and reinstating them as links.

In the event of a downloadable link being broken (404 or other HTTP error
statuses) or being redirected away to a HTML page, the file in cause is skipped
and will not be processed. If you want to retry, simply fire the script again
and all skipped resources will be attempted download again.

## Fix broken extras for datasets

A bug that occurred multiple times prevented the `package_update` action from
preserving the extras defined for a package. The worst side effect of this was
breaking the link between harvest sources and harvested records, so in the event 
of a reharvest, the now unlinked datasets would've been duplicated.

The `fix_extras` command is identifying the broken datasets and re-adding the 
`harvest_object_id` and `harvest_source_id` references where missing in package 
extras.

Synopsis:

```
ckan -c ckan.ini edcli fix-extras
```

## Seed the database

The initial population of the database is managed through a seeding command, 
reading from a JSON file with values provided by U.S. Dept. of Ed.

There are four different seed sources: groups, organizations, tags and data explores.

The command is used as follows:

```
# To create all the tag vocabularies (e.g. spatial, level of data):
ckan -c ckan.ini edcli ed create_ed_vocabularies

# To create all the ED categories (CKAN groups)
ckan -c ckan.ini edcli ed create_ed_groups 

# To create all the ED Publishers (CKAN organizations)
ckan -c ckan.ini edcli ed create_ed_organizations

# To create all the ED Data Explorers (CKAN groups)
ckan -c ckan.ini edcli ed create_ed_data_explorers
```

## Create the survey tables

Survey tables **must** be created before using the survey.

```
ckan -c ckan.ini edcli init-survey-db
```

## Send reports about broken links

A report containing information about resources with broken links can be sent to Organization admins and editors using this command.

```
ckan -c ckan.ini edcli broken-links-report
```

Each email contains information about one Organization. If the user is an administrator or editor of more than one organization, an email per Organization is sent to this user.

## Create and Populate `record_schedule` Table

To create a `record_schedule` Table

```
ckan -c ckan.ini edcli init-record-schedule
```

To populate the table with the crawled data 

```
ckan -c ckan.ini edcli populate-recordsdb
```

## Add Order column to package_relationship table

To add `order` column to `package_relationship` table

```
ckan -c ckan.ini edcli level-column
```

## Retrieve OMB control numbers and create their Sources

The following command parses the OMB Inventory Report XML file and creates Sources for each number. This is meant to be run as a **cron job or systemd timer**. Once scheduled, it will parse the Inventory file for any new OMB numbers and create their Sources.

```
ckan -c ckan.ini edcli omb-to-sources
```

**Note**: The URL for the Inventory Report isn't hard-coded. It's set in the `.ini` file with: `ckanext.ed.omb_inventory_url=URL_TO_OMB_XML`.


## Mail Admin/Co-ordinators about Dataset stuck in approval workflow

set config to numbers of days

```
ckanext.ed.stuck_dp_days = 5
```

Run commnad 
```
ckan -c ckan.ini edcli stuck-dp
```

## Initialize the Coordinator roles DB table

Coordinator roles require a custom table in the DB. To initialize it, run the following command (this is only required once):

```
ckan -c ckan.ini edcli init-coordinators
```

## Fix revision purging errors

If there's data in the `_revision` tables, purging Data Profiles, Organizations, or Groups will fail. This table is deprecated and is supposed to be cleaned/removed by a CKAN DB upgrade, but in some cases, data can remain. This command will remove all rows in these tables. This will **not** remove any current/active data—only the unused revision data is stored in these tables.

```
ckan -c ckan.ini edcli clean-revisions
```

## Initialize the notification preferences DB table

Notification preferences require a custom table in the DB. To initialize it, run the following command (this is only required once):

```
ckan -c ckan.ini edcli init-notf-preferences
```

## Intialize user data profile default field DB table

This commands create a table to save users and their default data profile (this is only required once)

```
ckan -c ckan.ini edcli add-user-package-fields
```

## List routes that are accessible from the browser

This commands prints a list of all routes that can be accessed from a browser

```
ckan -c ckan.ini edcli list-pages
```