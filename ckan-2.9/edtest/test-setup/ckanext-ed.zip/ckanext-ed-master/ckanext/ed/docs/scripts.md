# ckanext-ed misc tools

In addition to an integrated CKAN tooling, there are also a few utility scripts
shipped with the extension, having their own `requirements.txt` file and using
the CKAN public API instead of internal function calls. These scripts were testing using Python 3, and some of them won't work on Python 2.

## Create / Update publishers

This script uses the CKAN API to create or update Organizations based on JSON file entries. It can be used to populate or update the Organization list. The script should be used carefully because it could change the current Organization Hierarchy.

```
python create_update_publishers.py
```

Prior to running any of the above script, a few environment variables are required:

| Variable name  | Sample value                         | Default value | Effect                                                                                                                                                                                                                                               |
| -------------- | ------------------------------------ | ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ED_CKAN_URL`  | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API                                                                                                                                                                                                                    |
| `ED_CKAN_KEY`  | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target                                                                                                                                                                                                                    |
| `ED_SEEDS_DIR` | `ckanext-ed/ckanext/ed/seeds/`       | `None`        | Directory containing json files that can be used to populate the Organization list. This directory should contain an structure similar to: `/organizations/*.json`. Example: https://github.com/CivicActions/ckanext-ed/tree/master/ckanext/ed/seeds |

## Delete / hide all datasets belonging to a publisher

This script uses the CKAN API to select and delete or hide all datasets that
belong to a publisher. For example, if during testing there was a "test"
organization created, which then had a few datasets created for it, this script
can be used to delete all of them in order to clean up the database:

```
python delete_publisher_datasets.py
```

If hiding them is preferred instead, this script will flip the value of the `private` property to `True` or `False`, based on an environment variable:

```
python publisher_datasets_visibility.py
```

Prior to running any of the above scripts, a few environment variables control
its options:

| Variable name                | Sample value                         | Default value | Effect                                                                          |
| ---------------------------- | ------------------------------------ | ------------- | ------------------------------------------------------------------------------- |
| `ED_CKAN_URL`                | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API                                               |
| `ED_CKAN_KEY`                | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target                                               |
| `ED_CKAN_ORG_ID`             | `fsa`                                | `None`        | CKAN organization filter for `package_search` used to select datasets to delete |
| `ED_CKAN_DATASET_VISIBILITY` | `public`                             | `None`        | Visibility state to update the data profiles                                    |

## Export datasets metadata to XLSX files

Calling this script will create an output XLSX file per selected publisher, or one for each existing publisher if nothing is explicitly selected.

Export is by default "slim", containing only:

- Title
- Categories list
- URL
- Publisher ID

If all fields are selected for export, these additional columns will appear in the XLSX output:

- `license`
- `tags`
- `description`
- `program_code`
- `level_of_data`
- `update_frequency`
- `helpdesk_phone`
- `helpdesk_email`
- `steward_name`
- `steward_email`
- `access_level`
- `spatial`
- `start_date`
- `end_date`
- `uuid`
- `source_url`

As for the other utilities, a few environment variables govern over the behaviour of the script:

| Variable name           | Sample value                         | Default value                 | Effect                                                                 |
| ----------------------- | ------------------------------------ | ----------------------------- | ---------------------------------------------------------------------- |
| `ED_CKAN_URL`           | https://us-ed-testing.ckan.io        | https://us-ed-testing.ckan.io | URL of the target CKAN public API                                      |
| `ED_CKAN_KEY`           | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`                        | CKAN API key for the above target                                      |
| `ED_CKAN_XLSX`          | `/path/to/output.xlsx`               | `output.xlsx`                 | Path to output XLSX file                                               |
| `XLS_EXPORT_ORGS`       | `fsa,ocr`                            | `None`                        | Comma separated list of publisher names or IDs to export datasets for  |
| `XLS_EXPORT_ALL_FIELDS` | `True`                               | `False`                       | Whether or not to export all metadata fields for the selected datasets |

## Migrate level of data to the new format (deprecated)

In the earlier days (and versions) of the project, the `level_of_data` information was recorded in a CSV field in `extras`. Its implementation was changed to a tag vocabulary lookup later on, so a script migrating all the old values already entered was needed to preserve the data.

The following script fixes the `level_of_data` values entered before version `1.4.4`:

```
python migrate_level_of_data.py
```

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

## Update Helpdesk email metadata field

This script changes the Helpdesk Email field to 'odp@ed.gov' for all the data profiles that have the field with an empty value.

```
python fill_helpdesk_email_fields.py
```

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

## Translate XLSX to CSV

The `xlsx2csv_cli.py` script handles translation of simple (one shee well formed) excel files into CSV.
It is intended as a first step towards a more complex format translatio on specific cases.

Below we have some examples on

### Help

```
python xlsx2csv_cli.py --help
```

### converting one XLSX resource into CSV

```
python ckanext/ed/scripts/xlsx2csv_cli.py --id d8084af2-6ba1-44af-9bbd-2158c6c5f9e6
```

This will output two files, the `.csv` file contains the translation and the `metadata.json` contains the metadata of the translated resource:

```console
    kyepd.csv
    kyepd.metadata.json
```

There is also the possibility to pass a file as input with the resource ids, one per line. In this case the script will translate all of the available files.

```
python ckanext/ed/scripts/xlsx2csv_cli.py -f M_FILE_WITH_RESOURCE_ID_LIST
```

An output folder can be given (it must exist) where all the translated files will be saved.

```
python ckanext/ed/scripts/xlsx2csv_cli.py -f M_FILE_WITH_RESOURCE_ID_LIST -o OUTPUT_FOLDER
```

It's also possible to translate resources in a batch process. In this case, new resources will be created under the same Data Profile as the original resources.

```
python ckanext/ed/scripts/xlsx2csv_cli.py -a
```

A timeout value for each translation thread can be passed by the `-t` parameter:

```
python ckanext/ed/scripts/xlsx2csv_cli.py -a -t 500
```

To list all XLSX resources available in the OPD we can call:

```
python ckanext/ed/scripts/xlsx2csv_cli.py -l
```

Some environment values should be created to use this script:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

## Export all resource urls to CSV file

This script exports all resource names and urls to a CSV file. The CKAN host is identified by the environment variable `ED_CKAN_URL`. If `ED_CKAN_KEY` is present, the script will write all the resources to the CSV file, including private. If `ED_CKAN_KEY` is not present, the script will write only public resources to the CSV file.

```
python export_resources_to_csv.py
```

Some environment values should be created to use this script:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

## Download linked resources

In the harvesting process we have set up, all resources (DCAT "distribution"
key) are links to remote files, as they were collected during the scraping
process. While this is outsourcing the responsibility for the file contents and
availability to their respective publishers, it also cannot ensure the file
stays online for its users indefinitely. For this we have designed a command that
follows all links and transforms the resources from links into CKAN hosted files.

The process simulates a regular file upload, so if any third party storage extension
is configured (e.g. `s3filestore`), it will follow its implementation as it normally
would on a form based upload.

```
python download_resources.py <TYPE> <NAME>
```

The `TYPE` argument can be either `harvester`, `publisher`, or `id`:

- **harvester** type selects all resources belonging to datasets harvested from
  the mentioned harvest source
- **publisher** means that the resources are selected based on the `owner_org`
  attribute of all datasets, thus downloading the resources for all datasets
  belonging to the mentioned publisher name
- **id** requires the path to a file containing a list of Data Profile or Documentation names/ids (one per line) as an argument

The `NAME` argument is the selector for the selected `TYPE`. This could be
either a `name` or an `id` of a harvest source or publisher.

In the event of a downloadable link being broken (404 or other HTTP error
statuses) or being redirected away to a HTML page, the file in cause is skipped
and will not be processed. If you want to retry, simply fire the script again
and all skipped resources will be attempted download again.

Some environment values should be created to use this script:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Change owner organization of data profiles

During the harvesting process of the data.json files, some duplicated Organizations can be created due to some typo or small differences in the Organization titles, as the use of abbreviations.

Duplicated publishers can be removed by:

- 1. moving all datasets from the duplicated organization to the right organization
- 2. Delete the duplicated organization (described in the next section)

The described script performs the first task listed above, and it can be used in two different ways:

- move all datasets from the FROM_OWNER_ORG to TO_OWNER_ORG. The parameters passed to the interpreter are the names of the corresponding organizations

```
python change_datasets_owner_org.py <FROM_OWNER_ORG> <TO_OWNER_ORG>
```

- move all datasets from all the instances FROM_OWNER_ORG to TO_OWNER_ORG listed in the rows of a CSV file passed by a parameter

```
python change_datasets_owner_org.py -f <FILE_PATH>
```

An example of the CSV file referenced above is showed below:

```
acsfa,nceera
octae,oii
```

In this example, all the datasets belonging to `acsfa` will be moved to the `nceera` organization. And then, all the datasets belonging to `octae` will be moved to the `oii` organization.

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Delete Organization

We provided a script to automate the process of deleting Organizations. This script is useful when you have a list of organizations to delete. A scenario where a list of organizations should be deleted is described in the former section.

The described script can be used in two different ways:

```
python delete_org.py <ORG_NAME>
```

It deletes the organization corresponding to the name passed as a parameter.

```
python delete_org.py -f <FILE_PATH>
```

It deletes all the organizations listed on a one-column CSV file passed as a parameter. An example of the CSV file is shown below:

```
acsfa
nceera
octae
oii
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Update Bureau Code

The Data profiles bureau code field can be updated using a script. This script sets the value of the bureau code field based on the data profile's organization. In the default mode, the script updates the bureau code for the data profiles that have this value as null or empty. You can run the script as follows:

```
python update_bureau_code.py
```

In addition, the script can be used to update the bureau code of all data profiles present on the ODP. This mode is activated by passing the parameter `-all`.

```
python update_bureau_code.py -all
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Fix update frequencies (accrualPeriodicity)

This script allows bulk reassignment of the value `update_frequency` (in the data profile metadata), which is mapped to `accrualPeriodicity` in the `data.json`. **All** data profiles with `update_frequency=<CURRENT_VALUE>` will be updated. The values are case sensitive, and the new value **must** be the ISO-8610 code, not the term.

| Term                                          | ISO-8610         |
| --------------------------------------------- | ---------------- |
| Irregular                                     | irregular        |
| Decennial                                     | R/P10Y           |
| Quadrennial                                   | R/P4Y            |
| Annual                                        | R/P1Y            |
| Bimonthly (every two months or twice a month) | R/P2M or R/P0.5M |
| Semiweekly                                    | R/P3.5D          |
| Daily                                         | R/P1D            |
| Biweekly (every two weeks or twice a week)    | R/P2W or R/P0.5W |
| Semiannual                                    | R/P6M            |
| Biennial                                      | R/P2Y            |
| Triennial                                     | R/P3Y            |
| Three times a week                            | R/P0.33W         |
| Three times a month                           | R/P0.33M         |
| Continuously updated                          | R/PT1S           |
| Monthly                                       | R/P1M            |
| Quarterly                                     | R/P3M            |
| Semimonthly                                   | R/P0.5M          |
| Three times a year                            | R/P4M            |
| Weekly                                        | R/P1W            |
| Hourly                                        | R/PT1H           |

The script can be used in 4 different ways. You can run without arguments, which will replace 'Other' with 'irregular' as their `accrualPeriodicity` for all data profiles:

```
python fix_update_frequencies.py
```

You can pass the current value (the one to be replaced) and the new ISO-8610 value to the script:

```
python fix_update_frequencies.py <CURRENT_VALUE> <NEW_VALUE>
```

You can pass a 2 column CSV file to the script, using `-f`:

```
python fix_update_frequencies.py -f <FILE_PATH>
```

An example of the CSV file is shown below. It follows the same ordering as manually passing the values (`<CURRENT_VALUE>,<NEW_VALUE>`):

```
R/P1W,R/P0.5M
Other,irregular
R/P1Y,R/P4Y
```

The last way to run this is for removing incorrect/invalid values (this can be used on valid values as well, but this isn't recommended since this handles everything in bulk). You can use it in the same way as the previous 2, but instead of `<NEW_VALUE>`, pass `remove`:

```
python fix_update_frequencies.py <CURRENT_VALUE> remove
```

It can be used in a CSV file as well:

```
<INVALID_STRING>,remove
<ANOTHER_INVALID_STRING>,remove
```

And when using a CSV file with the `-f` argument, you can use both removal and reassignment in the same file:

```
R/P1Y,R/P4Y
<INVALID_STRING>,remove
Other,irregular
<ANOTHER_INVALID_STRING>,remove
R/P1Y,R/P4Y
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Update Resource URLs

The Data profiles resource URLs can be updated using a script. This script sets the value of each resource's URL. The script reads the values from a CSV file, with five columns (only `CORRECTED_RESOURCE_URL` and `CURRENT_RESOURCE_URL` are _required_):

```
RESOURCE_TITLE,CORRECTED_RESOURCE_URL,CURRENT_RESOURCE_URL,SCRAPED_FROM,DATASET_NAME
School Data,http://correct.com,http://incorrect.com,http://scrapedfromsource.com,school-data
```

```
python update_resource_urls.py -f /path/to/csv
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Add organization tags to existing Data Profiles

Data Profiles are assigned the organization acronym as a tag by default on creation now. This script will add the organization acronym as a tag for all pre-existing data profiles that don't have this tag assigned already. It doesn't take any arguments, as it shouldn't need to be run more than once (all Data Profiles will already have their proper tags on creation now, including harvested Data Profiles):

```
python add_default_tag.py
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Clean up Invalid Program codes

This script clean up Data Profile identified with invalid program code. This script update such Data Profile program code and assign it a default one which is `018:000`

```
python correct_program_codes.py <PROGRAM_CODE>
```

`<PROGRAM_CODE>` serve as the invalid code to search for, and the script will obtain all Data Profile containing this `<PROGRAM_CODE>` and replace it with `018:000`

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Reset all API keys and passwords

**CAUTION**: This script will reset the API keys and passwords for _all_ users, including sysadmins. It resets all other users before resetting the CLI users' key and password as well.

The usage is simple. Along with the usual environment variables (`ED_CKAN_URL` and `ED_CKAN_KEY`), you _must_ run this script with the **sysadmin username** that the `ED_CKAN_KEY` belongs to as its only argument:

```
python reset_keys_and_passwords.py <SYSADMIN_USERNAME>
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |

# Validate if data profiles are according to the DCAT standard

Currently, data profiles have the following fields from DCAT:

- Title
- Description
- Owner organization
- Tags
- Author
- Author's email
- Access Level
- Program code

All the above listed fields are required for a new data profile to be eligible to become active. As the project hasn't always followed this standard, there are older data profiles that might be active that do not follow the DCAT guidelines. The `validate_dcat.py` script serves as a tool to help identify and hide these active invalid data profiles. After runnig it, the user is going to be presented with all the fields that are invalid for the selected organizations data profiles.

Additionally, this script will fix any Data Profiles with incorrect `private` and `indraft` states. Some older Data Profiles may be visibile when they don't meet the minumum DCAT requirements, which this will handle. You can document which Data Profiles have been fixed by using the `--csv-output-changes /PATH/TO/OUTPUT.csv` argument.

To use the script, run:

```
python validate_dcat.py
```

#### Arguments:

- `--all` - validate all publishers
- `--publisher PUBLISHER` - validate one publisher by name
- `--file` - bulk validation, each line in the file should be a publisher name
- `--log-output OUTPUT` - log output file path
- `--csv-output OUTPUT` - output results as a CSV file
- `--csv-output-changes OUTPUT` - output changed packages results as a CSV file
- `--dry-run` - do not modify state nor visibility of invalid data profiles
- `-h`, `--help` - show this help message and exit

#### Example:

Validate data profiles for a list of publishers:

```
python validate_dcat.py --file ./orgs.txt
```

Validate data profiles for a publisher:

```
python validate_dcat.py --publisher dummy_publisher
```

Validate data profiles for a list of publishers and save the script output to a file:

```
python validate_dcat.py --file ./orgs.txt --output ./results.txt
```

Validate data profiles for all publishers:

```
python validate_dcat.py --all
```

Validate all data profiles and export results to a CSV file:

```
python validate_dcat.py --all --csv-output ./results.csv
```

Output the Data Profiles that have been fixed (draft/hidden):

```
python validate_dcat.py --all --csv-output-changes ./changed_results.csv
```

Prior to running this script, some environment values should be created:

| Variable name | Sample value                         | Default value | Effect                            |
| ------------- | ------------------------------------ | ------------- | --------------------------------- |
| `ED_CKAN_URL` | https://us-ed-testing.ckan.io        | `None`        | URL of the target CKAN public API |
| `ED_CKAN_KEY` | 3554a32d-528e-4ec4-bf80-00bf4c4e513c | `None`        | CKAN API key for the above target |
