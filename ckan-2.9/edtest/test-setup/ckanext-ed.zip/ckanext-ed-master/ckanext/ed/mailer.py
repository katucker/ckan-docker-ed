import logging
from collections import namedtuple

from ckan.config.middleware import make_app
import ckan.lib.dictization
from ckan import model
from ckan.common import config, c
from ckan.plugins import toolkit
from ckan.lib.mailer import mail_user
from ckan.lib.base import render
#from ckan.controllers.admin import get_sysadmins
from ckan.logic.action.get import member_list as core_member_list
from ckanext.ed.helpers import get_sysadmins, is_coordinator

import ckanext.ed.helpers as ed_helpers 

log = logging.getLogger(__name__)

def mail_package_publish_request_to_admins(
                        context, data_dict, event='request', feedback=None,
                        capacity=["Admin"]):
    '''
    Sends an email to organization admin with request to publish dataset
    '''
    members = []
    if data_dict.get("owner_org", False):
        members = toolkit.get_action('member_list')(
            context=context,
            data_dict={'id': data_dict.get('owner_org')}
        )
    else:
        for owner_org in data_dict.get("owner_orgs"):
            member = toolkit.get_action('member_list')(
                context=context,
                data_dict={'id': owner_org}
            )
            members += member

    members = [m for m in members if 'user' in m]

    sysadmins = get_sysadmins()
    admin_ids = []

    if "Admin" in capacity:
        admin_ids += [model.User.get(i[0]) for i in members if i[2] in capacity]

    admin_ids += sysadmins

    if "coordinator" in capacity:
        if data_dict.get("owner_org", False):
            coordinators = [model.User.get(m[0]) for m in members if is_coordinator(user_id=m[0], 
                        org_id=data_dict.get('owner_org'))]
            admin_ids += coordinators
        else:
            for owner_org in data_dict.get("owner_orgs"):
                coordinators = [model.User.get(m[0]) for m in members if is_coordinator(user_id=m[0], 
                        org_id=owner_org)]
                admin_ids += coordinators

    for user in set(admin_ids):
        user_id = user.id

        #   Defaults to sending the email
        notf_enabled = True

        if event is 'ready':
            notf_enabled = ed_helpers.get_notf_preference('data_profile_publishing_ready', user_id)
        elif event is 'stuck':
            notf_enabled = ed_helpers.get_notf_preference('data_profile_stuck', user_id)
        else:
            notf_enabled = ed_helpers.get_notf_preference(f'data_profile_{event}', user_id)

        if user.email and notf_enabled:
            subj = _compose_email_subj(data_dict, 'package', event=event)
            body = _compose_email_body(data_dict, user, event=event)
            header = {'Content-Type': 'text/html; charset=UTF-8'}
            try:
                mail_user(user, subj, body, headers=header)
                log.debug('[email] Package publishing request email sent to {0}'.format(user.name))
            except:
                log.debug('[email] Package publishing request - Could not send email to {0}'.format(user.name))



def mail_package_publish_update_to_user(
                            context, pkg_dict, event='approval', feedback=None):
    '''
    Sends an email to user who published the dataset about approbal state.
    One of approved or rejected
    '''
    context.setdefault('model', model)
    user = model.User.get(pkg_dict['creator_user_id'])

    if user and user.email:
        subj = _compose_email_subj(pkg_dict, event=event)
        body = _compose_email_body(pkg_dict, user, event=event, feedback=feedback)
        header = {'Content-Type': 'text/html; charset=UTF-8'}
        try:
            mail_user(user, subj, body, headers=header)
            log.debug('[email] Data container update email sent to {0}'.format(user.name))
        except:
            log.debug('[email] Package publishing request - Could not send email to {0}'.format(user.name))


def mail_data_explorer_to_sysadmins(group_dict, event, feedback=None):
    '''
    Sends an email to all sysadmin users about data explorers approval state.
    Event: 'request' - 'approve' - 'reject'
    '''

    if not ed_helpers.get_config_value('ckanext.ed.approval_email_notifications'):
        return

    context = {'model': model, 'session': model.Session,
                    'user': c.user, 'auth_user_obj': c.userobj,
                    'ignore_auth' : True}

    if type(group_dict) is not dict:
        group_dict = ckan.lib.dictization.table_dictize(group_dict, context)

    # User model objects
    sysadmins = ed_helpers.get_sysadmins()
    for admin in sysadmins:
        notification_enabled = True

        if event is 'request':
            notification_enabled = ed_helpers.get_notf_preference('data_explorer_publishing_ready', admin.id)

        if admin.email and notification_enabled:
            subj = _compose_email_subj(group_dict, 'data-explorer', event=event)
            body = _compose_email_body_data_explorer(group_dict, admin, event, feedback)
            header = {'Content-Type': 'text/html; charset=UTF-8'}
            try:
                mail_user(admin, subj, body, headers=header)
                log.debug('[email] Data container update email sent to {0}'.format(admin.name))
            except:
                log.debug('[email] Could not send email to {0}'.format(admin.name))
            
def mail_data_explorer_to_user(group_dict, event, feedback=None):

    if not ed_helpers.get_config_value('ckanext.ed.approval_email_notifications'):
        return

    context = {'model': model, 'session': model.Session,
                    'user': c.user, 'auth_user_obj': c.userobj,
                    'ignore_auth' : True}

    if type(group_dict) is not dict:
        group_dict = ckan.lib.dictization.table_dictize(group_dict, context)

    user = model.User.get(group_dict.get('creator_user_id',''))

    notification_enabled = True

    if event is 'approval' or event is 'reject':
        notification_enabled = ed_helpers.get_notf_preference('data_explorer_approval_process', user.id)

    if user and user.email and notification_enabled:
        subj = _compose_email_subj(group_dict, 'data-explorer', event=event)
        body = _compose_email_body_data_explorer(group_dict, user, event, feedback)
        header = {'Content-Type': 'text/html; charset=UTF-8'}
        try:
            mail_user(user, subj, body, headers=header)
            log.debug('[email] Data container update email sent to {0}'.format(user.name))
        except:
            log.debug('[email] Could not send email to {0}'.format(user.name))


def mail_notif_resource_translate_to_user(context, metadata, action, translated, errors, user):
    """[summary]

    Args:
        context (dict): Contains the context 
        metadata (dict): resource data dictionary
        action ([type]): create|upgrade
    """
    log.debug("Sending email for event: "+ action +" with Context "+ str(context) +" and metadata = " + str(metadata))
    if not ed_helpers.get_config_value('ckanext.ed.resource_translate_email_notifications'):
        return

    notification_enabled = ed_helpers.get_notf_preference('resource_excel_translation', user.id)

    if user and user.email and notification_enabled:
        subj = "Resource translated on {} for package {}".format(action, metadata.get('name',''))
        header = {'Content-Type': 'text/html; charset=UTF-8'}
        body = _compose_email_body_translated_resource(context, metadata, user, translated=translated,
                                                    errors=errors, action=action)
        try:
            mail_user(user, subj, body, headers=header)
            log.debug('[email] Data container update email sent to {0}'.format(user.name))
        except:
            log.debug('[email] Could not send email to {0}'.format(user.name))


def mail_survey_feedback(package_id, feedback):
    config_email = ed_helpers.get_config_value(
        'ckanext.ed.survey_feedback_email_recipient')
    if not (ed_helpers.get_config_value('ckanext.ed.survey_email_notifications')
            and config_email):
        return

    data_dict = toolkit.get_action('package_show')({}, {'id': package_id})
    user_obj = namedtuple('User', ['display_name', 'name', 'email'])
    user = user_obj('ODP Admin', 'ODP Admin', config_email)
    subj = "Feedback for package {}".format(data_dict['title'])
    header = {'Content-Type': 'text/html; charset=UTF-8'}
    body = _compose_survey_feedback_email_body(data_dict, user, feedback)
    try:
        mail_user(user, subj, body, headers=header)
        log.debug('[email] email sent to {0}'.format(user.name))
    except:
        log.debug('[email] Could not send email to {0}'.format(user.name))

def mail_resource_to_sysadmins(resource_dict, event, user_creator='', feedback=None):
    '''
    Sends an email to all sysadmin users about resources approval state.
    Event: 'request' - 'approve' - 'reject'
    '''

    if not ed_helpers.get_config_value('ckanext.ed.approval_email_notifications'):
        return

    user = model.User.get(user_creator)
    resource_dict['creator_user_id'] = user.fullname or user.name

    # User model objects
    sysadmins = ed_helpers.get_sysadmins()
    for admin in sysadmins:
        user_id = admin.id
        notification_enabled = True

        if event is 'request':
            notification_enabled = ed_helpers.get_notf_preference('resource_publishing_ready', user_id)

        if admin.email and notification_enabled:
            subj = _compose_email_subj(resource_dict, 'resource', event=event)
            body = _compose_email_body_resource(resource_dict, admin, event, feedback)
            header = {'Content-Type': 'text/html; charset=UTF-8'}
            try:
                mail_user(admin, subj, body, headers=header)
                log.debug('[email] Data container update email sent to {0}'.format(admin.name))
            except:
                log.debug('[email] Could not send email to {0}'.format(admin.name))

def mail_resource_to_user(resource_dict, event, user_creator='', feedback=None, user=None):
    app = make_app(config)

    with app._wsgi_app.test_request_context():
        if not ed_helpers.get_config_value('ckanext.ed.approval_email_notifications'):
            return

        if user is None:
            user = model.User.get(user_creator)

        resource_dict['creator_user_id'] = user.fullname or user.name

        notification_enabled = True

        if event is 'approval' or event is 'reject':
            notification_enabled = ed_helpers.get_notf_preference('resource_approval_process', user.id)

        if user and user.email and notification_enabled:
            subj = _compose_email_subj(resource_dict, 'resource', event=event)
            body = _compose_email_body_resource(resource_dict, user, event, feedback)
            header = {'Content-Type': 'text/html; charset=UTF-8'}
            try:
                mail_user(user, subj, body, headers=header)
                log.debug('[email] Data container update email sent to {0}'.format(user.name))
            except:
                log.debug('[email] Could not send email to {0}'.format(user.name))

def mail_broken_link_report_to_users(organization, user_id):
    app = make_app(config)

    with app._wsgi_app.test_request_context():
        user = model.User.get(user_id)
        if user and user.email:
            subj = '[US ED] Resources with broken links report'
            body = _compose_broken_links_report_email_body(user, organization)
            header = {'Content-Type': 'text/html; charset=UTF-8'}
            try:
                mail_user(user, subj, body, headers=header)
                log.debug('[email] Broken links report email sent to {0}'.format(user.name))
            except:
                log.debug('[email] Could not send email to {0}'.format(user.name))


def _compose_email_subj(data_dict, object_type, event='request'):
    '''
    Formats an email subject
    '''
    object_type_str = ''
    if object_type == 'package':
        object_type_str = 'Package'
    elif object_type == 'data-explorer':
        object_type_str = 'Data Explorer'
    elif object_type == 'resource':
        object_type_str = 'Resource'

    if data_dict.get('title') or data_dict.get('name'):
        return '[US ED] {0} Publishing {1}: {2}'.format(object_type_str, event.capitalize(), data_dict.get('title') or data_dict.get('name'))
    
    return '[US ED] {0} Publishing {1}'.format(object_type_str, event.capitalize())


def _compose_email_body_translated_resource(context, metadata, user, translated=[],
                                            errors=[], action='create', feedback=None):
    '''
    Formats an email body for the XLSX to CSV automated translation notification
    '''
    data_dict = {
    'admin_name': user.fullname or user.name,
    'site_title': config.get('ckan.site_title'),
    'site_url': config.get('ckan.site_url'),
    'title': context.get('title', ''),
    'package_title':  context.get('package').title,
    'package_url': context.get('package').url,
    'description': metadata.get('description', ''),
    'url': metadata.get('url', ''),
    'publisher_name': context.get('creator_user_id', 'anon'),
    'resource_name':  metadata.get('name', 'anonymous'),
    'approval_status': metadata.get('approval_status', 'unknown'),
    'action': action,  # resource_create|resource_update
    'feedback': feedback,
    'translated': translated,
    'errors': errors,
    'object': 'Resource Automated XLSX to CSV translation'
    }
    # log.debug("EMAIL TEMPLATE data_dict : " + str(data_dict))
    # resource_[create|update]
    # this is failing, I should get the user from somewhere 
    
    return render('emails/resource_translate_email_notifications.html', data_dict)


def _compose_email_body_data_explorer(data_dict, user, event='request', feedback=None):
    '''
    Formats an email body
    '''
    data_explorer_link = toolkit.url_for('data_explorer.read', id=data_dict['name'], qualified=True)
    return render('emails/publish_{0}.html'.format(event), {
        'admin_name': user.fullname or user.name,
        'site_title': config.get('ckan.site_title'),
        'site_url': config.get('ckan.site_url'),
        'title': data_dict.get('title'),
        'description': data_dict.get('description', ''),
        'url': data_explorer_link,
        'publisher_name': data_dict.get('creator_user_id'),
        'feedback': feedback,
        'object': 'Data Explorer'
    })

def _compose_email_body_resource(data_dict, user, event='request', feedback=None):
    '''
    Formats an email body
    '''

    #resource_link = toolkit.url_for('resource_read', id=data_dict['id'], qualified=True)
    resource_link = toolkit.url_for(
        'ed_dataset.resources',
        id=data_dict['package_id'],
        resource_id=data_dict['id'],
        qualified=True
    )
    return render('emails/publish_{0}.html'.format(event), {
        'admin_name': user.fullname or user.name,
        'site_title': config.get('ckan.site_title'),
        'site_url': config.get('ckan.site_url'),
        'title': data_dict.get('name'),
        'description': data_dict.get('description', ''),
        'url': resource_link,
        'publisher_name': data_dict.get('creator_user_id'),
        'feedback': feedback,
        'object': 'Resource',
        'object_type': 'resource'
    })

def _compose_email_body(data_dict, user, event='request', feedback=None):
    '''
    Formats an email body
    '''
    pkg_links = []
    pkg_link = ''
    if data_dict.get('pkg_names', ''):
        for pkg_name in data_dict['pkg_names']:
            pkg_link = toolkit.url_for('dataset.read', id=pkg_name[0], qualified=True)
            pkg_links.append(pkg_link)
    else:
        pkg_link = toolkit.url_for('dataset_read', id=data_dict['name'], qualified=True)
    creator = model.User.get(data_dict['creator_user_id']).name
    return render('emails/package_publish_{0}.html'.format(event), {
        'admin_name': user.fullname or user.name,
        'site_title': config.get('ckan.site_title'),
        'site_url': config.get('ckan.site_url'),
        'package_title': data_dict.get('title'),
        'package_description': data_dict.get('notes', ''),
        'package_url': pkg_link,
        'publisher_name': creator,
        'feedback': feedback,
        'items_edited': data_dict.get('items_edited', ''),
        'pkg_names': zip(data_dict.get('pkg_names', []), pkg_links),
    })


def _compose_survey_feedback_email_body(data_dict, user, feedback):
    '''
    Formats an email body for survey feedback
    '''
    pkg_link = toolkit.url_for('dataset_read', id=data_dict['name'], qualified=True)
    return render('emails/survey_feedback.html', {
        'admin_name': user.name,
        'site_title': config.get('ckan.site_title'),
        'site_url': config.get('ckan.site_url'),
        'package_title': data_dict.get('title'),
        'package_description': data_dict.get('notes', ''),
        'package_url': pkg_link,
        'publisher_name': data_dict.get('contact_name'),
        'feedback': feedback
    })

def _compose_broken_links_report_email_body(user, org_report):
    return render('emails/broken_links_report_by_org.html', {
        'publisher_name': user.name,
        'organization': org_report
    })