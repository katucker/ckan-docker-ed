import logging
import click

import ckan.model as model

import ckanext.ed.dbutil as dbutil
import ckanext.ed.model as edmodel

log = logging.getLogger('ckanext.ed')

@click.command()
def init_notf_preferences():
    """
    Add table for notification preferences
    """
    model.Session.remove()
    model.Session.configure(bind=model.meta.engine)
    dbutil.init_notf_preferences_tables()
    click.secho("Notification preferences table is now set up in main database", fg=u"green")


@click.command()
def add_bulk_preference():
    dbutil.add_column_to_table("data_profile_bulk_update")
    click.secho("Bulk updated preference column is now added", fg=u"green")


@click.command()
def add_user_package_fields():
    dbutil.create_user_default_packge_field()
    click.secho("User package field table is now added", fg=u"green")
