# encoding: utf-8

from urllib.request import urlopen
from urllib.error import URLError
import logging
from lxml import etree as ET
import tempfile

from ckan.common import config
from ckan.logic import get_action
from ckan.logic import ValidationError
from ckanapi import LocalCKAN
import click


log = logging.getLogger(__name__)


class OMBToSources():
    """Retrieve new OMB numbers and create their Sources
    """

    def __init__(self, ctx):
        self.ctx = ctx
        self.api_client = LocalCKAN()


    def command(self):
        url = config.get('ckanext.ed.omb_inventory_url')

        if url is None:
            return ('\nNo URL set in the ckan.ini file:\n\n'
                    'ckanext.ed.omb_inventory.url=URL_TO_OMB_XML\n')

        omb_inventory_temp = tempfile.TemporaryFile()
        omb_inventory = self.retrieve_inventory(url, omb_inventory_temp)
        omb_inventory.seek(0)

        if omb_inventory is None:
            omb_inventory.close()
            return

        new_sources = self.parse_xml(omb_inventory)
        omb_inventory.close()

        if new_sources is None:
            return

        self.omb_to_sources(new_sources)

    def parse_xml(self, omb_inventory):
        try:
            root = ET.parse(omb_inventory)
        except ET.XMLSyntaxError as e:
            print('\n{}\n\nError: Invalid XML format.\n'.format(e))
            return

        new_sources = []

        print('\nParsing XML for new OMB numbers...\n')

        for info_request in root.findall('./InformationCollectionRequest'):
            omb_agency_code = int(
                info_request.find('AgencyCode').text.encode('utf-8')
            )

            if 1900 > omb_agency_code >= 1800:
                omb_title = info_request.find('Title')
                omb_abstract = info_request.find('Abstract')
                omb_number = info_request.find('OMBControlNumber')
                omb_collections = info_request.find('InformationCollections')
                new_source = {}
                info_collections = []

                new_source['title'] = omb_title.text.encode('utf-8')
                new_source['agency_code'] = omb_agency_code
                new_source['control_number'] = omb_number.text.encode('utf-8')

                if omb_abstract is not None:
                    new_source['abstract'] = omb_abstract.text.encode('utf-8')
                else:
                    new_source['abstract'] = None

                for omb_collection in omb_collections.findall(
                 'InformationCollection'):
                    info_collection = {}
                    collection_instruments = []

                    collection_title = omb_collection.find('Title')
                    omb_instruments = omb_collection.find('Instruments')

                    if collection_title is not None:
                        info_collection['title'] = \
                            collection_title.text.encode('utf-8')
                    else:
                        info_collection['title'] = None

                    if omb_instruments is not None:
                        for omb_instrument in omb_instruments.findall(
                         'Instrument'):
                            instrument = {}

                            form_name = omb_instrument.find('FormName')
                            form_number = omb_instrument.find('FormNumber')

                            if form_number is not None:
                                instrument['form_number'] = \
                                    form_number.text.encode('utf-8')
                            else:
                                instrument['form_number'] = None

                            if form_name is not None:
                                instrument['form_name'] = \
                                    form_name.text.encode('utf-8')
                            else:
                                instrument['form_name'] = None

                            collection_instruments.append(instrument)

                    info_collection['instruments'] = collection_instruments
                    info_collections.append(info_collection)

                new_source['information_collections'] = info_collections
                new_sources.append(new_source)

        return new_sources

    def retrieve_inventory(self, url, omb_inventory_temp):

        print('\nRetrieving OMB inventory XML...')

        try:
            omb_inventory_read = urlopen(url).read()
            omb_inventory_temp.write(omb_inventory_read)
        except URLError as e:
            print('\nError: {}\n\nVerify that ckanext.ed.omb_inventory_url'
                  ' in the ckan.ini is a valid URL.\nCurrent URL: {}\n'
                  .format(e, url))
        except Exception as e:
            print('Error: {}'.format(e.read()))

        return omb_inventory_temp

    def omb_to_sources(self, new_sources):
        source_url = config.get('ckanext.ed.omb_inventory_url')
        with self.ctx.meta['flask_app'].test_request_context():
            # existing_sources = get_action('source_list')({'ignore_auth': True}, {})
            existing_sources = self.api_client.call_action('source_list', {})
        existing_sources = [str(source) for source in existing_sources]
        new_sources = [
            source for source in new_sources
            if source['control_number'] not in existing_sources
        ]
        new_source_count = len(new_sources)

        for source in new_sources:
            description = ''
            source_name = source['control_number']
            source_title = source['title']
            source_abstract = source['abstract']
            source_collections = source['information_collections']
            source_url = \
                ('https://www.reginfo.gov/public/do/PRAOMBHistory?ombControlNumber={}'
                 .format(source_name))

            print('Creating Source: {}'.format(source_name))

            if source_title is not None:
                description += '**Title**: [{}]({})\n\n\n'.format(
                    source['title'], source_url
                )

            if source_abstract is not None:
                description += '**Abstract**: {}\n\n\n'.format(
                    source['abstract']
                )

            if len(source_collections) > 0:
                description += '## Information Collections\n---\n'

                for i, collection in enumerate(source_collections):
                    instruments = collection['instruments']
                    collection_title = collection['title']

                    if collection_title is not None:
                        description += '**Collection**: {}\n\n'.format(
                            collection_title
                        )

                    if len(instruments) > 0:
                        description += '**Instruments**:\n\n'
                    else:
                        description += '**Instruments**:\n_None listed_\n'

                    for instrument in instruments:
                        if len(instrument) > 0:
                            form_name = instrument['form_name']
                            # form_number = instrument['form_number']

                            if form_name is not None:
                                description += '- {}\n'.format(
                                    form_name
                                )

                    if i < len(source_collections) - 1:
                        description += '\n---\n\n'

            source_dict = {
                'name': source_name, 'title': source_name,
                'description': description, 'type': 'ed_source',
                'approval_status': 'approved', 'scraped_from': source_url,
                'ed_sources_type': 'Information Collection Instrument'
            }

            try:
                with self.ctx.meta['flask_app'].test_request_context():
                    # get_action('group_create')({'ignore_auth': True}, source_dict)
                    self.api_client.call_action('group_create', source_dict)
                print('{} was created successfully'.format(source_name))
            except ValidationError:
                new_source_count -= 1
                print('Skipping duplicate found for: {}'.format(source_name))

        if new_source_count == 0:
            print('Currently up to date.\n')
        else:
            print('\nSuccessfully created {} Sources.\n'.format(
                new_source_count)
            )


@click.command()
@click.pass_context
def omb_to_sources(ctx):
    """Retrieve new OMB numbers and create their Sources
    """
    omb = OMBToSources(ctx)
    omb.command()
    click.secho("Omb command successful", fg="green")