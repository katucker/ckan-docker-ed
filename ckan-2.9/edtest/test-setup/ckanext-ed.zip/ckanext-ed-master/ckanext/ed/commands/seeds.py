import sys
import re
import fnmatch
import os
import json
from ckanext import ed as ckanext_ed

from ckan.logic import get_action
from ckanapi import LocalCKAN

import click


class Ed():
    '''
 		Usage:
 		ed create_ed_vocabularies
 			- create vocabularies from json files
 		ed create_ed_groups
 			- create groups from json files
 		ed create_ed_organizations
 			- create organizations from json files
        ed create_ed_data_explorers
            - create data explorers from json files
    '''
    def __init__(self, ctx, args):
        self.ctx = ctx
        self.args = args
        self.api_client = LocalCKAN()

    def command(self):
        print('')

        if len(self.args) == 0:
            sys.exit(1)
        cmd = self.args[0]

        if cmd == 'create_ed_vocabularies':
            self.create_ed_vocabularies()

        elif cmd == 'create_ed_groups':
            self.create_ed_groups()

        elif cmd == 'create_ed_organizations':
            self.create_ed_organizations()

        elif cmd == 'create_ed_data_explorers':
            self.create_ed_data_explorers()

        else:
            print('Command {0} not recognized'.format(cmd))


    def _get_seeds_path(self, object_type):
        default_source_dir = os.path.join(os.path.dirname(ckanext_ed.plugin.__file__), 'seeds', object_type)
        source_dir = default_source_dir if not len(self.args) > 1 else self.args[1]

        return source_dir

    def create_ed_groups(self):
        source_dir = self._get_seeds_path('groups')
        # self.context['return_id_only'] = True

        if len(self.args) >= 1:
            seeds = []
            for root, dirnames, filenames in os.walk(source_dir):
                for filename in fnmatch.filter(filenames, '*.json'):
                    groups_file = re.sub(r'(\.json)$', '', filename)
                    groups = self._load_json_groups(os.path.join(root, filename))
                    for group in groups:
                        try:
                            with self.ctx.meta['flask_app'].test_request_context():
                                # created = get_action('group_create')(self.context, group)
                                created = self.api_client.call_action('group_create', group)
                                print('Created group {} ({})'.format(created['id'], created['name']))
                        except Exception as error:
                            print('Could not create group {}, skipping ({})'.format(group['name'], error))

        else:
            print('Please provide a path to the file')
            sys.exit(1)

    def create_ed_vocabularies(self):
        source_dir = self._get_seeds_path('tags')

        if len(self.args) >= 1:
            seeds = []
            for root, dirnames, filenames in os.walk(source_dir):
                for filename in fnmatch.filter(filenames, '*.json'):
                    vocabulary_name = re.sub(r'(\.json)$', '', filename)
                    tags = self._load_json_tags(os.path.join(root, filename))
                    self._create_or_update_vocabulary(vocabulary_name, tags)
        else:
            print('Please provide a path to the file')
            sys.exit(1)


    def _create_or_update_vocabulary(self, name, tags=[]):
        
        try:
            with self.ctx.meta['flask_app'].test_request_context():
                # vocabulary = get_action('vocabulary_show')(self.context, {'id': name})
                vocabulary = self.api_client.call_action('vocabulary_show', {'id': name})
                print('Found vocabulary {}'.format(name))
                for tag in tags:
                    try:
                        # get_action('tag_create')(self.context, {'name': tag['name'], 'vocabulary_id': vocabulary['id']})
                        self.api_client.call_action('tag_create', {'name': tag['name'], 'vocabulary_id': vocabulary['id']})
                        print('Created tag [{}] {}'.format(name, tag['name']))
                    except Exception as error:
                        print('Could not create tag {}, skipping ({})'.format(tag['name'], error))
        except:
            print('Could not find vocabulary {}, I will create it for you'.format(name))
            with self.ctx.meta['flask_app'].test_request_context():
                # new_vocabulary = get_action('vocabulary_create')(self.context, {'name': name})
                new_vocabulary = self.api_client.call_action('vocabulary_create', {'name': name})
            print('Created: \n{}'.format(new_vocabulary))
            self._create_or_update_vocabulary(new_vocabulary['name'], tags)


    def create_ed_organizations(self):
        source_dir = self._get_seeds_path('organizations')

        if len(self.args) >= 1:
            seeds = []
            for root, dirnames, filenames in os.walk(source_dir):
                for filename in fnmatch.filter(filenames, '*.json'):
                    organizations_file = re.sub(r'(\.json)$', '', filename)
                    organizations = self._load_json_organizations(os.path.join(root, filename))
                    for organization in organizations:
                        if organization.get('groups') and not organization.get('groups')[0].get('name'):
                            del(organization['groups'])
                        try:
                            with self.ctx.meta['flask_app'].test_request_context():
                                # created = get_action('organization_create')(self.context, organization)
                                created = self.api_client.call_action('organization_create', organization)
                                print('Created organization {} ({})'.format(created['id'], created['name']))
                        except Exception:
                            try:
                                organization['id'] = organization['name']
                                with self.ctx.meta['flask_app'].test_request_context():
                                    # updated = get_action('organization_update')(self.context, organization)
                                    updated = self.api_client.call_action('organization_update', organization)
                                    print('Updated organization {} ({})'.format(updated['id'], updated['name']))
                            except Exception as error:
                                print('Could not create/update organization {}, skipping ({})'.format(organization['name'], error))

        else:
            print('Please provide a path to the file')
            self.parser.print_usage()
            sys.exit(1)

    def create_ed_data_explorers(self):  
        source_dir = self._get_seeds_path('data_explorer')

        if len(self.args) >= 1:
            seeds = []
            for root, dirnames, filenames in os.walk(source_dir):
                for filename in fnmatch.filter(filenames, '*.json'):
                    groups_file = re.sub(r'(\.json)$', '', filename)
                    groups = self._load_json_data_explorers(os.path.join(root, filename))
                    for group in groups:
                        group['type'] = 'data_explorer'
                        try:
                            with self.ctx.meta['flask_app'].test_request_context():
                                # created = get_action('group_create')(self.context, group)
                                created = self.api_client.call_action('group_create', group)
                                print('Created data explorer {} ({})'.format(created['id'], created['name']))
                        except Exception as error:
                            print('Could not create data explorer {}, skipping ({})'.format(group['name'], error))

        else:
            print('Please provide a path to the file')
            sys.exit(1)



    def _load_json_tags(self, file_path):
        with open(file_path, 'r') as f:
            try:
                return [{"name": t['name']} for t in json.loads(f.read())]
            except Exception as error:
                print(error)
                sys.exit(1)

    def _load_json_groups(self, file_path):
        with open(file_path, 'r') as f:
            try:
                return [{"name": g['name'], "title": g['title']} for g in json.loads(f.read())]
            except Exception as error:
                print(error)
                sys.exit(1)

    def _load_json_organizations(self, file_path):
        with open(file_path, 'r') as f:
            try:
                return [{"name": g['name'], "title": g['title'], "groups": [{"capacity": "public", "name": g['subOrganizationOf']}]} for g in json.loads(f.read())]
            except Exception as error:
                print(error)
                sys.exit(1)

    def _load_json_data_explorers(self, file_path):
        with open(file_path, 'r') as f:
            try:
                return [{"name": g['name'], "title": g['title'], 
                    "description": g['description'], 
                    "extras": [
                        {"key" : "url", "value": g['url']},
                        {"key" : "owner_org", "value": g['owner_org']},
                        {"key" : "creator_user_id", "value": g['creator_user_id']}
                        ]
                    } for g in json.loads(f.read())]
            except Exception as error:
                print(error)
                sys.exit(1)


@click.command()
@click.argument('args', nargs=-1)
@click.pass_context
def ed(ctx, args):
    '''
 		Usage:
 		ed create_ed_vocabularies
 			- create vocabularies from json files
 		ed create_ed_groups
 			- create groups from json files
 		ed create_ed_organizations
 			- create organizations from json files
        ed create_ed_data_explorers
            - create data explorers from json files
    '''
    ed_cli = Ed(ctx, args)
    ed_cli.command()
    click.secho("Seed initiated", fg="cyan")
    