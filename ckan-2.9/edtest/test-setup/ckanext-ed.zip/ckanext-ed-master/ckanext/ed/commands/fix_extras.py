import sys
from pprint import pprint
import re
import fnmatch
import os
import json
from ckanext import ed

from ckan import model
from ckan.logic import get_action
from ckan.plugins import toolkit

from ckan.model import Package, User
from ckanext.harvest.model import HarvestObject, HarvestSource
from ckanext.ed.actions import package_update, core_package_show as package_show
import click


class Ed():
    '''
 		Usage:
 		fix_extras
 			- fix broken dataset extras
    '''
    query_limit = 100

    def __init__(self):
        self.ok = 0
        self.updated = 0
        self.skipped = 0

    def command(self):
        #self._get_new_extras('d926ea8b-74b6-4187-a58c-1b609520dee2')
        all_ids = self._get_all_ids()

        for id in all_ids:
            extras = self._get_new_extras(id)
            if extras:
                self._update_extras(id, extras)

        print('')
        print('======================================')
        print('{} packages OK.'.format(self.ok))
        print('{} packages updated.'.format(self.updated))
        print('{} packages skipped (they were manually added).'.format(self.skipped))


    def _get_all_ids(self, ids=[], offset=0):
        ids_q = "select id from package where type='dataset' offset {} limit {};".format(offset, self.query_limit)  #   nosec
        ids_result = model.Session.execute(ids_q)
        fetched = ids_result.fetchall()
        for row in fetched:
            ids.append(row[0])

        # If we have multiple of <limit>, recurse until you get all data
        # However, if we don't have results, stop this madness
        if not len(ids) % self.query_limit and len(fetched):
            self._get_all_ids(ids, offset + self.query_limit)

        # import ipdb; ipdb.set_trace()
        return ids



    def _get_new_extras(self, package_id):

        # Get ready to find the harvest object for this package.
        # We get the ID from the DB, then we will delegate the dirty work to CKAN models
        hobj_q = "select * from harvest_object where package_id = '{}';".format(package_id) #   nosec
        hobj_result = model.Session.execute(hobj_q)
        hobj_id = None

        for row in hobj_result.fetchall():
            # Fetch the harvest object ID
            hobj_id = row[0]

        if not hobj_id:
            # Not everything was harvested...
            print('Skipping package {}, it was not harvested'.format(package_id))
            self.skipped = self.skipped + 1
            return False

        # Fetch the harvest object via CKAN model
        hobj = HarvestObject.get(hobj_id)

        try:
            # Get the harvest source object
            hs = HarvestSource.get(hobj.harvest_source_id)
        except:
            # ...or don't, whatever
            hs = {}

        # Update the old extras with the new ones
        old_extras = Package.get(package_id).as_dict().get('extras', {})
        if not old_extras.get('harvest_object_id') or not(old_extras.get('harvest_source_id')):
            # Define the extras we want
            extras = {
                "catalog_@context": "https://project-open-data.cio.gov/v1.1/schema/catalog.jsonld",
                "catalog_describedBy": "https://project-open-data.cio.gov/v1.1/schema/catalog.json",
                "harvest_source_id": hobj.harvest_source_id,
                # "amended_by_user": False,
                "resource-type": "Dataset",
                # "program_code": "{018:000}",
                # "modified": hobj.get('import_finished', '2020-08-01')[:10],
                "harvest_source_title": hs.title,
                "source_schema_version": "1.1",
                "source_datajson_identifier": True,
                # "access_level": "public",
                # "scraped_from": json.loads(hobj.content).get('scraped_from'),
                "catalog_@id": "datopian_data_json_edgov",
                "catalog_conformsTo": "https://project-open-data.cio.gov/v1.1/schema",
                # "bureau_code": "{018:00}",
                "identifier": json.loads(hobj.content).get('identifier'),
                "harvest_object_id": hobj.id,
            }

            self.updated = self.updated + 1
            return extras
            # new_extras = old_extras.copy()
            # new_extras.update(extras)
            # # Give me the extras!
            # return new_extras
        else:
            print('Nothing to do for package {}'.format(package_id))
            self.ok = self.ok + 1
            return None


    def _update_extras(self, package_id, extras):
        context = {
            "model": model,
            "session": model.Session,
            "allow_partial_update": True,
            "use_cache": False,
            "ignore_auth": True,
            # "defer_commit": True,
            }
        user_id = Package.get(package_id).creator_user_id
        context['user'] = User.get(user_id).name

        package = package_show(context, {'id': package_id})

        extras_list = []

        for key, value in extras.items():
            if key not in ['program_code', 'bureau_code', 'access_level', 'update_frequency', 'amended_by_user', 'license', 'scraped_from']:
                extras_list.append({
                    'key': key,
                    'value': value
                })

        package['extras'] = extras_list

        print('Updating extras for package {}'.format(package_id))

        try:
            package_update(context, package)
        except Exception as e:
            print(e)


@click.command()
def fix_extras():
    '''
 		Usage:
 		fix_extras
 			- fix broken dataset extras
    '''
    extras = Ed()
    extras.command()
    click.secho("Fix Extras", fg="green")
