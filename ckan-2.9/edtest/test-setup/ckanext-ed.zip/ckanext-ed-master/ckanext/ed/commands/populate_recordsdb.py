from pprint import pprint
from bs4 import BeautifulSoup
import requests
import ckan.model as model
import logging
import click
from ckan.common import config

log = logging.getLogger('ckanext.ed')


@click.command()
def populate_recordsdb():
    """Populate record schedule table
    """
    datas = fetchdata()
    connection = model.Session.connection()
    delete_sql = """DELETE FROM "record_schedule"; """
    connection.execute(delete_sql)

    if datas:
        for data in datas:
            ed_no = data["ed_no"]
            sch_title = data["schedule_title"]
            nara_disposition_authority = data["nara_disposition_authority"]

            sql = """INSERT INTO "record_schedule" ("ed_no", "schedule_title", "nara_disposition_authority")
                    VALUES ( '{ed}', '{st}', '{nda}' );""".format(ed=ed_no, st=sch_title, nda=nara_disposition_authority) # nosec

            connection.execute(sql)
        model.Session.commit()
        click.secho("Record schedule table succesfully populated...", fg="green")



def fetchdata():
    url = config.get('ckanext.ed.record_schedule_url')
    data = []

    if not url:
        click.secho("ckanext.ed.record_schedule_url is not set", fg="red")
        return data

    page = requests.get(url)

    if page.status_code != 200:
        raise ValueError('Could not access the provided url')

    soup = BeautifulSoup(page.content, 'html.parser')
    table = soup.find('table')
    trs = table.find_all('tr')
    i = 1

    for tr in trs[2:-1]:
        table_headings = tr.find_all('th')
        table_data = tr.find_all('td')

        try:
            ed_no = table_headings[0].get_text(strip=True).replace('\u200b', '')
            schedule = table_data[0].get_text(strip=True).replace('\u200b', '').replace("'", "\'\'").replace('(See below)', '').replace('(See Below)', '')
            nara_disposition_authority = table_data[1].get_text(strip=True).replace('\u200b', '')

            data.append({
                'ed_no': ed_no,
                'schedule_title': schedule,
                'nara_disposition_authority': nara_disposition_authority
            })

        except Exception as e:
            log.error(e)
            log.error('Failed to parse data for table row {}: {}'.format(i, tr))
            continue

        i += 1

    return data