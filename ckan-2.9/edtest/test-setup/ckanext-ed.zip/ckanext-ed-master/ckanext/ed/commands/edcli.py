import click
from .add_column_level import level_column
from .broken_links_report import broken_links_report
from .download_resources import download_resources
from .survey import init_survey_db
from .populate_recordsdb import populate_recordsdb
from .record_schedule import init_record_schedule
from .fix_extras import fix_extras
from .omb_to_sources import omb_to_sources
from .seeds import ed
from .coordinators import init_coordinators
from .notf_preferences import init_notf_preferences, add_bulk_preference, add_user_package_fields
from .stuck_dp import stuck_dp
from .remove_revisions import clean_revisions
from .list_pages import list_pages

@click.group(short_help=u"ED commands")
def edcli():
    pass

edcli.add_command(level_column)
edcli.add_command(broken_links_report)
edcli.add_command(download_resources)
edcli.add_command(init_survey_db)
edcli.add_command(populate_recordsdb)
edcli.add_command(init_record_schedule)
edcli.add_command(fix_extras)
edcli.add_command(omb_to_sources)
edcli.add_command(ed)
edcli.add_command(init_coordinators)
edcli.add_command(init_notf_preferences)
edcli.add_command(stuck_dp)
edcli.add_command(clean_revisions)
edcli.add_command(add_bulk_preference)
edcli.add_command(add_user_package_fields)
edcli.add_command(list_pages)
