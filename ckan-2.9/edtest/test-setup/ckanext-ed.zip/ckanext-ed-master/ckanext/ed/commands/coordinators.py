import logging
import click

import ckan.model as model

import ckanext.ed.dbutil as dbutil
import ckanext.ed.model as edmodel

log = logging.getLogger('ckanext.ed')


@click.command()
def init_coordinators():
    """
    Add table for coordinators
    """
    model.Session.remove()
    model.Session.configure(bind=model.meta.engine)
    dbutil.init_coordinator_tables()
    click.secho("Set up a coordinators table in main database", fg=u"green")
