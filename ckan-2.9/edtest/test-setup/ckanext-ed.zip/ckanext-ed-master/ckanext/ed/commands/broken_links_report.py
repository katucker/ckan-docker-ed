from ckan import model
from ckan.logic import get_action
from ckanext.ed import helpers, mailer
from ckan.plugins import toolkit
from ckanapi import LocalCKAN
import click

import logging

log = logging.getLogger('ckanext.ed')

@click.command()
@click.pass_context
def broken_links_report(ctx):
    """Send report by email about broken links
    """
    click.secho('Looking for broken resource links.', fg='green', nl=True)
    api_client = LocalCKAN()

    report_by_org = get_report_by_org(ctx, api_client)
    users_by_org = get_users_by_org(ctx, api_client)

    for organization in report_by_org:
        org_name = organization.get('name')
        users = users_by_org.get(org_name)
        for user in users:
            notification_enabled = helpers.get_notf_preference('broken_links', user.get('id'))

            click.secho('Sending email to {0} with a report for {1}'.format(user.get('name'), org_name), fg='cyan', nl=True)
            if user.get('capacity') in ['admin', 'editor'] and notification_enabled:
                org_report = prepare_report(ctx, organization, api_client)
                mailer.mail_broken_link_report_to_users(org_report, user.get('id'))


def get_report_by_org(ctx, api_client: LocalCKAN=None):
    with ctx.meta['flask_app'].test_request_context():
        # report_by_org = get_action('ckanext_deadoralive_broken_links_by_organization')(context)
        report_by_org = api_client.call_action('ckanext_deadoralive_broken_links_by_organization')
    return report_by_org


def get_users_by_org(ctx, api_client: LocalCKAN=None):
    data_dict = {
        'all_fields': True,
        'include_users' : True
    }
    with ctx.meta['flask_app'].test_request_context():
        # organizations = get_action('organization_list')(context, data_dict)
        organizations = api_client.call_action('organization_list', data_dict)
    users_by_org = {}
    for org in organizations:
        users_by_org[org.get('name')] = org.get('users')

    return users_by_org


def get_resource(ctx, resource_id, api_client: LocalCKAN=None):
    data_dict = {
        'id': resource_id,
    }
    with ctx.meta['flask_app'].test_request_context():
        # resource = get_action('resource_show')(context, data_dict)
        resource = api_client.call_action('resource_show', data_dict)
    return resource


def prepare_report(ctx, organization, api_client: LocalCKAN=None):
    org_url = toolkit.url_for('organization.read', id=organization.get('name'), qualified=True)
    
    org_report = {
        'display_name' : organization.get('display_name'),
        'description': organization.get('description'),
        'num_broken_links': organization.get('num_broken_links'),
        'url': org_url,
        'datasets_with_broken_links': []
    }

    datasets_broken_links_report_lst = []
    datasets = organization.get('datasets_with_broken_links')
    for dataset in datasets:
        dataset_link = toolkit.url_for('dataset_read',
                    id=dataset.get('name'), qualified=True)

        dataset_report = {
            'num_broken_links': dataset.get('num_broken_links'),
            'display_name': dataset.get('display_name'),
            'name': dataset.get('name'),
            'url': dataset_link,
            'resources_with_broken_links': []
        }

        resource_report_list = []
        resources = dataset.get('resources_with_broken_links')
        for resource in resources:
            resource = get_resource(ctx, resource, api_client)
            
            resource_url = toolkit.url_for('ed_dataset.resources',
                id=dataset.get('name'),
                resource_id=resource.get('id'),
                qualified=True)
            
            resource_report = {
                'id': resource.get('id'),
                'name': resource.get('name'),
                'url': resource_url
            }
            resource_report_list.append(resource_report)
        
        dataset_report['resources_with_broken_links'] = resource_report_list
        datasets_broken_links_report_lst.append(dataset_report)
    
    org_report['datasets_with_broken_links'] = datasets_broken_links_report_lst
    return org_report
