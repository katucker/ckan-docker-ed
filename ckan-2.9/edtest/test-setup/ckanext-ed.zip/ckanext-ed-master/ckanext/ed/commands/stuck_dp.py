from ckan.common import config
from ckan.logic import get_action
import click
from ckanapi import LocalCKAN
import logging
from ckanext.ed.mailer import mail_package_publish_request_to_admins
from datetime import datetime

@click.command()
@click.pass_context
def stuck_dp(ctx):
    api_client = LocalCKAN()
    with ctx.meta['flask_app'].test_request_context():
        result = api_client.call_action('package_search', {
            'q': '',
            'type': 'dataset',
            'include_drafts': True,
            'include_private': True
        })
        for dataset in result['results']:
            if dataset.get('approval_status') != 'approved' and (dataset.get("indraft") in ["false", False, None]):
                #get datset created date
                created_date = dataset.get('metadata_modified')
                # convert created date to datetime object
                created_date = datetime.strptime(created_date, '%Y-%m-%dT%H:%M:%S.%f')
                #find the difference between current date and created date
                diff = datetime.now() - created_date
                #if the difference is greater than n days in ckan.config
                if diff.days >= int(config.get('ckanext.ed.stuck_dp_days')):
                    #send email to admins
                    mail_package_publish_request_to_admins({}, dataset, event='stuck', capacity=['coordinator'])
                    logging.info("Email sent to admins for dataset: %s", dataset.get('name'))

        click.echo('Done')


