import ckanext.ed.dbutil as dbutil
import logging

import ckan.model as model
import click


@click.command()
def init_survey_db():
    model.Session.remove()
    model.Session.configure(bind=model.meta.engine)
    dbutil.init_survey_tables()
    click.secho("Set up survey tables in main database", fg="cyan")