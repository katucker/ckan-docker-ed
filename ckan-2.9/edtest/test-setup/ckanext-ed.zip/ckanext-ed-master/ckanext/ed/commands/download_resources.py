import cgi
import sys
from pprint import pprint
import re
import fnmatch
import os
import json
import mimetypes
import tempfile
import requests

from ckanext import ed
from requests.exceptions import *

from ckan import model
from ckan.logic import get_action
from ckan.plugins import toolkit
from ckan.common import config

import ckan.lib.munge as munge
import ckan.lib.uploader as uploader
from ckan.lib.uploader import ResourceUpload, get_storage_path

from ckan.model import Package, User
from ckanext.harvest.model import HarvestObject, HarvestSource
from ckanext.ed.actions import package_update, core_package_show as package_show, resource_update
import click
import logging
from ckanapi import LocalCKAN
log = logging.getLogger(__name__)


class Ed():
    # We can use the same context for all operations
    def __init__(self, ctx):
        self.ctx = ctx
        self.api_client = LocalCKAN()

    def command(self, cmd='', name='', arg=None):

        if cmd not in ['harvester', 'publisher']:
            print('Command {0} not recognized'.format(cmd))
            sys.exit(1)

        if arg and arg not in ['restore']:
            print('Argument {0} not recognized'.format(arg))
            sys.exit(1)
        elif arg and arg in ['restore']:
            restore = True
        else:
            restore = False

        if not restore:
            # Get a list of all resources, and a list of all resources that are links
            resources, links = self.get_resources(cmd, name)
            try:
                print('{} resources found.'.format(len(resources)))
                print('{} resources need to be transformed.'.format(len(links)))
                print('================================')
            except Exception as e:
                print(e)
                sys.exit(1)

            # Transform them one by one, count them etc\.
            counter = 0
            for link in links:
                counter = counter + 1
                print('[{}/{}] Transforming resource {} '.format(counter, len(links), link['url']))
                self._download_resource(link)
        else:
            # Get a list of all resources, and a list of all resources that are uploads
            resources, uploads = self.get_resources(cmd, name, get_uploads=True)
            try:
                print('{} resources found.'.format(len(resources)))
                print('{} resources need to be restored.'.format(len(uploads)))
                print('================================')
            except Exception as e:
                print(e)
                sys.exit(1)

            # Transform them one by one, count them etc\.
            counter = 0
            for uploaded in uploads:
                counter = counter + 1
                print('[{}/{}] Restoring resource {} '.format(counter, len(uploads), uploaded['url']))
                self._restore_resource(uploaded)


    def get_resources(self, cmd, name, get_uploads=False):

        # List of all dataset IDs belonging to this publisher or harvest source
        datasets = getattr(self, '_get_{}_datasets'.format(cmd))(name)

        resources = []       # List of all resources
        transformables = []  # List of all transformable resources

        for dataset_id in datasets:
            with self.ctx.meta['flask_app'].test_request_context():
                # dataset = get_action('package_show')(self.context, {'id': dataset_id})
                dataset = self.api_client.call_action('package_show', {'id': dataset_id})
            if dataset.get('resources'):
                if get_uploads:
                    dataset_resources = [{'id': r['id'], 'url': r['url'], 'scraped_from': r.get('scraped_from', None)} for r in dataset['resources']]
                    dataset_transformables = [{'id': r['id'], 'url': r['scraped_from']} for r in dataset['resources'] if r.get('scraped_from', False) and r.get('url_type', '') == 'upload']
                else:
                    dataset_resources = [{'id': r['id'], 'url': r['url']} for r in dataset['resources']]
                    dataset_transformables = [{'id': r['id'], 'url': r['url']} for r in dataset['resources'] if r['url_type'] != 'upload' and r['url']]
                resources.extend(dataset_resources)
                transformables.extend(dataset_transformables)

        # import ipdb; ipdb.set_trace()

        return (resources, transformables)

    def _get_harvester_datasets(self, harvest_source_name, datasets=[], offset=0):
        limit = 100

        with self.ctx.meta['flask_app'].test_request_context():
            # source_id = get_action('harvest_source_show')(self.context, {'id': harvest_source_name}).get('id')
            source_id = self.api_client.call_action('harvest_source_show', {'id': harvest_source_name}).get('id')
            if not source_id:
                print('Cannot find harvest source named {}'.format(harvest_source_name))
                sys.exit(1)

            result = get_action('package_search')(self.context, {
                'q': '',
                'fq': '+harvest_source_id:"{0}"'.format(source_id),
                'type': 'dataset',
                'start': offset,
                'rows': limit,
                'include_drafts': True,
                'include_private': True
            })

        # We are only interested in the IDs, as there's nothing else relevant there
        ids = [d['id'] for d in result.get('results')]

        # Extend the existing list, if anything was found
        if result:
            datasets.extend(ids)

        # If there could be more to get, request the next batch
        if not len(result.get('results')) % limit and len(result.get('results')):
            self._get_harvester_datasets(harvest_source_name, datasets, offset + limit)

        return datasets


    def _get_publisher_datasets(self, publisher_name, datasets=[], offset=0):
        limit = 100

        # import ipdb; ipdb.set_trace()
        print(self.context)
        with self.ctx.meta['flask_app'].test_request_context():
            # result = get_action('package_search')(self.context, {
            #     'q': '',
            #     'fq': 'organization:{}'.format(publisher_name),
            #     'type': 'dataset',
            #     'start': offset,
            #     'rows': limit,
            #     'include_drafts': True,
            #     'include_private': True
            # })
            result = self.api_client.call_action('package_search', {
                'q': '',
                'fq': 'organization:{}'.format(publisher_name),
                'type': 'dataset',
                'start': offset,
                'rows': limit,
                'include_drafts': True,
                'include_private': True
            })

        # We are only interested in the IDs, as there's nothing else relevant there
        ids = [d['id'] for d in result.get('results')]

        # Extend the existing list, if anything was found
        if result:
            datasets.extend(ids)

        # If there could be more to get, request the next batch
        if not len(result.get('results')) % limit and len(result.get('results')):
            self._get_publisher_datasets(publisher_name, datasets, offset + limit)

        return datasets


    def _download_file(self, url):
        # Let's create, populate and return a temporary file
        tmp_file = tempfile.TemporaryFile()
        content_type = None

        try:
            r = requests.get(url, stream=True)
            #r.raise_for_status()
            # save the content type, we will need to return it
            content_type = r.headers.get('Content-Type','')
            # if it's HTML, don't even bother downloading the chunks
            if 'html' in content_type.lower():
                return (None, content_type)
            # For each chunk of the file we are getting, flush it into out temp file
            for chunk in r.iter_content(chunk_size=8192):
                tmp_file.write(chunk)
            # Return the file-like object we need and its content type from headers
            return (tmp_file, content_type)

        except requests.exceptions.HTTPError as e:
            print("HTTP Error: %s", e)
        except requests.exceptions.ConnectionError as e:
            print("Connection Error: %s", e)
        except requests.exceptions.Timeout as e:
            print("Timeout Error: %s", e)
        except requests.exceptions.TooManyRedirects as e:
            print("Too Many Redirects Error: %s", e)
        except requests.exceptions.RequestException as e:
            print("Request Exception Error: %s", e)

        return (None, '')          

    def _download_resource(self, mini_resource):

        # import ipdb; ipdb.set_trace()

        resource_id = mini_resource['id']
        resource_url = mini_resource['url']

        try:
            # Get a file-like object with the file we need to save
            downloaded_file, downloaded_type = self._download_file(resource_url)
        except HTTPError as e:
            print('Cannot fetch {}. Error was: {}'.format(resource_url, e))
            return False

        if not downloaded_type:
            print('Cannot fetch {}.'.format(resource_url))
            return False

        if 'html' in downloaded_type.lower():
            print('Cannot fetch {}, got HTML instead.'.format(resource_url))
            return False

        if not downloaded_file:
            print('Cannot download {} due to an error.'.format(resource_url))
            return False

        # CKAN only accepts this kind of object here...
        file_obj = cgi.FieldStorage()
        file_obj.file = downloaded_file
        file_obj.filename = resource_url.split('/')[-1]

        try:
            result = resource_update(self.context,
                                    {'id': resource_id,
                                    'file': downloaded_file,
                                    'upload': file_obj,
                                    # The `scraped_from` property is useful to help the harvester not overwrite this
                                    'scraped_from': resource_url})
        except Exception as e:
            return False
            print('Cannot update resource with ID {}. Error was: {}'.format(resource_id, e))

        # Get an uploader instance
        uploader = ResourceUpload(mini_resource)
        try:
            # ...and upload the file!
            uploader.upload(resource_id, 107374187500) # 100 GiB
        except Exception as e:
            # Put back the file for upload if the upload failed
            result = resource_update(self.context,
                                    {'id': resource_id,
                                    'file': downloaded_file,
                                    'upload': file_obj,
                                    'scraped_from': resource_url})
            print('Cannot upload file for resource with ID {}. Error was: {}'.format(resource_id, e))
            return False

        # Closing a temporary file also triggers its deletion from the disk
        downloaded_file.close()

        return result


    def _restore_resource(self, mini_resource):

        # import ipdb; ipdb.set_trace()

        resource_id = mini_resource['id']
        resource_url = mini_resource['url']

        try:
            result = resource_update(self.context,
                                    {'id': resource_id,
                                     'url': resource_url,
                                     'clear_upload': True,
                                     'url_type': 'null'})
        except Exception as e:
            print('Cannot update resource with ID {}. Error was: {}'.format(resource_id, e))
            return False

        # Get an uploader instance
        uploader = ResourceUpload(mini_resource)
        try:
            # ...and upload the file!
            uploader.upload(resource_id, 107374187500) # 100 GiB
        except Exception as e:
            # Put back the file for upload if the upload failed
            result = resource_update(self.context,
                                    {'id': resource_id,
                                     # 'clear_upload': True,
                                     # 'url_type': None,
                                     'scraped_from': resource_url})
            print('Cannot upload file for resource with ID {}. Error was: {}'.format(resource_id, e))
            return False

        return result


@click.command()
@click.argument('args', nargs=-1)
@click.pass_context
def download_resources(ctx, args):
    '''
 		Usage:
 		download_resources harvester|publisher <name> [restore]
 			- downloads the resources for the harvest source/publisher <name>
                        - UNLESS the *restore* arg is present, in which case REMOVE the downloaded
                          resources and restore the old resource links.
        Note:
        Deprecated command. It should be removed in future releases.
        Use the download_resource script instead.
    '''
    if len(args) == 0:
        sys.exit(1)
    else:
        cmd = args[0]
        name = args[1]

    if len(args) > 2:
        arg = args[2]
    else:
        arg = None

    ed_cli = Ed(ctx)
    ed_cli.command(cmd, name, arg)

    click.secho("{}".format(len(args)), fg='green')

    


    