import ckanext.ed.dbutil as dbutil
import ckan.model as model
import click

@click.command()
def init_record_schedule():
    model.Session.remove()
    model.Session.configure(bind=model.meta.engine)
    dbutil.init_record_schedule()
    click.secho("Set up a record schedule tables in main database", fg=u"green")