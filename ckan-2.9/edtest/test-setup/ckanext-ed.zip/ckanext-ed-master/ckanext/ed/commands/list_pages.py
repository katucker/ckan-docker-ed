import logging
import click


log = logging.getLogger('ckanext.ed')

@click.command()
@click.pass_context
def list_pages(ctx):
    app = ctx.meta['flask_app']

    banned_pieces = [
        "/api/",
        "/action/",
        ".json",
        "/zh_TW",
        "<path:path>",
        "/zh_CN/",
        "/<path:filename>",
        "<path:filename>",
        "/_debug_toolbar",
        "<filename>"
    ]

    with app.app_context():
        paths = []
        for rule in app.url_map.iter_rules():
            if "GET" in rule.methods and not any(x in str(rule) for x in banned_pieces):
                paths.append(str(rule))

        paths = list(set(paths))
        for path in paths:
            click.secho(path, fg="cyan")