import ckan.model as model
import logging
import click

log = logging.getLogger('ckanext.ed')


@click.command()
def level_column():
    """
    Add `level` column to package_relationship
    """
    connection = model.Session.connection()
    sql = """ALTER TABLE "package_relationship"
            ADD COLUMN "order" INT """
    connection.execute(sql)
    model.Session.commit()
    click.secho('add level column created', fg='green')
