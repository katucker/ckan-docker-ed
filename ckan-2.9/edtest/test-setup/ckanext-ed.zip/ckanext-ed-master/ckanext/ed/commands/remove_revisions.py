import click
from ckanext.ed.model import clean_revision_tables
# Used for testing/debugging deprecated revision tables
# from ckanext.ed.model import add_to_revision_table

REVISION_TABLES = [
    'group_extra_revision',
    'group_revision',
    'member_revision',
    'package_extra_revision',
    'package_relationship_revision',
    'package_revision',
    'package_tag_revision',
    'resource_revision',
    'system_info_revision'
]

@click.command()
@click.pass_context
def clean_revisions(ctx):
    with ctx.meta['flask_app'].test_request_context():
        # Used for testing/debugging deprecated revision tables
        # add_to_revision_table(ctx)
        click.echo('Cleaning up revisions...')

        for table in REVISION_TABLES:
            clean_revision_tables(table)

        click.echo('Finished cleaning up revision tables.')
