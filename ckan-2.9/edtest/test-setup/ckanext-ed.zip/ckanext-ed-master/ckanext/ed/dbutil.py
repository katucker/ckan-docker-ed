import logging
from sqlalchemy import Table, Column, Integer, String, MetaData, Boolean, event

import ckan.model as model

log = logging.getLogger(__name__)


def init_survey_tables():
    metadata = MetaData()

    Table('survey_0_1', metadata,
          Column('package_id', String),
          Column('question_1', String),
          Column('question_2', String),
          Column('question_3', String))
    Table('survey_0_1_summary', metadata,
          Column('package_id', String),
          Column('helpful', Integer),
          Column('not_helpful', Integer),
          Column('never_used', Integer),
          Column('percentage_helpful', Integer))

    metadata.create_all(model.meta.engine)

def init_record_schedule():
    metadata = MetaData()
    record_schedule = Table('record_schedule', metadata,
            Column('ed_no', String),
            Column('schedule_title', String),
            Column('nara_disposition_authority', String))
    metadata.create_all(model.meta.engine)

def init_coordinator_tables():
    metadata = MetaData()
    Table('org_coordinators', metadata,
            Column('user', String),
            Column('org_list', String))
    metadata.create_all(model.meta.engine)

def init_notf_preferences_tables():
    metadata = MetaData()

    Table('notf_preferences', metadata,
            Column('user_id', String, primary_key=True, nullable=False),
            Column('data_profile_publishing_ready', Boolean, server_default="true"),
            Column('data_profile_stuck', Boolean, server_default="true"),
            Column('resource_publishing_ready', Boolean, server_default="true"),
            Column('resource_approval_process', Boolean, server_default="true"),
            Column('resource_excel_translation', Boolean, server_default="true"),
            Column('data_explorer_publishing_ready', Boolean, server_default="true"),
            Column('data_explorer_approval_process', Boolean, server_default="true"),
            Column('broken_links', Boolean, server_default="true")),
    metadata.create_all(model.meta.engine)

    connection = model.Session.connection()

    #   Adding default values to all users
    users_sql = 'SELECT "id" FROM "user";'

    result = connection.execute(users_sql)
    ids = result.fetchall()

    for id in ids:
        sql = """
            INSERT INTO "notf_preferences" (
                "user_id"
            )
            VALUES (
                %s
            ) ON CONFLICT DO NOTHING;"""

        connection.execute(sql, id[0])
    model.Session.commit()

@event.listens_for(model.User, 'after_insert')
def receive_after_insert(mapper, connection, target):
    id = target.id

    if id:
        sql = """
            INSERT INTO "notf_preferences" (
                "user_id"
            )
            VALUES (
                %s
            ) ON CONFLICT DO NOTHING;"""

        connection.execute(sql, id)



# function to add new column to existing table with a default Boolean value True
def add_column_to_table(column_name):
    connection = model.Session.connection()
    sql = """
        ALTER TABLE "notf_preferences" ADD COLUMN "{}" BOOLEAN DEFAULT TRUE;
        """.format(column_name)
    connection.execute(sql)
    model.Session.commit()



# function to create a new table containing users_id foreign key and a column to save json data
def create_user_default_packge_field():
    metadata = MetaData()
    Table("user_package_fields", metadata,
            Column('user_id', String, primary_key=True, nullable=False),
            Column('fields', String))
    metadata.create_all(model.meta.engine)
