import datetime
from urllib.parse import urlparse
import logging

from ckan.common import config
from sqlalchemy.sql import select, func
from sqlalchemy import MetaData

from ckan.lib.dictization.model_dictize import extras_dict_dictize, group_list_dictize, _get_members, tag_list_dictize, user_list_dictize

from ckan import model
import ckan.logic as logic
import ckan.plugins as plugins
import ckan.lib.helpers as h
import ckan.lib.dictization as d
import ckan.authz as authz
import ckan.lib.search as search
import ckan.lib.munge as munge
from bisect import bisect_right

log = logging.getLogger(__name__)


def group_dictize(group, context,
                  include_groups=True,
                  include_tags=True,
                  include_users=True,
                  include_extras=True,
                  packages_field='datasets',
                  **kw):
    '''
    Turns a Group object and related into a dictionary. The related objects
    like tags are included unless you specify it in the params.

    :param packages_field: determines the format of the `packages` field - can
    be `datasets`, `dataset_count` or None.
    '''
    assert packages_field in ('datasets', 'dataset_count', None)
    if packages_field == 'dataset_count':
        dataset_counts = context.get('dataset_counts', None)

    result_dict = d.table_dictize(group, context)
    result_dict.update(kw)

    result_dict['display_name'] = group.title or group.name

    if include_extras:
        result_dict['extras'] = extras_dict_dictize(
            group._extras, context)

    context['with_capacity'] = True

    if packages_field:
        def get_packages_for_this_group(group_, just_the_count=False):
            # Ask SOLR for the list of packages for this org/group
            q = {
                'facet': 'false',
                'rows': 0,
            }

            if group_.is_organization:
                q['fq'] = '(owner_org:"{0}" OR owner_suborg:"{0}")'.format(group_.id)
            else:
                q['fq'] = 'groups:"{0}"'.format(group_.name)

            # Allow members of organizations to see private datasets.
            if group_.is_organization:
                is_group_member = (context.get('user') and
                    authz.has_user_permission_for_group_or_org(
                        group_.id, context.get('user'), 'read'))
                if is_group_member:
                    q['include_private'] = True

            if not just_the_count:
                # Is there a packages limit in the context?
                try:
                    packages_limit = context['limits']['packages']
                except KeyError:
                    q['rows'] = 1000  # Only the first 1000 datasets are returned
                else:
                    q['rows'] = packages_limit

            search_context = dict((k, v) for (k, v) in context.items()
                                  if k != 'schema')
            search_results = logic.get_action('package_search')(search_context,
                                                                q)
            return search_results['count'], search_results['results']

        if packages_field == 'datasets':
            package_count, packages = get_packages_for_this_group(group)
            result_dict['packages'] = packages
        else:
            if dataset_counts is None:
                package_count, packages = get_packages_for_this_group(
                    group, just_the_count=True)
            else:
                # Use the pre-calculated package_counts passed in.
                facets = dataset_counts
                if group.is_organization:
                    package_count = facets['owner_org'].get(group.id, 0) + facets['suborganization'].get(group.id, 0)
                else:
                    package_count = facets['groups'].get(group.name, 0)

        result_dict['package_count'] = package_count

    if include_tags:
        # group tags are not creatable via the API yet, but that was(/is) a
        # future intention (see kindly's commit 5c8df894 on 2011/12/23)
        result_dict['tags'] = tag_list_dictize(
            _get_members(context, group, 'tags'),
            context)

    if include_groups:
        # these sub-groups won't have tags or extras for speed
        result_dict['groups'] = group_list_dictize(
            _get_members(context, group, 'groups'),
            context, include_groups=True)

    if include_users:
        result_dict['users'] = user_list_dictize(
            _get_members(context, group, 'users'),
            context)

    context['with_capacity'] = False

    if context.get('for_view'):
        if result_dict['is_organization']:
            plugin = plugins.IOrganizationController
        else:
            plugin = plugins.IGroupController
        for item in plugins.PluginImplementations(plugin):
            result_dict = item.before_view(result_dict)

    image_url = result_dict.get('image_url')
    result_dict['image_display_url'] = image_url
    if image_url and not image_url.startswith('http'):
        #munge here should not have an effect only doing it incase
        #of potential vulnerability of dodgy api input
        image_url = munge.munge_filename_legacy(image_url)
        result_dict['image_display_url'] = h.url_for_static(
            'uploads/group/%s' % result_dict.get('image_url'),
            qualified=True
        )
    return result_dict


def update_survey_results(survey_results):
    log.info('Updating survey tables: {}'.format(survey_results))
    survey = get_table('survey_0_1')
    survey_summary = get_table('survey_0_1_summary')
    id_col_name = 'package_id'
    id_col = getattr(survey.c, id_col_name)
    id_col = getattr(survey_summary.c, id_col_name)
    select_survey = select([func.count(id_col)])
    select_survey_summary = select([func.count(id_col)])
    connection = model.Session.connection()
    count = connection.execute(select_survey).fetchone()
    count_summary = connection.execute(select_survey_summary).fetchone()
    package_id = survey_results['package_id']
    question_1 = survey_results['question_1']
    question_2 = survey_results['question_2']
    question_3 = survey_results['question_3'].replace("'", "''")

    if count and count_summary:
        sql = """INSERT INTO "survey_0_1" (
            "package_id",
            "question_1",
            "question_2",
            "question_3") VALUES (%s, %s, %s, %s);"""

        connection.execute(
            sql, 
            package_id,
            question_1,
            question_2,
            question_3
        )
        log.info('Survey results updated successfully! '
                 'Updating survey summaries...')

        sql_survey_count = """SELECT COUNT("package_id") FROM "survey_0_1"
            WHERE "package_id" = %s AND "question_1" = 'Yes';
            """

        surveys_taken = int(connection.execute(sql_survey_count, package_id).first()[0])
        helpful = 1 if question_2 == 'Yes' else 0
        not_helpful = 1 if question_2 == 'No' else 0
        never_used = 1 if question_1 == 'No' else 0
        percentage_helpful = 100 if question_2 == 'Yes' else 0

        sql_exists = """SELECT COUNT("package_id") FROM
            "survey_0_1_summary" WHERE "package_id" = %s
            """
        package_exists = connection.execute(sql_exists, package_id).first()[0]

        if package_exists > 0:
            sql_1 = """SELECT COUNT("question_1") FROM "survey_0_1"
                WHERE "package_id" = %s AND "question_2" = 'Yes';
                """
            helpful = int(connection.execute(sql_1, package_id).first()[0])

            sql_2 = """SELECT COUNT("question_1") FROM "survey_0_1"
                WHERE "package_id" = %s AND "question_1" = 'No';
                """
            never_used = int(connection.execute(sql_2, package_id).first()[0])

            sql_3 = """SELECT COUNT("question_2") FROM "survey_0_1"
                WHERE "package_id" = %s AND "question_2" = 'No';
                """
            not_helpful = int(connection.execute(sql_3, package_id).first()[0])

            percentage_helpful = int(round((helpful / surveys_taken) * 100))

            sql_update_summary = """UPDATE "survey_0_1_summary" SET
                "package_id" = %s,
                "helpful" = %s,
                "not_helpful" = %s,
                "never_used" = %s,
                "percentage_helpful" = %s WHERE "package_id" = %s;
                """

            connection.execute(
                sql_update_summary, 
                package_id,
                helpful,
                not_helpful,
                never_used,
                percentage_helpful,
                package_id
            )
            model.Session.commit()
        else:
            sql_update_summary = """INSERT INTO "survey_0_1_summary" (
                "package_id",
                "helpful",
                "not_helpful",
                "never_used",
                "percentage_helpful") VALUES (%s, %s, %s, %s, %s);
                """

            connection.execute(
                sql_update_summary, 
                package_id,
                helpful,
                not_helpful,
                never_used,
                percentage_helpful
            )
            model.Session.commit()
        log.info('The survey summary has been updated.')
    else:
        log.error('The survey tables haven\'t been created yet.'
                  'Please create the tables before enabling the survey.')


def retrieve_survey_summary(id):
    survey_summary = get_table('survey_0_1_summary')
    id_col_name = 'package_id'
    id_col = getattr(survey_summary.c, id_col_name)
    select_survey_summary = select([func.count(id_col)])
    connection = model.Session.connection()
    count_summary = connection.execute(select_survey_summary).fetchone()
    summary = None

    if count_summary:
        sql = """SELECT * FROM "survey_0_1_summary" WHERE "package_id" = %s;"""

        summary_execution = connection.execute(sql, id)

        try:
            summary = {
                key: value for key, value in summary_execution.fetchone().items()
            }

            log.info('Successfully retrieved the survey summary for id: {}'
                     .format(id))
        except AttributeError:
            log.info('No survey summary data yet for id: {}'
                     .format(id))

    return summary


def get_table(name):
    meta = MetaData()
    meta.reflect(bind=model.meta.engine)
    table = meta.tables[name]
    return table


def remove_hierarchy_relationships(id):
    connection = model.Session.connection()

    sql = """
        UPDATE public.member SET "state" = 'deleted' WHERE "table_id" = %s;
    """

    try:
        connection.execute(sql, id)
        model.Session.commit()
    except Exception as e:
        log.error('Unable to remove hierarchy relationships: {}'.format(e))


class GroupTreeNode(dict):
    '''Represents a group in a tree, used when rendering the tree.
    Is a dict, with links to child GroupTreeNodes, so that it is already
    'dictized' for output from the logic layer.
    '''
    def __init__(self, group_dict):
        dict.__init__(self)
        self.update(group_dict)
        self['highlighted'] = False
        self['children'] = []
        # self._children_titles has a 1:1 relationship with values in
        # self.['children'], and is used to help keep them sorted by title
        self._children_titles = []

    def add_child_node(self, child_node):
        '''Adds the child GroupTreeNode to this node, keeping the children
        in alphabetical order by title.
        '''
        title = child_node['title']
        insert_index = bisect_right(self._children_titles, title)
        self['children'].insert(insert_index, child_node)
        self._children_titles.insert(insert_index, title)

    def highlight(self):
        '''Flag this group to indicate it should be shown highlighted
        when rendered.'''
        self['highlighted'] = True


def grouptree_dictize(group):
    '''Convert a Group object into a dict suitable for GroupTreeNode
    Much simpler and quicker to do this than run than the full package_show.
    '''
    return {'id': group.id,
            'name': group.name,
            'title': group.title,
            'type': group.type}


def get_record_scheduledb():
    connection = model.Session.connection()
    sql = """SELECT * FROM "record_schedule"; """

    records = connection.execute(sql)
    record_result = list(set(["{0}: {1}; {2}".format(record[0], record[1], record[2]) for record in records]))
    record_rsult = sorted([dict(name=i, value=i) for i in record_result], key=lambda k: k['name'])
    
    log.info('Successfully retrieved record schedules')

    return record_rsult


def get_package_child(object_id):
    connection = model.Session.connection()
    sql = """SELECT * FROM "package_relationship" 
          WHERE "subject_package_id" = %s AND "state" = 'active' 
          """
    pkg_rel = connection.execute(sql, object_id)
    rows = pkg_rel.fetchall()
    rslt_dict = []
    #for rel in rows:
    #    data_dict = {}
    #    data_dict['subject'] = rel[1]
    #    data_dict['object'] = rel[2]
    #    data_dict['type'] = rel[3]
    #    data_dict['order'] = rel[6]
    #    rslt_dict.append(data_dict)
    # Use dict comprehension instead
    rslt_dict = [
        {
            'subject': rel[1],
            'object': rel[2],
            'type': rel[3],
            'order': rel[6]
        } for rel in rows
    ]

    connection = model.Session.connection()
    sql2 = """SELECT * FROM "package_relationship" 
          WHERE "object_package_id" = %s AND "state" = 'active' 
          """
    pkg_rel = connection.execute(sql2, object_id)
    rows = pkg_rel.fetchall()
    swap_types = model.PackageRelationship.forward_to_reverse_type
    log.warn(swap_types)
    #for rel in rows:
    #    data_dict = {}
    #    data_dict['subject'] = rel[2]
    #    data_dict['object'] = rel[1]
    #    data_dict['type'] = swap_types(rel[3])
    #    data_dict['order'] = rel[6]
    #    rslt_dict.append(data_dict)
    # Use dict comprehension instead
    rslt_dict += [
        {
            'subject': rel[2],
            'object': rel[1],
            'type': swap_types(rel[3]),
            'order': rel[6]
        } for rel in rows
    ]
    
    log.info('Successfully retrieved data')

    return rslt_dict


def update_package_child(object_id, subject_id, level):
    connection = model.Session.connection()
    sql = """UPDATE "package_relationship"
          SET "order" = %s
          WHERE "subject_package_id" = %s 
          AND "object_package_id" = %s 
          """

    connection.execute(sql, level, subject_id, object_id)
    model.Session.commit()
    log.info('Package relationship updated successfully')

def update_package_owner(new_owner_id, package_id):
    """
    Updates the owner of a package and its documentation

    package_id: The id of the package
    new_owner_id: The id of the new owner
    """
    connection = model.Session.connection()
    sql = "UPDATE package SET creator_user_id = %s where id = %s;"
    connection.execute(sql, new_owner_id, package_id)
    model.Session.commit()
    search.rebuild(package_id)
    log.info("The owner of package {} has been successfully changed to {}".format(
        package_id, new_owner_id))

def update_coordinator(user, organization):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "org_coordinators" WHERE "user" = %s;
    """

    result = connection.execute(sql, user)
    rows = result.fetchall()


    
    if len(rows) == 0:
        sql = """
            INSERT INTO "org_coordinators" ("user", "org_list") VALUES (%s, %s);
        """

        connection.execute(sql, user, organization)
        model.Session.commit()

        log.info('Successfully added coordinator: {}'.format(user))
    else:
        log.info('Coordinator already exists: {}'.format(user))

        sql = """
            SELECT "org_list" FROM "org_coordinators" WHERE "user" = %s;
        """

        result = connection.execute(sql, user)
        rows = result.fetchall()
        org_list = rows[0][0]

        if not org_list or organization not in org_list.split(','):
            org_list = org_list + ',' + organization if org_list else organization

            sql = """
                UPDATE "org_coordinators" SET "org_list" = %s WHERE "user" = %s;
            """

            connection.execute(sql, org_list, user)
            model.Session.commit()

            log.info('Successfully updated coordinator: {}'.format(user))
        else:
            log.info('Coordinator already has this organization: {}'.format(user))

def remove_coordinator(user, organization, remove_all=False):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "org_coordinators" WHERE "user" = %s;
    """

    result = connection.execute(sql, user)
    rows = result.fetchall()

    if len(rows) == 0:
        log.info('Coordinator does not exist: {}'.format(user))
    else:
        sql = """
            SELECT "org_list" FROM "org_coordinators" WHERE "user" = %s;
        """

        result = connection.execute(sql, user)
        rows = result.fetchall()
        org_list = rows[0][0]

        if not org_list or len(org_list) == 0:
            log.info('Coordinator does not exist: {}'.format(user))
        else:
            org_list = org_list.split(',')
            org_list.remove(organization)
            org_list = ','.join(org_list)

            sql = """
                UPDATE "org_coordinators" SET "org_list" = %s WHERE "user" = %s;
            """

            connection.execute(sql, org_list, user)
            model.Session.commit()

            if remove_all is True:
                connection = model.Session.connection()
                log.info('Coordinator name has changed, removing old row: {}'.format(user))

                sql = """
                    DELETE FROM "org_coordinators" WHERE "user" = %s;
                """

                connection.execute(sql, user)
                model.Session.commit()

            log.info('Successfully removed coordinator: {}'.format(user))

def is_coordinator(user, organization=None):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "org_coordinators" WHERE "user" = %s;
    """

    result = connection.execute(sql, user)
    rows = result.fetchall()

    if len(rows) == 0:
        return False
    else:
        sql = """
            SELECT "org_list" FROM "org_coordinators" WHERE "user" = %s;
        """

        result = connection.execute(sql, user)
        rows = result.fetchall()
        org_list = rows[0][0]

        if not org_list or len(org_list) == 0:
            return False
        else:
            org_list = org_list.split(',')

            if org_list and (organization is None or organization in org_list):
                return True
            else:
                return False

def get_coordinator_orgs(user):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "org_coordinators" WHERE "user" = %s;
    """

    result = connection.execute(sql, user)
    rows = result.fetchall()

    if len(rows) == 0:
        return []
    else:
        sql = """
            SELECT "org_list" FROM "org_coordinators" WHERE "user" = %s;
        """

        result = connection.execute(sql, user)
        rows = result.fetchall()
        org_list = rows[0][0]

        if org_list is None:
            return []
        else:
            org_list = org_list.split(',')

            return org_list

def clean_revision_tables(table):
    """
    Cleans the revision tables from the database
    """
    try:
        connection = model.Session.connection()
        sql = """
            DELETE FROM "{}";
        """.format(table)   #   nosec

        connection.execute(sql)
        model.Session.commit()

        log.info('Table "{}" cleaned successfully.'.format(table))

    except Exception as e:
        model.Session.rollback()

        log.error('Table "{}" does not exist. Proceeding to next table...'.format(table))

# # WARNING: ONLY RUN ON LOCAL INSTANCES. This can be used to test the revision tables purge fix
# def add_to_revision_table(ctx, table='package_relationship_revision'):
#     import uuid
#     from ckan.plugins import toolkit
#
#     with ctx.meta['flask_app'].test_request_context():
#         packages = toolkit.get_action('package_search')({'ignore_auth': True}, {})['results']
#         package_ids = [package['id'] for package in packages]
#         # Get all id, subject_package_id, object_package_id, type, revision_id, continuity_id, state, order from package_relationship
#         connection = model.Session.connection()
#         sql = """
#             SELECT id, subject_package_id, object_package_id, type, state FROM package_relationship;
#         """
#
#         result = connection.execute(sql)
#         rows = result.fetchall()
#         pkg_dicts = []
#         for row in rows:
#             pkg_dicts.append({
#                 'id': row[0],
#                 'subject_package_id': row[1],
#                 'object_package_id': row[2],
#                 'type': row[3],
#                 'state': row[4]
#             })
#
#         for pkg_dict in pkg_dicts:
#             connection = model.Session.connection()
#             # First insert into the main revision table: id, timestamp, author, message, state, approved_timestamp
#             revision_id = str(uuid.uuid4())
#             sql = """
#                 INSERT INTO revision (id, timestamp, author, message, state, approved_timestamp)
#                 VALUES ('{}', now(), 'admin', 'test', 'active', now());
#             """.format(revision_id)
#             connection.execute(sql)
#             model.Session.commit()
#
#             connection = model.Session.connection()
#             # Insert the following into the revision table: id, subject_package_id, object_package_id, type, comment, revision_id, continuity_id, state, expired_id, revision_timestamp, expired_timestamp, current
#             sql = """
#                 INSERT INTO "{}" (id, subject_package_id, object_package_id, type, comment, revision_id, continuity_id, state, expired_id, revision_timestamp, expired_timestamp, current)
#                 VALUES ('{}', '{}', '{}', '{}', '', '{}', '{}', '{}', '', now(), '9999-12-31 00:00:00', true);
#             """.format(table, str(uuid.uuid4()), pkg_dict['subject_package_id'], pkg_dict['object_package_id'], pkg_dict['type'], revision_id, pkg_dict['id'], pkg_dict['state'])
#
#             connection.execute(sql)
#             model.Session.commit()

def get_notf_preferences(user_id):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "notf_preferences" WHERE "user_id" = %s;
    """

    result = connection.execute(sql, user_id)
    rows = result.fetchall()

    return rows

def get_notf_preference(preference, user_id):
    connection = model.Session.connection()

    sql = """
        SELECT * FROM "notf_preferences" WHERE "user_id" = %s;
    """

    result = connection.execute(sql, user_id)
    rows = result.fetchall()

    return rows[0][preference] if len(rows) > 0 else False

def update_notf_preferences(user_id, notf_preferences=None):
    if not user_id:
        return

    connection = model.Session.connection()

    rows = get_notf_preferences(user_id)

    notf_cols = [
        'data_profile_publishing_ready',
        'data_profile_stuck',
        'resource_publishing_ready',
        'resource_approval_process',
        'resource_excel_translation',
        'data_explorer_publishing_ready',
        'data_explorer_approval_process',
        'broken_links',
        'data_profile_bulk_update'
    ]

    notf_dict = dict.fromkeys(notf_cols)

    for key in notf_dict:
        log.info(key)
        log.info(notf_preferences)
        notf_dict[key] = 'true' if key in notf_preferences else 'false'


    if len(rows) == 0:

        sql = """
            INSERT INTO "notf_preferences" (
                "user_id",
                "data_profile_publishing_ready",
                "data_profile_stuck",
                "resource_publishing_ready",
                "resource_approval_process",
                "resource_excel_translation",
                "data_explorer_publishing_ready",
                "data_explorer_approval_process",
                "broken_links",
                "data_profile_bulk_update"
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            );
        """

        connection.execute(
            sql, 
            user_id,
            notf_dict["data_profile_publishing_ready"],
            notf_dict["data_profile_stuck"],
            notf_dict["resource_publishing_ready"], 
            notf_dict["resource_approval_process"], 
            notf_dict["resource_excel_translation"], 
            notf_dict["data_explorer_publishing_ready"], 
            notf_dict["data_explorer_approval_process"], 
            notf_dict["broken_links"], 
            notf_dict["data_profile_bulk_update"])
        model.Session.commit()

        log.info('Successfully created notification preferences for user: {}'.format(user_id))
    else:
        log.info('Updating email preferences for user: {}'.format(user_id))

        values_list = list(notf_dict.values())

        sql = """
            UPDATE
                "notf_preferences"
            SET
                "data_profile_publishing_ready" = %s,
                "data_profile_stuck" = %s,
                "resource_publishing_ready" = %s,
                "resource_approval_process" = %s,
                "resource_excel_translation" = %s,
                "data_explorer_publishing_ready" = %s,
                "data_explorer_approval_process" = %s,
                "broken_links" = %s,
                "data_profile_bulk_update" = %s 
            WHERE
                "user_id" = %s
            ;
        """

        connection.execute(
            sql, 
            notf_dict["data_profile_publishing_ready"],
            notf_dict["data_profile_stuck"],
            notf_dict["resource_publishing_ready"], 
            notf_dict["resource_approval_process"], 
            notf_dict["resource_excel_translation"], 
            notf_dict["data_explorer_publishing_ready"], 
            notf_dict["data_explorer_approval_process"], 
            notf_dict["broken_links"], 
            notf_dict["data_profile_bulk_update"],
            user_id)

        model.Session.commit()

        log.info('Successfully updated email preferences for user: {}'.format(user_id))


def get_user_package_fields(user_id):
    connection = model.Session.connection()

    sql = """
        SELECT fields FROM "user_package_fields" WHERE "user_id" = %s;
    """

    result = connection.execute(sql, user_id)
    rows = result.fetchone()

    if rows:
        return rows[0]
    return rows

def set_user_package_fields(data_dict):
    connection = model.Session.connection()

    user_id = data_dict['user_id']
    rows = get_user_package_fields(user_id)

    fields = data_dict['fields']

    if rows is None:

        sql = """
            INSERT INTO "user_package_fields" (
                "user_id",
                "fields"
                )
                VALUES (
                    %s,
                    %s
                );
        """

        connection.execute(sql, user_id, fields)
        model.Session.commit()

        log.info('Successfully created user package fields for user: {}'.format(user_id))
    else:
        log.info('Updating user package fields for user: {}'.format(user_id))

        fields = data_dict['fields']

        sql = """
            UPDATE
                "user_package_fields"
            SET
                "fields" = %s
            WHERE
                "user_id" = %s
            ;
        """

        connection.execute(sql, fields, user_id)
        model.Session.commit()

        log.info('Successfully updated user package fields for user: {}'.format(user_id))