import json
import os
from flask import Flask

from ckanext.ed.core_activity_streams import activity_stream_string_functions, activity_snippet_functions
from ckan.lib.plugins import DefaultTranslation, DefaultOrganizationForm
import ckan.lib.plugins as lib_plugins
import ckan.plugins as plugins
import ckan.plugins.toolkit as toolkit
import ckan.logic.schema as ckan_schema
import ckan.logic as logic
from ckan.common import g

from ckanext.harvest.plugin import Harvest as HarvestPlugin

from ckanext.ed import actions, helpers, validators
from ckanext.ed import actions as ed_actions
from ckanext.ed import activity_streams as ed_activity_streams
from ckanext.ed.mailer import mail_data_explorer_to_sysadmins, mail_resource_to_sysadmins
from ckanext.ed.blueprints import (
    organization_blueprint, ed_user_blueprint,
    ed_datajson_blueprint, ed_harvest_blueprint, ed_api_blueprint,
    ed_home_blueprint, ed_group_blueprint, ed_workflow_activity_blueprint,
    ed_tags_blueprint, ed_survey_blueprint, ed_roles_blueprint,
    ed_group_admin_blueprint, ed_forgot_password_blueprint,
    ed_collections_blueprint, ed_approval_workflow_blueprint,
    ed_data_explorer_blueprint, ed_source_blueprint, ed_user_blueprint,
    ed_dataset_blueprint, ed_documentation_blueprint, ed_dashboard
)
from ckanext.ed.format_converters import translate2csv
from ckanext.ed.commands.edcli import edcli
import logging
log = logging.getLogger(__name__)

app = Flask(__name__)



class EDPlugin(plugins.SingletonPlugin, DefaultTranslation, toolkit.DefaultDatasetForm):
    plugins.implements(plugins.IConfigurer, inherit=True)
    plugins.implements(plugins.ITemplateHelpers)
    plugins.implements(plugins.ITranslation)
    plugins.implements(plugins.IFacets, inherit=True)
    plugins.implements(plugins.IActions)
    plugins.implements(plugins.IValidators)
    plugins.implements(plugins.IPackageController, inherit=True)
    plugins.implements(plugins.IDatasetForm)
    plugins.implements(plugins.IBlueprint)
    plugins.implements(plugins.IResourceController, inherit=True)
    plugins.implements(plugins.IClick)


    def get_commands(self):
        return [edcli]

    def after_create(self, context, resource):
        # New resources should always be at the top of the list (position 0)
        try:
            pkg = toolkit.get_action('package_show')(
                context, {
                    'id': resource.get('package_id'),
                    'name_or_id': resource.get('package_id')
                }
            )
            pkg_resources = pkg.get('resources', [])
            updated_resources = []
            resource_count = len(pkg_resources)

            if resource_count > 0:
                resource_count -= 1
                new_resource = pkg_resources[resource_count]
                new_resource['position'] = 0
                updated_resources.append(new_resource)

                for pkg_resource in pkg_resources[:-1]:
                    pkg_resource['position'] += 1
                    updated_resources.append(pkg_resource)

                pkg['resources'] = updated_resources
                toolkit.get_action('package_patch')(context, pkg)

        except Exception as e:
            log.error(
                '{}\n'
                '\nResource Name: {}\n'
                'Resource ID: {}\n'
                'Package ID: {}\n'
                .format(
                    str(e),
                    resource.get('name'),
                    resource.get('id'),
                    resource.get('package_id')
                )
            )

    # IBlueprint
    def get_blueprint(self):
        return [
            organization_blueprint,
            ed_user_blueprint,
            ed_datajson_blueprint,
            ed_harvest_blueprint,
            ed_api_blueprint,
            ed_home_blueprint,
            ed_group_blueprint,
            ed_workflow_activity_blueprint,
            ed_tags_blueprint,
            ed_survey_blueprint,
            ed_roles_blueprint,
            ed_group_admin_blueprint,
            ed_forgot_password_blueprint,
            ed_approval_workflow_blueprint,
            ed_user_blueprint,
            ed_dataset_blueprint,
            ed_source_blueprint,
            ed_collections_blueprint,
            ed_documentation_blueprint,
            ed_data_explorer_blueprint,
            ed_dashboard
        ]

    # ITemplateHelpers
    def get_helpers(self):
        '''
        Define custom helpers (or override existing ones).
        Available as h.{helper-name}() in templates.
        '''
        return {
            'ed_get_groups': helpers.get_groups,
            'ed_is_admin': helpers.is_admin,
            'ed_is_editor': helpers.is_editor,
            'ed_get_recently_updated_datasets': helpers.get_recently_updated_datasets,
            'ed_get_most_popular_datasets': helpers.get_most_popular_datasets,
            'ed_get_total_views_for_dataset': helpers.get_total_views_for_dataset,
            'ed_get_pending_datasets': helpers.get_pending_datasets,
            'quality_mark' : helpers.quality_mark,
            'get_org_for_package' : helpers.get_org_for_package,
            'alphabetize_dict' : helpers.alphabetize_dict,
            'get_any': helpers.get_any,
            'get_facet_items_dict': helpers.get_facet_items_dict,
            'get_facet_all_items_dict': helpers.get_facet_all_items_dict,
            'programs_list': helpers.get_programs_list,
            'access_level': helpers.get_access_level,
            'get_publisher': helpers.get_publisher,
            'get_collections': helpers.get_collections,
            'get_dataset_collections': helpers.get_dataset_collections,
            'get_collections_list': helpers.get_collections_list,
            'collection_datasets_string': actions.collection_datasets_string,  # located in actions due to dependency fix
            'filter_collections': helpers.filter_collections,
            'filter_attribute': helpers.filter_attribute,
            'get_update_frequencies': helpers.update_frequencies,
            'get_package_extra_field': helpers.get_package_extra_field,
            'filter_categories': helpers.filter_categories,
            'get_level_of_data_values': helpers.get_level_of_data_values,
            'get_dataset_for_documentation': helpers.get_dataset_for_documentation,
            'get_organization': helpers.get_organization,
            'get_collection_for_documentation': helpers.get_dataset_for_documentation,
            'get_documentation_parent': helpers.get_documentation_parent,
            'get_dataset_collections_json': helpers.get_dataset_collections_json,
            'access_to_link_resources': helpers.access_to_link_resources,
            'get_organizations': helpers.get_organizations,
            'get_publishers': helpers.get_publishers,
            'get_suborganizations': helpers.get_suborganizations,
            'publishers_available_to_the_user': helpers.publishers_available_to_the_user,
            'check_access_to_create_collections': helpers.check_access_to_create_collections,
            'group_list_for_source':  helpers.group_list_for_harvest_source,
            'group_count_for_source': helpers.group_count_for_harvest_source,
            'get_config_value': helpers.get_config_value,
            'package_count_for_source': helpers.package_count_for_source,
            'package_list_for_source': helpers.package_list_for_source,
            'get_relationship_parent_identifiers': helpers.get_relationship_parent_identifiers,
            'get_relationship_parent': helpers.get_relationship_parent,
            'get_relationship_siblings': helpers.get_relationship_siblings,
            'get_relationship_children': helpers.get_relationship_children,
            'get_translated_from': helpers.get_translated_from,
            'validate_survey_data': helpers.validate_survey_data,
            'guess_mimetypes': helpers.guess_mimetypes,
            'get_program_codes': helpers.get_program_codes,
            'get_data_qualities': helpers.get_data_qualities,
            'get_harvested_data_quality': helpers.get_harvested_data_quality,
            'get_harvested_system_of_records': helpers.get_harvested_system_of_records,
            'get_primary_it_investment_uii': helpers.get_primary_it_investment_uii,
            'get_current_frequency_name': helpers.get_current_frequency_name,
            'get_relationship_depends_on': helpers.get_relationship_depends_on,
            'get_relationship_dependencies_of': helpers.get_relationship_dependencies_of,
            'convert_relationship_string_to_list': helpers.convert_relationship_string_to_list,
            'convert_copy_dict': helpers.convert_copy_dict,
            'get_relationship_has_derivation': helpers.get_relationship_has_derivation,
            'get_relationship_derives_from': helpers.get_relationship_derives_from,
            'get_sorted_relationships': helpers.get_sorted_relationships,
            'update_copy_dict': helpers.update_copy_dict,
            'get_bureau_codes': helpers.get_bureau_codes,
            'get_dataset_data': helpers.get_dataset_data,
            'get_record_schedule': helpers.get_record_schedule,
            'filter_out_bureaucode': helpers.filter_out_bureaucode,
            'bureau_code_auto_lookup': helpers.bureau_code_auto_lookup,
            'get_sources': helpers.get_sources,
            'get_sources_list': helpers.get_sources_list,
            'get_source_types': helpers.get_source_types,
            'get_source_by_name': helpers.get_source_by_name,
            'get_dataset_source': helpers.get_dataset_source,
            'get_source_resources_data': helpers.get_source_resources_data,
            'get_resource_source': helpers.get_resource_source,
            'get_source_resources_data_list':helpers.get_source_resources_data_list,
            'get_package_hierarchy_html': helpers.get_package_hierarchy_html,
            'get_data_explorers': helpers.get_data_explorers,
            'get_group_activity_list': helpers.get_group_activity_list,
            'get_resource_data': helpers.get_resource_data,
            'get_package_data': helpers.get_package_data,
            'get_announcement_values': helpers.get_announcement_values,
            'get_child_package': helpers.get_child_package,
            'get_roles': helpers.get_roles,
            'get_orgs_with_roles': helpers.get_orgs_with_roles,
            'check_order': helpers.check_order,
            'render_markdown': helpers.render_markdown,
            'get_user_by_id': helpers.get_user_by_id,
            'get_organization_editors': helpers.get_organization_editors,
            'get_sysadmins': helpers.get_sysadmins,
            'get_group_owner': helpers.get_group_owner,
            'get_all_users': helpers.get_all_users,
            'get_all_admins': helpers.get_all_admins,
            'get_admin_users_orgs': helpers.get_admin_users_orgs,
            'get_all_other_users': helpers.get_all_other_users,
            'get_all_user_groups': helpers.get_all_user_groups,
            'get_group_dict': helpers.get_group_dict,
            'filter_file': helpers.filter_file,
            'is_coordinator': helpers.is_coordinator,
            'get_coordinator_orgs': helpers.get_coordinator_orgs,
            'get_private_packages': helpers.get_private_packages,
            'get_draft_packages': helpers.get_draft_packages,
            'get_notf_preferences': helpers.get_notf_preferences,
            'get_notf_preference': helpers.get_notf_preference,
            'is_in_plugins': helpers.is_in_plugins,
            'filter_activity_stream': helpers.filter_activity_stream
        }

    # IActions
    def get_actions(self):
        '''
        Define custom functions (or override existing ones).
        Available via API /api/action/{action-name}
        '''
        return {
            'ed_prepare_zip_resources': actions.prepare_zip_resources,
            'ed_scraping_dashboard': actions.dashboard,
            'package_show': actions.package_show,
            'package_create': actions.package_create,
            'package_update': actions.package_update,
            'package_search': actions.package_search,
            'package_activity_list': actions.package_activity_list,
            'resource_update': actions.resource_update,
            'resource_search': actions.resource_search,
            'dashboard_activity_list': actions.dashboard_activity_list,
            'group_activity_list': actions.group_activity_list,
            'recently_changed_packages_activity_list': actions.recently_changed_packages_activity_list,
            'package_autocomplete': actions.package_autocomplete,
            # 'organization_show': actions.organization_show,
            # 'organization_member_create': actions.organization_member_create,
            # 'organization_member_delete': actions.organization_member_delete,
            'user_update': actions.user_update,
            'ed_harvest_source_clear': actions.harvest_source_clear,
            'ed_organization_delete': ed_actions.ed_organization_delete,
            'update_relationship_dependencies': ed_actions.update_relationship_dependencies,
            # 'organization_create': actions.organization_create
            'get_record_schedule':ed_actions.get_record_schedule,
            'package_hierarchy': ed_actions.get_full_package_hierarchy,
            'package_hierarchy_html': ed_actions.get_package_hierarchy_html,
            'group_activity_list_html': ed_actions.group_activity_list_html,
            'config_option_update': ed_actions.config_option_update,
            'package_relationship_list_db': ed_actions.package_relationship_list_db,
            'package_update_relationship_db':ed_actions.package_update_relationship_db,
            'package_update_multiple_relationship': ed_actions.package_update_multiple_relationship,
            'create_user_default_fields': ed_actions.create_user_default_fields,
            'get_user_default_fields': ed_actions.get_user_default_fields
        }

    def create_package_schema(self):
        # let's grab the default schema in our plugin
        schema = super(EDPlugin, self).create_package_schema()
        options = {
            'default': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_converter('convert_to_extras')],
            'ignore_missing': [toolkit.get_validator('ignore_missing')],
            'default_required': [toolkit.get_validator('not_empty')],
            'default_unicode_required': [toolkit.get_validator('not_empty')],
            'extras_required': [toolkit.get_validator('not_empty'),
                        toolkit.get_converter('convert_to_extras')],
        }
        # our custom field
        schema.update({
            'notes': options['ignore_missing'],
            'owner_org': options['ignore_missing'],
            'owner_suborg': options['default'],
            'private': [
                toolkit.get_validator('ignore_missing'),  # not_empty fails with "False" value
                toolkit.get_validator('datasets_with_no_organization_cannot_be_private')],
            'author': options['ignore_missing'],
            'author_email': [
                toolkit.get_validator('ignore_missing'),
                toolkit.get_validator('unicode_safe'),
                toolkit.get_validator('email_validator')],
            'update_frequency': options['default'],
            'programs': options['default'],
            'program_code': options['default'],
            'bureau_code': options['default'],
            'rights': options['default'],
            'access_level': options['default'],
            'start_date': options['default'],
            'end_date': options['default'],
            'scraped_from': options['default'],
            'amended_by_user': options['default'],
            'level_of_data': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_converter('convert_to_tags')('level_of_data')],
            'spatial': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_validator('create_spatial_tags_if_not_exist'),
                        toolkit.get_validator('spatial_tag_name_validator'),
                        toolkit.get_converter('convert_to_tags')('spatial')],
            'data_dictionary_pkg': options['default'],
            'data_dictionary_pkg_format': options['default'],
            'data_dictionary_pkg_mimetype': options['default'],
            'data_quality': options['default'] + [toolkit.get_validator('boolean_validator')],
            'system_of_records': options['default'],
            'primary_it_investment_uii': options['default'],
            'record_schedule' : options['default'],
            'indraft': options['default'],
            'resources_indraft': options['default'],
            'resource_index': options['default'],
        })
        schema['resources'].update({
                'data_dictionary_res' : options['ignore_missing'],
                'data_dictionary_res_format' : options['ignore_missing'],
                'data_dictionary_res_mimetype': options['ignore_missing'],
                'approval_status': options['ignore_missing'],
                'ed_source': options['ignore_missing']
        })
        return schema


    def update_package_schema(self):
        schema = super(EDPlugin, self).update_package_schema()
        options = {
            'default': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_converter('convert_to_extras')],
            'ignore_missing': [toolkit.get_validator('ignore_missing')],
            'default_required': [toolkit.get_validator('not_empty')],
            'default_unicode_required': [toolkit.get_validator('not_empty')],
            'extras_required': [toolkit.get_validator('not_empty'),
                        toolkit.get_converter('convert_to_extras')],
        }
        # our custom field
        schema.update({
            'notes': options['ignore_missing'],
            'owner_org': options['ignore_missing'],
            'owner_suborg': options['default'],
            'private': [
                toolkit.get_validator('ignore_missing'),  # not_empty fails with "False" value
                toolkit.get_validator('boolean_validator'),
                toolkit.get_validator('datasets_with_no_organization_cannot_be_private')],
            'author': options['ignore_missing'],
            'author_email': [
                toolkit.get_validator('ignore_missing'),
                toolkit.get_validator('unicode_safe'),
                toolkit.get_validator('email_validator')],
            'update_frequency': options['default'],
            'programs': options['default'],
            'program_code': options['default'],
            'bureau_code': options['default'],
            'rights': options['default'],
            'access_level': options['default'],
            'level_of_data': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_converter('convert_to_tags')('level_of_data')],
            'spatial': [toolkit.get_validator('ignore_missing'),
                        toolkit.get_validator('spatial_tag_name_validator'),
                        toolkit.get_validator('create_spatial_tags_if_not_exist'),
                        toolkit.get_converter('convert_to_tags')('spatial')],
            'start_date': options['default'],
            'end_date': options['default'],
            'scraped_from': options['default'],
            'amended_by_user': options['default'],
            'data_dictionary_pkg': options['default'],
            'data_dictionary_pkg_format': options['default'],
            'data_dictionary_pkg_mimetype': options['default'],
            'data_quality': options['default'] + [toolkit.get_validator('boolean_validator')],
            'system_of_records': options['default'],
            'primary_it_investment_uii': options['default'],
            'record_schedule' : options['default'],
            'ed_source': options['default'],
            'indraft': options['default'],
            'resources_indraft': options['default'],
            'resource_index': options['default'],
        })
        schema['resources'].update({
                'data_dictionary_res' : options['ignore_missing'],
                'data_dictionary_res_format' : options['ignore_missing'],
                'data_dictionary_res_mimetype': options['ignore_missing'],
                'approval_status': options['ignore_missing'],
                'ed_source': options['ignore_missing']
        })
        return schema


    def show_package_schema(self):
        schema = super(EDPlugin, self).show_package_schema()
        options = {
            'default': [toolkit.get_converter('convert_from_extras'),
                        toolkit.get_validator('ignore_missing')],
            'ignore_missing': [toolkit.get_validator('ignore_missing')],
        }
        schema.update({
            'owner_suborg': options['default'],
            'update_frequency': options['default'],
            'level_of_data': [toolkit.get_converter('convert_from_tags')('level_of_data'),
                        toolkit.get_validator('ignore_missing')],
            'spatial': [toolkit.get_converter('convert_from_tags')('spatial'),
                        toolkit.get_validator('ignore_missing')],
            'programs': options['default'],
            'program_code': options['default'],
            'bureau_code': options['default'],
            'rights': options['default'],
            'access_level': options['default'],
            'start_date': options['default'],
            'end_date': options['default'],
            'scraped_from': options['default'],
            'amended_by_user': options['default'],
            'data_dictionary_pkg': options['default'],
            'data_dictionary_pkg_format': options['default'],
            'data_dictionary_pkg_mimetype': options['default'],
            'data_quality': options['default'] + [toolkit.get_validator('boolean_validator')],
            'system_of_records': options['default'],
            'primary_it_investment_uii': options['default'],
            'record_schedule' : options['default'],
            'ed_source': options['default'],
            'indraft': options['default'],
            'resources_indraft': options['default'],
            'resource_index': options['default'],
        })
        schema['resources'].update({
                'data_dictionary_res' : options['ignore_missing'],
                'data_dictionary_res_format' : options['ignore_missing'],
                'data_dictionary_res_mimetype' : options['ignore_missing'],
                'approval_status': options['ignore_missing'],
                'ed_source': options['ignore_missing']
        })

        return schema


    def is_fallback(self):
        # Return True to register this plugin as the default handler for
        # package types not handled by any other IDatasetForm plugin.
        return True

    def package_types(self):
        # This plugin doesn't handle any special package types, it just
        # registers itself as the default (above).
        return []


    # IPackageController
    def before_index(self, pkg):

        data_dict = json.loads(pkg['data_dict'])

        try:
            # Get vocabulary IDs if present
            spatial_vocab_id = logic.get_action('vocabulary_show')({}, {"id": 'spatial'})['id']
            level_of_data_vocab_id = logic.get_action('vocabulary_show')({}, {"id": 'level_of_data'})['id']
        except:
            print("Failed to get a vocabulary, maybe you need to run the create_ed_vocabularies command?")
            # No return yet, we need to add more stuff to the dict

        # Add spatial
        if spatial_vocab_id:
            spatial_tags = [t['name'] for t in data_dict['tags'] if t['vocabulary_id'] == spatial_vocab_id]
            pkg['vocab_spatial'] = spatial_tags

        # Add level of data
        if level_of_data_vocab_id:
            level_of_data_tags = [t['name'] for t in data_dict['tags'] if t['vocabulary_id'] == level_of_data_vocab_id]
            pkg['vocab_level_of_data'] = level_of_data_tags

        # Cleanup tags
        to_dismiss = [' ', '  ', '_', '__']
        if any(tag in pkg.get('tags') for tag in to_dismiss):
            pkg['tags'] = [tag for tag in pkg['tags'] if tag not in to_dismiss]

        # Add org hierarchy
        pkg['suborganization'] = 'No Organization'
        for extra in data_dict.get('extras', []):
            if extra.get('key') == 'owner_suborg':
                pkg['suborganization'] = helpers.get_publisher(extra['value']).get('name')

        return pkg

    # IPackageController
    def before_search(self, search_params):
        '''
        Override with custom search params
        '''
        # For requests dashboard we need approval_pending datasets. Passing in
        # extras that request is sent from dashboard. Return params as is if so

        if 'topics' in str(search_params.get('fq')):
            search_params['fq'] = search_params['fq'].replace('topics:"', 'groups:"')

        if 'collections' in str(search_params.get('fq')):
            search_params['fq'] = search_params['fq'].replace('collections:"', 'groups:"')

        if search_params.get('extras', {}).get('from_dashboard'):
            return search_params

        search_params.update({
            'fq': '!(approval_state:approval_pending OR approval_state:rejected) ' + search_params.get('fq', '')
        })
        return search_params

    def after_search(self, search_results, search_params):
        if not search_results['search_facets'].get('groups'):
            return search_results

        all_collections = helpers.get_collections()
        all_sources = helpers.get_sources()
        groups = search_results['search_facets']['groups']
        search_results['search_facets']['collections'] = {
           'items': [c for c in groups['items'] if c['name'] in all_collections]
        }
        search_results['search_facets']['sources'] = {
           'items': [c for c in groups['items'] if c['name'] in all_sources]
        }
        search_results['search_facets']['groups']['items'] = [c for c in groups['items'] if c['name'] not in all_collections and c['name'] not in all_sources]
        return search_results


    # IConfigurer
    def update_config(self, config_):
        '''
        Override with custom configurations
        '''
        toolkit.add_template_directory(config_, 'templates')
        toolkit.add_public_directory(config_, 'public')
        toolkit.add_public_directory(config_, 'assets')
        toolkit.add_resource('assets', 'ed')

        activity_stream_string_functions['changed package'] = ed_activity_streams.custom_activity_renderer_package
        activity_stream_string_functions['changed group'] = ed_activity_streams.custom_activity_renderer_group
        activity_stream_string_functions['changed resource'] = ed_activity_streams.custom_activity_renderer_resource

        activity_snippet_functions['group'] = ed_activity_streams.get_snippet_group
        activity_snippet_functions['resource'] = ed_activity_streams.get_snippet_resource

        logic.validators.object_id_validators['changed resource'] = validators.resource_id_exists

    # IValidators
    def get_validators(self):
        '''
        Define custom validators
        '''
        return {
            'state_validator': validators.state_validator,
            'resource_type_validator': validators.resource_type_validator,
            'dummy_validator': validators.dummy_validator,
            'package_name_validator': validators.package_name_validator,
            'create_spatial_tags_if_not_exist': validators.create_spatial_tags_if_not_exist,
            'spatial_tag_name_validator': validators.spatial_tag_name_validator,
            'resource_id_exists': validators.resource_id_exists,
            'user_name_validator': validators.user_name_validator,
            'user_password_validator': validators.user_password_validator,
        }

    def dataset_facets(self, facets_dict, package_type):
        '''
        Override core search fasets for datasets
        '''
        from collections import OrderedDict
        facets_dict = OrderedDict({})
        facets_dict['groups'] = "Categories"
        facets_dict['collections'] = "Collections"
        facets_dict['tags'] = "Tags"
        facets_dict['organization'] = "Publishers"
        facets_dict['suborganization'] = "Organizations"
        facets_dict['res_format'] = "Formats"
        facets_dict['vocab_spatial'] = "Geography"
        facets_dict['vocab_level_of_data'] = "Level Of Data"
        facets_dict['license_id'] = "License"
        return facets_dict

    def organization_facets(self, facets_dict, organization_type, package_type):
        '''
        Override core search fasets for publishers
        '''

        facets_dict['organization'] = 'Publishers'
        facets_dict['suborganization'] = 'Organizations'
        facets_dict['groups'] = 'Categories'
        return facets_dict


class EdHarvestPlugin(HarvestPlugin):

    def read_template(self):
        return 'source/read.html'

class DocumentationPlugin(plugins.SingletonPlugin, lib_plugins.DefaultDatasetForm):
    #plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.IDatasetForm, inherit=True)
    plugins.implements(plugins.IPackageController, inherit=True)
    plugins.implements(plugins.IRoutes, inherit=True)

    # IBlueprint
    #def get_blueprint(self):
    #    return [ed_documentation_blueprint]

    def package_types(self):
        return ('documentation',)

    #def package_controller(self):
    #    return 'documentation'

    def is_fallback(self):
        False

    def package_form(self, package_type='documentation'):
        return 'documentation/snippets/package_form.html'

    def search_template(self):
        return 'documentation/search.html'

    def resources_template(self):
        return 'documentation/resources.html'

    def new_template(self):
        return 'documentation/new.html'

    def new_resource_template(self):
        return 'documentation/new_resource.html'

    def read_template(self):
        return 'documentation/read.html'

    def edit_template(self):
        return 'documentation/edit.html'

    def about_template(self):
        return 'documentation/about.html'

    def history_template(self):
        return 'documentation/history.html'

    def activity_template(self):
        return 'documentation/activity_stream.html'

    def admins_template(self):
        return 'documentation/admins.html'

    def resource_form(self):
        return 'documentation/snippets/resource_form.html'

    def create_package_schema(self):
        schema = super(DocumentationPlugin, self).create_package_schema()

        return schema

    def update_package_schema(self):
        schema = super(DocumentationPlugin, self).update_package_schema()

        return schema

    def show_package_schema(self):
        schema = super(DocumentationPlugin, self).show_package_schema()

        return schema


    # IConfigurer

    #def update_config(self, config_):
    #    toolkit.add_template_directory(config_, 'templates')
    #    toolkit.add_public_directory(config_, 'public')
    #    #toolkit.add_resource('assets', 'collections')


class CollectionsPlugin(plugins.SingletonPlugin):
    #plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.IValidators)
    plugins.implements(plugins.IGroupForm, inherit=True)
    plugins.implements(plugins.IPackageController, inherit=True)
    plugins.implements(plugins.IRoutes, inherit=True)
    plugins.implements(plugins.IActions, inherit=True)
    plugins.implements(plugins.ITemplateHelpers, inherit=True)
    plugins.implements(plugins.IBlueprint)

    def get_actions(self):
        return {
                'collection_list': actions.collection_list,
                'group_update': actions.group_update,
                'group_create': actions.group_create,
                'source_list': actions.source_list
               }

    # IValidators
    def get_validators(self):
        '''
        Define custom validators
        '''
        return {
            'create_spatial_tags_if_not_exist': validators.create_spatial_tags_if_not_exist,
        }

    def group_types(self):
        return ('collection',)

    #def get_blueprint(self):
    #    return [ed_collections_blueprint]

    #def group_controller(self):
    #    return 'collection'

    def is_fallback(self):
        return False

    def form_to_db_schema(self):
        """
        Returns the schema for mapping group data from a form to a format
        suitable for the database.
        """
        schema = ckan_schema.group_form_schema()
        schema.update({'owner_org' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'source_url' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'author' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'author_email' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'maintainer' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'maintainer_email' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'owner_suborg' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'scraped_from' : [toolkit.get_converter('convert_to_extras'),
                            toolkit.get_validator('ignore_missing')]})
        return schema

    def db_to_form_schema(self):
        """
        Returns the schema for mapping group data from the database into a
        format suitable for the form (optional)
        """
        schema = ckan_schema.group_form_schema()
        schema.update({'owner_org' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'source_url' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'author' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'author_email' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'maintainer' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'maintainer_email' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'owner_suborg' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        schema.update({'scraped_from' : [toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        return schema

    def group_form(self, group_type='collection'):
        return 'collection/snippets/collection_form.html'

    def index_template(self):
        return 'collection/index.html'

    def read_template(self):
        return 'collection/read.html'

    def new_template(self):
        return 'collection/new.html'

    def edit_template(self):
        return 'collection/edit.html'

    def about_template(self):
        return 'collection/about.html'

    def history_template(self):
        return 'collection/history.html'

    def activity_template(self):
        return 'collection/activity_stream.html'

    def admins_template(self):
        return 'collection/admins.html'

    # IConfigurer

    #def update_config(self, config_):
    #    toolkit.add_template_directory(config_, 'templates')
    #    toolkit.add_public_directory(config_, 'public')
    #    #toolkit.add_resource('assets', 'collections')


    def get_helpers(self):
        return {
            'update_frequencies': helpers.update_frequencies,
            'data_level': helpers.data_level,
            'unassociated_datasets': helpers.unassociated_datasets,
            'collection_datasets': helpers.collection_datasets,
            'get_spatial_tags': helpers.get_spatial_tags,
            'get_programs_list': helpers.get_programs_list,
            'sources': helpers.sources,
            'source_parent': helpers.source_parent

        }


class DataExplorersPlugin(plugins.SingletonPlugin):
    #plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.IGroupForm, inherit=True)
    plugins.implements(plugins.ITemplateHelpers, inherit=True)
    plugins.implements(plugins.IAuthFunctions, inherit=True)
    plugins.implements(plugins.IBlueprint)

    # IConfigurer
    #def update_config(self, config_):
    #    toolkit.add_template_directory(config_, 'templates')
    #    toolkit.add_public_directory(config_, 'public')
    #    #toolkit.add_resource('assets', 'data_explorer')

    # ITemplateHelpers
    def get_helpers(self):
        return {
        }

    # IAuthFunctions
    def get_auth_functions(self):
        return {
            'group_create': ed_actions.check_access_to_create_data_explorers,
            'group_update': ed_actions.check_access_to_update_data_explorers
        }

    #def get_blueprint(self):
    #    return [ed_data_explorer_blueprint]    

    def form_to_db_schema(self):
        schema = ckan_schema.group_form_schema()

        schema.update({'url' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras')
        ]})
        schema.update({'data_explorer_image' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras')
        ]})

        schema.update({'owner_org' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras')
        ]})

        schema.update({'creator_user_id' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras')
        ]})

        return schema

    def db_to_form_schema(self):
        """
        Returns the schema for mapping group data from the database into a
        format suitable for the form (optional)
        """
        schema = ckan_schema.group_form_schema()

        schema.update({'url' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')
        ]})
        schema.update({'data_explorer_image' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')
        ]})

        schema.update({'owner_org' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')
        ]})

        schema.update({'creator_user_id' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')
        ]})

        return schema

    def group_types(self):
        return ('data_explorer',)

    def group_form(self, group_type='data_explorer'):
        return 'data_explorer/snippets/data_explorer_form.html'

    def index_template(self):
        return 'data_explorer/index.html'

    def new_template(self):
        return 'data_explorer/new.html'

    def read_template(self):
        return 'data_explorer/read.html'

    def edit_template(self):
        return 'data_explorer/edit.html'
    
    # IGroupController
    def create(self, entity):
        '''Called after group had been created inside group_create.
        '''
        group_type = self.group_types()[0]
        # only create activities for the same group type
        if not entity.type == group_type:
            return

        # Create activity workflow for the group
        ed_activity_streams.workflow_activity_create('submitted_for_review', group_type,
            entity, toolkit.c.user)

        # Send email to all sysadmins requesting review
        mail_data_explorer_to_sysadmins(entity, 'request')

    def edit(self, entity):
        '''Called after group had been updated inside group_update.
        '''
        # Create activity workflow for the group
        group_type = self.group_types()[0]
        # only create activities for the same group type
        if not entity.type == group_type:
            return        

        ### Only create activities when resubmitted for approval
        if entity.approval_status == 'approval_pending':
            # create activity
            ed_activity_streams.workflow_activity_create('resubmitted_for_review', group_type,
                entity, toolkit.c.user)

            # Send email
            mail_data_explorer_to_sysadmins(entity, 'request')


class FormatTranslatorPlugin(plugins.SingletonPlugin):
    plugins.implements(plugins.IResourceController, inherit=True)

    def after_create(self, context, resource_dict):
        #log.debug("Translation to CSV After Resource Create")
        translate2csv.enqueue_translation(context, resource_dict, 'resource_create')

    def after_update(self, context, resource_dict):
        #log.debug("Translation to CSV After Resource Update")
        #don't do anything if the resource has approval_pending
        if resource_dict.get('approval_status','') == 'approval_pending':
            return

        #don't do anything if the resource has been approved
        if context.get('action', '') == 'approval':
            return

        #don't do anything if the resource has been rejected
        if context.get('action', '') == 'reject':
            return

        translate2csv.enqueue_translation(context, resource_dict, 'resource_update')

class ResourceApprovalPlugin(plugins.SingletonPlugin):
    plugins.implements(plugins.IResourceController, inherit=True)

    def after_create(self, context, resource_dict):
        #log.debug("After Resource Create hook for Resource Approval")
        user_creator = context.get('user', None)
        resource = ed_actions.make_resource_approval_pending(context, resource_dict)
        if resource:
            # Create activity workflow for the resource
            ed_activity_streams.workflow_activity_create('submitted_for_review', 'resource',
                resource, toolkit.c.user)
            # Send email to all sysadmins requesting review
            mail_resource_to_sysadmins(resource, 'request', user_creator=user_creator)

    def after_update(self, context, resource_dict):
        # log.debug("After Resource Update hook for Resource Approval")
        # don't do anything if the resource has approval_pending
        user_creator = context.get('user', None)
        if resource_dict.get('approval_status', '') == 'approval_pending':
            return

        # don't do anything if the resource has already been approved
        # and this is a normal update
        if resource_dict.get('approval_status', '') == 'approved':
            return

        # don't do anything if the resource has been approved
        if context.get('action', '') == 'approval':
            return

        # don't do anything if the resource has been rejected
        if context.get('action', '') == 'reject':
            return

        if context.get('skip_approval', False) is False:
            resource = ed_actions.make_resource_approval_pending(context, resource_dict)
            if resource:
                # Create activity workflow for the resource
                ed_activity_streams.workflow_activity_create('resubmitted_for_review', 'resource',
                    resource, toolkit.c.user)
                # Send email to all sysadmins requesting review
                mail_resource_to_sysadmins(resource, 'request', user_creator=user_creator)


c = toolkit.c
g = toolkit.g
def custom_convert_from_extras(key, data, errors, context):
    '''Converts values from extras, tailored for groups.'''

    # Set to empty string to remove Missing objects
    data[key] = ""

    to_remove = []
    for data_key in list(data.keys()):
        if (data_key[0] == 'extras'):
            data_value = data[data_key]
            if 'key' in data_value and data_value['key'] == key[-1]:
                data[key] = data_value['value']
                to_remove.append(data_key)
                break
    else:
        return

    for remove_key in to_remove:
        del data[remove_key]


class HierarchyDisplay(plugins.SingletonPlugin):
    #plugins.implements(plugins.IConfigurer, inherit=True)
    plugins.implements(plugins.IActions, inherit=True)
    plugins.implements(plugins.ITemplateHelpers, inherit=True)
    plugins.implements(plugins.IPackageController, inherit=True)

    # IConfigurer

    #def update_config(self, config):
    #    plugins.toolkit.add_template_directory(config, 'templates')
    #    plugins.toolkit.add_public_directory(config, 'assets/hierarchy')
    #    plugins.toolkit.add_resource('assets/hierarchy', 'hierarchy')

    #    try:
    #        from ckan.lib.webassets_tools import add_public_path
    #    except ImportError:
    #        pass
    #    else:
    #        asset_path = os.path.join(
    #            os.path.dirname(__file__), 'assets/hierarchy'
    #        )
    #        add_public_path(asset_path, '/')

    # IActions

    def get_actions(self):
        return {'group_tree': actions.group_tree,
                'group_tree_section': actions.group_tree_section,
                }

    # ITemplateHelpers
    def get_helpers(self):
        return {'group_tree': helpers.group_tree,
                'group_tree_section': helpers.group_tree_section,
                'group_tree_parents': helpers.group_tree_parents,
                'group_tree_get_longname': helpers.group_tree_get_longname,
                'group_tree_highlight': helpers.group_tree_highlight,
                'get_allowable_parent_groups':
                helpers.get_allowable_parent_groups,
                'is_include_children_selected':
                helpers.is_include_children_selected,
                }

    # IPackageController

    def before_search(self, search_params):
        '''When searching an organization, optionally extend the search any
        sub-organizations too. This is achieved by modifying the search options
        before they go to SOLR.
        '''
        with app.app_context():

            # Check if we're called from the organization controller, as detected
            # by c being registered for this thread, and the existence of g.fields
            # values
            try:
                if not isinstance(g.fields, list) and not hasattr(g, 'fields'):
                    return search_params
            except TypeError:
                return search_params
            except AttributeError:
                return search_params

            # e.g. search_params['q'] = u' owner_org:"id" include_children: "True"'
            query = search_params.get('q')
            fq = search_params.get('fq')

            # Fix the issues with multiple times repeated fields
            # Remove the param from the fields - NB no longer works
            # e.g. [('include_children', 'True')]
            new_fields = set()
            for field, value in g.fields:
                if (field != 'include_children'):
                    new_fields.add((field, value))
            g.fields = list(new_fields)

            # parse the query string to check if children are requested
            g.include_children_selected = query and \
                'include_children: "True"' in query

            if g.include_children_selected:

                # get a list of all the children organizations and include them in
                # the search params
                children_org_hierarchy = model.Group.get(g.group_dict.get('id')).\
                    get_children_group_hierarchy(type='organization')
                children_names = [org[1] for org in children_org_hierarchy]

                # remove include_children clause - it is a message for this func,
                # not solr
                query = query.replace('include_children: "True"', '')

                if children_names:
                    # remove existing owner_org:"<parent>" clause - we'll replace
                    # it with the tree of orgs in a moment.
                    owner_org_q = 'owner_org:"{}"'.format(c.group_dict.get('id'))
                    # CKAN<=2.7 it's in the q field:
                    query = query.replace(owner_org_q, '')
                    # CKAN=2.8.x it's in the fq field:
                    search_params['fq'] = fq.replace(owner_org_q, '')

                    # add the org clause
                    query = query.strip()
                    if query:
                        query += ' AND '
                    query += '({})'.format(
                        ' OR '.join(
                            'organization:{}'.format(org_name)
                            for org_name in [c.group_dict.get('name')] +
                            children_names))

                search_params['q'] = query.strip()

                del g.fields_grouped['include_children']

            return search_params


class HierarchyForm(plugins.SingletonPlugin, DefaultOrganizationForm):
    plugins.implements(plugins.IGroupForm, inherit=True)
    plugins.implements(plugins.IActions, inherit=True)

    # IGroupForm

    def group_types(self):
        return ('organization',)

    def group_controller(self):
        return 'organization'

    def get_actions(self):
        return {
            'organization_show': actions.organization_show,
            'organization_member_create': actions.organization_member_create,
            'organization_member_delete': actions.organization_member_delete,
        }

    def setup_template_variables(self, context, data_dict):
        group_id = data_dict.get('id')
        g.allowable_parent_groups = \
            helpers.get_allowable_parent_groups(group_id)
    
    def form_to_db_schema(self):
        schema = ckan_schema.group_form_schema()
        schema.update({'bureau_code' : [toolkit.get_validator('ignore_missing'),
                                        toolkit.get_converter('convert_to_extras')]})
        return schema

    def db_to_form_schema(self):
        schema = ckan_schema.default_show_group_schema()
        schema.update({'bureau_code' : [toolkit.get_validator('ignore_missing'),
                                        toolkit.get_converter('convert_to_extras')]})
        return schema


class EdSourcesPlugin(plugins.SingletonPlugin):
    #plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.IGroupForm, inherit=True)
    plugins.implements(plugins.ITemplateHelpers, inherit=True)
    plugins.implements(plugins.IResourceController, inherit=True)

    template_folder = 'ed_source'

    #def get_blueprint(self):
    #    return [ed_source_blueprint]

    def after_create(self, context, resource_dict):

        # Check if it is a resource since we also implement the
        # IpackageController and if it has the ed_source field
        ed_source = resource_dict.get('ed_source', None)
        if ed_source:
            source = logic.get_action('group_show')(context, {'id': ed_source})
            source_res_list = source.get('source_resources').split(",")
            source_res_list.append(resource_dict['id'])
            source_resources = ','.join(map(str, source_res_list))

            logic.get_action('group_patch')(context, {
                'id': ed_source,
                'source_resources': source_resources
            })

    def group_types(self):
        return ('ed_source',)

    def is_fallback(self):
        False

    def form_to_db_schema(self):
        schema = ckan_schema.group_form_schema()

        schema.update({'ed_sources_type' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras'),
        ]})

        schema.update({'source_resources' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras'),
        ]})
        
        schema.update({'scraped_from' : [
                            toolkit.get_validator('ignore_missing'),
                            toolkit.get_converter('convert_to_extras'),
        ]})

        return schema

    def db_to_form_schema(self):
        """
        Returns the schema for mapping group data from the database into a
        format suitable for the form (optional)
        """
        schema = ckan_schema.group_form_schema()
        
        schema.update({'ed_sources_type' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})

        schema.update({'source_resources' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        
        schema.update({'scraped_from' : [
                            toolkit.get_converter('convert_from_extras'),
                            toolkit.get_validator('ignore_missing')]})
        return schema

    def group_form(self, group_type='ed_source'):
        return '{}/snippets/sources_form.html'.format(self.template_folder)

    def index_template(self):
        return '{}/index.html'.format(self.template_folder)

    def about_template(self):
        return '{}/about.html'.format(self.template_folder)

    def activity_template(self):
        return '{}/activity_stream.html'.format(self.template_folder)

    def admins_template(self):
        return '{}/admins.html'.format(self.template_folder)

    def read_template(self):
        return '{}/read.html'.format(self.template_folder)

    def new_template(self):
        return '{}/new.html'.format(self.template_folder)

    def edit_template(self):
        return '{}/edit.html'.format(self.template_folder)

    def history_template(self):
        return '{}/history.html'.format(self.template_folder)

    # IConfigurer

    #def update_config(self, config_):
    #    toolkit.add_template_directory(config_, 'templates')
    #    toolkit.add_public_directory(config_, 'public')
    #    #toolkit.add_resource('assets', 'collections')

    def get_actions(self):
        return {'collection_list': actions.collection_list,
                'source_list': actions.source_list,
                'source_update': actions.source_update,
                'group_update': actions.group_update
               }

    # ITemplateHelpers
    def get_helpers(self):
        return {
            'get_collections_child': helpers.get_collections_child,
            'update_frequencies': helpers.update_frequencies,
            'data_level': helpers.data_level,
            'unassociated_datasets': helpers.unassociated_datasets,
            'collection_datasets': helpers.collection_datasets,
            'sources': helpers.sources,
            'source_parent': helpers.source_parent
        }

class StatsPlugin(plugins.SingletonPlugin):
    u'''Stats plugin.'''

    #plugins.implements(plugins.IConfigurer)
    plugins.implements(plugins.IBlueprint)

    def get_blueprint(self):
        from ckanext.ed.blueprints.ed_stats import stats_blueprint
        return [stats_blueprint]

    #def update_config(self, config):
    #    plugins.toolkit.add_template_directory(config, 'templates')
    #    plugins.toolkit.add_public_directory(config, 'public')
    #    # plugins.toolkit.add_resource('stats/public/ckanext/stats', 'ckanext_stats')