from logging import getLogger, INFO


import openpyxl
from openpyxl import load_workbook
from io import BytesIO
import urllib
import json 

import ckan
from ckan import logic
import ckan.plugins.toolkit as toolkit
from ckan.plugins.toolkit import enqueue_job
from ckanext.ed.mailer import mail_notif_resource_translate_to_user

from ckanext.ed.format_converters.xlsx2csv import xlsx_uri2csv
from ckanext.ed.format_converters.xls2csv import xls_uri2csv
from werkzeug.datastructures import FileStorage
from flask import Flask
from ckan import model
from ckan.config.middleware import make_app
from ckan.common import config


# TODO import from current path the different format converters

import cgi
import tempfile


log = getLogger(__name__)

def _default_user():
    context = {"ignore_auth": True}
    return toolkit.get_action("get_site_user")(context, {})

def create_mem_file(name, mimetype, content):
    # print("name ", name, " mimetype ", mimetype, " content[0]: ", content[0], "content #lines ", len(content))
    fs = cgi.FieldStorage()
    fs.file = tempfile.NamedTemporaryFile('w+')
    fs.filename = name
    fs.type = mimetype
    # it seems that there are lines that are not valid strings, 2 options
    # EITHER lines that break are taken out -> this works but many documents end empty better to fail 
    # content = [r for r in content if isinstance(r, str)]
    # OR lines that are not string are converted to string
    # content = [str(r) for r in content] -> this too fails to write the file 
    fs.file.writelines(content)
    fs.file.seek(0)
    return fs


def create_file_stream(name, content):
    file = tempfile.NamedTemporaryFile('w+')
    file.writelines(content)
    file.seek(0)
    stream = BytesIO(open(file.name, "rb").read())
    return FileStorage(filename=name, content_type=u'CSV', stream=stream)


def convert_format(resource):
    """ Takes a resourceand translates an excel file into CSV 
    returns a tuple with (csv rows, metadata)
    Args:
        resource (dict)
    """
    resource_id = resource['id']
    try: 
        metadata = {
        "package_id": resource["package_id"], 
        "description": resource.get("description", 
                                    "translated to CSV from {}".format(resource_id)),
        "format": "CSV",
        "url": "",
        "resource_type": "text/csv", 
        #"approval_status": "pending",
        "translated_from": json.dumps(resource),
        }
        resource_url =  resource["url"]
        default_user = _default_user()
        #log.debug("Default user: {}".format(default_user))
        csv_sheets = []
        # translate the resources - call the right translator per format
        if resource_url.endswith(".xlsx"):
            csv_sheets = xlsx_uri2csv(resource_url, default_user.get('apikey'))
            metadata["name"] = resource.get("name", "none.csv").replace(".xlsx", ".csv")
        elif resource_url.endswith(".xls"):
            csv_sheets = xls_uri2csv(resource_url, default_user.get('apikey'))
            metadata["name"] = resource.get("name", "none.csv").replace(".xls", ".csv")
        else:
            # raise(Exception("Wrong format Exception. Given resource file {} is Not an XLSX file".format(resource_url)))
            log.error("Wrong format Exception. Given resource file {} is Not an XLSX file".format(resource_url))
            return None
        return csv_sheets, metadata
    except Exception as e:
        log.error("Error while trying to convert resource to csv: " + resource_id + " with Error: " + str(e))
        raise e
  

def resource2csv(resource_id, context={
           'ignore_auth': True,
           'user': '',
            }, action='resource_create'):
    """ Takes a resource id and an optional context and translates an excel file into CSV
    Args:
        resource_id (str): id (UUID) of the resource to transform from XLSX into CSV
        context (dict, optional): [description]. Defaults to {}.
    """
    assert(action in ['resource_create', 'resource_update'])
    log = getLogger(__name__)  # needed as it is another process
    app = make_app(config) # set up flask app
    with app._wsgi_app.test_request_context():
        context['user'] = _default_user()['name']
        resource = logic.get_action('resource_show')(context, {'id': resource_id})
        #update the metadata fields wiht the converted values
        converted = convert_format(resource)
        if not converted:
            return
        csv_sheets, metadata = converted
    
        try:
            if action == 'resource_update':
                package = logic.get_action('package_show')(context, {'id': resource['package_id']})
                # now go over all resources and find the related one (if there is one)
                pkg_resources = package['resources']
                # find related translated resource (if there is one)
                for r in pkg_resources:
                    if 'translated_from' in r:
                        tf = r['translated_from']
                        tf = tf if type(tf) == 'dict' else json.loads(tf)
                        if tf['id'] == resource_id:
                            # change metadata to the related one (if there is one)
                            metadata['id'] = r['id']
                            break  # there should be only one translated resource
        except Exception as e:
            log.error("getting translated resource from Package Error: " + str(e))
        name = metadata['name']
        mimetype = metadata['resource_type']

        errors = []
        translated = []
        for sheet_name, sheet in csv_sheets:
            try:
                # log.debug("SAVING sheet: {} - {}".format(name, sheet_name, len(sheet)))
                # print("SAVING sheet: {} - {}".format(name, sheet_name, len(sheet)))
                metadata["name"] = name.replace('.csv', '_'+sheet_name+'.csv')
                metadata["url"] = name.replace('.csv', '_'+sheet_name+'.csv')
                fcsv = create_file_stream(metadata["url"], sheet)
                metadata["upload"] = fcsv
                #log.debug('Resource metadata: {}'.format(metadata))
                _ = logic.get_action(action)(context, metadata)
                translated.append(metadata['name'])
                # clean 
                metadata["upload"] = None
                # del(fcsv)
                # log.debug("SAVED sheet: {} - {}".format(name, sheet_name, len(sheet)))
                # print("SAVED sheet: {} - {}".format(name, sheet_name, len(sheet)))
            except Exception as e:
                log.error("Error writing file sheet {}".format(sheet_name) + str(e))
                errors.append(("File Sheet {} could not be translated to CSV".format(sheet_name), sheet_name, e))
            # finally:
        
        # mail notification
        try:
            user = model.User.get(context.get('creator_user_id',''))
            mail_notif_resource_translate_to_user(context, metadata, action, translated, errors, user)
        except Exception as e:
            log.error("Error sending email notification to user with ERROR: " + str(e))


def enqueue_translation(context, data_dict, action='resource_create'):
    """
    Sets a background job for XLSX to CSV translation
    Checks that the input resource exists, is accesible and enqueues the translation job
    """
    assert(action in ['resource_create', 'resource_update'])
    resource_id = data_dict['id']
    try:
        pkg = context['package']
        ctxt = {
                'package_id': pkg.id,
                'name': pkg.name,
                'title': pkg.title,
                'author': pkg.author,
                'author_email': pkg.author_email,
                'maintainer_email': pkg.maintainer_email,
                'creator_user_id': pkg.creator_user_id,
                'ignore_auth': True,
                'user': '',
                }
    except Exception as e:
        log.error("Error extracting dict from context with error " + str(e))
        ctxt = {
                'user': '',
                'ignore_auth': True,
                }
    # set a background job to call xlsx2csv on the resource    
    enqueue_job(resource2csv,  [resource_id, ctxt, action], 
                title="resource2csv-"+str(resource_id)  # if needed we can change the title
                )
    # return that has been enqueued and job ID
    return {"id": resource_id,
            "action": "Resource enqueued for translation"
            } 
