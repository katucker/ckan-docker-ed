from logging import getLogger

from io import BytesIO
import urllib

import ckan.plugins.toolkit as toolkit
import xlrd


log = getLogger(__name__)


def load_workbook_from_url(url, api_key):
    '''
    file_name, headers = urllib.urlretrieve(url)
    wb = xlrd.open_workbook(file_name)
    return wb
    '''
    req = urllib.request.Request(url)
    req.add_header('X-CKAN-API-KEY', api_key)
    xfile = urllib.request.urlopen(req)

    import shutil
    import tempfile

    tmp_file = tempfile.NamedTemporaryFile()
    shutil.copyfileobj(xfile, tmp_file)

    return xlrd.open_workbook(tmp_file.name)


def xls2csvsheets(wb, separator=','):
    sheets = []
    for s in wb.sheets():
        
        row_len = 0
        srows = []
        sname = '-'.join([str(s.number), s.name])
        # log.debug("Processing sheet: {}".format(sname))
        print("Processing sheet: {}".format(sname))
        for i_row in range(s.nrows):
            row_items = [ str(s.cell(i_row, i_col).value) for i_col in range(s.ncols)]
            # clean intermediate newline chars, join by separator and add a newline only at the end
            srows.append(separator.join(row_items).replace('\n', '')+'\n')
        srows = [r for r in srows if r]
        sheets.append((sname,srows))
    return sheets


def single_sheet_xls2csv(xls):
    pass
    

def xls_file2csv_file(fname, oname):
    pass
  
  
def xls_uri2csv(resource_url, api_key):
    xlsx_wb = load_workbook_from_url(resource_url, api_key)
    sheets = xls2csvsheets(xlsx_wb)
    return sheets
  
