from logging import getLogger

import openpyxl
from openpyxl import load_workbook
from io import BytesIO
import urllib.request

from ckan import logic
import ckan.plugins.toolkit as toolkit

log = getLogger(__name__)

def _cell2str(cell):
    """[summary]
    Transforms an XLSX cell into string
    Args:
        cell ([type]): [description]
    """
    c = cell.value or ''  # Deal with None value in the cell
    if type(c) != str:
        return str(c)  # Deal with any type that should be convertible
    # WARNING that there are many more error sources when converting from excel,
    # this deals with some of them but not all possible instances
    try:
        sc = str(c)  # most well-encoded text should work correctly here
        return sc
    except:
        # try to do some magic to deal with invalid encoding
        # converting each character to raw string and printing that
        return r''.join(c)
        

def load_workbook_from_url(url, api_key):
    req = urllib.request.Request(url)
    req.add_header('X-CKAN-API-KEY', api_key)
    xfile = urllib.request.urlopen(req).read()
    return load_workbook(filename = BytesIO(xfile))


def single_sheet_xlsx2csv(xlsx, separator=','):
    """[summary]

    Args:
        xlsx (Workbook): [description]
    """
    sheet = xlsx.active
    data = sheet.rows
    rows = []
    row_len = 0
    for row in data:
        row_items = [_cell2str(c) for c in row]
        # validate that the csv row is correct (number of items must equal the ones in the header)
        if row_len > 0:
            if row_len != len(row_items):
                log.warn("Invalid CSV conversion, inconsistent column count")
                continue # do not raise an error as there are other sheets that might convert correctly
        else:
            row_len = len(row_items)
        # if row_items:
        rows.append(separator.join(row_items)+'\n')
    return rows
    
    
def xlsx2csvsheets(wb, separator=','):
    sheets = []
    
    for sheet in wb.worksheets:
        row_len = 0
        sname = sheet.title
        # log.debug("Processing sheet: ", sname)
        # print("Processing sheet: ", sname)
        print("Processing sheet: {}".format(sname))
        rows = []
        for row in sheet.rows:
            row_items = [_cell2str(c) for c in row]
            # clean intermediate newline chars, join by separator and add a newline only at the end
            rows.append(separator.join(row_items).replace('\n', '')+'\n')
        rows = [r for r in rows if r]
        sheets.append((sname, rows))
    return sheets


def xlsx_file2csv_file(fname, oname):
    """Converts an xlsx file from a given path into csv and saves it in the output path given
    Args:
        fname ([path|str]): Path to file to read
        oname ([path|str]): Path of csv file to write
    """
    xlsx = openpyxl.load_workbook(fname)
    csv_data = single_sheet_xlsx2csv(xlsx)
    
    csv = open(oname, "w+")
    csv.writelines(csv_data)
    
    csv.close()
  
  
def xlsx_uri2csv(resource_url, api_key):
    """
    """
    # open from url
    # https://stackoverflow.com/questions/20635778/using-openpyxl-to-read-file-from-memory
    xlsx_wb = load_workbook_from_url(resource_url, api_key)
    sheets = xlsx2csvsheets(xlsx_wb)
    return sheets
  
