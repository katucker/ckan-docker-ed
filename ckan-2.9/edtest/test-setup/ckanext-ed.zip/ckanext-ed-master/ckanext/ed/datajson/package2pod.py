import os
import json
try:
    from collections import OrderedDict  # 2.7
except ImportError:
    from sqlalchemy.util import OrderedDict

from logging import getLogger
import logging

from ckanext.datajson.helpers import *
from ckanext.ed.helpers import get_publisher, filter_categories, \
    get_config_value, get_relationship_parent, get_org_list, \
    get_package_documentation
from ckanext.ed.accrual_periodicity.accrual_periodicity import UPDATE_FREQUENCIES

import ckan.logic as logic
import ckan.model as model

from ckanext.datajson.package2pod import log
from ckanext.datajson import helpers as data_json_helpers

log = getLogger(__name__)


class Package2Pod:
    def __init__(self):
        pass

    seen_identifiers = None

    @staticmethod
    def wrap_json_catalog(dataset_dict, json_export_map):
        catalog_headers = [(x, y) for x, y in json_export_map.get('catalog_headers').items()]
        catalog_id = get_config_value('ckan.site_url') + "/data.json"
        catalog_headers.append( ("@id", catalog_id) )
        catalog = OrderedDict(
            catalog_headers + [('dataset', dataset_dict)]
        )
        return catalog

    @staticmethod
    def filter(content):
        if not isinstance(content, str):
            return content
        content = Package2Pod.strip_redacted_tags(content)
        content = strip_if_string(content)
        return content

    @staticmethod
    def strip_redacted_tags(content):
        if not isinstance(content, str):
            return content
        return re.sub(REDACTED_TAGS_REGEX, '', content)

    @staticmethod
    def mask_redacted(content, reason):
        if not content:
            content = ''
        if reason:
            # check if field is partial redacted
            masked = content
            for redact in re.findall(PARTIAL_REDACTION_REGEX, masked):
                masked = masked.replace(redact, '')
            if len(masked) < len(content):
                return masked
            return '[[REDACTED-EX ' + reason + ']]'
        return content

    @staticmethod
    def convert_package(package, json_export_map, redaction_enabled=False):
        import sys, os

        try:
            dataset = Package2Pod.export_map_fields(package, json_export_map, redaction_enabled)

            # skip validation if we export whole /data.json catalog
            if json_export_map.get('validation_enabled'):
                return Package2Pod.validate(package, dataset)
            else:
                return dataset
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            filename = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            log.error("%s : %s : %s : %s", exc_type, filename, exc_tb.tb_lineno, e)
            raise e

    @staticmethod
    def export_map_fields(package, json_export_map, redaction_enabled=False):
        import sys, os

        public_access_level = get_extra(package, 'public_access_level')
        if not public_access_level or public_access_level not in ['non-public', 'restricted public']:
            redaction_enabled = False

        Wrappers.redaction_enabled = redaction_enabled

        json_fields = json_export_map.get('dataset_fields_map')

        try:
            dataset = OrderedDict([("@type", "dcat:Dataset")])

            Wrappers.pkg = package
            Wrappers.full_field_map = json_fields

            for key, field_map in json_fields.items():
                # log.debug('%s => %s', key, field_map)

                field_type = field_map.get('type', 'direct')
                is_extra = field_map.get('extra')
                array_key = field_map.get('array_key')
                field = field_map.get('field')
                split = field_map.get('split')
                wrapper = field_map.get('wrapper')
                default = field_map.get('default')


                if redaction_enabled and field and 'publisher' != field and 'direct' != field_type:
                    redaction_reason = get_extra(package, 'redacted_' + field, False)
                    # keywords(tags) have some UI-related issues with this, so we'll check both versions here
                    if not redaction_reason and 'tags' == field:
                        redaction_reason = get_extra(package, 'redacted_tag_string', False)
                    if redaction_reason:
                        dataset[key] = '[[REDACTED-EX ' + redaction_reason + ']]'
                        continue

                if 'direct' == field_type and field:
                    if is_extra:
                        # log.debug('field: %s', field)
                        # log.debug('value: %s', get_extra(package, field))
                        dataset[key] = strip_if_string(get_extra(package, field, default))
                    else:
                        dataset[key] = strip_if_string(package.get(field, default))
                    if redaction_enabled and 'publisher' != field:
                        redaction_reason = get_extra(package, 'redacted_' + field, False)
                        # keywords(tags) have some UI-related issues with this, so we'll check both versions here
                        if redaction_reason:
                            dataset[key] = Package2Pod.mask_redacted(dataset[key], redaction_reason)
                            continue
                    else:
                        dataset[key] = Package2Pod.filter(dataset[key])

                elif 'array' == field_type:
                    if is_extra:
                        found_element = strip_if_string(get_extra(package, field))
                        if found_element:
                            if is_redacted(found_element):
                                dataset[key] = found_element
                            elif split:
                                dataset[key] = [Package2Pod.filter(x) for x in found_element.split()]

                    else:
                        if array_key:
                            dataset[key] = [Package2Pod.filter(t[array_key]) for t in package.get(field, {})]
                if wrapper:
                    #log.debug('wrapper: %s', wrapper)
                    try:
                        method = getattr(Wrappers, wrapper)
                        if method:
                            Wrappers.current_field_map = field_map
                            dataset[key] = method(dataset.get(key))
                    except Exception as e:
                        log.error('%s: %s', wrapper, e)

                if key == 'accessLevel' and dataset.get(key) == 'restricted-public':
                    dataset[key] = 'restricted public'

                if key == 'references':
                    # Get the dataset's documentation if it exists
                    doc = get_package_documentation(dataset.get('identifier'))
                    if doc:
                        context = {'model': model, 'session': model.Session}
                        doc_pkg = logic.get_action('package_show')(context,
                            { 'id': doc.get('id')})
                        references = [r['url'] for r in doc_pkg.get('resources', [])]
                        dataset[key] = references

            # CKAN doesn't like empty values on harvest, let's get rid of them
            # Remove entries where value is None, "", or empty list []
            dataset = OrderedDict([(x, y) for x, y in dataset.items() if y is not None and y != "" and y != []])
            
            return dataset
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            filename = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            log.error("%s : %s : %s : %s", exc_type, filename, exc_tb.tb_lineno, e)
            raise e

    @staticmethod
    def validate(pkg, dataset_dict):
        import sys, os

        global currentPackageOrg

        try:
            # When saved from UI DataQuality value is stored as "on" instead of True.
            # Check if value is "on" and replace it with True.
            dataset_dict = OrderedDict(dataset_dict)
            if dataset_dict.get('dataQuality') == "on" \
                    or dataset_dict.get('dataQuality') == "true" \
                    or dataset_dict.get('dataQuality') == "True":
                dataset_dict['dataQuality'] = True
            elif dataset_dict.get('dataQuality') == "false" \
                    or dataset_dict.get('dataQuality') == "False":
                dataset_dict['dataQuality'] = False

            errors = []
            try:
                from datajsonvalidator import do_validation
                do_validation([dict(dataset_dict)], errors, Package2Pod.seen_identifiers)
            except Exception as e:
                errors.append(("Internal Error", ["Something bad happened: " + e]))
            if len(errors) > 0:
                for error in errors:
                    log.warn(error)

                try:
                    currentPackageOrg
                except NameError:
                    currentPackageOrg = 'unknown'

                errors_dict = OrderedDict([
                    ('id', pkg.get('id')),
                    ('name', Package2Pod.filter(pkg.get('name'))),
                    ('title', Package2Pod.filter(pkg.get('title'))),
                    ('organization', Package2Pod.filter(currentPackageOrg)),
                    ('errors', errors),
                ])

                return errors_dict

            return dataset_dict
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            filename = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            log.error("%s : %s : %s", exc_type, filename, exc_tb.tb_lineno)
            raise e  

class Wrappers:

    redaction_enabled = False
    pkg = None
    current_field_map = None
    full_field_map = None
    bureau_code_list = None
    resource_formats = None
    organization_list = get_org_list()

    def __init__(self):
        pass

    @staticmethod
    def get_organization(org_name):
        if not Wrappers.organization_list:
            return None
        
        for organization in Wrappers.organization_list:
            if organization.get('name') == org_name:
                return organization
        
        return None

    @staticmethod
    def make_organization_tree(name):
        if not name:
            return None
       
        organization = Wrappers.get_organization(name)
        if not organization:
            return None

        top_level_org = OrderedDict([
                ("@type", "org:Organization"),
                ("name", "U.S. Government"),   
        ])

        if not organization.get('groups', None):
            # no parent - top level organization
            return OrderedDict([
                ("@type", "org:Organization"),
                ("name", organization.get('title')),
                ("subOrganizationOf", top_level_org)   
            ])

        parent_name = organization.get('groups')[0].get('name')
        parent = Wrappers.make_organization_tree(parent_name)

        if not parent:
            return OrderedDict([
                ("@type", "org:Organization"),
                ("name", organization.get('title')),
                ("subOrganizationOf", top_level_org)      
            ])
        else:
            return OrderedDict([
                ("@type", "org:Organization"),
                ("name", organization.get('title')),
                ("subOrganizationOf", parent)   
            ])

        return None

    @staticmethod
    def catalog_publisher(value):
        publisher = None
        if value:
            publisher = get_responsible_party(value)
        if not publisher and 'organization' in Wrappers.pkg and 'name' in Wrappers.pkg.get('organization'):
            publisher_name = Wrappers.pkg.get('organization').get('name')
            publisher = Wrappers.make_organization_tree(publisher_name)

        return publisher
        
    @staticmethod
    def inventory_publisher(value):
        global currentPackageOrg

        publisher = strip_if_string(get_extra(Wrappers.pkg, Wrappers.current_field_map.get('field')))
        if publisher is None:
            return None

        currentPackageOrg = publisher

        organization_list = list()
        organization_list.append([
            ('@type', 'org:Organization'),  # optional
            ('name', Package2Pod.filter(publisher)),  # required
        ])

        for i in range(1, 6):
            pub_key = 'publisher_' + str(i)  # e.g. publisher_1
            if get_extra(Wrappers.pkg, pub_key):  # e.g. package.extras.publisher_1
                organization_list.append([
                    ('@type', 'org:Organization'),  # optional
                    ('name', Package2Pod.filter(get_extra(Wrappers.pkg, pub_key))),  # required
                ])
                currentPackageOrg = Package2Pod.filter(get_extra(Wrappers.pkg, pub_key))  # e.g. GSA

        if Wrappers.redaction_enabled:
            redaction_mask = get_extra(Wrappers.pkg, 'redacted_' + Wrappers.current_field_map.get('field'), False)
            if redaction_mask:
                return OrderedDict(
                    [
                        ('@type', 'org:Organization'),  # optional
                        ('name', '[[REDACTED-EX ' + redaction_mask + ']]'),  # required
                    ]
                )

        # so now we should have list() organization_list e.g.
        # (
        #   [('@type', 'org:Org'), ('name','GSA')],
        #   [('@type', 'org:Org'), ('name','OCSIT')]
        # )

        size = len(organization_list)  # e.g. 2

        tree = organization_list[0]
        for i in range(1, size):
            tree = organization_list[i] + [('subOrganizationOf', OrderedDict(tree))]

        return OrderedDict(tree)

    @staticmethod
    def fix_accrual_periodicity(frequency):

        if frequency is None:
            frequency = Wrappers.pkg.get('update_frequency', None)

        if frequency == 'None':
            frequency = None

        if frequency in UPDATE_FREQUENCIES:
            frequency = UPDATE_FREQUENCIES[frequency]

        frequencies = [value for key, value in UPDATE_FREQUENCIES.items()]

        if frequency not in frequencies:
            frequency = None

        return frequency

    @staticmethod
    def description(value):
        if not value:
            value = Wrappers.pkg.get('title', 'n/a')
        return value

    @staticmethod
    def references(value):
        updated_value = list()

        if isinstance(value, list):
            for ref in value:
                if isinstance(ref, str):
                    ref = ref.replace('{', '')
                    ref = ref.replace('}', '')
                    ref = ref.split(',')

                    for url in ref:
                        updated_value.append(url)

            return updated_value

        return value

    @staticmethod
    def language(value):
        updated_value = list()

        if isinstance(value, list):
            for lang in value:
                if isinstance(lang, str):
                    lang = lang.replace('{', '')
                    lang = lang.replace('}', '')
                    lang = lang.split(',')

                    for l in lang:
                        updated_value.append(l)

            return updated_value

        return value

    @staticmethod
    def build_contact_point(someValue):
        import sys, os

        try:
            contact_point_map = Wrappers.full_field_map.get('contactPoint').get('map')
            if not contact_point_map:
                return None

            package = Wrappers.pkg

            if contact_point_map.get('fn').get('extra'):
                fn = get_extra(package, contact_point_map.get('fn').get('field'),
                               get_extra(package, "Contact Name",
                                         package.get('author')))
            else:
                fn = package.get(contact_point_map.get('fn').get('field'),
                                 get_extra(package, "Contact Name",
                                           package.get('author')))
            if not fn:
                try:
                    fn = package['organization']['name']
                except:
                    fn = 'n/a'

            fn = get_responsible_party(fn)

            if Wrappers.redaction_enabled:
                redaction_reason = get_extra(package, 'redacted_' + contact_point_map.get('fn').get('field'), False)
                if redaction_reason:
                    fn = Package2Pod.mask_redacted(fn, redaction_reason)
            else:
                fn = Package2Pod.filter(fn)

            if contact_point_map.get('hasEmail').get('extra'):
                email = get_extra(package, contact_point_map.get('hasEmail').get('field'),
                                  package.get('author_email'))
            else:
                email = package.get(contact_point_map.get('hasEmail').get('field'),
                                    package.get('author_email'))

            if not email:
                try:
                    email = '{}@ed.gov'.format(package['organization']['name'])
                except:
                    email = 'odp@ed.gov'

            if email and not is_redacted(email) and '@' in email:
                email = 'mailto:' + email

            if Wrappers.redaction_enabled:
                redaction_reason = get_extra(package, 'redacted_' + contact_point_map.get('hasEmail').get('field'),
                                             False)
                if redaction_reason:
                    email = Package2Pod.mask_redacted(email, redaction_reason)
            else:
                email = Package2Pod.filter(email)

            contact_point = OrderedDict([('@type', 'vcard:Contact')])
            if fn:
                contact_point['fn'] = fn
            if email:
                contact_point['hasEmail'] = email

            return contact_point
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            filename = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            log.error("%s : %s : %s", exc_type, filename, exc_tb.tb_lineno)
            raise e

    @staticmethod
    def inventory_parent_uid(parent_dataset_id):
        if parent_dataset_id:
            import ckan.model as model

            parent = model.Package.get(parent_dataset_id)
            parent_uid = parent.extras.col.target['unique_id'].value
            if parent_uid:
                parent_dataset_id = parent_uid
        return parent_dataset_id

    @staticmethod
    def generate_distribution(someValue):

        arr = []
        package = Wrappers.pkg

        distribution_map = Wrappers.full_field_map.get('distribution').get('map')
        if not distribution_map or 'resources' not in package:
            return arr

        for r in package["resources"]:
            resource = OrderedDict([('@type', "dcat:Distribution")])

            for pod_key, json_map in distribution_map.items():
                value = strip_if_string(r.get(json_map.get('field'), json_map.get('default')))

                if Wrappers.redaction_enabled:
                    if 'redacted_' + json_map.get('field') in r and r.get('redacted_' + json_map.get('field')):
                        value = Package2Pod.mask_redacted(value, r.get('redacted_' + json_map.get('field')))
                else:
                    value = Package2Pod.filter(value)

                # filtering/wrapping if defined by export_map
                wrapper = json_map.get('wrapper')
                if wrapper:
                    method = getattr(Wrappers, wrapper)
                    if method:
                        value = method(value)

                if value:
                    resource[pod_key] = value

            # inventory rules
            res_url = strip_if_string(r.get('url'))
            if Wrappers.redaction_enabled:
                if 'redacted_url' in r and r.get('redacted_url'):
                    res_url = '[[REDACTED-EX ' + r.get('redacted_url') + ']]'
            else:
                res_url = Package2Pod.filter(res_url)

            if res_url:
                res_url = res_url.replace('http://[[REDACTED', '[[REDACTED')
                res_url = res_url.replace('http://http', 'http')
                if r.get('resource_type') in ['access_url', 'api_url']:
                    resource['accessURL'] = res_url
                    if 'mediaType' in resource:
                        resource.pop('mediaType')
                else:
                    if 'accessURL' in resource:
                        resource.pop('accessURL')
                    resource['downloadURL'] = res_url
                    if 'mediaType' not in resource:
                        resource['mediaType'] = 'text/plain'
                        log.warn("Missing mediaType for resource in package ['%s']", package.get('id'))
            else:
                log.warn("Missing downloadURL for resource in package ['%s']", package.get('id'))
                continue

            # data dictionary
            data_dictionary = r.get('data_dictionary_res','')
            if data_dictionary:                 
                if all(p not in data_dictionary for p in ['http://', 'https://']):
                    resource['describedBy'] = get_config_value('ckan.site_url') + '/uploads/data_dictionary/' + data_dictionary
                else:
                    resource['describedBy'] = data_dictionary
                if r.get('data_dictionary_res_mimetype',''):
                    resource['describedByType'] = r.get('data_dictionary_res_mimetype','')

            striped_resource = OrderedDict(
                [(x, y) for x, y in resource.items() if y is not None and y != "" and y != []])

            arr += [OrderedDict(striped_resource)]

        return arr

    @staticmethod
    def keyword(value):
        tags = [v.get('display_name', None) for v in value if v.get('vocabulary_id') is None]
        if not tags:
            pkg = Wrappers.pkg
            tags = [
                pkg.get('organization', {}).get('name', 'data'),
                get_publisher(pkg.get('owner_suborg', 'edgov')).get('name', 'data')
                ]

        return tags

    @staticmethod
    def spatial(value):
        if value is None:
            return None
        return ','.join(value)

    @staticmethod
    def level_of_data(value):
        if value is None:
            return None
        return ','.join(value)

    @staticmethod
    def bureau_code(value):
        # Hardcode the bureau code
        # return ['018:15']

        if value:
            if isinstance(value, str):
                value = value.replace('{','')
                value = value.replace('}','')

            return [value]

        if not 'organization' not in Wrappers.pkg or 'title' not in Wrappers.pkg.get('organization'):
            return ['018:15']

        org_title = Wrappers.pkg.get('organization').get('title')
        log.debug("org title: %s", org_title)

        code_list = Wrappers._get_bureau_code_list()

        if org_title not in code_list:
            return ['018:15']

        bureau = code_list.get(org_title)

        log.debug("found match: %s", "[{0}:{1}]".format(bureau.get('OMB Agency Code'), bureau.get('OMB Bureau Code')))
        result = "{0}:{1}".format(bureau.get('OMB Agency Code'), bureau.get('OMB Bureau Code'))
        log.debug("found match: '%s'", result)
        return [result]
    
    @staticmethod
    def landing_page(value):

        if value is None:
            value = Wrappers.pkg.get('scraped_from', None)
        
        return value

    @staticmethod
    def license(value):

        if value is None:
            value = Wrappers.pkg.get('license_url', None)
        
        return value

    @staticmethod
    def data_quality(value):
        new_value = Wrappers.pkg.get('data_quality', None)

        if new_value:
            value = new_value if new_value is not False else None

        if value == 'true':
            value = True

        if value == 'false':
            value = None

        return value

    @staticmethod
    def system_of_records(value):
        updated_system_of_records = Wrappers.pkg.get('system_of_records', None)

        if value is None or updated_system_of_records is not None:
            value = updated_system_of_records

        return value

    @staticmethod
    def temporal(value):

        start_date = Wrappers.pkg.get('start_date', None)
        end_date = Wrappers.pkg.get('end_date', None)

        if start_date and end_date:
            value = start_date + "/" + end_date

        return value

    @staticmethod
    def theme(value):
        groups = Wrappers.pkg.get('groups', [])
        categories = filter_categories(groups)

        extras = Wrappers.pkg.get('extras', [])
        theme = list(filter(lambda x: x.get('key') == 'theme', extras))

        if theme and not categories:
            theme_value = theme[0].get('value').replace('{', '').replace('}', '').split(',')
            theme = [t.strip() for t in theme_value if t.strip()]
            value = list(filter(None, theme))

            return list(set(value))

        if not categories:
            return []
        
        value = []
        for category in categories:
            value.append(category.title)

        return list(set(value))

    @staticmethod
    def relationship_parent(value):

        if value is None:
            value = get_relationship_parent(Wrappers.pkg, for_dcat=True).get('id')

        return value

    @staticmethod
    def _get_bureau_code_list():
        if Wrappers.bureau_code_list:
            return Wrappers.bureau_code_list
        import os
        bc_file = open(
            os.path.join(os.path.dirname(__file__), "resources", "omb-agency-bureau-treasury-codes.json"),
            "r"
        )
        code_list = json.load(bc_file)
        Wrappers.bureau_code_list = {}
        for bureau in code_list:
            Wrappers.bureau_code_list[bureau['Agency']] = bureau
        return Wrappers.bureau_code_list

    @staticmethod
    def program_code(value):
        if value:
            if isinstance(value, str):
                value = value.replace('{','')
                value = value.replace('}','')

            return value.split(',')
        else:
            return ['018:000']

    @staticmethod
    def primary_it_investment_uii(value):
        uii = Wrappers.pkg.get('primary_it_investment_uii', None)

        if value is None or uii is not None:
            value = uii

        return value

    @staticmethod
    def mime_type_it(value):
        if not value:
            return value
        formats = h.resource_formats()
        format_clean = value.lower()
        if format_clean in formats:
            mime_type = formats[format_clean][0]
        else:
            mime_type = value
        msg = value + ' ... BECOMES ... ' + mime_type
        log.debug(msg)
        return mime_type

    @staticmethod
    def described_by(value):
        if value:
            return value

        data_dictionary = Wrappers.pkg.get('data_dictionary_pkg', '')
        if data_dictionary and all(p not in data_dictionary for p in ['http://', 'https://']):
            return get_config_value('ckan.site_url') + '/uploads/data_dictionary/' + data_dictionary

        return data_dictionary

    @staticmethod
    def described_by_type(value):
        if value:
            return value

        data_dictionary_mimetype = Wrappers.pkg.get('data_dictionary_pkg_mimetype', '')
        return data_dictionary_mimetype