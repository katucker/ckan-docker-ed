'''
    This script helps finding and hiding data profiles
    that are not following the DCAT guidelines.
'''

import os
import sys
from argparse import ArgumentParser
from ckanapi import RemoteCKAN

#   Environment variables
url = os.getenv('ED_CKAN_URL', None)
api_key = os.getenv('ED_CKAN_KEY', None)


#   DCAT fields
dcat_fields = ['title', 'notes', 'owner_org', 'tags',
        'author', 'author_email', 'access_level', 'program_code']


def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)

def package_search_by_publisher(publisher):
    rows = 1000

    data_dict = {
        'q'  : 'organization:' + publisher,
        'rows' : rows,
        'start' : 0,
        'type' : 'dataset',
        'include_private': True
    }

    result = package_search(data_dict=data_dict)
    if not result:
        return []

    packages = []
    packages.extend(result.get('results',[]))

    count = result.get('count')
    number_of_pages = (count // rows if count % rows == 0 else count // rows + 1)

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'q'  : 'organization:' + publisher,
                'rows': rows,
                'start': page_number * rows,
                'type' : 'dataset',
                'include_private': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results',[]))

    return packages

def get_publishers_from_file(path):
    with open(path, 'r') as f:
        print(f.read())

def get_all_publishers():
    return remote.call_action(action='organization_list')

def update_package(package):
    return remote.call_action(action='package_patch', data_dict=package)

#   For debugging purposes
def show_package(package):
    package['indraft'] = False
    package['private'] = False
    update_package(package)

def hide_package(package):
    package['indraft'] = True
    package['private'] = True
    update_package(package)

def publisher_exists(publisher):
    data_dict = {
        'id': publisher
    }

    try:
        remote.call_action(action='organization_show', data_dict=data_dict)
        return True
    except Exception as e:
        print('[!] Publisher \'%s\' does not exist: %s' % (publisher, e))


def validate_package_dcat(package):
    invalid_fields = []

    for field in dcat_fields:
        if not package.get(field):
            invalid_fields.append(field)

    return {
        'valid': len(invalid_fields) == 0,
        'invalid_fields': invalid_fields
    }

def validate_publisher(publisher):
    validation_results = []
    packages_changed = []

    if publisher_exists(publisher):
        print('* Validating publisher \'%s\'' % publisher)
        packages = package_search_by_publisher(publisher)
        print('%d data profiles found\n' % len(packages))
        for package in packages:
            print('Validating data profile \'%s\' of \'%s\'' % (package.get('name'), publisher))
            validation = validate_package_dcat(package)
            validation_results.append({ 'package': package, 'validation': validation })

            if validation['valid']:
                print('All fields are valid...')
            else:
                for field in dcat_fields:
                    status = 'VALID'
                    if field in validation['invalid_fields']:
                        status = 'INVALID'

                    print('- %s: %s' % (field, status))

                if str(package.get('private', 'false')).lower() != 'true' or str(package.get('indraft', 'false')).lower() != 'true':
                    print('Hiding data profile \'%s\' of \'%s\'' % (package.get('name'), publisher))
                    packages_changed.append({ 'package': package.copy(), 'validation': validation })

                    if not args.dry_run:
                        hide_package(package)
                        print('Data profile is now set as draft and private')
            print('\n')

    return validation_results, packages_changed

def export_csv(path, package_results, changed_packages=None):
    with open(path, 'w') as f:
        header = 'publisher,data_profile,hidden,draft,' + ','.join(dcat_fields) + ',url' + '\n'
        f.write(header)

        if changed_packages is not None:
            packages = changed_packages
        else:
            packages = package_results

        for package_result in packages:
            validation = package_result.get('validation')

            if not validation.get('valid'):
                invalid_fields = validation.get('invalid_fields');
                package = package_result.get('package')
                publisher = package.get('organization')
                private_changed = str(package.get('private', 'false')).lower()
                indraft_changed = str(package.get('indraft', 'false')).lower()

                if changed_packages is not None:
                    private_changed = 'UPDATED: false to true' if private_changed == 'false' else 'true'
                    indraft_changed = 'UPDATED: false to true' if indraft_changed == 'false' else 'true'

                metadata_str = '%s,%s,%s,%s,' % (
                    publisher.get('name'), package.get('name'),
                    private_changed, indraft_changed
                )

                field_str = ','.join([
                    'INVALID' if field in invalid_fields else 'VALID' for field in dcat_fields
                ])
                field_url = ''
                field_url = url

                if len(field_url) > 0:
                    field_url = '{}/dataset/{}'.format(
                        field_url, package.get('name')
                    ) if field_url[-1] != '/' else '{}dataset/{}'.format(
                        field_url, package.get('name')
                    )
                else:
                    field_url = '/dataset/{}'.format(package.get('name'))

                f.write(metadata_str + field_str + ',' + field_url + '\n')


if __name__ == '__main__':
    #   Validate env variables
    if not url:
        print('[!] Missing environment variable \'ED_CKAN_URL\'')
        exit()

    if not api_key:
        print('[!] Missing environment variable \'ED_CKAN_KEY\'')
        exit()

    remote = RemoteCKAN(url, api_key)

    #   Set up CLI args
    parser = ArgumentParser()

    parser.add_argument('--all', help="validate all publishers", action="store_true")
    parser.add_argument('--publisher', help="validate one publisher by name")
    parser.add_argument('--file', help="bulk validation, each line in the file should be a publisher name")
    parser.add_argument('--log-output', help="log output file path")
    parser.add_argument('--csv-output', help="output results to a CSV file")
    parser.add_argument('--csv-output-changes', help="output changed results to a CSV file")
    parser.add_argument('--dry-run', help="do not modify state nor visibility of invalid data profiles", action="store_true")

    args = parser.parse_args()

    #   In case the user enables logging to file,
    #   replace stdout temporarily
    output_path = args.log_output
    stdout = None
    f = None
    if output_path:
        stdout = sys.stdout
        try:
            f = open(output_path, 'w')
            print('Saving output to file \'%s\'' % output_path)
        except Exception as e:
            print('[!] Could not open \'%s\':' % output_path)
            print(e)
            exit()
        sys.stdout = f

    #   Validation results are saved in this variable
    #   in order to later export it as a CSV file
    package_results = []
    packages_changed = []
    #   Bulk validation
    if args.all or args.file:
        publishers = []
        if args.file:
            with open(args.file, 'r') as f:
                publishers = f.readlines()
        else:
            publishers = get_all_publishers()

        for publisher in publishers:
            validated, changed = validate_publisher(publisher.strip())
            package_results.extend(validated)
            packages_changed.extend(changed)
    #   Individual publisher validation
    elif args.publisher:
        validated, changed = validate_publisher(args.publisher)
        package_results.extend(validated)
        packages_changed.extend(changed)
    else:
        parser.print_help()

    #   Write to CSV file if the user has chosen to run
    #   the script with the --csv-output argument
    if args.csv_output:
        print('Writing results to \'%s\'' % args.csv_output)
        export_csv(args.csv_output, package_results)

    if args.csv_output_changes:
        print('Writing changed results to \'%s\'' % args.csv_output_changes)
        export_csv(args.csv_output_changes, package_results, packages_changed)

    #   Reverts stdout to it's original value
    if output_path:
        sys.stdout = stdout
        f.close()
