import os
import random
import sys
import string
from ckanapi import RemoteCKAN
from ckanapi import errors as api_errors

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)
characters = string.ascii_letters + string.digits + '!@#$%^*()_-'


def user_list(current_user):
    users = []

    for user in remote.call_action(action='user_list'):
        if user['name'] != current_user:
            users.append(user['name'])

    return users


def verify_user(current_user):
    is_admin = False

    try:
        user = remote.call_action(
            action='user_show',
            data_dict={'id': current_user}
        )
        is_admin = user.get('sysadmin', False)
    except (api_errors.NotFound, api_errors.NotAuthorized) as e:
        print('\n{}'.format(e))
        is_admin = False

    return is_admin


def update_password(user_dict):
    return remote.call_action(
        action='user_update',
        data_dict=user_dict
    )


def update_api_key(user_dict):
    return remote.call_action(
        action='user_generate_apikey',
        data_dict=user_dict
    )


def run(current_user):
    users = user_list(current_user)
    i = 0
    users_count = len(users)

    for user in users + [current_user]:
        password = ''.join(random.sample(characters, 20))

        if i == users_count:
            print(
                '\nAll other users have been reset. Moving to current user: '
                '{}.\n'.format(current_user)
            )

        print('Resetting password for user: {}'.format(user))

        try:
            update_password({'id': user, 'password': password})
        except Exception as e:
            print(('\nPassword reset failed for user {}: {}\n'
                   'CKAN creates an internal system user for creating\n'
                   'objects in the backend. You can ignore this if {}\n'
                   'matches ckan.site_id in your .ini file. This user\n'
                   'doesn\'t use a password or API key.\n'
                   ).format(user, e, user))

        print('Resetting API key for user: {}'.format(user))

        try:
            update_api_key({'id': user})
        except Exception as e:
            print(('\nAPI reset failed for user {}: {}\n'
                   'CKAN creates an internal system user for creating\n'
                   'objects in the backend. You can ignore this if {}\n'
                   'matches ckan.site_id in your .ini file. This user\n'
                   'doesn\'t use a password or API key.\n'
                   ).format(user, e, user))

        i += 1


if __name__ == '__main__':
    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    remote = RemoteCKAN(url, apiKey)
    is_admin = False

    if len(sys.argv) < 2:
        errors.append(
            '\nYou must supply the sysadmin username the API key belongs to.\n\n'
            'Use `python reset_keys_and_passwords.py <SYSADMIN_USERNAME>`\n'
        )

    if len(sys.argv) > 2:
        errors.append(
            '\nToo many arguments given.\n\n'
            'Use `python reset_keys_and_passwords.py <SYSADMIN_USERNAME>`\n'
        )

    if len(sys.argv) == 2:
        current_user = sys.argv[1]
        is_admin = verify_user(current_user)

        if is_admin is False:
            errors.append((
                '\nUnable to run script. Please verify that {} is a sysadmin\n'
                'and that the API key you\'re using is valid and belongs to this user.\n\n'
                'Use `python reset_keys_and_passwords.py <SYSADMIN_USERNAME>`\n'
            ).format(current_user))

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    print('CKAN URL: {}'.format(url))
    run(current_user)
    print('\nDone!\n')
