import os
import sys
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

def get_packages():
    packages = remote.action.package_list()
    return packages

def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)

def get_all_packages():

    rows = 1000

    data_dict = {
        'q'  : '*:*',
        'rows' : rows,
        'start' : 0,
        'type' : 'dataset',
        'include_private': True
    }

    print('Getting a list of all packages... ', end='')

    result = package_search(data_dict=data_dict)
    if not result:
        return []

    packages = []
    packages.extend(result.get('results',[]))

    count = result.get('count')
    number_of_pages = (count // rows if count % rows == 0 else count // rows + 1)

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'q'  : '*:*',
                'rows': rows,
                'start': page_number * rows,
                'type' : 'dataset',
                'include_private': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results',[]))

    print('done!')
    return packages

def get_package(id):
    try:
        package = remote.action.package_show(id=id)
    except Exception as e:
        return None
    return package

def update_package(package):
    return remote.call_action(action='package_patch', data_dict=package)

def filter_datasets_with_empty_bureau_code(datasets):
    filtered_datasets = []
    for dataset in datasets:
        if not dataset.get('bureau_code', ''):
            filtered_datasets.append(dataset)
    
    return filtered_datasets

def bureau_code_auto_lookup(org_name):
    data_dict = {
        'id' : org_name
    }
    result = remote.call_action(action='organization_show', data_dict=data_dict)
    
    extras = result.get('extras', [])
    for extra in extras:
        if extra.get('key', '') == 'bureau_code':
            bureau_code = extra.get('value')
            if bureau_code:
                return bureau_code
    
    groups = result.get('groups',[])
    if groups:
        parent = groups[0]
        parent_name = parent.get('name','')
        bureau_code = bureau_code_auto_lookup(parent_name)
        if bureau_code:
            return bureau_code

    return ''

def update_packages(datasets):
    current = 1
    total_packages = len(datasets)
    print('Number of packages to update: ', total_packages)
    for dataset in datasets:
        package = get_package(dataset.get('id'))
        print('[{}/{}] Updating package {}... '.format(current,
                                                       total_packages,
                                                       package.get('name')), end='')
        package['bureau_code'] = bureau_code_auto_lookup(package.get('owner_org'))
        try:
            result = update_package(package)
            print('Package updated sucessfully.')
        except:
            print('Failed updating package.')

        current = current + 1

if __name__ == '__main__':
    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')
    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    all_datasets = False
    if len(sys.argv) > 1:
        if sys.argv[1] == "-all":
            all_datasets = True

    datasets = get_all_packages()
    if not all_datasets:
        datasets = filter_datasets_with_empty_bureau_code(datasets)
    update_packages(datasets)