import os
import re
import sys
import json
import fnmatch
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)
seedsDir = os.getenv('ED_SEEDS_DIR', None)

def get_seeds_path(object_type):
    default_source_dir = os.path.join(seedsDir, object_type)
    return default_source_dir

def load_json_organizations(file_path):
    with open(file_path, 'r') as f:
        try:
            return [{
                "id": g['name'], 
                "name": g['name'], 
                "title": g['title'], 
                "groups": [{
                    "name": g['subOrganizationOf'],
                    "capacity": "public"
                    }],
                "extras": [{
                    "key": "bureau_code",
                    "value": g['bureauCode']
                }]
                } for g in json.loads(f.read())]
        except Exception as error:
            print(error)
            sys.exit(1)

def update_publishers():
    source_dir = get_seeds_path('organizations')
    print(source_dir)
    seeds = []
    for root, dirnames, filenames in os.walk(source_dir):
        for filename in fnmatch.filter(filenames, '*.json'):
            organizations_file = re.sub(r'(\.json)$', '', filename)
            organizations = load_json_organizations(os.path.join(root, filename))
            for organization in organizations:
                if organization.get('groups') and not organization.get('groups')[0].get('name'):
                    del(organization['groups'])
                try:
                    created = remote.call_action(action='organization_create', data_dict=organization)
                    print('Created organization {} ({})'.format(created['id'], created['name']))
                except Exception as e:
                    try:
                        organization['id'] = organization['name']
                        #make organization active
                        organization['state'] = 'active'
                        updated = remote.call_action(action='organization_update', data_dict=organization)
                        print('Updated organization {} ({})'.format(updated['id'], updated['name']))
                    except Exception as error:
                        print('Could not create/update organization {}, skipping ({})'.format(organization['id'], error))

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')
    if not seedsDir:
        errors.append('ED_SEEDS_DIR environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)
    update_publishers()