import os
import sys
import csv, codecs, cStringIO

from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

class UnicodeWriter:
    """
    A CSV writer which will write rows to CSV file "f",
    which is encoded in the given encoding.
    """

    def __init__(self, f, dialect=csv.excel, encoding="utf-8", **kwds):
        # Redirect output to a queue
        self.queue = cStringIO.StringIO()
        self.writer = csv.writer(self.queue, dialect=dialect, **kwds)
        self.stream = f
        self.encoder = codecs.getincrementalencoder(encoding)()

    def writerow(self, row):
        self.writer.writerow([s.encode("utf-8") for s in row])
        # Fetch UTF-8 output from the queue ...
        data = self.queue.getvalue()
        data = data.decode("utf-8")
        # ... and reencode it into the target encoding
        data = self.encoder.encode(data)
        # write to the target stream
        self.stream.write(data)
        # empty queue
        self.queue.truncate(0)

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)

def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)

def get_all_packages():

    rows = 1000

    data_dict = {
        'q'  : '*:*',
        'rows' : rows,
        'start' : 0,
        'type' : 'dataset',
        'include_private': True
    }

    print('Getting a list of all packages... ')

    result = package_search(data_dict=data_dict)
    if not result:
        return []

    packages = []
    packages.extend(result.get('results',[]))

    count = result.get('count')
    number_of_pages = (count // rows if count % rows == 0 else count // rows + 1)

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'q'  : '*:*',
                'rows': rows,
                'start': page_number * rows,
                'type' : 'dataset',
                'include_private': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results',[]))

    print('done!')
    return packages

def parse_package(package):
    '''
    returns rows corresponding to the package passed by parameter
    one resource per row
    '''
    
    lines = []

    resources = package.get('resources', [])
    for resource in resources:
        res_name = resource.get('name', '')
        res_url = resource.get('url', '')

        line = [res_name, res_url]
        lines.append(line)

    return lines

def write_file(rows):

    with open('ed_odp_resources.csv', 'wb') as csv_file:
        csv_writer = UnicodeWriter(csv_file)
        csv_writer.writerows(rows)

def export_resources():
    packages = get_all_packages()

    csv_rows = []
    for package in packages:

        package_rows = parse_package(package)
        csv_rows.extend(package_rows)

    write_file(csv_rows)

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    export_resources()    