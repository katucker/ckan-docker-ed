import os
import sys
import csv
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

def read_csv(file_name):
    with open(file_name) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        org_list = []
        for row in csv_reader:
            org_name = row[0]
            org_list.append(org_name)

        return org_list

def delete_org(org_id):
    try:
        remote.call_action(action='ed_organization_delete', data_dict={'id': org_id})
    except Exception as e:
        print('Could not delete organization: ', e)
        return False
    
    print('The organization was deleted successfully.')
    return True

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    is_file_input = False
    org_name = ''
    if len(sys.argv) > 1:
        if sys.argv[1] == "-f":
            is_file_input = True
        else:
            org_name = sys.argv[1]

    filename = ''
    if len(sys.argv) > 2:
        if is_file_input:
            filename = sys.argv[2]

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    if is_file_input:
        org_list = read_csv(filename)
        for org_name in org_list:
            print('Deleting organization: {}'.format(org_name))
            delete_org(org_name)
    else:
        print('Deleting organization: {}'.format(org_name))
        delete_org(org_name)