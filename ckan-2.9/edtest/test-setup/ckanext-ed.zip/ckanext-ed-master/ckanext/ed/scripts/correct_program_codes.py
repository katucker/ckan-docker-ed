import os
import sys
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)


def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)


def get_packages(program_code):
    rows = 1000

    data_dict = {
        'rows': rows,
        'start': 0,
        'type': 'dataset',
        'q': 'program_code:"{}"'.format(program_code),
        'include_private': True
    }
    print('program_code:"{}"'.format(program_code))
    result = package_search(data_dict=data_dict)
    if not result:
        return []

    packages = []
    packages.extend(result.get('results', []))

    count = result.get('count')
    number_of_pages = (
        count // rows if count % rows == 0 else count // rows + 1)

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'rows': rows,
                'start': page_number * rows,
                'type': 'dataset',
                'q': 'program_code: "{}"'.format(program_code),
                'include_private': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results', []))

    return packages

def get_package(id):
    try:
        package = remote.action.package_show(id=id)
    except Exception as e:
        print(e)
        return
    return package

def update_package(package):
    return remote.call_action(action='package_update', data_dict=package)


def correct_program(program_code):
    packages = get_packages(program_code)

    total_packages = len(packages)
    current = 1
    errors = []

    print('Total Packages Found', total_packages)
    for package in packages:
        package = get_package(package.get('id'))

        print('[{}/{}] Updating package {}... '.format(current,
                                                       total_packages,
                                                       package.get('name')
                                                       ), end='')

        package['program_code'] = '018:000'
        try:
            update_package(package)
            print('done!')
        except:
            errors.append(package)
            print('failed!')
        current = current + 1
    if len(errors):
        print('=================================')
        print('Failed updating {} package{}:'.format(len(errors),
              ('s' if len(errors) > 1 else '')))
        for e in errors:
            print(e['name'])

if __name__ == '__main__':
    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')
    if len(sys.argv) < 2:
        errors.append('No invlaid Program code provided')
    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)

    print('CKAN URL: {}'.format(url))

    program_code = sys.argv[1]

    correct_program(program_code)