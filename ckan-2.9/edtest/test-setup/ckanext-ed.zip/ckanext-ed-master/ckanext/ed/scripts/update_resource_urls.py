import os
import sys
import csv
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)


def resource_show(data_dict):
    return remote.call_action(action='resource_show', data_dict=data_dict)


def resource_patch(data_dict):
    return remote.call_action(action='resource_patch', data_dict=data_dict)


def package_show(data_dict):
    return remote.call_action(action='package_show', data_dict=data_dict)


def update_urls(url_updates_list):
    resources_to_update = len(url_updates_list)
    update_number = 0

    for dataset_fields in url_updates_list:
        res_new_url = dataset_fields['url']
        res_old_url = dataset_fields['old_url']
        # unused fields provided in original OCR CSV
        # pkg_id = dataset_fields['name']
        # csv_scraped_from = dataset_fields['scraped_from']
        # resource_name = dataset_fields['title']
        update_number += 1

        resource_results = remote.call_action(
            action='resource_search',
            data_dict={'query': "url:{}".format(res_old_url)}).get('results')

        matching_resources = []
        resource_datasets = []

        if resource_results:
            for resource in resource_results:
                if resource.get('url') == res_old_url:
                    resource['url'] = res_new_url
                    package = package_show(
                        {'id': resource['package_id']})
                    resource_datasets.append(package['name'])
                    matching_resources.append(resource['name'])
                    resource_patch({'id': resource['id'], 'url': res_new_url})
        else:
            print('[{}/{}] WARNING: CSV "current URL" "{}" does not match any '
                  'resource URLs\nSkipping...'
                  .format(update_number, resources_to_update, res_old_url))
            continue

        matching_resources = list(set(matching_resources))
        resource_datasets = list(set(resource_datasets))

        print('[{}/{}] Updating resource(s) {} for dataset(s) {}:\n'
              'OLD URL: {}\n'
              'NEW URL: {}'.format(
                  update_number,
                  resources_to_update,
                  ', '.join(matching_resources),
                  ', '.join(resource_datasets),
                  res_old_url, res_new_url))

        matching_resources = []
        resource_datasets = []


def read_csv(file_name):
    with open(file_name) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        dataset_fields = []

        for row in csv_reader:
            dataset_title = row[0]
            new_url = row[1]
            old_url = row[2]
            scraped_from_url = row[3]
            dataset_name = row[4]

            dataset_fields.append(
                {'title': dataset_title, 'url': new_url, 'old_url': old_url,
                 'scraped_from': scraped_from_url, 'name': dataset_name})

        return dataset_fields


if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    file_name = ''
    args = sys.argv

    if '-f' in args and args.index('-f') + 1 < len(args):
        file_name = args[args.index('-f') + 1]
    else:
        print('Error: You must supply a file path with "-f" \n'
              '(i.e. python update_urls.py -f /path/to/csv)')
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    url_updates_list = read_csv(file_name)
    update_urls(url_updates_list)
