import os
import sys
import csv
from ckanapi import RemoteCKAN
from time import sleep

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)
failed_attempt=[]

def get_package_list():
    return remote.call_action(action='package_list')

def get_org_name(package_metadata):
    try:
        org_name = package_metadata.get('organization').get('name')
    except:
        org_name = None
    return org_name

def add_default_tag(package):
    package_metadata = remote.action.package_show(id=package)
    org_name = get_org_name(package_metadata)
    if not org_name:
        print("{0}Skipping Organization not found for {1}{2}".format(bcolors.WARNING,package,bcolors.ENDC))
        return
    package_type = package_metadata.get('type')
    package_tags = package_metadata.get('tags')
    if package_type != 'dataset' or any(tag.get('name') == org_name 
    for tag in package_tags):
        print("{0}Skipping {1}{2}".format(bcolors.WARNING,package,bcolors.ENDC))
        return

    acronym_tag = {'name': org_name}
    package_metadata.get('tags').append(acronym_tag)
    try:
        print('Updating dataset: {0}'.format(package))
        remote.call_action(action='package_update', data_dict=package_metadata)
        print("{0}Successfully updated {1} with tag {2}{3}".format(bcolors.OKGREEN,package,org_name,bcolors.ENDC))
    except Exception as e:
        print("{0}Could not update the dataset: {1} with tag {2} \n{3}".format(bcolors.FAIL,package,org_name,bcolors.ENDC),e)
        failed_attempt.append(package)

def update_tag():
    package_list = get_package_list()
    for package in package_list:
        add_default_tag(package)
    print("{0}All Done{1}".format(bcolors.OKBLUE,bcolors.ENDC))
    if failed_attempt:
        print("{0}Failed to update the following datasets\n{1}{2}".format(
            bcolors.FAIL,failed_attempt,bcolors.FAIL))

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)
    print("{0}CKAN URL:{1}{2}".format(bcolors.OKBLUE,url,bcolors.ENDC))
    update_tag()