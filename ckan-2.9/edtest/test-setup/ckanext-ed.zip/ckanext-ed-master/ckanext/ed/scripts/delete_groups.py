import os
import sys
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)
groupType = os.getenv('ED_CKAN_GROUP_TYPE', None)

'''
This script deletes and purges groups by type.
'''

def get_all_groups(group_type):
    data_dict = {
        'type': group_type
    }
    return remote.call_action(action='group_list', data_dict=data_dict)

def delete_groups(groups):
    for group in groups:
        data_dict = {
            'id' : group
        }
        remote.call_action(action='group_delete', data_dict=data_dict)

def purge_groups(groups):
    for group in groups:
        data_dict = {
            'id' : group
        }
        remote.call_action(action='group_purge', data_dict=data_dict)

def delete_and_purge_groups(group_type): 
    groups = get_all_groups(group_type)
    delete_groups(groups)
    purge_groups(groups)

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')
    if not groupType:
        errors.append('ED_CKAN_GROUP_TYPE environment variable is needed.')
    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = RemoteCKAN(url, apiKey)

    print('CKAN URL: {}'.format(url))
    print('Group Type: {}'.format(groupType))

    delete_and_purge_groups(groupType)