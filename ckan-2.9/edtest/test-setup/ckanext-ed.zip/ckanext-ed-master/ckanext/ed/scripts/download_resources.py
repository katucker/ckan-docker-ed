import os
import sys
import cgi
import tempfile
import requests

import ckanapi

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

def get_publisher_datasets(publisher_name, datasets=[], offset=0):
        limit = 100
        result = remote.call_action(action='package_search', data_dict={
            'q': '',
            'fq': 'organization:{}'.format(publisher_name),
            'type': 'dataset',
            'start': offset,
            'rows': limit,
            'include_drafts': True,
            'include_private': True
        })

        # We are only interested in the IDs, as there's nothing else relevant there
        ids = [d['id'] for d in result.get('results')]

        # Extend the existing list, if anything was found
        if result:
            datasets.extend(ids)

        # If there could be more to get, request the next batch
        if not len(result.get('results')) % limit and len(result.get('results')):
            get_publisher_datasets(publisher_name, datasets, offset + limit)

        return datasets

def get_harvester_datasets(harvest_source_name, datasets=[], offset=0):
        limit = 100

        source_id = remote.call_action(action='harvest_source_show', data_dict={
            'id': harvest_source_name}).get('id')
        if not source_id:
            print('Cannot find harvest source named {}'.format(harvest_source_name))
            sys.exit(1)

        result = remote.call_action(action='package_search', data_dict={
            'q': '',
            'fq': '+harvest_source_id:"{0}"'.format(source_id),
            'type': 'dataset',
            'start': offset,
            'rows': limit,
            'include_drafts': True,
            'include_private': True
        })

        # We are only interested in the IDs, as there's nothing else relevant there
        ids = [d['id'] for d in result.get('results')]

        # Extend the existing list, if anything was found
        if result:
            datasets.extend(ids)

        # If there could be more to get, request the next batch
        if not len(result.get('results')) % limit and len(result.get('results')):
            get_harvester_datasets(harvest_source_name, datasets, offset + limit)

        return datasets

def get_id_datasets(id_file_name):
        # Read the contents of the named file, expecting each line to contain an identifier.
        ids = []
        with open(id_file_name,) as id_file:
            ids = id_file.readlines()
            #Strip trailing newline characters
            ids = [line.strip() for line in ids]
            # Remove any blank lines
            while ("" in ids):
                    ids.remove("")
                    
        return ids

def get_documentation_datasets(ids):
    for dataset_id in ids:
        try:
            rel_result = remote.call_action(action='package_relationships_list', data_dict={
                'id': dataset_id,
                'rel': 'parent_of'
                })
            for rel in rel_result:
                try:
                    doc_id = rel['object']
                    # Check whether this object of the relationship is a documentation dataset.
                    result = remote.call_action(action='package_show', data_dict={'id': doc_id})
                    if (result.get('type') != 'documentation'): continue
                    ids.append(doc_id)

                except ckanapi.errors.NotFound:
                    continue
            
        except:
            continue
        
    return ids
    
def get_resources(cmd, name, get_uploads=False):

    # List of all dataset IDs belonging to this publisher or harvest source
    if cmd == 'publisher':
        datasets = get_publisher_datasets(name)
    elif cmd == 'harvester':
        datasets = get_harvester_datasets(name)
    elif cmd == 'id':
        datasets = get_id_datasets(name)
    
    # Add documentation datasets to the list.
    datasets = get_documentation_datasets(datasets)

    print("{0} datasets found".format(len(datasets)))

    resources = []       # List of all resources
    transformables = []  # List of all transformable resources

    for dataset_id in datasets:
        try:
            dataset = remote.call_action(action='package_show', data_dict={
                'id': dataset_id})
            if dataset.get('resources'):
                if get_uploads:
                    dataset_resources = [{'id': r['id'], 'url': r['url'], 'scraped_from': r.get('scraped_from', None)} for r in dataset['resources']]
                    dataset_transformables = [{'id': r['id'], 'url': r['scraped_from']} for r in dataset['resources'] if r.get('scraped_from', False) and r.get('url_type', '') == 'upload']
                else:
                    dataset_resources = [{'id': r['id'], 'url': r['url']} for r in dataset['resources']]
                    dataset_transformables = [{'id': r['id'], 'url': r['url']} for r in dataset['resources'] if r['url_type'] != 'upload' and r['url']]
                    resources.extend(dataset_resources)
                    transformables.extend(dataset_transformables)
                        
        except ckanapi.errors.NotFound:
            print('ID not found: {}'.format(dataset_id))

    return (resources, transformables)

def download_file(url):
    # Let's create, populate and return a temporary file
    tmp_file = tempfile.NamedTemporaryFile()
    content_type = None

    try:
        headers = {
            "User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"
        }
        r = requests.get(url, stream=True, headers=headers)
        #r.raise_for_status()
        # save the content type, we will need to return it
        content_type = r.headers.get('Content-Type','')

        # if it's HTML, don't even bother downloading the chunks
        if 'html' in content_type.lower():
            return (None, content_type)
        # For each chunk of the file we are getting, flush it into out temp file
        for chunk in r.iter_content(chunk_size=8192):
            tmp_file.write(chunk)
        tmp_file.seek(0)
        # Return the file-like object we need and its content type from headers
        return (tmp_file, content_type)

    except requests.exceptions.HTTPError as e:
        print("HTTP Error: %s", e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error: %s", e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error: %s", e)
    except requests.exceptions.TooManyRedirects as e:
        print("Too Many Redirects Error: %s", e)
    except requests.exceptions.RequestException as e:
        print("Request Exception Error: %s", e)

    return (None, '')

def download_resource(resource):

    # import ipdb; ipdb.set_trace()

    resource_id = resource['id']
    resource_url = resource['url']

    # try:
    #     # Get a file-like object with the file we need to save
    #     downloaded_file, downloaded_type = download_file(resource_url)
    # except HTTPError as e:
    #     print('Cannot fetch {}. Error was: {}'.format(resource_url, e))
    #     return False
    downloaded_file, downloaded_type = download_file(resource_url)

    if not downloaded_type:
        print('Cannot fetch {}.'.format(resource_url))
        return False

    if 'html' in downloaded_type.lower():
        print('Cannot fetch {}, got HTML instead.'.format(resource_url))
        return False

    if not downloaded_file:
        print('Cannot download {} due to an error.'.format(resource_url))
        return False

    try:
        # CKAN only accepts this kind of object here...
        file_obj = cgi.FieldStorage()
        file_obj.file = downloaded_file
        file_obj.filename = resource_url.split('/')[-1]
        file_obj.file.name = resource_url.split('/')[-1]
        
        #scraped_from = resource.get('scraped_from')
        data_dict = {
            'id': resource_id,
            'format': downloaded_type,
            # 'name': file_obj.filename,
            'scraped_from':  resource_url
        }
        result = requests.post('{}api/action/resource_update'.format(url),
            data=data_dict,
            headers={"X-CKAN-API-Key": apiKey},
            files=[('upload', file_obj.file)]
            )
        

    except Exception as e:
        print('Cannot update resource with ID {}. Error was: {}'.format(resource_id, e))
        return False

    # Closing a temporary file also triggers its deletion from the disk
    downloaded_file.close()

    return result

def restore_resource(resource):

    # import ipdb; ipdb.set_trace()

    resource_id = resource['id']
    resource_url = resource['url']
    scraped_from = resource.get('scraped_from', '')

    try:
        result = remote.call_action(action='resource_update', data_dict=
                                {'id': resource_id,
                                    'url': scraped_from if scraped_from else resource_url,
                                    'clear_upload': True,
                                    'url_type': 'null'})
    except Exception as e:
        print('Cannot update resource with ID {}. Error was: {}'.format(resource_id, e))
        return False

    return result        

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    remote = ckanapi.RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    cmd = ''
    if len(sys.argv) > 1:
        cmd = sys.argv[1]

    name = ''
    if len(sys.argv) > 2:
        name = sys.argv[2]

    if len(sys.argv) > 3:
        arg = sys.argv[3]
    else:
        arg = None

    if cmd not in ['harvester', 'publisher', 'id']:
        print('Command {0} not recognized'.format(cmd))
        sys.exit(1)

    if not name :
        print('Name {0} not recognized or provided'.format(name))
        sys.exit(1)

    # Get a list of all resources, and a list of all resources that are links
    resources, links = get_resources(cmd, name)
    print('{} resources found.'.format(len(resources)))
    print('{} resources need to be transformed.'.format(len(links)))
    print('================================')

    # Transform them one by one, count them etc\.
    counter = 0
    for link in links:
        counter = counter + 1
        print('[{}/{}] Transforming resource {} '.format(counter, len(links), link['url']))
        download_resource(link)