import os
import sys
import csv
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)

def get_publisher_packages(publisher_id, package_type='dataset'):

    rows = 1000

    data_dict = {
        'q'  : 'organization:' + str(publisher_id),
        'rows' : rows,
        'start' : 0,
        'type' : package_type,
        'include_private': True,
        'include_drafts': True
    }

    result = package_search(data_dict=data_dict)
    if not result:
        return []

    packages = []
    packages.extend(result.get('results',[]))

    count = result.get('count')
    number_of_pages = (count // rows if count % rows == 0 else count // rows + 1)

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'q'  : 'organization:' + str(publisher_id),
                'rows': rows,
                'start': page_number * rows,
                'type' : package_type,
                'include_private': True,
                'include_drafts': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results',[]))

    return packages

def get_package(id):
    try:
        package = remote.action.package_show(id=id)
    except Exception as e: 
        print('Could not find the dataset: ', id)
        print(str(e))
        return None
    return package


def update_owner_org(pkg_data_dict, new_owner_org):
    pkg_id = pkg_data_dict.get('id','')

    pkg = get_package(pkg_id)

    if not pkg:
        return False

    pkg['owner_org'] = new_owner_org

    try:
        remote.call_action(action='package_update', data_dict=pkg)
        return True
    except Exception as e:
        print('Could not update the dataset: ', e)
        return False

def read_csv(file_name):
    with open(file_name) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        org_updates_list = []
        for row in csv_reader:
            from_owner_org = row[0]
            to_owner_org = row[1]
            org_updates_list.append({'from_owner_org': from_owner_org,
                'to_owner_org': to_owner_org})

        return org_updates_list

def move_datasets(from_owner_org, to_owner_org):
    print("Moving datasets from {} to {}".format(from_owner_org, to_owner_org))
    datasets = get_publisher_packages(from_owner_org,package_type='dataset')
    print('{} datasets to update'.format(len(datasets)))
    for dataset in datasets:
        print("Updating dataset: ", dataset.get('name'))
        update_owner_org(pkg_data_dict=dataset, new_owner_org=to_owner_org)

def move_documentation(from_owner_org, to_owner_org):
    print("Moving documentation from {} to {}".format(from_owner_org, to_owner_org))
    datasets = get_publisher_packages(from_owner_org,package_type='documentation')
    print('{} documentation to update'.format(len(datasets)))
    for dataset in datasets:
        print("Updating documentation: ", dataset.get('name'))
        update_owner_org(pkg_data_dict=dataset, new_owner_org=to_owner_org)    

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    is_file_input = False
    from_owner_org = ''
    if len(sys.argv) > 1:
        if sys.argv[1] == "-f":
            is_file_input = True
        else:
            from_owner_org = sys.argv[1]

    filename = ''
    to_owner_org = ''
    if len(sys.argv) > 2:
        if is_file_input:
            filename = sys.argv[2]
        else:
            to_owner_org = sys.argv[2]

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))

    if is_file_input:
        org_updates_list = read_csv(filename)
        for org_update in org_updates_list:
            from_owner_org = org_update.get('from_owner_org', '')
            to_owner_org = org_update.get('to_owner_org', '')
            
            move_datasets(from_owner_org, to_owner_org)
            move_documentation(from_owner_org, to_owner_org)
            
    else:
        move_datasets(from_owner_org, to_owner_org)
        move_documentation(from_owner_org, to_owner_org)