import argparse
import json
from logging import getLogger
import ntpath
import os
import sys

from ckanapi import RemoteCKAN

import openpyxl
from openpyxl import load_workbook
from io import BytesIO
import urllib

from multiprocessing import Pool, cpu_count, TimeoutError
from multiprocessing.dummy import Pool as ThreadPool
from functools import partial

import cgi

import tempfile

import requests

log = getLogger(__name__)

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)
# publisher_id = os.getenv('ED_CKAN_ORG_ID', None)


# from 
# https://stackoverflow.com/questions/29494001/how-can-i-abort-a-task-in-a-multiprocessing-pool-after-a-timeout
def abortable_worker(func, *args, **kwargs):
    # print("Abortable worker with args: {} and kwargs: {}".format(args, kwargs))
    timeout = kwargs.get('timeout', 300)
    p = ThreadPool(1)
    res = p.apply_async(func, args=args)
    try:
        out = res.get(timeout)  # Wait timeout seconds for func to complete.
        return out
    except TimeoutError:
        return "Timeout Error {} sec. for args: {} and kwargs: {}".format(timeout, args, kwargs)


def _create_fs(name, mimetype, content):
    fs = cgi.FieldStorage()
    fs.file = tempfile.NamedTemporaryFile('w+')
    fs.filename = name
    fs.type = mimetype
    fs.file.writelines(content)
    fs.file.seek(0)
    return fs


def load_workbook_from_url(url):
    xfile = urllib.request.urlopen(url).read()
    return load_workbook(filename = BytesIO(xfile), read_only=True)


def single_sheet_xlsx2csv(xlsx):
    """[summary]

    Args:
        xlsx (Workbook): [description]
    """
    sheet = xlsx.active
    data = sheet.rows
    rows = []
    row_len = 0
    for row in data:
        row_items = [str(c.value) for c in row]
        # validate that the csv row is correct (number of items must equal the ones in the header)
        if row_len > 0:
            if row_len != len(row_items):
                raise Exception("Invalid CSV conversion, inconsistent column count")
        else:
            row_len = len(row_items)
        rows.append(','.join(row_items)+'\n')
    return rows
    

def xlsx_file2csv_file(fname, oname):
    """Converts an xlsx file from a given path into csv and saves it in the output path given
    Args:
        fname ([path|str]): Path to file to read
        oname ([path|str]): Path of csv file to write
    """
    xlsx = openpyxl.load_workbook(fname, read_only=True)
    csv_data = single_sheet_xlsx2csv(xlsx)
    csv = open(oname, "w+")
    csv.writelines(csv_data)
    csv.close()
    xlsx.close()
  
def xlsx_uri2csv(resource_url):
    """

    Args:
        fname ([path|str]): Path to file to read
        oname ([path|str]): Path of csv file to write
    """
    # open from url
    log.debug("Loading Workbook")
    # https://stackoverflow.com/questions/20635778/using-openpyxl-to-read-file-from-memory
    xlsx_wb = load_workbook_from_url(resource_url)
    log.debug("Converting to CSV")
    csv_rows = single_sheet_xlsx2csv(xlsx_wb)
    xlsx_wb.close()
    return csv_rows
  

def path_leaf(path):
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)


def convert_format(resource_id):
    """ Takes a resource id and an optional context and translates an excel file into CSV
    Args:
        resource_id (str): id (UUID) of the resource to transform from XLSX into CSV
    """
    try: 
        resource = remote.action.resource_show(id=resource_id)
        
        metadata = {
        "package_id": resource["package_id"], 
        "description": resource.get("description", "translated to CSV from {}".format(resource_id)),
        "format": "CSV",
        "name": resource.get("name", "none.csv").replace(".xlsx", ".csv"),
        "resource_type": "text/csv", 
        "approval_status": "pending",
        # translated_from gets saved as "name" if not dumped as json (anything in ckan?)
        "translated_from": json.dumps(resource),
        # "translated_from": resource,
        }
        
        resource_url =  resource["url"]
        # validate that the resource is (or at least seems) an excel file
        if not resource_url.endswith(".xlsx"):
            print("Given resource file {} is not XLSX format".format(resource_url))
            raise(Exception("Wrong format Exception. Given resource file {} is Not an XLSX file").format(resource_url))
        # oname = path_leaf(resource_url).replace(".xlsx", ".csv")
        # open and convert
        csv_rows = xlsx_uri2csv(resource_url)
        return csv_rows, metadata
    except Exception as e:
        print("Error while trying to convert resource {} to csv".format(resource_id))
        print(e)
        raise e


def save_to_disk(csv_rows, metadata, opath="."):
    tfrom = json.loads(metadata["translated_from"])
    oname = path_leaf(tfrom["url"]).replace(".xlsx", ".csv")
    with open(os.path.join(opath, oname), "w") as f:
            f.writelines(csv_rows)
    # save resource metadata for reference
    with open(os.path.join(opath, oname.replace(".csv", ".metadata.json")), "w", encoding="utf-8") as f:
        f.write((json.dumps(metadata, ensure_ascii=False)).decode("utf-8"))

def get_all_resource_ids():
    all_packages = remote.action.current_package_list_with_resources()
    log.debug( all_packages)
    to_translate = []
    xlsx_dict = {}
    # separate by packages
    for pkg in all_packages:
        ress = pkg["resources"]
        for r in ress:
            try:
                if r["url"].endswith(".xlsx"):
                    xlsx_dict[r['id']] = r['url']
                if r['format'] == "CSV" or r["resource_type"] == "text/csv" or r["url"].endswith(".csv") or r["name"].endswith(".csv"):
                    if 'translated_from' in r:
                        orig = json.loads(r['translated_from'].replace("'", '"'))
                        k_xlsx = orig['id']
                        # take the element out of the translation queue (it is already translated)
                        xlsx_dict.pop(k_xlsx, None)
            except Exception as e:
                log.error("Error trying to get resources from the list of packages")
                log.error(e)
    return xlsx_dict


def create_translated_resource(resource_id):
    print("Translating {}".format(resource_id))
    try: 
        # Translate
        csv_rows, metadata = convert_format(resource_id)
        name = metadata['name']
        mimetype = metadata['resource_type']
        fcsv = _create_fs(name, mimetype, csv_rows)
        # metadata["upload"] = fcsv.file
        # create resource - API is failing here to correctly upload the file
        # remote.action.resource_create(**metadata)
        # Alternative usage while finding the reason of remoteCKAN failure:
        requests.post('{}/api/action/resource_create'.format(url),
                      data=metadata,
                      headers={"X-CKAN-API-Key": apiKey},
                      files=[('upload', fcsv.file)])
        return "Translation SUCCESS, id={}\n".format(resource_id)
    except Exception as e:
        log.error("Error translating resource: {}".format(resource_id), e)
    return "Translation FAILED, id={}\n".format(resource_id)


def translate_all(ofile="translated.txt", timeout=300):
    # get the list of all resources
    xlsx_dict = get_all_resource_ids()
    print(xlsx_dict)
    # translate them in parallel
    pool = Pool(maxtasksperchild=1)
   
    results = []
    def collect_results(res):
        results.append(res)

    for k in xlsx_dict.keys():
        print("Setting resource {} for translation ".format(k))
        abortable_func = partial(abortable_worker,create_translated_resource, timeout=timeout)
        pool.apply_async(abortable_func, args=[k, ],callback=collect_results)
    pool.close()
    pool.join()
    # res = pool.map(create_translated_resource, params)
    # res = pool.map_async(create_translated_resource, params)
    # write down the list of translated resources
    with open(ofile, "w") as f:
        f.write('\n'.join(results))
        f.flush()


def create_translated_file(resource_id, output_path):
    try:
        csv_rows, metadata = convert_format(resource_id)
        save_to_disk(csv_rows, metadata, output_path)
        return "Translation SUCCESS, id={}\n".format(resource_id)
    except Exception as e:
        # exceptions should not halt the rest of the process
        log.error("Error translating resource id: {} ".format(resource_id), e)
        print("Error translating resource id: {}".format(resource_id), e)
    return "Translation FAILED, id={}\n".format(resource_id)


def translate_all_to_local(resources, output_path, ofile="translated.txt", timeout=300):

    # translate them in parallel
    pool = Pool(maxtasksperchild=1)
   
    results = []
    def collect_results(res):
        results.append(res)

    for res_id in resources:
        print("Setting resource {} for translation ".format(res_id))
        abortable_func = partial(abortable_worker, create_translated_file, timeout=timeout)
        pool.apply_async(abortable_func, args=[res_id, output_path],callback=collect_results)
    pool.close()
    pool.join()
    # res = pool.map(create_translated_resource, params)
    # res = pool.map_async(create_translated_resource, params)
    # write down the list of translated resources
    with open(ofile, "w") as f:
        f.write('\n'.join(results))
        f.flush()



def main():
    parser = argparse.ArgumentParser()
    # parser.add_argument("url", nargs='+', help="CKAN URL, Mandatory")
    parser.add_argument("--id", help="Resource ID to convert. Creates the translated file in local.")
    parser.add_argument("-f", "--file", help="file containing a list of resource ids to convert, one per line. Creates the translated files in local.")
    parser.add_argument("-o", "--output-path", default=".", help="Local path where to save the CSV files.")
    parser.add_argument("-t", "--timeout", default=300, help="Timeout for each translation thread")
    parser.add_argument("-a", "--all", action='store_true', help="Translate all the available resources in CKAN creating new resources.")
    parser.add_argument("-l", "--list", action='store_true', help="list all XLSX resources available, outputs to terminal")
    
    args = parser.parse_args()
    if args.list:
        all_resources = get_all_resource_ids()
        print('\n'.join(all_resources))
    elif args.all:
        translate_all(timeout=args.timeout)
    elif args.file:
        with open(args.file, "r") as f:
            resources = [e.strip() for e in f.readlines()]
            translate_all_to_local(resources, args.output_path, timeout=args.timeout)
    elif args.id:
        csv_rows, metadata = convert_format(args.id)
        save_to_disk(csv_rows, metadata, args.output_path)
    else:
        print("Missing arguments. Pass either --all, the resource id or a file containing a list of resource ids")
        sys.exit(1)
        

if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')
    # if not publisher_id:
    #     errors.append('ED_CKAN_ORG_ID environment variable is needed.')
    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)
    # remote = RemoteCKAN(url)
    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}'.format(url))
    print('CKAN API KEY: {}'.format(apiKey))
    # print('Publisher: {}'.format(publisher_id))
    main()
