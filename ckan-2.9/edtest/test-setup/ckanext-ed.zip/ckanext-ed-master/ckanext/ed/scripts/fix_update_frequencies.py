import os
import sys
import csv
from ckanapi import RemoteCKAN

url = os.getenv('ED_CKAN_URL', None)
apiKey = os.getenv('ED_CKAN_KEY', None)

UPDATE_FREQUENCIES = [
    'R/P2M', 'R/P3.5D', 'R/P0.5W', 'irregular', 'R/P1D', 'R/P0.33M', 'R/P1Y',
    'R/P4M', 'R/P1W', 'R/P3M', 'R/P10Y', 'R/P1M', 'R/P0.33W', 'R/P4Y',
    'R/PT1H', 'R/P2Y', 'R/PT1S', 'R/P3Y', 'R/P2W', 'R/P0.5M', 'R/P6M',
    'remove', ''
]


def package_search(data_dict):
    return remote.call_action(action='package_search', data_dict=data_dict)


def get_packages(package_type='dataset'):

    rows = 1000

    data_dict = {
        'rows': rows,
        'start': 0,
        'type': package_type,
        'include_private': True,
        'include_drafts': True
    }

    result = package_search(data_dict=data_dict)

    if not result:
        return []

    packages = []
    packages.extend(result.get('results', []))

    count = result.get('count')
    number_of_pages = (
        count // rows if count % rows == 0 else count // rows + 1
    )

    if number_of_pages == 1:
        return packages
    else:

        for page_number in range(1, number_of_pages):

            data_dict = {
                'rows': rows,
                'start': page_number * rows,
                'type': package_type,
                'include_private': True,
                'include_drafts': True
            }

            result = package_search(data_dict=data_dict)
            packages.extend(result.get('results', []))

    return packages


def check_input(old_frequency, new_frequency):
    if new_frequency not in UPDATE_FREQUENCIES:
        print('\nError: {} is not a valid accrualPeriodicity.'
              .format(new_frequency))
        quit()


def update_frequencies(
    old_frequency=None,
    new_frequency=None,
    is_file_input=False,
        file_path=None):

    remove = new_frequency == 'remove'

    frequency_conversion = {
        old_frequency: new_frequency if remove is False else ''
    }

    if is_file_input:
        frequency_conversion = iterate_file(file_path)

    if remove is False:
        for key, value in frequency_conversion.items():
            check_input(key, value)

    packages = get_packages()

    if not packages:
        return False

    packages_updated = 0

    for package in packages:
        current_frequency = package.get('update_frequency')

        if current_frequency in frequency_conversion:
            new_frequency_value = frequency_conversion[current_frequency]
            package['update_frequency'] = new_frequency_value

            try:
                if new_frequency_value == '':
                    print('Removing accrualPeriodicity {} for {}'
                          .format(current_frequency, package['name'])
                          )
                else:
                    print('Changing accrualPeriodicity for {} from {} to {}'
                          .format(package['name'], current_frequency,
                                  new_frequency_value)
                          )
                remote.call_action(action='package_update', data_dict=package)
                packages_updated += 1

            except Exception as e:
                print('Error: Could not update {}: {}'
                      .format(package['name'], e))

    print('\n{} package(s) were updated'.format(packages_updated))


def iterate_file(file_path):
    with open(file_path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        frequency_conversion = {}

        for row in csv_reader:
            old_frequency, new_frequency = row[0], row[1]
            frequency_conversion[old_frequency] = \
                new_frequency if new_frequency != 'remove' else ''

        return frequency_conversion


if __name__ == '__main__':

    errors = []

    if not url:
        errors.append('ED_CKAN_URL environment variable is needed.')
    if not apiKey:
        errors.append('ED_CKAN_KEY environment variable is needed.')

    if len(errors):
        for e in errors:
            print(e)
        sys.exit(1)

    is_file_input = False
    old_frequency = ''
    new_frequency = ''
    file_path = ''

    if len(sys.argv) == 3:
        if sys.argv[1] == '-f':
            is_file_input = True
            file_path = sys.argv[2]
        else:
            old_frequency = sys.argv[1]
            new_frequency = sys.argv[2]

    if len(sys.argv) == 1:
        old_frequency = 'Other'
        new_frequency = 'irregular'

    remote = RemoteCKAN(url, apiKey)
    print('CKAN URL: {}\n'.format(url))
    update_frequencies(old_frequency, new_frequency, is_file_input, file_path)
