import os
import time
import distutils.util
import pandas as pd
from ckanapi import RemoteCKAN, CKANAPIError

import logging
log = logging.getLogger(__name__)

ckan_url = os.getenv('ED_CKAN_URL', 'https://us-ed-testing.ckan.io')
api_url = os.getenv('ED_CKAN_URL', ckan_url)
api_key = os.getenv('ED_CKAN_KEY', None)
xlsx_file = os.getenv('ED_CKAN_XLSX', 'output.xlsx')

ckan = RemoteCKAN(api_url, apikey=api_key)

if bool(os.getenv('XLS_EXPORT_ORGS')):
    wanted_organizations = os.getenv('XLS_EXPORT_ORGS', '').split(',')
else:
    wanted_organizations = None
wanted_organizations_names = []
wanted_organizations_ids = []

export_all_fields = bool(
    distutils.util.strtobool(
        os.getenv('XLS_EXPORT_ALL_FIELDS', 'False')))

def make_ckan_request(action, data_dict, retry=0):
    result = None
    try:
        time.sleep(0.1)
        result = ckan.call_action(action, data_dict)
    except CKANAPIError:
        if retry < 6:
            print('retrying...', end='')
            result = make_ckan_request(action, data_dict, retry+1)
        else:
            print('FAILED', end='')
            raise Exception('Max retries exceeded')
    return result


def get_all_organizations():
    organization_names = []
    organization_details = []
    organizations = []

    try:
        organization_names = make_ckan_request('organization_list', {})
        for organization in organization_names:
            print('Getting details for organization {}...'.format(organization), end='')
            organization_details.append(
                make_ckan_request(
                    'organization_show',
                    {'id': organization}))
            print('done.')
    except:
        raise Exception('Could not get organizations list, please retry.')

    organizations = {o['id']: o['name'] for o in organization_details}
    return organizations

def get_all_datasets():
    datasets = []
    offset = 0

    datasets = get_datasets(offset)
    while not len(datasets) % 500:
        offset = offset + 500
        datasets.extend(get_datasets(offset))
    print('Collected {} datasets.'.format(len(datasets)))
    return datasets

def get_datasets(offset):
    print('Collecting datasets between {} and {}...'.format(offset, offset+500), end='')
    result = make_ckan_request('package_search',
                               {'rows': 500,
                                'include_private': True,
                                'start': offset})
    print('done.')
    results = result.get('results', [])
    return [r['name'] for r in results]

def get_dataset(name, retry=0):
    result = None
    try:
        time.sleep(0.1)
        result = ckan.call_action('package_show', {'id': name})
        if result.get('type', 'dataset') != 'dataset':
            return None
        if wanted_organizations:
            result_org = result.get('owner_org')
            if result_org not in wanted_organizations_names\
                     and result_org not in wanted_organizations_ids:
                return None

        result_dict = {
            'Title': result.get('title', 'no title'),
            'Categories': ', '.join([str(g['display_name']) for g in result['groups']]),
            'URL': '{}/dataset/{}'.format(ckan_url, result['name']),
            'owner_org': result.get('owner_org'),
        }

        if export_all_fields:
            result_dict.update({
                'license': result.get('license'),
                'tags': ', '.join([str(t['display_name']) for t in result['tags']]),
                'description': result.get('notes'),
                'program_code': result.get('program_code'),
                'level_of_data' : ', '.join([str(l) for l in result['level_of_data']]),
                'update_frequency': result.get('update_frequency'),
                'helpdesk_phone': result.get('author'),
                'helpdesk_email': result.get('author_email'),
                'steward_name': result.get('maintainer'),
                'steward_email': result.get('maintainer_email'),
                'access_level': result.get('access_level'),
                'spatial': ', '.join([str(s) for s in result['spatial']]),
                'start_date': result.get('start_date'),
                'end_date': result.get('end_date'),
                'uuid': result.get('id'),
                'source_url': result.get('scraped_from'),
            })

        return result_dict
    except CKANAPIError:
        if retry < 6:
            print('retrying...', end='')
            return get_dataset(name, retry+1)
        else:
            print('FAILED', end='')
            raise Exception('Max retries exceeded')

def get_datasets_df(datasets):
    ckan_packages = []
    errors = []
    for dataset in datasets:
        print('Getting details for package {}...'.format(dataset), end='')
        try:
            dataset_dict = get_dataset(dataset)
            if dataset_dict is not None:
                ckan_packages.append(dataset_dict)
                print('done')
            else:
                print('done, not the droids we are looking for.')
        except Exception as e:
            errors.append({dataset: e})
            print('ERROR.')
    result = (ckan_packages, errors)

    if len(result[1]):
        print('{} error(s) occured, please check the output before using it.'.format(len(result[1])))
        print(result[1])

    df = pd.DataFrame(result[0])
    return df


# Script main execution thread

if wanted_organizations:
    for w in wanted_organizations:
        wanted_organizations_names.append(make_ckan_request('organization_show', {'id': w}).get('name'))
        wanted_organizations_ids.append(make_ckan_request('organization_show', {'id': w}).get('id'))

print('Collecting data from {}'.format(ckan_url))

df = get_datasets_df(get_all_datasets())
organizations = get_all_organizations()

existing_organizations = df['owner_org'].unique()
print('Got {} organizations.'.format(len(existing_organizations)))

for organization in existing_organizations:
    print('Dumping {} datasets'.format(organizations[organization]))
    result = df[df['owner_org']==organization]
    output_file = 'data-profiles_{}_{}'.format(organizations[organization], xlsx_file)
    if os.path.exists(output_file):
        os.unlink(output_file)
    with pd.ExcelWriter(output_file, engine="openpyxl",
                        mode='w') as writer:
        result = result.drop('owner_org', axis=1)
        result['Reviewed'] = 'NO'
        result.to_excel(writer,
                        index=False,
                        engine='openpyxl')
