from logging import getLogger
import os
import json
import requests
import uuid
import zipfile
import datetime
import ckan
import sqlalchemy
#from paste.deploy.converters import asbool
import six
from six import text_type, string_types
import cgi
from collections import OrderedDict
import time
from werkzeug.datastructures import FileStorage as FlaskFileStorage

from ckan.common import config
import ckan.logic as logic
import ckan.authz as authz
import ckan.logic.auth as logic_auth
import ckan.plugins as plugins
import ckan.lib.plugins as lib_plugins
import ckan.lib.search as search
import ckan.lib.dictization as dictization
import ckan.lib.dictization.model_dictize as model_dictize
import ckan.lib.dictization.model_save as model_save
import ckan.lib.uploader as uploader
import ckan.lib.helpers as h
import ckan.model.misc as misc

from ckan.common import _, c, g
import ckan.model as model
from ckan.model import system_info

from ckan.plugins import toolkit
#from ckan.controllers.admin import get_sysadmins
from ckan.lib.mailer import MailerException
from ckan.logic.action.get import activity_show as core_activity_detail_dict
from ckan.logic.action.get import dashboard_activity_list as core_dashboard_activity_list
from ckan.logic.action.get import group_activity_list as core_group_activity_list
from ckan.logic.action.get import package_activity_list as core_package_activity_list
from ckan.logic.action.get import package_show as core_package_show
from ckan.logic.action.get import recently_changed_packages_activity_list as core_recently_changed_packages_activity_list
from ckan.logic.auth.create import _check_group_auth
from ckan.logic.action.update import user_update as ckan_user_update
from ckan.logic.action.get import _tag_search
import ckan.lib.app_globals as app_globals
import ckan.logic.schema as schema_

from ckanext.harvest.model import HarvestSource, HarvestJob, HarvestObject
from ckanext.harvest.logic.action.update import harvest_source_index_clear
from ckanext.ed import helpers, core_activity_streams
from ckanext.ed.model import group_dictize, remove_hierarchy_relationships, GroupTreeNode, get_record_scheduledb
from ckanext.ed.model import get_package_child, update_package_child
from ckanext.ed.model import update_notf_preferences, is_coordinator, get_coordinator_orgs, update_coordinator, remove_coordinator
from ckanext.ed.mailer import mail_package_publish_request_to_admins
from ckanext.ed.model import get_user_package_fields, set_user_package_fields

from ckanext.ed.format_converters.translate2csv import enqueue_translation

from flask import Flask

app = Flask(__name__)


SUPPORTED_RESOURCE_MIMETYPES = [
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/x-msdownload',
    'application/msword',
    'application/vnd.google-earth.kml+xml',
    'application/vnd.ms-excel',
    'application/msexcel',
    'application/x-msexcel',
    'application/x-ms-excel',
    'application/x-excel',
    'application/x-dos_ms_excel',
    'application/xls',
    'application/x-xls',
    'wcs',
    'application/x-javascript',
    'application/x-msaccess',
    'application/netcdf',
    'text/tab-separated-values',
    'text/x-perl',
    'application/vnd.google-earth.kmz+xml',
    'application/vnd.google-earth.kmz',
    'application/owl+xml',
    'application/x-n3',
    'application/zip',
    'application/gzip',
    'application/x-gzip',
    'application/x-qgis',
    'application/vnd.oasis.opendocument.spreadsheet',
    'application/vnd.oasis.opendocument.text',
    'application/json',
    'image/x-ms-bmp',
    'application/rar',
    'image/tiff',
    'application/vnd.oasis.opendocument.database',
    'text/plain',
    'application/x-director',
    'application/vnd.oasis.opendocument.formula',
    'application/vnd.oasis.opendocument.graphics',
    'application/xml',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/octet-stream',
    'application/xslt+xml',
    'image/svg+xml',
    'application/vnd.ms-powerpoint',
    'application/vnd.oasis.opendocument.presentation',
    'image/jpeg',
    'application/sparql-results+xml',
    'image/gif',
    'application/rdf+xml',
    'application/pdf',
    'text/csv',
    'application/vnd.oasis.opendocument.chart',
    'application/atom+xml',
    'application/x-tar',
    'image/png',
    'application/rss+xml',
    'application/geo+json'
]

log = getLogger(__name__)
_check_access = logic.check_access
_get_action = logic.get_action
_get_or_bust = logic.get_or_bust
NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
_validate = ckan.lib.navl.dictization_functions.validate
_or_ = sqlalchemy.or_


# WARNING moved from helpers due to circular dependency if situated there
def collection_datasets_string(collection_id):
    context = { 'model': model, 'session': model.Session }
    fq = '+groups:"{0}"'.format(collection_id)
    search_dict = {
        'q': '',
        'type': 'dataset',
        'fq': fq,
    }
    collection_data = package_search(context, search_dict)['results']

    collection_datasets = [package['name'] for package in collection_data]
    return ','.join(collection_datasets)


def csv_to_tags(csv_string):
    # If it's already a list, skip this
    if isinstance(csv_string, list):
        return csv_string

    tags_list = None
    if csv_string:
        tags_list = csv_string.split(',')
    else:
        tags_list = csv_string
    return tags_list

@toolkit.side_effect_free
def package_show(context, data_dict):
    '''
    ckanext-ed implementation for package show
    it calls the core package show and filter the resources 
    based on the approval status
    '''
    package_dict = core_package_show(context, data_dict)
    user = context.get('user')

    # if sysadmin returns the core package show result
    if user is not None and len(user) > 0:
        if helpers.is_admin(user) or helpers.is_editor(user) or helpers.is_coordinator(user, package_dict.get('organization', {}).get('name')) or authz.is_sysadmin(user):
            return package_dict
        else:
            if package_dict.get('indraft', False) and package_dict.get('private', False):
                if package_dict['indraft'] in [True, 'true']:
                    raise NotAuthorized

    if context.get('ignore_auth') is True:
        return package_dict

    filtered_resources = []
    approval_workflow = True
    if approval_workflow:
        resources = package_dict['resources']
        for resource in resources:
            approval_status = resource.get('approval_status', '')
            if not approval_status or approval_status == 'approved':
                filtered_resources.append(resource)
    
    package_dict['resources'] = filtered_resources
    return package_dict

@toolkit.side_effect_free
def package_create(context, data_dict):
    model = context['model']
    session = context['session']
    user = context['user']

    try:
        _get_action('package_show')(context, {'name_or_id': data_dict.get('name')})
        log.info('Package already exists: {0}'.format(data_dict.get('name')))
        return
    except NotFound:
        # Package doesn't exist, continue
        pass

    # Use boolean values for CKAN 2.9+
    if data_dict.get('private') == 'False':
        data_dict['private'] = False
    if data_dict.get('private') == 'True':
        data_dict['private'] = True

    if 'type' not in data_dict:
        package_plugin = lib_plugins.lookup_package_plugin()
        try:
            # use first type as default if user didn't provide type
            package_type = package_plugin.package_types()[0]
        except (AttributeError, IndexError):
            package_type = 'dataset'
            # in case a 'dataset' plugin was registered w/o fallback
            package_plugin = lib_plugins.lookup_package_plugin(package_type)
        data_dict['type'] = package_type
    else:
        package_plugin = lib_plugins.lookup_package_plugin(data_dict['type'])

    if 'schema' in context:
        schema = context['schema']
    else:
        schema = package_plugin.create_package_schema()

    _check_access('package_create', context, data_dict)

    spatial_tags = csv_to_tags(csv_string=data_dict.pop('spatial', []))

    try:
        current_path = os.path.abspath(__file__)
        current_dir = os.path.split(current_path)[0]
        file_path = "seeds/tags/spatial.json"
        abs_file_path = os.path.join(current_dir, file_path)
        existing_spatial_tags = []

        with open(abs_file_path) as spatial_tags_file:
            for tag in json.load(spatial_tags_file):
                existing_spatial_tags.append(tag['name'])

        for tag in spatial_tags:
            if tag not in existing_spatial_tags:
                spatial_tags.remove(tag)
    except:
        log.warn('Error while validating spatial vocabularies, skipping...')

    data_dict['spatial'] = spatial_tags
    level_of_data_tags = csv_to_tags(csv_string=data_dict.pop('level_of_data', []))
    data_dict['level_of_data'] = level_of_data_tags

    data_dict['owner_suborg'] = ""

    if not data_dict.get('groups'):
        data_dict['groups'] = []

    collections = data_dict.pop('collections', None)
    ed_source = data_dict.pop('ed_source', None)
    current_groups = data_dict['groups']
    ed_sources = []
    ed_collections = []

    if collections is not None:
        if type(collections) == list:
            ed_collections = collections

            for c in collections:
                group = helpers.get_group_dict({'id': c})
                data_dict['groups'].append(group)

        if type(collections) == str:
            ed_collections = [collections]
            group = helpers.get_group_dict({'id': collections})
            data_dict['groups'].append(group)
    
    if ed_source is not None:
        if type(ed_source) == list:
            ed_sources = ed_source

            for c in ed_source:
                group = helpers.get_group_dict({'id': c})
                data_dict['groups'].append(group)

        if type(ed_source) == str:
            ed_sources = [ed_source]
            group = helpers.get_group_dict({'id': ed_source})
            data_dict['groups'].append(group)

    for group in current_groups:
        group_dict = helpers.get_group_dict(group)

        if data_dict.get('type') != 'documentation':
            if group_dict.get('type') == 'collection' \
               and group_dict.get('name') not in ed_collections:
                data_dict['groups'].remove(group)

            if group_dict.get('type') == 'ed_source' \
               and group_dict.get('name') not in ed_sources:
                data_dict['groups'].remove(group)

    if 'api_version' not in context:
        # check_data_dict() is deprecated. If the package_plugin has a
        # check_data_dict() we'll call it, if it doesn't have the method we'll
        # do nothing.
        check_data_dict = getattr(package_plugin, 'check_data_dict', None)
        if check_data_dict:
            try:
                check_data_dict(data_dict, schema)
            except TypeError:
                # Old plugins do not support passing the schema so we need
                # to ensure they still work
                package_plugin.check_data_dict(data_dict)

    # upload package data dictionary before validation
    data_dictionary_upload(context, data_dict, 'package')
    # set data dictionary format and mimetype
    if data_dict.get('format', ''):
        # set format and mimetype based on the format field
        data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(data_dict.get('format', '')) 
        fake_url = 'any_filename' + '.' + data_dict.get('format', '').lower()
        mimetype = helpers.guess_mimetypes(fake_url)
        data_dict['data_dictionary_pkg_mimetype'] = mimetype
    else:
        # set format and mimetype based on the file extension
        data_dictionary_url = data_dict.get('data_dictionary_pkg', '')
        data_dict['data_dictionary_pkg_mimetype'] = helpers.guess_mimetypes(data_dictionary_url)
        splitted = data_dictionary_url.split('.')
        if splitted:
            data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(splitted[-1])

    updated_extras = []
    data_dict_extras = data_dict.get('extras', [])

    if data_dict_extras:
        for extra in data_dict_extras:
            extra_key = extra.get('key')

            if extra_key:
                if extra_key in schema:
                    data_dict[extra['key']] = extra['value']
                else:
                    updated_extras.append(extra)

    data_dict['extras'] = updated_extras

    data, errors = lib_plugins.plugin_validate(
        package_plugin, context, data_dict, schema, 'package_create')
    log.debug('package_create validate_errs=%r user=%s package=%s data=%r',
              errors, context.get('user'),
              data.get('name'), data_dict)
    if errors:
        log.error('Package not valid: {}'.format(data_dict))
        model.Session.rollback()
        raise ValidationError(errors)

    #rev = model.repo.new_revision()
    #rev.author = user
    #if 'message' in context:
    #    rev.message = context['message']
    #else:
    #    rev.message = _(u'REST API: Create object %s') % data.get("name")

    if user:
        user_obj = model.User.by_name(user)
        if user_obj:
            data['creator_user_id'] = user_obj.id

    # Append owner_org as a tag by default
    owner_org_tag = data.get('owner_org')
    tags = data.get('tags')
    # check if data has the tags field
    if tags and (type(tags) == list) and owner_org_tag:
        tags.append({'name':owner_org_tag})
        data['tags'] = tags

    pkg = model_save.package_dict_save(data, context)
    is_dataset = True

    # Needed to let extensions know the package and resources ids
    model.Session.flush()
    data['id'] = pkg.id
    if data.get('resources'):
        is_dataset = False
        for index, resource in enumerate(data['resources']):
            resource['id'] = pkg.resources[index].id

    if data_dict.get('save_relationship'):
        is_dataset = False

    context_org_update = context.copy()
    context_org_update['ignore_auth'] = True
    context_org_update['defer_commit'] = True
    context_org_update['add_revision'] = False
    _get_action('package_owner_org_update')(context_org_update,
                                            {'id': pkg.id,
                                             'organization_id': pkg.owner_org})

    for item in plugins.PluginImplementations(plugins.IPackageController):
        item.create(pkg)

        item.after_create(context, data)

    # Make sure that a user provided schema is not used in create_views
    # and on package_show
    context.pop('schema', None)

    # Create default views for resources if necessary
    if data.get('resources'):
        logic.get_action('package_create_default_resource_views')(
            {'model': context['model'], 'user': context['user'],
             'ignore_auth': True},
            {'package': data})

    # Create activity
    if not pkg.private:
        user_obj = model.User.by_name(user)
        if user_obj:
            user_id = user_obj.id
        else:
            user_id = 'not logged in'

        activity = pkg.activity_stream_item('new', user_id)
        session.add(activity)

    if not context.get('defer_commit'):
        model.repo.commit()

    # need to let rest api create
    context["package"] = pkg
    # this is added so that the rest controller can make a new location
    context["id"] = pkg.id
    log.debug('Created object %s' % pkg.name)

    # don't update parent for documentation or data_dictionary
    # TODO call this function only if we need to update the parent
    if data_dict.get('type') == 'dataset':
        try:
            update_parent(context, data_dict)
        except Exception as e:
            log.error('Error updating data profile parent: {}'.format(e))
        if is_dataset:
            try:
                update_relationship_dependencies(context, data_dict)
            except Exception as e:
                log.error('Error updating data profile dependencies: {}'.format(e))
            try:
                update_relationship_derivations(context, data_dict)
            except Exception as e:
                log.error('Error updating data profile derivations: {}'.format(e))

    return_id_only = context.get('return_id_only', False)

    output = context['id'] if return_id_only \
        else _get_action('package_show')(context, {'id': context['id']})

    return output


@toolkit.side_effect_free
def package_update(context, data_dict, is_dataset=True):
    model = context['model']
    session = context['session']
    user = context['user']
    name_or_id = data_dict.get('id') or data_dict.get('name')
    if name_or_id is None:
        raise ValidationError({'id': _('Missing value')})
    
    # remove relationships if they are empty
    # this is required to add a documentation
    if data_dict.get('relationships_as_object') == []:
        del data_dict['relationships_as_object']

    if data_dict.get('relationships_as_subject') == []:
        del data_dict['relationships_as_subject']

    if not data_dict.get('program_code'):
        data_dict['program_code'] = ''

    pkg = model.Package.get(name_or_id)
    if pkg is None:
        raise NotFound(_('Package was not found.'))
    context["package"] = pkg
    data_dict["id"] = pkg.id
    data_dict['type'] = pkg.type

    # Use boolean values for CKAN 2.9+
    if data_dict.get('private') == 'False':
        data_dict['private'] = False
    if data_dict.get('private') == 'True':
        data_dict['private'] = True

    spatial_tags = csv_to_tags(csv_string=data_dict.pop('spatial', []))
    data_dict['spatial'] = spatial_tags
    level_of_data_tags = csv_to_tags(csv_string=data_dict.pop('level_of_data', []))
    data_dict['level_of_data'] = level_of_data_tags

    _check_access('package_update', context, data_dict)

    # get the schema
    package_plugin = lib_plugins.lookup_package_plugin(pkg.type)
    if 'schema' in context:
        schema = context['schema']
    else:
        schema = package_plugin.update_package_schema()

    if not 'groups' in data_dict:
        data_dict['groups'] = []

    collections = data_dict.pop('collections', None)
    ed_source = data_dict.pop('ed_source', None)
    current_groups = data_dict['groups']
    ed_sources = []
    ed_collections = []

    if collections is not None:
        if type(collections) == list:
            ed_collections = collections

            for c in collections:
                group = helpers.get_group_dict({'id': c})
                data_dict['groups'].append(group)

        if type(collections) == str:
            ed_collections = [collections]
            group = helpers.get_group_dict({'id': collections})
            data_dict['groups'].append(group)
    
    if ed_source is not None:
        if type(ed_source) == list:
            ed_sources = ed_source

            for c in ed_source:
                group = helpers.get_group_dict({'id': c})
                data_dict['groups'].append(group)

        if type(ed_source) == str:
            ed_sources = [ed_source]
            group = helpers.get_group_dict({'id': ed_source})
            data_dict['groups'].append(group)

    for group in current_groups:
        group_dict = helpers.get_group_dict(group)

        if data_dict.get('state') != 'draft' and data_dict.get('type') != 'documentation' \
            and data_dict.get('preserve_collection') != True:
            if group_dict.get('type') == 'collection' \
               and group_dict.get('name') not in ed_collections:
                data_dict['groups'].remove(group)

            if group_dict.get('type') == 'ed_source' \
               and group_dict.get('name') not in ed_sources:
                data_dict['groups'].remove(group)

    if 'api_version' not in context:
        # check_data_dict() is deprecated. If the package_plugin has a
        # check_data_dict() we'll call it, if it doesn't have the method we'll
        # do nothing.
        check_data_dict = getattr(package_plugin, 'check_data_dict', None)
        if check_data_dict:
            try:
                package_plugin.check_data_dict(data_dict, schema)
            except TypeError:
                # Old plugins do not support passing the schema so we need
                # to ensure they still work.
                package_plugin.check_data_dict(data_dict)

    ########################################################################
    ################################ ED FIX ################################
    # Avoid saving harvested extras that conflict with schema property names

    saved_extras = []
    pkg_extras_keys = []

    ### for new extras
    new_extras = data_dict.get('extras', [])
    for extra in new_extras:
        key = extra.get('key')
        value = extra.get('value')
        pkg_extras_keys.append(key)
        if key not in schema.keys():
            saved_extras.append({'key': key, 'value': value})
        else:
            data_dict[key] = value

    ### for existing extras
    for key, value in pkg.extras.items():
        # if the key exists, we'll update with the new value
        if key in pkg_extras_keys:
            continue
        # we may have fields in pkg.extras to update from data_dict
        # these fields are in the extras of the pkg(model)
        # but are outside extras of data_dict(action)
        # schema functions are applied on actions, not on models

        # check if we have a value in the data_dict for the key
        if not(data_dict.get(key, None) == None):
            #updating value
            value = data_dict.get(key) 
        # keeping the existing extras
        if key not in schema.keys():
            saved_extras.append({'key': key, 'value': value})
        else:
            data_dict[key] = value
        
    data_dict['extras'] = saved_extras
    ################################################################

    # When the `data_dictionary_res_file field in the package resource is empty
    # it seems to default to `<FileStorage: u'' ('application/octet-stream')>`
    # somewhere before getting here and throws an internal server error.
    # It is being set to an empty string if that happens to prevent an error
    # TODO: find exactly where is being defaulted to a FileStorage object and
    # fix that there.

    str_type = str

    if data_dict.get('resources', []):
        for i in range(len(data_dict.get('resources'))):
            if data_dict['resources'][i].get('data_dictionary_res_file') is not None:
                if type(data_dict['resources'][i]['data_dictionary_res_file']) != str_type:
                    data_dict['resources'][i]['data_dictionary_res_file'] = ''
    data, errors = lib_plugins.plugin_validate(
        package_plugin, context, data_dict, schema, 'package_update')
    '''
    log.debug('package_update validate_errs=%r user=%s package=%s data=%r',
              errors, context.get('user'),
              context.get('package').name if context.get('package') else '',
              data)
    '''
    if errors:
        model.Session.rollback()
        raise ValidationError(errors)

    #rev = model.repo.new_revision()
    #rev.author = user
    #if 'message' in context:
    #    rev.message = context['message']
    #else:
    #    rev.message = _(u'REST API: Update object %s') % data.get("name")

    #avoid revisioning by updating directly
    model.Session.query(model.Package).filter_by(id=pkg.id).update(
        {"metadata_modified": datetime.datetime.utcnow()})
    model.Session.refresh(pkg)

    pkg = model_save.package_dict_save(data, context)

    context_org_update = context.copy()
    context_org_update['ignore_auth'] = True
    context_org_update['defer_commit'] = True
    context_org_update['add_revision'] = False
    _get_action('package_owner_org_update')(context_org_update,
                                            {'id': pkg.id,
                                             'organization_id': pkg.owner_org})

    data_dict['owner_suborg'] = ""
    is_dataset = True

    # Needed to let extensions know the new resources ids
    model.Session.flush()
    if data.get('resources'):
        is_dataset = False
        for index, resource in enumerate(data['resources']):
            resource['id'] = pkg.resources[index].id

    if data_dict.get('save_relationship'):
        is_dataset = False
    
    for item in plugins.PluginImplementations(plugins.IPackageController):
        item.edit(pkg)

        item.after_update(context, data)

    # Create activity
    if not pkg.private:
        user_obj = model.User.by_name(user)
        if user_obj:
            user_id = user_obj.id
        else:
            user_id = 'not logged in'

        activity = pkg.activity_stream_item('changed', user_id)
        session.add(activity)

    if not context.get('defer_commit'):
        model.repo.commit()

    return_id_only = context.get('return_id_only', False)

    # don't update parent for documentation or data_dictionary
    # TODO call this function only if we need to update the parent
    if data_dict.get('type') == 'dataset':
        try:
            update_parent(context, data_dict)
        except Exception as e:
            log.error('Error updating data profile parent: {}'.format(e))
        if is_dataset:
            try:
                update_relationship_dependencies(context, data_dict)
            except Exception as e:
                log.error('Error updating data profile dependencies: {}'.format(e))
            try:
                update_relationship_derivations(context, data_dict)
            except Exception as e:
                log.error('Error updating data profile derivations: {}'.format(e))

    # Make sure that a user provided schema is not used on package_show
    context.pop('schema', None)

    # we could update the dataset so we should still be able to read it.
    context['ignore_auth'] = True
    output = data_dict['id'] if return_id_only \
            else _get_action('package_show')(context, {'id': data_dict['id']})

    return output


@toolkit.side_effect_free
def resource_update(context, data_dict):
    '''Update a resource.

    To update a resource you must be authorized to update the dataset that the
    resource belongs to.

    For further parameters see
    :py:func:`~ckan.logic.action.create.resource_create`.

    :param id: the id of the resource to update
    :type id: string

    :returns: the updated resource
    :rtype: string

    '''
    model = context['model']
    user = context['user']
    id = _get_or_bust(data_dict, "id")

    if not data_dict.get('url'):
        data_dict['url'] = ''

    resource = model.Resource.get(id)

    # Only re-submit for approval if "name", "description",
    # "url", or "data_dictionary_res" has changed
    if getattr(resource, 'approval_status', None) == 'approved':
        resource_dict = resource.as_dict()
        approval_updated = any(updated is True for updated in [
            data_dict.get('name') != resource_dict.get('name'),
            data_dict.get('description') != resource_dict.get('description'),
            data_dict.get('url') != resource_dict.get('url'),
            data_dict.get('data_dictionary_res') != resource_dict.get('data_dictionary_res')
        ])

        if approval_updated is False:
            context['skip_approval'] = True

    context["resource"] = resource
    old_resource_format = resource.format

    if not resource:
        log.debug('Could not find resource %s', id)
        raise NotFound(_('Resource was not found.'))

    _check_access('resource_update', context, data_dict)
    del context["resource"]

    package_id = resource.package.id
    pkg_dict = _get_action('package_show')(dict(context, return_type='dict'),
        {'id': package_id})

    for n, p in enumerate(pkg_dict['resources']):
        if p['id'] == id:
            break
    else:
        log.error('Could not find resource %s after all', id)
        raise NotFound(_('Resource was not found.'))

    # Persist the datastore_active extra if already present and not provided
    if ('datastore_active' in resource.extras and
            'datastore_active' not in data_dict):
        data_dict['datastore_active'] = resource.extras['datastore_active']

    for plugin in plugins.PluginImplementations(plugins.IResourceController):
        plugin.before_update(context, pkg_dict['resources'][n], data_dict)

    upload = uploader.get_resource_uploader(data_dict)

    #upload resource data dictionary
    data_dictionary_upload(context, data_dict, 'resource')

    # set data dictionary format and mimetype
    if data_dict.get('data-dictionary-format', ''):
        # set format and mimetype based on the format field
        data_dict['data_dictionary_res_format'] = h.unified_resource_format(data_dict.get('data-dictionary-format', '')) 
        fake_url = 'any_filename' + '.' + data_dict.get('data-dictionary-format', '').lower()
        mimetype = helpers.guess_mimetypes(fake_url)
        data_dict['data_dictionary_res_mimetype'] = mimetype
    else:
        # set format and mimetype based on the file extension
        data_dictionary_url = data_dict.get('data_dictionary_res', '')
        data_dict['data_dictionary_res_mimetype'] = helpers.guess_mimetypes(data_dictionary_url)
        splitted = data_dictionary_url.split('.')
        if splitted:
            data_dict['data_dictionary_res_format'] = h.unified_resource_format(splitted[-1])

    # remove form fields that don't belong to the schema
    if data_dict.get('data-dictionary-format'):
        del data_dict['data-dictionary-format']
    
    if data_dict.get('data_dictionary_res_file'):
        del data_dict['data_dictionary_res_file']

    if data_dict.get('field-clear-data-dict'):
        del data_dict['field-clear-data-dict']

    if data_dict.get('resource_set') == 'indirect':
        if data_dict.get('access_url'):
            data_dict['url'] = data_dict.get('access_url')
            data_dict['resource_type'] = 'access_url'
        elif data_dict.get('api_url'):
            data_dict['url'] = data_dict.get('api_url')
            data_dict['resource_type'] = 'api_url'
            data_dict['format'] = 'API'

    if 'mimetype' not in data_dict:
        if hasattr(upload, 'mimetype'):
            data_dict['mimetype'] = upload.mimetype

    if 'size' not in data_dict and 'url_type' in data_dict:
        if hasattr(upload, 'filesize'):
            data_dict['size'] = upload.filesize

    pkg_dict['resources'][n] = data_dict

    try:
        context['defer_commit'] = True
        context['use_cache'] = False
        updated_pkg_dict = _get_action('package_update')(
            context, pkg_dict)
        context.pop('defer_commit')
    except ValidationError as e:
        try:
            raise ValidationError(e.error_dict['resources'][-1])
        except (KeyError, IndexError):
            raise ValidationError(e.error_dict)

    upload.upload(id, uploader.get_max_resource_size())
    model.repo.commit()

    # Don't store the ed_source with the resource
    ed_source = data_dict.pop('ed_source', None)

    if ed_source:
        source = _get_action('group_show')(context, {'id': ed_source})
        source_resources = source.get('source_resources')
        res_name = data_dict['id']

        # check if the resource had an existing source
        helpers.remove_previous_resource_source(context, res_name)

        if res_name not in source_resources:
            if source_resources:
                source_resources += ',{}'.format(res_name)
            else:
                source_resources = res_name

            source['source_resources'] = source_resources
            _get_action('group_patch')(context, {
                'id': ed_source,
                'source_resources': source_resources
            })

    resource = _get_action('resource_show')(context, {'id': id})

    if old_resource_format != resource['format']:
        _get_action('resource_create_default_resource_views')(
            {'model': context['model'], 'user': context['user'],
             'ignore_auth': True},
            {'package': updated_pkg_dict,
             'resource': resource})

    for plugin in plugins.PluginImplementations(plugins.IResourceController):
        plugin.after_update(context, resource)

    return resource



@toolkit.side_effect_free
def prepare_zip_resources(context, data_dict):
    """Creates zip archive and stores it under CKAN's storage path.

    :param resources: a list of ids of the resources
    :type resources: list

    :return: a dictionary containing the zip_id of the created archive
    :rtype: dict
    """
    file_name = uuid.uuid4().hex + '.{ext}'.format(ext='zip')
    file_path = helpers.get_storage_path_for('temp-ed') + '/' + file_name
    resourceArchived = False
    package_id = None

    try:
        resource_ids = data_dict.get('resources')
        with zipfile.ZipFile(file_path, 'w') as zip:
            for resource_id in resource_ids:
                data_dict = {'id': resource_id}
                resource = toolkit.get_action('resource_show')({}, data_dict)

                url = resource.get('url')
                if resource['url_type'] == 'upload':
                    name = url.split('/')[-1]
                else:
                    name = resource['name']
                    if os.path.splitext(name)[-1] == '':
                        _format = resource['format']
                        if _format:
                            name += '.{ext}'.format(ext=_format.lower())

                if package_id is None:
                    package_id = resource['package_id']

                headers = {'Authorization': helpers.get_sysadmins()[0].apikey}
                try:
                    r = requests.get(url, headers=headers)
                except Exception:
                    continue

                content_type = r.headers['Content-Type'].split(';')[0]

                if content_type in SUPPORTED_RESOURCE_MIMETYPES:
                    resourceArchived = True
                    zip.writestr(name, r.content)
    except Exception as ex:
        log.error('An error occured while preparing zip archive. Error: %s' % ex)
        raise

    zip_id = file_name
    try:
        package = toolkit.get_action('package_show')({}, {'id': package_id})
        package_name = package['name']

        zip_id += '::{name}'.format(name=package_name)
    except:
        pass

    if resourceArchived:
        return {'zip_id': zip_id}

    os.remove(file_path)

    return {'zip_id': None}


def convert_to_tags_format(predefined_data):
    '''
        Returns list of tags in tags_format
        :param: list of predefined tags

        :returns: list of tags in tags_format
        :rtype: list
    '''
    tags_format = []

    for data in predefined_data:
        if data not in tags_format:
            tags_tmp = {}
            tags_tmp['name'] = data
            tags_tmp['state'] = 'active'
            tags_format.append(tags_tmp)

    return tags_format


@toolkit.side_effect_free
def package_activity_list(context, data_dict):
    '''Override core ckan package_activity_list
    '''
    get_workflow_activities = data_dict.get('get_workflow_activities')
    full_list = core_package_activity_list(context, data_dict)
    workflow_activities = [
        a for a in full_list if 'workflow_activity' in a.get('data', {})]
    normal_activities = [
        a for a in full_list if 'workflow_activity' not in a.get('data', {})]
    # Filter out the activities that are related `approval_state`
    normal_activities = list(filter(
        lambda activity: core_activity_detail_dict(
            context, {'id': activity['id'], 'include_data': True })
            .get('data', {})
            .get('package_extra', {})
            .get('key') != 'approval_state', normal_activities))
    return (workflow_activities
        if get_workflow_activities else normal_activities)


@toolkit.side_effect_free
def dashboard_activity_list(context, data_dict):
    '''Override core ckan dashboard_activity_list
    '''
    full_list = core_dashboard_activity_list(context, data_dict)
    normal_activities = [
        a for a in full_list if 'workflow_activity' not in a.get('data', {})]

    return normal_activities


@toolkit.side_effect_free
def group_activity_list(context, data_dict):
    '''Override core ckan group_activity_list
    '''
    full_list = core_group_activity_list(context, data_dict)
    normal_activities = [
        a for a in full_list if 'workflow_activity' not in a.get('data', {})]
    return normal_activities


@toolkit.side_effect_free
def recently_changed_packages_activity_list(context, data_dict):
    '''Override core ckan recently_changed_packages_activity_list
    '''
    full_list = core_recently_changed_packages_activity_list(context, data_dict)
    normal_activities = [a for a in full_list if 'workflow_activity' not in a.get('data', {})]
    return normal_activities


@toolkit.side_effect_free
def package_search(context, data_dict):
    # sometimes context['schema'] is None
    schema = (context.get('schema') or
              logic.schema.default_package_search_schema())
    data_dict, errors = _validate(data_dict, schema, context)
    # put the extras back into the data_dict so that the search can
    # report needless parameters
    data_dict.update(data_dict.get('__extras', {}))
    data_dict.pop('__extras', None)

    # basestring has been removed in python 3.X
    if data_dict.get('fl') and  isinstance(data_dict.get('fl', None), str):
        data_dict['fl'] = data_dict['fl'].split(' ')

    if errors:
        print(errors)
        print(data_dict)
        raise ValidationError(errors)

    model = context['model']
    session = context['session']
    user = context.get('user')

    _check_access('package_search', context, data_dict)

    # Move ext_ params to extras and remove them from the root of the search
    # params, so they don't cause and error
    data_dict['extras'] = data_dict.get('extras', {})
    for key in [key for key in data_dict.keys() if key.startswith('ext_')]:
        data_dict['extras'][key] = data_dict.pop(key)

    # check if some extension needs to modify the search params
    for item in plugins.PluginImplementations(plugins.IPackageController):
        data_dict = item.before_search(data_dict)

    # the extension may have decided that it is not necessary to perform
    # the query
    abort = data_dict.get('abort_search', False)

    if data_dict.get('sort') in (None, 'rank'):
        data_dict['sort'] = 'score desc, metadata_modified desc'

    package_type = data_dict.pop('type', None)

    results = []
    if not abort:
        if toolkit.asbool(data_dict.get('use_default_schema')):
            data_source = 'data_dict'
        else:
            data_source = 'validated_data_dict'
        data_dict.pop('use_default_schema', None)

        result_fl = data_dict.get('fl')
        if not result_fl:
            data_dict['fl'] = 'id {0}'.format(data_source)
        else:
            data_dict['fl'] = ' '.join(result_fl)

        # Remove before these hit solr FIXME: whitelist instead
        include_private = toolkit.asbool(data_dict.pop('include_private', False))
        include_drafts = toolkit.asbool(data_dict.pop('include_drafts', False))
        data_dict.setdefault('fq', '')

        if not include_private and (user and not helpers.is_admin(user) and not helpers.is_coordinator(user)):
            data_dict['fq'] = '-indraft:true +capacity:public ' + data_dict['fq']
        if include_drafts and (user and not helpers.is_admin(user) and not helpers.is_coordinator(user)):
            data_dict['fq'] += ' +state:(active OR draft) +private:false'
        elif include_private and (user and helpers.is_coordinator(user)) and 'private' in data_dict.get('sort'):
            data_dict['fq'] = ' '

        if not package_type:
            data_dict['fq'] += ' -type:"documentation"'
        else:
            data_dict['fq'] += ' +type:{}'.format(package_type)

        # Pop these ones as Solr does not need them
        extras = data_dict.pop('extras', None)

        # enforce permission filter based on user
        if context.get('ignore_auth') or (user and authz.is_sysadmin(user)):
            labels = None
        else:
            labels = lib_plugins.get_permission_labels(
                ).get_user_dataset_labels(context['auth_user_obj'])
            if len(labels) < 3:
                data_dict['fq'] += ' -indraft:true'

        query = search.query_for(model.Package)
        query.run(data_dict, permission_labels=labels)

        # Add them back so extensions can use them on after_search
        data_dict['extras'] = extras

        if result_fl:
            for package in query.results:
                if isinstance(package, text_type):
                    package = {result_fl[0]: package}
                if package.get('extras'):
                    package.update(package['extras'] )
                    package.pop('extras')
                results.append(package)
        else:
            for package in query.results:
                # get the package object
                package_dict = package.get(data_source)
                ## use data in search index if there
                if package_dict:
                    # the package_dict still needs translating when being viewed
                    package_dict = json.loads(package_dict)
                    if context.get('for_view'):
                        for item in plugins.PluginImplementations(
                                plugins.IPackageController):
                            package_dict = item.before_view(package_dict)
                    ## remove non-appoved resources
                    try:
                        is_admin = helpers.is_admin(c.user) or helpers.is_editor(c.user)
                    except AttributeError:
                        is_admin = helpers.is_admin(user) or helpers.is_editor(user)

                    if not is_admin:
                        filtered_resources = []
                        resources = package_dict.get('resources')
                        for resource in resources:
                            approval_status = resource.get('approval_status', '')
                            if not approval_status or approval_status == 'approved':
                                filtered_resources.append(resource)
            
                        package_dict['resources'] = filtered_resources
                    results.append(package_dict)
                else:
                    log.error('No package_dict is coming from solr for package '
                              'id %s', package['id'])

        count = query.count
        facets = query.facets
    else:
        count = 0
        facets = {}
        results = []

    search_results = {
        'count': count,
        'facets': facets,
        'results': results,
        'sort': data_dict['sort']
    }

    # create a lookup table of group name to title for all the groups and
    # organizations in the current search's facets.
    group_names = []
    for field_name in ('groups', 'organization', 'suborganization'):
        group_names.extend(facets.get(field_name, {}).keys())

    groups = (session.query(model.Group.name, model.Group.title)
                    .filter(model.Group.name.in_(group_names))
                    .all()
              if group_names else [])
    group_titles_by_name = dict(groups)

    # Transform facets into a more useful data structure.
    restructured_facets = {}
    for key, value in facets.items():
        restructured_facets[key] = {
            'title': key,
            'items': []
        }
        for key_, value_ in value.items():
            if key == 'organization' and key_ in facets.get('suborganization', {}).keys():
                continue
            new_facet_dict = {}
            new_facet_dict['name'] = key_
            if key in ('groups', 'organization', 'suborganization'):
                display_name = group_titles_by_name.get(key_, key_)
                display_name = display_name if display_name and display_name.strip() else key_
                new_facet_dict['display_name'] = display_name
            elif key == 'license_id':
                license = model.Package.get_license_register().get(key_)
                if license:
                    new_facet_dict['display_name'] = license.title
                else:
                    new_facet_dict['display_name'] = key_
            else:
                new_facet_dict['display_name'] = key_
            new_facet_dict['count'] = value_
            restructured_facets[key]['items'].append(new_facet_dict)
    search_results['search_facets'] = restructured_facets
    search_results['search_dict'] = data_dict

    # check if some extension needs to modify the search results
    for item in plugins.PluginImplementations(plugins.IPackageController):
        search_results = item.after_search(search_results, data_dict)

    # After extensions have had a chance to modify the facets, sort them by
    # display name.
    for facet in search_results['search_facets']:
        search_results['search_facets'][facet]['items'] = sorted(
            search_results['search_facets'][facet]['items'],
            key=lambda facet: facet['display_name'], reverse=True)

    return search_results

@toolkit.side_effect_free
#@logic.validate(logic.schema.default_resource_search_schema)
def resource_search(context, data_dict):
    '''
    ckanext-ed override of resource_search
    It allows searching resources on private datasets

    Searches for resources satisfying a given search criteria.

    It returns a dictionary with 2 fields: ``count`` and ``results``.  The
    ``count`` field contains the total number of Resources found without the
    limit or query parameters having an effect.  The ``results`` field is a
    list of dictized Resource objects.

    The 'query' parameter is a required field.  It is a string of the form
    ``{field}:{term}`` or a list of strings, each of the same form.  Within
    each string, ``{field}`` is a field or extra field on the Resource domain
    object.

    If ``{field}`` is ``"hash"``, then an attempt is made to match the
    `{term}` as a *prefix* of the ``Resource.hash`` field.

    If ``{field}`` is an extra field, then an attempt is made to match against
    the extra fields stored against the Resource.

    Note: The search is limited to search against extra fields declared in
    the config setting ``ckan.extra_resource_fields``.

    Note: Due to a Resource's extra fields being stored as a json blob, the
    match is made against the json string representation.  As such, false
    positives may occur:

    If the search criteria is: ::

        query = "field1:term1"

    Then a json blob with the string representation of: ::

        {"field1": "foo", "field2": "term1"}

    will match the search criteria!  This is a known short-coming of this
    approach.

    All matches are made ignoring case; and apart from the ``"hash"`` field,
    a term matches if it is a substring of the field's value.

    Finally, when specifying more than one search criteria, the criteria are
    AND-ed together.

    The ``order`` parameter is used to control the ordering of the results.
    Currently only ordering one field is available, and in ascending order
    only.

    The ``fields`` parameter is deprecated as it is not compatible with calling
    this action with a GET request to the action API.

    The context may contain a flag, `search_query`, which if True will make
    this action behave as if being used by the internal search api.  ie - the
    results will not be dictized, and SearchErrors are thrown for bad search
    queries (rather than ValidationErrors).

    :param query: The search criteria.  See above for description.
    :type query: string or list of strings of the form ``{field}:{term1}``
    :param fields: Deprecated
    :type fields: dict of fields to search terms.
    :param order_by: A field on the Resource model that orders the results.
    :type order_by: string
    :param offset: Apply an offset to the query.
    :type offset: int
    :param limit: Apply a limit to the query.
    :type limit: int

    :returns:  A dictionary with a ``count`` field, and a ``results`` field.
    :rtype: dict

    '''
    model = context['model']
    user = context['user']

    # Allow either the `query` or `fields` parameter to be given, but not both.
    # Once `fields` parameter is dropped, this can be made simpler.
    # The result of all this gumpf is to populate the local `fields` variable
    # with mappings from field names to list of search terms, or a single
    # search-term string.
    query = data_dict.get('query')
    fields = data_dict.get('fields')

    if query is None and fields is None:
        raise ValidationError({'query': _('Missing value')})

    elif query is not None and fields is not None:
        raise ValidationError(
            {'fields': _('Do not specify if using "query" parameter')})

    elif query is not None:
        if isinstance(query, string_types):
            query = [query]
        try:
            fields = dict(pair.split(":", 1) for pair in query)
        except ValueError:
            raise ValidationError(
                {'query': _('Must be <field>:<value> pair(s)')})

    else:
        log.warning('Use of the "fields" parameter in resource_search is '
                    'deprecated.  Use the "query" parameter instead')

        # The legacy fields paramter splits string terms.
        # So maintain that behaviour
        split_terms = {}
        for field, terms in fields.items():
            if isinstance(terms, string_types):
                terms = terms.split()
            split_terms[field] = terms
        fields = split_terms

    order_by = data_dict.get('order_by')
    offset = data_dict.get('offset')
    limit = data_dict.get('limit')

    include_private = toolkit.asbool(data_dict.pop('include_private', False))
    if not (helpers.is_admin(user) or helpers.is_editor(user)) and include_private:
        include_private = False

    if include_private:
        q = model.Session.query(model.Resource) \
            .join(model.Package) \
            .filter(model.Package.state == 'active') \
            .filter(model.Resource.state == 'active') 
    else:
        q = model.Session.query(model.Resource) \
            .join(model.Package) \
            .filter(model.Package.state == 'active') \
            .filter(model.Package.private == False) \
            .filter(model.Resource.state == 'active') \

    #TODO block non-sysadmin users for searching by approval status

    # Manually add the extra resource fields, because ckan doesn't 
    # seem to return it anymore
    #TODO: call the extra fields instead so that they are only declared
    # in one place
    resource_extra_fields = [
        'data_dictionary_res',
        'data_dictionary_res_format',
        'data_dictionary_res_mimetype',
        'approval_status',
        'ed_source'
    ]
    resource_fields = model.Resource.get_columns() + resource_extra_fields
    for field, terms in fields.items():

        if isinstance(terms, string_types):
            terms = [terms]

        if field not in resource_fields:
            msg = _('Field "{field}" not recognised in resource_search.')\
                .format(field=field)

            # Running in the context of the internal search api.
            if context.get('search_query', False):
                raise search.SearchError(msg)

            # Otherwise, assume we're in the context of an external api
            # and need to provide meaningful external error messages.
            raise ValidationError({'query': msg})

        for term in terms:

            # prevent pattern injection
            term = misc.escape_sql_like_special_characters(term)

            # Treat the has field separately, see docstring.
            if field == 'hash':
                model_attr = getattr(model.Resource, field)
                q = q.filter(model_attr.ilike(text_type(term) + '%'))

            # Resource extras are stored in a json blob.  So searching for
            # matching fields is a bit trickier.  See the docstring.
            elif field in resource_extra_fields:
                model_attr = getattr(model.Resource, 'extras')

                like = _or_(
                    model_attr.ilike(
                        u'''%%"%s": "%%%s%%",%%''' % (field, term)),
                    model_attr.ilike(
                        u'''%%"%s": "%%%s%%"}''' % (field, term))
                )
                q = q.filter(like)

            # Just a regular field
            else:
                model_attr = getattr(model.Resource, field)
                q = q.filter(model_attr.ilike('%' + text_type(term) + '%'))

    if order_by is not None:
        if hasattr(model.Resource, order_by):
            q = q.order_by(getattr(model.Resource, order_by))

    count = q.count()
    q = q.offset(offset)
    q = q.limit(limit)

    results = []
    for result in q:
        if isinstance(result, tuple) \
                and isinstance(result[0], model.DomainObject):
            # This is the case for order_by rank due to the add_column.
            results.append(result[0])
        else:
            results.append(result)

    # If run in the context of a search query, then don't dictize the results.
    if not context.get('search_query', False):
        results = model_dictize.resource_list_dictize(results, context)

    return {'count': count,
            'results': results}

@toolkit.side_effect_free
@logic.validate(logic.schema.default_autocomplete_schema)
def package_autocomplete(context, data_dict):
    '''Return a list of datasets (packages) that match a string.

    Datasets with names or titles that contain the query string will be
    returned.

    :param q: the string to search for
    :type q: string
    :param limit: the maximum number of resource formats to return (optional,
        default: ``10``)
    :type limit: int

    :rtype: list of dictionaries

    '''
    model = context['model']

    _check_access('package_autocomplete', context, data_dict)

    limit = data_dict.get('limit', 10)
    q = data_dict['q']

    like_q = u"%s%%" % q

    query = model.Session.query(model.Package)
    query = query.filter(model.Package.state == 'active')
    query = query.filter(model.Package.type == 'dataset')
    query = query.filter(_or_(model.Package.name.ilike(like_q),
                              model.Package.title.ilike(like_q)))
    query = query.limit(limit)

    q_lower = q.lower()
    pkg_list = []
    for package in query:
        if package.name.startswith(q_lower):
            match_field = 'name'
            match_displayed = package.name
        else:
            match_field = 'title'
            match_displayed = '%s (%s)' % (package.title, package.name)
        result_dict = {
            'name': package.name,
            'title': package.title,
            'match_field': match_field,
            'match_displayed': match_displayed}
        pkg_list.append(result_dict)

    return pkg_list


@toolkit.side_effect_free
def dashboard(context, data_dict):

    resources_by_org_q = """select o.name, o.title, count(*) as total from resource r
    join package p on(r.package_id = p.id)
    join "group" o on (p.owner_org = o.id)
    join package_extra e on (e.package_id = p.id)
    where p.type = 'dataset'
    and p.state = 'active'
    and e.key = 'scraped_from'
    group by o.name, o.title order by o.name;"""

    ## includes datasets without resources
    ## and does not include datasets manually added
    packages_by_org_q = """select o.name, o.title, count(*) as total from package p
    join "group" o on (p.owner_org = o.id)
    join package_extra e on (e.package_id = p.id)
    where p.type = 'dataset'
    and p.state = 'active'
    and e.key = 'scraped_from'
    group by o.name, o.title order by o.name;"""

    domain_list_q = """
    select distinct(
        regexp_replace(
            substr(value,
                   position('://' in value) + 3,
                   position('/' in substr(value, position('://' in value) + 3))),
            '(www[^\.]*\.)|(/)',
            '','g'
    )) from package_extra where key='scraped_from';
    """

    page_list_q = """
    select distinct(e.value)
    from package_extra e
    join package p on (e.package_id = p.id)
    where key = 'scraped_from'
    and p.type = 'dataset'
    and p.state = 'active';
    """

    ## only getting datasets with resources
    ## and does not include datasets manually added
    org_q = """
    select o.name, o.title, count(distinct(p.id)) as total_datasets, count(r.id) as total_resources
    from resource r
    join package p on(r.package_id = p.id)
    join "group" o on (p.owner_org = o.id)
    join package_extra e on (e.package_id = p.id)
    where p.state = 'active'
    and p.type = 'dataset'
    and e.key = 'scraped_from'
    group by o.name, o.title;
    """

    ## only getting datasets with resources
    ## and does not include datasets manually added
    domain_q = """
    select
    regexp_replace(substr(value,
                          position('://' in value)+3,
                          position('/' in substr(value, position('://' in value) +3))),
                   '(www[^\.]*\.)|(/)',
                   '', 'g') as domain,
    count(distinct(p.*)) as packages,
    count(r.*) as resources
    from package_extra e
    join package p on (e.package_id = p.id)
    join resource r on (p.id = r.package_id)
    where e.key = 'scraped_from'
    and p.state = 'active'
    group by domain;
    """

    amended_q = """
    select distinct(dataset.id)
    from package_extra as extras
    join package as dataset on (dataset.id = extras.package_id)
    where extras.key = 'amended_by_user' and extras.value = 'true'
    and dataset.state = 'active' and dataset.type = 'dataset';
    """

    domain_dict = {}
    domain_result = model.Session.execute(domain_q).fetchall()
    for row in domain_result:
        domain_dict[row[0]] = {
            'package_count': row[1],
            'resource_count': row[2],
        }

    org_dict = {}
    org_result = model.Session.execute(org_q)
    for row in org_result.fetchall():
        org_dict[row[0]] = {
            'org_title': row[1],
            'package_count': row[2],
            'resource_count': row[3],
        }

    '''
    packages_by_org_result = model.Session.execute(packages_by_org_q)
    resources_by_org_result = model.Session.execute(resources_by_org_q)

    org_dict = {}
    for row in packages_by_org_result.fetchall():
        org_name = row[0]
        org_title = row[1]
        dataset_count = row[2]

        org_dict[org_name] = {
            'org_title': org_title,
            'package_count': dataset_count,
            'resource_count': 0,
        }
    
    for row in resources_by_org_result.fetchall():
        org_name = row[0]
        org_title = row[1]
        resource_count = row[2]

        dict_count = org_dict.get(org_name)
        dict_count['resource_count'] = resource_count
        org_dict[org_name] = dict_count
    '''

    count_domain = model.Session.execute(domain_q).rowcount
    count_package = model.Session.execute('select distinct(p.id) from package p where p.state = \'active\' and p.type = \'dataset\';').rowcount
    count_package_scraped = model.Session.execute('select distinct(p.id) from package p join package_extra e on (p.id = e.package_id) where e.key = \'scraped_from\' and p.state = \'active\' and p.type = \'dataset\';').rowcount
    count_page = model.Session.execute(page_list_q).rowcount
    count_resource = model.Session.execute('select r.id from resource r join package p on (r.package_id = p.id) where p.state = \'active\' and p.type = \'dataset\';').rowcount
    count_resource_scraped = model.Session.execute('select r.id from resource r join package p on (r.package_id = p.id) join package_extra e on (p.id = e.package_id) where e.key = \'scraped_from\' and p.state = \'active\' and p.type = \'dataset\';').rowcount
    count_amended = model.Session.execute(amended_q).rowcount

    result = {
        'count': {
            'domain': count_domain,
            'package': count_package,
            'package_amended': count_amended,
            'package_manual': count_package - count_package_scraped,
            'package_scraped': count_package_scraped,
            'page': count_page,
            'resource': count_resource,
            'resource_scraped': count_resource_scraped,
        },
        'domain': domain_dict,
        'organization': org_dict,
    }

    return result


@toolkit.side_effect_free
def organization_member_create(context, data_dict):
    '''Make a user a member of an organization.

    You must be authorized to edit the organization.

    :param id: the id or name of the organization
    :type id: string
    :param username: name or id of the user to be made member of the
        organization
    :type username: string
    :param role: role of the user in the organization. One of ``member``,
        ``editor``, or ``admin``
    :type role: string

    :returns: the newly created (or updated) membership
    :rtype: dictionary
    '''
    _check_access('organization_member_create', context, data_dict)
    return _group_or_org_member_create(context, data_dict, is_org=True)


@toolkit.side_effect_free
def _group_or_org_member_create(context, data_dict, is_org=False):
    # creator of group/org becomes an admin
    # this needs to be after the repo.commit or else revisions break
    model = context['model']
    user = context['user']
    session = context['session']

    schema = ckan.logic.schema.member_schema()
    data, errors = _validate(data_dict, schema, context)
    if errors:
        model.Session.rollback()
        raise ValidationError(errors)

    username = _get_or_bust(data_dict, 'username')
    role = data_dict.get('role')
    group_id = data_dict.get('id')

    group = model.Group.get(group_id)

    if group.type == 'organization':
        context_copy = context.copy()
        context['ignore_auth'] = True
        search_dict = {
            'all_fields': True,
            'include_extras': True,
            'include_groups': True,
            'limit': 1000
        }
        all_collections = _get_action('collection_list')(context, search_dict)
        collections_to_update = [c['name'] for c in all_collections if c.get('owner_org') == group_id]

        to_update = []
        to_update.extend(collections_to_update)

        for updatable in to_update:
            update_data_dict = data_dict.copy()
            update_data_dict['id'] = updatable
            if str(role).lower() in ['editor', 'admin']:
                update_data_dict['role'] = 'admin'
            _get_action('group_member_create')(context_copy, update_data_dict)

    if not group:
        msg = _('Organization not found') if is_org else _('Group not found')
        raise NotFound(msg)
    result = model.User.get(username)
    if result:
        user_id = result.id
    else:
        message = _(u'User {username} does not exist.').format(
            username=username)
        raise ValidationError({'message': message}, error_summary=message)
    member_dict = {
        'id': group.id,
        'object': user_id,
        'object_type': 'user',
        'capacity': role,
    }
    member_create_context = {
        'model': model,
        'user': user,
        'session': session,
        'ignore_auth': context.get('ignore_auth'),
    }
    return logic.get_action('member_create')(member_create_context,
                                             member_dict)


@toolkit.side_effect_free
def organization_member_delete(context, data_dict=None):
    '''Remove a user from an organization.

    You must be authorized to edit the organization.

    :param id: the id or name of the organization
    :type id: string
    :param username: name or id of the user to be removed
    :type username: string

    '''
    return _group_or_org_member_delete(context, data_dict)


@toolkit.side_effect_free
def _group_or_org_member_delete(context, data_dict=None):
    model = context['model']
    user = context['user']
    session = context['session']

    group_id = data_dict.get('id')
    group = model.Group.get(group_id)
    user_id = data_dict.get('username')
    user_id = data_dict.get('user_id') if user_id is None else user_id
    member_dict = {
        'id': group.id,
        'object': user_id,
        'object_type': 'user',
    }
    member_context = {
        'model': model,
        'user': user,
        'session': session
    }

    # Create a copy of the context with auth disabled, so we can use it
    # to seamlessly edit Master Collections memberships for Collections
    member_context_copy = member_context.copy()
    member_context_copy['ignore_auth'] = True

    _get_action('member_delete')(member_context_copy, member_dict)

    if group.type == 'organization':
        search_dict = {
            'all_fields': True,
            'include_extras': True,
            'include_groups': True,
            'limit': 1000
        }
        all_collections = _get_action('collection_list')(context, search_dict)
        all_sources = _get_action('source_list')(context, search_dict)

        collections_to_update = [c['name'] for c in all_collections if c.get('owner_org') == group_id]
        sources_to_update = [c['name'] for c in all_sources if c.get('owner_org') == group_id]

        to_update = []
        to_update.extend(collections_to_update)
        to_update.extend(sources_to_update)

        for updatable in to_update:
            delete_data_dict = {'id': updatable,
                                'object': user_id,
                                'object_type': 'user'}
            _get_action('member_delete')(member_context_copy, delete_data_dict)

@toolkit.side_effect_free
def organization_show(context, data_dict):
    return _group_or_org_show(context, data_dict, is_org=True)


def _group_or_org_show(context, data_dict, is_org=False):
    model = context['model']
    id = _get_or_bust(data_dict, 'id')

    group = model.Group.get(id)
    context['group'] = group
    if toolkit.asbool(data_dict.get('include_datasets', False)):
        packages_field = 'datasets'
    elif toolkit.asbool(data_dict.get('include_dataset_count', True)):
        packages_field = 'dataset_count'
    else:
        packages_field = None

    try:
        include_tags = toolkit.asbool(data_dict.get('include_tags', True))
        if toolkit.asbool(config.get('ckan.auth.public_user_details', True)):
            include_users = toolkit.asbool(data_dict.get('include_users', True))
        else:
            include_users = toolkit.asbool(data_dict.get('include_users', False))
        include_groups = toolkit.asbool(data_dict.get('include_groups', True))
        include_extras = toolkit.asbool(data_dict.get('include_extras', True))
        include_followers = toolkit.asbool(data_dict.get('include_followers', True))
    except ValueError:
        raise logic.ValidationError(_('Parameter is not an bool'))

    if group is None:
        raise logic.NotFound
    if is_org and not group.is_organization:
        raise logic.NotFound
    if not is_org and group.is_organization:
        raise logic.NotFound

    if is_org:
        _check_access('organization_show', context, data_dict)
    else:
        _check_access('group_show', context, data_dict)

    group_dict = group_dictize(group, context,
                               packages_field=packages_field,
                               include_tags=include_tags,
                               include_extras=include_extras,
                               include_groups=include_groups,
                               include_users=include_users,)

    if is_org:
        plugin_type = plugins.IOrganizationController
    else:
        plugin_type = plugins.IGroupController

    for item in plugins.PluginImplementations(plugin_type):
        item.read(group)

    group_plugin = lib_plugins.lookup_group_plugin(group_dict['type'])
    
    try:
        schema = group_plugin.db_to_form_schema_options({
            'type': 'show',
            'api': 'api_version' in context,
            'context': context})
    except AttributeError:
        schema = group_plugin.db_to_form_schema()
    
    if include_followers:
        group_dict['num_followers'] = logic.get_action('group_follower_count')(
            {'model': model, 'session': model.Session},
            {'id': group_dict['id']})
    else:
        group_dict['num_followers'] = 0

    if schema is None:
        schema = logic.schema.default_show_group_schema()
    
    group_dict, errors = lib_plugins.plugin_validate(
        group_plugin, context, group_dict, schema,
        'organization_show' if is_org else 'group_show')

    return group_dict


@toolkit.side_effect_free
def user_update(context, data_dict):
    user_id = data_dict.get('_user_id')
    id = _get_or_bust(data_dict, 'id')  #   Is actually username
    user_name = data_dict.get('name')
    user_obj = model.User.get(id)

    if user_obj is None:
        raise NotFound('User was not found.')

    if user_name and user_name != id and is_coordinator(id):
        coordinator_orgs = get_coordinator_orgs(id)

        for org in coordinator_orgs:
            remove_coordinator(id, org, remove_all=True)
            update_coordinator(user_name, org)

    # set old email to pass validation when none email is passed
    if not data_dict.get('email', None):
        data_dict['email'] = user_obj.email

    notf_col_fn = lambda c: c.startswith('notf_')
    notf_pref_raw = list(filter(notf_col_fn, data_dict.keys()))
    notf_pref= [pref.replace('notf_', '') for pref in notf_pref_raw]
    update_notf_preferences(user_id, notf_pref)

    # Note: this isn't required anymore, but we'll leave
    # this here until we've completed the ticket around
    # allowing admins to edit user emails
    #if data_dict.get('email', None) != user_obj.email:
    #    raise ValidationError("Email can't be changed.")

    #   Checks mimetype of the profile picture file
    image_upload = data_dict.get('image_upload');
    if image_upload:
        image_upload_type = image_upload.content_type

        if 'image' not in image_upload_type:
            #   This prevents the image from being updated
            data_dict['image_url'] = None
            data_dict['image_upload'] = None


    return ckan_user_update(context, data_dict)


@toolkit.side_effect_free
def harvest_source_clear(context, data_dict):
    '''
    Clears all datasets, jobs and objects related to a harvest source, but
    keeps the source itself.  This is useful to clean history of long running
    harvest sources to start again fresh.

    :param id: the id of the harvest source to clear
    :type id: string
    '''

    _check_access('harvest_source_clear', context, data_dict)

    harvest_source_id = data_dict.get('id')

    source = HarvestSource.get(harvest_source_id)
    if not source:
        log.error('Harvest source %s does not exist', harvest_source_id)
        raise NotFound('Harvest source %s does not exist' % harvest_source_id)

    harvest_source_id = source.id

    # Clear all datasets from this source from the index
    harvest_source_index_clear(context, data_dict)

    model = context['model']

    # CKAN-2.6 or above: related don't exist any more
    if toolkit.check_ckan_version(max_version='2.5.99'):

        sql = '''select id from related where id in (
                  select related_id from related_dataset where dataset_id in (
                      select package_id from harvest_object
                      where harvest_source_id = :harvestsourceid));'''
        result = model.Session.execute(sql, { "harvestsourceid": harvest_source_id })
        ids = []
        for row in result:
            ids.append(row[0])
        related_ids = "('" + "','".join(ids) + "')"

    sql = '''begin;
        update package set state = 'to_delete' where id in (
            select package_id from harvest_object
            where harvest_source_id = :harvestsourceid);'''

    # Also delete documentation packages
    sql += '''
    update package set state = 'to_delete' where id in (
        select package_id from package_extra
        where key = 'harvest_source_id' and value = :harvestsourceid'
    ) and type = 'documentation';
    '''

    sql += '''
        update "group"
            set state = 'to_delete'
            where id in (
                select group_id from group_extra e
                where e.key = 'harvest_source_id'
                and e.value = :harvestsourceid
            );'''


    sql += '''
    delete from group_revision where continuity_id in (
            select id from "group" where state = 'to_delete');
    delete from group_extra_revision where group_id in (
            select id from "group" where state = 'to_delete');
    delete from group_extra where group_id in (
            select id from "group" where state = 'to_delete');
    delete from member_revision where group_id in (
            select id from "group" where state = 'to_delete');
    delete from member where group_id in (
            select id from "group" where state = 'to_delete');
    delete from "group" where id in (
            select id from "group" where state = 'to_delete');
    '''

    # CKAN-2.3 or above: delete resource views, resource revisions & resources
    if toolkit.check_ckan_version(min_version='2.3'):
        sql += '''
        delete from resource_view where resource_id in (
            select id from resource where package_id in (
                select id from package where state = 'to_delete'));
        delete from resource_revision where package_id in (
            select id from package where state = 'to_delete');
        delete from resource where package_id in (
            select id from package where state = 'to_delete');
        '''
    # Backwards-compatibility: support ResourceGroup (pre-CKAN-2.3)
    else:
        sql += '''
        delete from resource_revision where resource_group_id in (
            select id from resource_group where package_id in (
                select id from package where state = 'to_delete'));
        delete from resource where resource_group_id in (
            select id from resource_group where package_id in (
                select id from package where state = 'to_delete'));
        delete from resource_group_revision where package_id in (
            select id from package where state = 'to_delete');
        delete from resource_group where package_id in (
            select id from package where state = 'to_delete');
        '''
    # CKAN pre-2.5: authz models were removed in migration 078
    if toolkit.check_ckan_version(max_version='2.4.99'):
        sql += '''
        delete from package_role where package_id in (
            select id from package where state = 'to_delete');
        delete from user_object_role where id not in (
            select user_object_role_id from package_role)
            and context = 'Package';
        '''

    sql += '''
    delete from harvest_object_error where harvest_object_id in (
        select id from harvest_object
        where harvest_source_id = :harvestsourceid);
    delete from harvest_object_extra where harvest_object_id in (
        select id from harvest_object
        where harvest_source_id = :harvestsourceid);
    delete from harvest_object where harvest_source_id = :harvestsourceid;
    delete from harvest_gather_error where harvest_job_id in (
        select id from harvest_job where source_id = :harvestsourceid);
    delete from harvest_job where source_id = :harvestsourceid;
    delete from package_tag_revision where package_id in (
        select id from package where state = 'to_delete');
    delete from member_revision where table_id in (
        select id from package where state = 'to_delete');
    delete from package_extra_revision where package_id in (
        select id from package where state = 'to_delete');
    delete from package_revision where id in (
        select id from package where state = 'to_delete');
    delete from package_tag where package_id in (
        select id from package where state = 'to_delete');
    delete from package_extra where package_id in (
        select id from package where state = 'to_delete');
    delete from package_relationship_revision where subject_package_id in (
        select id from package where state = 'to_delete');
    delete from package_relationship_revision where object_package_id in (
        select id from package where state = 'to_delete');
    delete from package_relationship where subject_package_id in (
        select id from package where state = 'to_delete');
    delete from package_relationship where object_package_id in (
        select id from package where state = 'to_delete');
    delete from member where table_id in (
        select id from package where state = 'to_delete');
     '''

    if toolkit.check_ckan_version(max_version='2.5.99'):
        sql += '''
        delete from related_dataset where dataset_id in (
            select id from package where state = 'to_delete');
        delete from related where id in :relatedids};
        delete from package where id in (
            select id from package where state = 'to_delete');
        '''
    else:
        # CKAN-2.6 or above: related don't exist any more
        sql += '''
        delete from package where id in (
            select id from package where state = 'to_delete');
        '''

    sql += '''
    commit;
    '''
    model.Session.execute(sql, { "harvestsourceid": harvest_source_id, "relatedids": related_ids })

    # Refresh the index for this source to update the status object
    _get_action('harvest_source_reindex')(context, {'id': harvest_source_id})

    return {'id': harvest_source_id}


@logic.side_effect_free
def collection_list(context, data_dict):
    data_dict['type'] = 'collection'
    return logic.action.get.group_list(context, data_dict)

def _get_user_name():
    '''
    Returns the name of the user that will perform the harvesting actions
    (deleting, updating and creating datasets)
    By default this will be the old 'harvest' user to maintain
    compatibility. If not present, the internal site admin user will be
    used. This is the recommended setting, but if necessary it can be
    overridden with the `ckanext.harvest.user_name` config option:
       ckanext.harvest.user_name = harvest
    '''

    context = {'model': model,
               'ignore_auth': True,
               }


    context['defer_commit'] = True  # See ckan/ckan#1714
    site_user = toolkit.get_action('get_site_user')(context, {})
    user_name = site_user['name']

    return user_name

@logic.side_effect_free
def group_create(context, data_dict):

    if context.get('is_harvest') is True:
        context = {
            "user": _get_user_name(),
            "ignore_auth": True,
            "model": model,
            "session": model.Session,
            "defer_commit": True,
        }

    collection_packages = data_dict.get('collection_packages', None)
    data_dict.pop('collection_packages', None)

    children = data_dict.get('groups', None)
    data_dict.pop('groups', None)

    if not data_dict.get('scraped_from', None):
        data_dict['scraped_from'] = u''

    if not data_dict.get('source_url', None):
        data_dict['source_url'] = u''

    source_packages = data_dict.get('source_packages', None)
    data_dict.pop('source_packages', None)

    source_resources = data_dict.get('source_resources', None)

    group_type = data_dict.get('type', None)

    # remove extras for data_explorer group type
    if group_type == 'data_explorer':
        data_explorer_image_upload(context, data_dict)

        for extra in data_dict.get('extras', []):
            if extra.get('key', '') in ['url', 'owner_org', 'creator_user_id']:
                value = extra.get('value')
                data_dict[extra.get('key')] = value

        if data_dict.get('extras', None):
            data_dict.pop('extras')

    spatial_tags = csv_to_tags(csv_string=data_dict.pop('spatial', []))
    data_dict['spatial'] = spatial_tags

    tags = csv_to_tags(csv_string=data_dict.pop('tag_string', []))
    data_dict['tags'] = tags

    # make owner_suborg always blank
    data_dict['owner_suborg'] = ""

    group = logic.action.create._group_or_org_create(context, data_dict)

    # only continue from here for collections and master collections
    # TODO move this to an IGroupController hook(after create) in the plugin
    if group.get('type', '') not in ['collection', 'ed_source']:
        return group

    data_dict['id'] = group['id']

    # Create a copy of the context with auth disabled, so we can use it
    # to seamlessly edit Master Collections memberships for Collections
    context_copy = context.copy()
    context_copy['ignore_auth'] = True

    if group_type == 'collection':
        data_dict['packages'] = []

        if collection_packages:
            if isinstance(collection_packages, string_types):
                collection_packages = [collection_packages]
            collection_packages = set(collection_packages)
            for d in collection_packages:
                data_dict['packages'].append({'name': d})

        data_dict['groups'] = []

    if group_type == 'ed_source':
        data_dict['packages'] = []

        if source_packages:
            if isinstance(source_packages, string_types):
                source_packages = [source_packages]
            source_packages = set(source_packages)
            for src in source_packages:
                data_dict['packages'].append({'name': src})

        # check if that dataset has an existing source
        for pkg in data_dict['packages']:
            if helpers.get_dataset_source(pkg['name']):
                # delete previous source

                group_id = helpers.get_dataset_source(pkg['name'])[0]
                group = model.Group.get(group_id)
                member_dict = {
                    'id': group.id,
                    'object': pkg['name'],
                    'object_type': 'package',
                }

                _get_action('member_delete')(context_copy, member_dict)

        # check if the resources have an existing source
        if source_resources is not None:
            for res in source_resources.split(","):
                helpers.remove_previous_resource_source(context, res)

    return logic.action.patch.group_patch(context_copy, data_dict)

@logic.side_effect_free
def data_explorer_image_upload(context, data_dict):
    image_url = data_dict.get('data_explorer_image', data_dict.get('image_url'))

    if h.uploads_enabled() and image_url:
        image_upload = data_dict.get('image_upload')

        if isinstance(image_upload, (cgi.FieldStorage, FlaskFileStorage)):
            if image_upload:
                if 'image' not in image_upload.content_type:
                    #   This prevents the image from being updated
                    data_dict['image_url'] = None
                    data_dict['image_upload'] = None

            upload = uploader.get_uploader('data_explorer')
            upload.update_data_dict(data_dict,
                                    'data_explorer_image',
                                    'image_upload',
                                    'clear_upload')
            upload.upload(uploader.get_max_image_size())

@logic.side_effect_free
def data_dictionary_upload(context, data_dict, origin='package'):
    url_field = ''
    if origin == 'package':
        url_field = 'data_dictionary_pkg'
    else:
        url_field = 'data_dictionary_res'
    
    data_dictionary_url = data_dict.get(url_field)
    if h.uploads_enabled() and data_dictionary_url:
        upload_field_name = ''
        if origin == 'package':
            upload_field_name = 'data_dictionary_pkg_file'
        else:
            upload_field_name = 'data_dictionary_res_file'
        upload_field = data_dict.get(upload_field_name)
        if isinstance(upload_field, (cgi.FieldStorage, FlaskFileStorage)):
            upload = uploader.get_uploader('data_dictionary')
            upload.update_data_dict(data_dict,
                                    url_field,
                                    upload_field_name,
                                    'field-clear-data-dict')
            upload.upload(uploader.get_max_resource_size())

@logic.side_effect_free
def group_update(context, data_dict):

    # Callers that set context['allow_partial_update'] = True can choose to not
    # specify particular keys and they will be left at their existing
    # values. This includes: packages, users, groups, tags, extras

    model = context['model']
    user = context['user']
    session = context['session']
    id = _get_or_bust(data_dict, 'id')

    collection_packages = data_dict.get('collection_packages', None)
    data_dict.pop('collection_packages', None)

    source_packages = data_dict.get('source_packages', None)
    data_dict.pop('source_packages', None)

    source_resources = data_dict.get('source_resources', None)

    children = data_dict.get('groups', None)
    data_dict.pop('groups', None)

    group = model.Group.get(id)
    context["group"] = group
    if group is None:
        raise NotFound('Group was not found.')

    # Create a copy of the context with auth disabled, so we can use it
    # to seamlessly edit Master Collections memberships for Collections
    context_copy = context.copy()
    context_copy['ignore_auth'] = True

    data_dict['type'] = group.type

    if data_dict['type'] == 'collection':
        data_dict['packages'] = []

        documentation = package_search(
            context,
            {
                'fq': 'groups:"{}"'.format(group.name),
                'include_private': True,
                'type': 'documentation'
            }
        )

        if documentation['results']:
            for doc in documentation['results']:
                data_dict['packages'].append({'name': doc['name']})

        if collection_packages:
            if isinstance(collection_packages, string_types):
                collection_packages = [collection_packages]
            collection_packages = set(collection_packages)
            for d in collection_packages:
                data_dict['packages'].append({'name': d})

        data_dict['groups'] = []

    if data_dict['type'] == 'ed_source':
        data_dict['packages'] = []
        if source_packages:
            if isinstance(source_packages, string_types):
                source_packages = source_packages.split(',')
            source_packages = set(source_packages)
            for src in source_packages:
                data_dict['packages'].append({'name': src})

        # check if that dataset has an existing source
        for pkg in data_dict['packages']:
            if helpers.get_dataset_source(pkg['name']):
                # delete previous source

                group_id = helpers.get_dataset_source(pkg['name'])[0]
                group = model.Group.get(group_id)
                member_dict = {
                    'id': group.id,
                    'object': pkg['name'],
                    'object_type': 'package',
                }

                _get_action('member_delete')(context_copy, member_dict)

        # check if the resources have an existing source
        if source_resources is not None:
            for res in source_resources.split(","):
                helpers.remove_previous_resource_source(context, res)


    # Ge the IDs of the old and new owner_org property
    old_data = logic.action.get.group_show(context, {'id': id})
    old_owner_org = old_data.get('owner_org')   # Old ID
    owner_org = data_dict.get('owner_org')  # New ID

    # make owner_suborg always blank
    data_dict['owner_suborg'] = ""

    if data_dict['type'] == 'data_explorer' and data_dict['approval_status'] != 'approved':
        data_explorer_image_upload(context, data_dict)

    if data_dict['type'] == 'data_explorer':
        data_explorer_image_upload(context, data_dict)
        return _group_or_org_update(context, data_dict)

    if owner_org:

        # This is a flag indicating that the group update was performed (or not)
        action_update = None

        # re-add member to the owner_org, if that was updated, so it would trigger permissions update
        # first get the list of the new group's members
        new_members = logic.get_action('member_list')(context,
                                                      {'id': owner_org,
                                                       'object_type': 'user'})
        # if we actually changed the organization...
        if old_owner_org:
            # get a list of the old organization members
            old_members = logic.get_action('member_list')(context,
                                                          {'id': old_owner_org,
                                                           'object_type': 'user'})
            # Remove and re-add members of old_owner_org after patching the group
            for old_member in old_members:
                user_dict = logic.action.get.user_show(context, {'id': old_member[0]})
                old_member_dict = {
                    'id': old_owner_org,
                    'username': user_dict['name'],
                    'role': old_member[2].lower()
                }
                organization_member_delete(context_copy,
                                                      {'id': old_owner_org,
                                                       'username': old_member_dict['username']})
                try:
                    action_update = _group_or_org_update(context_copy, data_dict)
                except:
                    log.warning('Could not update the group {}'.format(id))
                organization_member_create(context_copy, old_member_dict)
        else:
            # Perform the update if not already performed
            if not action_update:
                action_update = _group_or_org_update(context, data_dict)

        # Make all members of owner_org members of this group
        for new_member in new_members:
            user_dict = logic.action.get.user_show(context, {'id': new_member[0]})
            new_member_dict = {
                'id': owner_org,
                'username': user_dict['name'],
                'role': new_member[2].lower()
            }
            organization_member_delete(context_copy,
                                                    {'id': owner_org,
                                                    'username': new_member_dict['username']})
            try:
                action_update = _group_or_org_update(context_copy, data_dict)
            except:
                log.warning('Could not update the group {}'.format(id))
            organization_member_create(context_copy, new_member_dict)

        if action_update:
            return action_update
    else:
        if old_owner_org:
            # First perform the update
            action_update = _group_or_org_update(context_copy, data_dict)

            old_members = logic.get_action('member_list')(context,
                                                          {'id': id,
                                                           'object_type': 'user'})
            # Remove all members of old_owner_org from the group
            for old_member in old_members:
                user_dict = logic.action.get.user_show(context, {'id': old_member[0]})
                old_member_dict = {
                    'id': id,
                    'username': user_dict['name'],
                }
                _group_or_org_member_delete(context_copy, old_member_dict)
            return action_update

    #if data_dict['type'] == 'data_explorer':
        #data_explorer_image_upload(context, data_dict)

    return _group_or_org_update(context, data_dict)

@logic.side_effect_free
def _group_or_org_update(context, data_dict, is_org=False):
    model = context['model']
    user = context['user']
    session = context['session']
    id = _get_or_bust(data_dict, 'id')

    group = model.Group.get(id)
    context["group"] = group
    if group is None:
        raise NotFound('Group was not found.')

    data_dict['type'] = group.type

    # get the schema
    group_plugin = lib_plugins.lookup_group_plugin(group.type)
    try:
        schema = group_plugin.form_to_db_schema_options({'type': 'update',
                                               'api': 'api_version' in context,
                                               'context': context})
    except AttributeError:
        schema = group_plugin.form_to_db_schema()

    upload = uploader.get_uploader('group', group.image_url)
    upload.update_data_dict(data_dict, 'image_url',
                            'image_upload', 'clear_upload')

    if is_org:
        _check_access('organization_update', context, data_dict)
    else:
        _check_access('group_update', context, data_dict)

    if 'api_version' not in context:
        # old plugins do not support passing the schema so we need
        # to ensure they still work
        try:
            group_plugin.check_data_dict(data_dict, schema)
        except TypeError:
            group_plugin.check_data_dict(data_dict)

    data, errors = lib_plugins.plugin_validate(
        group_plugin, context, data_dict, schema,
        'organization_update' if is_org else 'group_update')
    log.debug('group_update validate_errs=%r user=%s group=%s data_dict=%r',
              errors, context.get('user'),
              context.get('group').name if context.get('group') else '',
              data_dict)

    if errors:
        session.rollback()
        raise ValidationError(errors)

    # Not sure what this block of  code does, but it doesn't seem to be needed
    # to update the group. It is however causing an internal server error
    # AttributeError: Repository instance has no attribute 'new_revision'
    try:
        rev = model.repo.new_revision()
        rev.author = user

        if 'message' in context:
            rev.message = context['message']
        else:
            rev.message = _(u'REST API: Update object %s') % data.get("name")
    except Exception as e:
        log.warn(e)

    contains_packages = 'packages' in data_dict

    group = model_save.group_dict_save(
        data, context,
        prevent_packages_update=is_org or not contains_packages
    )

    if is_org:
        plugin_type = plugins.IOrganizationController
    else:
        plugin_type = plugins.IGroupController

    for item in plugins.PluginImplementations(plugin_type):
        item.edit(group)

    if is_org:
        activity_type = 'changed organization'
    else:
        activity_type = 'changed group'

    activity_dict = {
            'user_id': model.User.by_name(user).id,
            'object_id': group.id,
            'activity_type': activity_type,
            }
    # Handle 'deleted' groups.
    # When the user marks a group as deleted this comes through here as
    # a 'changed' group activity. We detect this and change it to a 'deleted'
    # activity.
    if group.state == u'deleted':
        if session.query(ckan.model.Activity).filter_by(
                object_id=group.id, activity_type='deleted').all():
            # A 'deleted group' activity for this group has already been
            # emitted.
            # FIXME: What if the group was deleted and then activated again?
            activity_dict = None
        else:
            # We will emit a 'deleted group' activity.
            activity_dict['activity_type'] = 'deleted group'
    if activity_dict is not None:
        activity_dict['data'] = {
                'group': dictization.table_dictize(group, context)
                }
        activity_create_context = {
            'model': model,
            'user': user,
            'defer_commit': True,
            'ignore_auth': True,
            'session': session
        }
        _get_action('activity_create')(activity_create_context, activity_dict)
        # TODO: Also create an activity detail recording what exactly changed
        # in the group.

    upload.upload(uploader.get_max_image_size())

    if not context.get('defer_commit'):
        model.repo.commit()

    return model_dictize.group_dictize(group, context)

@logic.side_effect_free
def check_access_to_create_data_explorers(context, data_dict=None):
    '''
    This helper is checking if the logged user has any
    role allowed to create data explorers (groups).

    :return: boolean
    '''

    model = context['model']
    user = context['user']
    session = context['session']

    if not user:
        return {'success': False, 'msg': 'User not allowed to create a Data Explorer'}

    data_dict_for_list_user = {
        'id' : user
    }

    organization_list = logic.get_action('organization_list_for_user')(context, data_dict_for_list_user)
    for organization in organization_list:
        if organization.get('capacity') in ['admin']:
            return {'success': True}

    return {'success': False, 'msg': 'User not allowed to create a Data Explorer'}

@logic.side_effect_free
def check_access_to_update_data_explorers(context, data_dict=None):

    model = context['model']
    user = context['user']
    session = context['session']

    if not user:
        return {'success': False, 'msg': 'User not allowed to create a Data Explorer'}
    
    group = logic_auth.get_group_object(context, data_dict)
    data_explorer_id = group.id

    context_group_show = {
        'model': model, 
        'session': model.Session,
        'for_view': True,
        'ignore_auth' : True
    }
    data_dict_group_show = {
        'id' : data_explorer_id
    }
    data_explorer = logic.get_action('group_show')(context_group_show, data_dict_group_show)
    owner_org = data_explorer.get('owner_org', '')

    data_dict_for_list_user = {'id': user}
    organization_list = logic.get_action('organization_list_for_user')(context, data_dict_for_list_user)
    for organization in organization_list:
        if organization.get('name') == owner_org:
            if organization.get('capacity') in ['admin']:
                return {'success': True}

    return {'success': False, 'msg': 'User not allowed to create a Data Explorer'}


@logic.side_effect_free
def resource_to_csv(context, data_dict):
    '''
    Wrapper for file translation to CSV call for usage as API endpoint
    '''
    return enqueue_translation(context, data_dict)


@logic.side_effect_free
def update_parent(context, data_dict):
    new_parent = data_dict.get('relationship_parent')
    relationships_query = _get_action('package_relationships_list')(
        context,
        {'id': data_dict['name']})

    if any(key in data_dict for key in ['relationship_parent', 'pkg_name']):
        for relationship in relationships_query:
            relationship_subject = relationship['subject']
            relationship_object = relationship['object']
            relationship_type = relationship['type']

            if relationship_type == 'child_of' \
               and relationship_object != new_parent:
                _get_action('package_relationship_delete')(context, {
                    'object': relationship_object,
                    'subject': relationship_subject,
                    'type': 'child_of'})

    if new_parent:
        parent_name_matches = _get_action('package_autocomplete')(
            context, {'q': new_parent})
        parent = list(filter(lambda package: package['title'] == new_parent or
                             package['name'] == new_parent, parent_name_matches))

        if parent:
            _get_action('package_relationship_create')(context, {
                'object': data_dict['name'],
                'subject': parent[0]['name'],
                'type': 'parent_of'})


@logic.side_effect_free
def update_relationship_dependencies(context, data_dict):

    new_dependencies = data_dict.get('relationship_dependency_of', [])
    package_name = data_dict.get('name')

    if new_dependencies:
        new_dependencies = new_dependencies.split(',')
    relationships_query = _get_action('package_relationships_list')(
        context,
        {'id': package_name})

    old_dependencies = [
        r['object'] for r in relationships_query
        if r['type'] == 'dependency_of'
    ]

    to_remove = [
        tr for tr in old_dependencies
        if tr not in new_dependencies
    ]

    if to_remove:
        for rp in to_remove:
            _get_action('package_relationship_delete')(context, {
                'object': rp,
                'subject': package_name,
                'type': 'dependency_of'})

    for nd in new_dependencies:
        _get_action('package_relationship_create')(context, {
            'object': nd,
            'subject': package_name,
            'type': 'dependency_of'})


@logic.side_effect_free
def update_relationship_derivations(context, data_dict):
    new_derivations = data_dict.get('relationship_derives_from', [])
    package_name = data_dict.get('name')

    if new_derivations:
        new_derivations = new_derivations.split(',')
    relationships_query = _get_action('package_relationships_list')(
        context,
        {'id': package_name})

    old_derivations = [
        r['object'] for r in relationships_query
        if r['type'] == 'derives_from'
    ]

    to_remove = [
        tr for tr in old_derivations
        if tr not in new_derivations
    ]

    if to_remove:
        for rp in to_remove:
            _get_action('package_relationship_delete')(context, {
                'object': rp,
                'subject': package_name,
                'type': 'derives_from'})

    context['model'] = model
    context['session'] = model.Session
    context['ignore_auth'] = True
    context['defer_commit'] = True
    for nd in new_derivations:
        _get_action('package_relationship_create')(context, {
            'object': nd,
            'subject': package_name,
            'type': 'derives_from'})

    model.repo.commit()
    


@logic.side_effect_free
def ed_organization_delete(context, data_dict):
    org_name = data_dict['id']
    org_id = _get_action(
        'organization_show')(
        context,
        {'id': org_name}).get('id')

    remove_hierarchy_relationships(org_id)

    _get_action(
        'organization_delete')(
        context,
        {'id': org_name})

def make_resource_approval_pending(context, resource_dict):   
    context_get_user = {"ignore_auth": True}
    try:
        default_user_dict = toolkit.get_action("get_site_user")(context_get_user, {})
        default_user_name = default_user_dict.get('name', '')
    except Exception as e:
        log.error("Could not get default site user: {}".format(e))
        return None
   
    model = context['model']
    context['ignore_auth'] = True
    try:
        context['auth_user_obj'] = model.User.by_name(default_user_name)
    except Exception as e:
        log.error("Could not get default site user object: {}".format(e))
        return None
    
    resource_dict['approval_status'] = 'approval_pending'

    try:
        resource = logic.get_action('resource_patch')(context, resource_dict)
    except Exception as e:
        log.error("Could not update resource: {}".format(e))
        return None
    
    return resource


@logic.side_effect_free
def group_tree(context, data_dict):
    '''Returns the full group tree hierarchy.
    :returns: list of top-level GroupTreeNodes
    '''
    model = _get_or_bust(context, 'model')
    group_type = data_dict.get('type', 'group')
    return [_group_tree_branch(group, type=group_type)
            for group in model.Group.get_top_level_groups(type=group_type)]


@logic.side_effect_free
def group_tree_section(context, data_dict):
    '''Returns the section of the group tree hierarchy which includes the given
    group, from the top-level group downwards.
    :param id: the id or name of the group to include in the tree
    :param include_parents: if false, starts from given group
    :param include_siblingss: if false, excludes given group siblings
    :returns: the top GroupTreeNode of the tree section
    '''
    group_name_or_id = _get_or_bust(data_dict, 'id')
    model = _get_or_bust(context, 'model')
    group = model.Group.get(group_name_or_id)
    if group is None:
        raise p.toolkit.ObjectNotFound
    group_type = data_dict.get('type', 'group')
    if group.type != group_type:
        how_type_was_set = 'was specified' if data_dict.get('type') \
            else 'is filtered by default'
        raise p.toolkit.ValidationError(
            'Group type is "%s" not "%s" that %s' %
            (group.type, group_type, how_type_was_set))
    include_parents = context.get('include_parents', True)
    include_siblings = context.get('include_siblings', True)
    if include_parents:
        root_group = (group.get_parent_group_hierarchy(type=group_type)
                      or [group])[0]
    else:
        root_group = group
    if include_siblings or root_group == group:
        return _group_tree_branch(root_group, highlight_group_name=group.name,
                                  type=group_type)
    else:
        section_subtree = _group_tree_branch(group,
                                             highlight_group_name=group.name,
                                             type=group_type)
        return _nest_group_tree_list(
            group.get_parent_group_hierarchy(type=group_type),
            section_subtree)

def _nest_group_tree_list(group_tree_list, group_tree_leaf):
    '''Returns a tree branch composed by nesting the groups in the list.
    :param group_tree_list: list of groups to build a tree, first is root
    :returns: the top GroupTreeNode of the tree
    '''
    root_node = None
    last_node = None
    for group in group_tree_list:
        node = GroupTreeNode(
            {'id': group.id,
             'name': group.name,
             'title': group.title})
        if not root_node:
            root_node = last_node = node
        else:
            last_node.add_child_node(node)
            last_node = node
    last_node.add_child_node(group_tree_leaf)
    return root_node

def _group_tree_branch(root_group, highlight_group_name=None, type='group'):
    '''Returns a branch of the group tree hierarchy, rooted in the given group.
    :param root_group_id: group object at the top of the part of the tree
    :param highlight_group_name: group name that is to be flagged 'highlighted'
    :returns: the top GroupTreeNode of the tree
    '''
    nodes = {}  # group_id: GroupTreeNode()
    root_node = nodes[root_group.id] = GroupTreeNode(
        {'id': root_group.id,
         'name': root_group.name,
         'title': root_group.title})
    if root_group.name == highlight_group_name:
        nodes[root_group.id].highlight()
        highlight_group_name = None
    for group_id, group_name, group_title, parent_id in \
            root_group.get_children_group_hierarchy(type=type):
        node = GroupTreeNode({'id': group_id,
                              'name': group_name,
                              'title': group_title})
        nodes[parent_id].add_child_node(node)
        if highlight_group_name and group_name == highlight_group_name:
            node.highlight()
        nodes[group_id] = node
    return root_node

@logic.side_effect_free
def get_record_schedule(context, data_dict):
    records = get_record_scheduledb()
    records = [dict(name='None', value=' ')] + sorted(records, key=lambda k: k['name'])
    return json.dumps(records)


@logic.side_effect_free
def get_relationships_from_api(context,
                               package_id,
                               relationship_type,
                               hierarchy=None,
                               i=1):
    relationships = []

    if hierarchy is None:
        hierarchy = list()

    try:
        relationships = logic.get_action('package_relationship_list_db')(
            context, {'id': package_id, 'rel': relationship_type})
        relationships = helpers._remove_private_relationships(relationships, True)

    except logic.NotFound:
        log.info('No {} relationships found for {}'.format(
            relationship_type,
            package_id
        ))
        return hierarchy

    if relationship_type == 'parent_of':
        hierarchy += [
            {'name': c['object'], 'parent': c['subject'], 'level': i}
            for c in relationships
        ]
        i += 1

        comp = [
            get_relationships_from_api(
                context, child['object'], relationship_type, hierarchy, i
            ) for child in relationships
        ]
        return hierarchy

    else:
        return get_relationships_from_api(
            context,
            relationships[0]['object'],
            relationship_type,
            relationships
        )


@logic.side_effect_free
def get_package_hierarchy_html(context, data_dict):
    context = {'model': model, 'session': model.Session}
    context['ignore_auth'] = True
    pkg_name = data_dict.get('id')
    full_hierarchy = get_full_package_hierarchy(
        context, {'id': pkg_name})

    full_hierarchy_documentation = full_hierarchy.get(pkg_name, {})

    if full_hierarchy_documentation:
        children = full_hierarchy_documentation.get('children')
        parent = full_hierarchy_documentation.get('parent')

        if all(f is None for f in [children, parent]):
            return

    cur_pkg_path = helpers.find_hierarchy_cur_pkg_path(full_hierarchy, pkg_name)

    full_html = ('<div class="relationship-hierarchy-tree"><ul class="package-hiera'
            'rchy">{}</ul></div>'.format(helpers.generate_html(
                context, full_hierarchy, pkg_name, cur_pkg_path
            )))

    return full_html


@logic.side_effect_free
def get_full_package_hierarchy(context, data_dict):
    package_id = data_dict.get('id')

    top_level_parent = get_relationships_from_api(
        context,
        package_id,
        'child_of'
    )

    top_level_parent = helpers._remove_private_relationships(top_level_parent, True)

    if isinstance(top_level_parent, list):
        if not top_level_parent or top_level_parent[0].get('object') is None:
            top_level_parent_id = package_id

        else:
            top_level_parent_id = top_level_parent[0].get('object')

        hierarchy = [
            {'name': top_level_parent_id, 'parent': None, 'level': 0}
        ] + get_relationships_from_api(
            context,
            top_level_parent_id,
            'parent_of'
        )
        
        lowest_level = max([level['level'] for level in hierarchy])
        nested_hierarchy = {}

        for i in range(lowest_level, -1, -1):
            tmp_nested_hierarchy = {}

            current_level = [
                relationship for relationship in hierarchy
                if relationship['level'] == i
            ]

            for relationship in current_level:
                cur_pkg = {}

                try:
                    q = get_package_from_db(name=relationship['name'])

                    cur_pkg = {
                        'title': q.get('title'),
                        'dataset_type': q.get('type')
                    }
                except Exception as e:
                    log.debug('Unable to retrieve package for name: {}\n{}'
                              .format(relationship['name'], e))

                if cur_pkg.get('dataset_type') != 'dataset':
                    continue

                updated_hierarchy = OrderedDict({
                    relationship['name']: OrderedDict([
                        ('title', cur_pkg.get('title')),
                        ('level', relationship['level']),
                        ('parent', relationship['parent']),
                        ('children', nested_hierarchy.get(
                            relationship['name']
                        ))
                    ])
                })

                if relationship['parent'] in tmp_nested_hierarchy:
                    tmp_nested_hierarchy[relationship['parent']].update(
                        updated_hierarchy)
                elif i > 0:
                    tmp_nested_hierarchy[relationship['parent']] = \
                        updated_hierarchy
                else:
                    tmp_nested_hierarchy = updated_hierarchy

            nested_hierarchy = tmp_nested_hierarchy

        return nested_hierarchy

def get_package_from_db(name=None, id=None):
    query = model.Session.query(model.Package)

    if name:
        query = query.filter_by(name=name)
        query = query.first()
    elif id:
        query = query.filter_by(id=id)
        query = query.first()

    if query:
        query = query.as_dict()

    return query

@logic.side_effect_free
def source_list(context, data_dict):
    data_dict['type'] = 'ed_source'
    return logic.action.get.group_list(context, data_dict)

@logic.side_effect_free
def source_update(context, data_dict):
    '''Update a group.
    You must be authorized to edit the group.
    Plugins may change the parameters of this function depending on the value
    of the group's ``type`` attribute, see the
    :py:class:`~ckan.plugins.interfaces.IGroupForm` plugin interface.
    For further parameters see
    :py:func:`~ckan.logic.action.create.group_create`.
    :param id: the name or id of the group to update
    :type id: string
    :returns: the updated group
    :rtype: dictionary
    '''
    # Callers that set context['allow_partial_update'] = True can choose to not
    # specify particular keys and they will be left at their existing
    # values. This includes: packages, users, groups, tags, extras

    return _group_or_org_update(context, data_dict)

def group_activity_list_html(context, data_dict):
    '''Return a group's activity stream as HTML.

    The activity stream is rendered as a snippet of HTML meant to be included
    in an HTML page, i.e. it doesn't have any HTML header or footer.

    :param id: the id or name of the group
    :type id: string
    :param offset: where to start getting activity items from
        (optional, default: ``0``)
    :type offset: int
    :param limit: the maximum number of activities to return
        (optional, default: ``31``, the default value is configurable via the
        ckan.activity_list_limit setting)
    :type limit: int

    :rtype: string

    '''
    activity_stream = helpers.get_group_activity_list(data_dict['id'])

    offset = int(data_dict.get('offset', 0))
    extra_vars = {
        'controller': 'group',
        'action': 'activity',
        'id': data_dict['id'],
        'offset': offset,
    }
    return core_activity_streams.activity_list_to_html(
        context, activity_stream, extra_vars)


def config_option_update(context, data_dict):
    '''
    .. versionadded:: 2.4
    Allows to modify some CKAN runtime-editable config options
    It takes arbitrary key, value pairs and checks the keys against the
    config options update schema. If some of the provided keys are not present
    in the schema a :py:class:`~ckan.plugins.logic.ValidationError` is raised.
    The values are then validated against the schema, and if validation is
    passed, for each key, value config option:
    * It is stored on the ``system_info`` database table
    * The Pylons ``config`` object is updated.
    * The ``app_globals`` (``g``) object is updated (this only happens for
      options explicitly defined in the ``app_globals`` module.
    The following lists a ``key`` parameter, but this should be replaced by
    whichever config options want to be updated, eg::
        get_action('config_option_update)({}, {
            'ckan.site_title': 'My Open Data site',
            'ckan.homepage_layout': 2,
        })
    :param key: a configuration option key (eg ``ckan.site_title``). It must
        be present on the ``update_configuration_schema``
    :type key: string
    :returns: a dictionary with the options set
    :rtype: dictionary
    .. note:: You can see all available runtime-editable configuration options
        calling
        the :py:func:`~ckan.logic.action.get.config_option_list` action
    .. note:: Extensions can modify which configuration options are
        runtime-editable.
        For details, check :doc:`/extensions/remote-config-update`.
    .. warning:: You should only add config options that you are comfortable
        they can be edited during runtime, such as ones you've added in your
        own extension, or have reviewed the use of in core CKAN.
    '''
    model = context['model']

    _check_access('config_option_update', context, data_dict)

    schema = schema_.update_configuration_schema()

    available_options = list(schema.keys()) + ['ckan.announcement_text', 'ckan.announcement_popup']
    available_options += ['ckan.footer_text', 'ckan.footer_popup']    

    provided_options = data_dict.keys()

    unsupported_options = set(provided_options) - set(available_options)
    if unsupported_options:
        msg = 'Configuration option(s) \'{0}\' can not be updated'.format(
              ' '.join(list(unsupported_options)))

        raise ValidationError(msg, error_summary={'message': msg})

    upload = uploader.get_uploader('admin')
    upload.update_data_dict(data_dict, 'ckan.site_logo',
                            'logo_upload', 'clear_logo_upload')
    upload.upload(uploader.get_max_image_size())
    data, errors = _validate(data_dict, schema, context)
    if errors:
        model.Session.rollback()
        raise ValidationError(errors)

    for key, value in data.items():

        # Set full Logo url
        if key == 'ckan.site_logo' and value and not value.startswith('http')\
                and not value.startswith('/'):
            image_path = 'uploads/admin/'

            value = h.url_for_static('{0}{1}'.format(image_path, value))

        # Save value in database
        system_info.set_system_info(key, value)

        # Update CKAN's `config` object
        config[key] = value

        # Only add it to the app_globals (`g`) object if explicitly defined
        # there
        globals_keys = app_globals.app_globals_from_config_details.keys()
        if key in globals_keys:
            app_globals.set_app_global(key, value)

    # Update the config update timestamp
    system_info.set_system_info('ckan.config_update', str(time.time()))

    log.info('Updated config options: {0}'.format(data))

    return data


@logic.side_effect_free
def package_relationship_list_db(context, data_dict):
    id = data_dict.get('id')
    context['ignore_auth'] = True
    pkg_id = get_package_from_db(name=id)
    if not pkg_id:
        pkg_id = id
    else:
        pkg_id = pkg_id.get('id')
    rslt = get_package_child(pkg_id)
    if data_dict.get('rel'):
        rel = data_dict.get('rel')
        rslt = list(filter(lambda k: k['type']==rel, rslt))
        if len(rslt) == 0:
            raise logic.NotFound
    rslt2 = []

    rslt2 = [
        {
            **pkg_c,
            'subject': get_package_from_db(id=pkg_c['subject']).get('name'),
            'object': get_package_from_db(id=pkg_c['object']).get('name')
        } for pkg_c in rslt
    ]

    child_order = helpers.check_order(rslt2)

    if child_order:
        if child_order == 'asc':
            rslt2 = sorted(rslt2, key=lambda k: k['object'])
        elif child_order == 'desc':
            rslt2 = sorted(rslt2, key=lambda k: k['object'], reverse=True)
        else:
            rslt2 = sorted(rslt2, key=lambda k: k['order'])
    else:
        rslt2 = sorted(rslt2, key=lambda k: k['object'])
    
    return rslt2

def package_update_relationship_db(context, data_dict):
    object_id = data_dict.get('object_id')
    subject_id = data_dict.get('subject_id')
    level = data_dict.get('order')
    try:
        update_package_child(object_id, subject_id, level)
        return 'success'
    except Exception as e:
        log.error('Error while updating reltionship db: {}'.format(e))
        raise


def package_update_multiple_relationship(context, data_dict):
    parent = data_dict.get('object_id')
    all_child = data_dict.get('subject_ids')
    
    for i, child in enumerate(all_child):
        data_dict = {
            'object_id': parent,
            'subject_id': child,
            'order': i + 1
        }
        package_update_relationship_db(context, data_dict)


@logic.side_effect_free
def create_user_default_fields(context, data_dict):
    model = context['model']
    user_id = data_dict.get('user_id')
    user = model.User.get(user_id)

    if user is None:
        raise NotFound('User not found')
    else:
        set_user_package_fields(data_dict)


@logic.side_effect_free
def get_user_default_fields(context, data_dict):
    model = context['model']
    user_id = data_dict.get('user_id')
    user = model.User.get(user_id)
    if user is None:
        raise NotFound('User not found')
    else:
        result = get_user_package_fields(user_id)
        log.info('result: {}'.format(result))
        return result
    