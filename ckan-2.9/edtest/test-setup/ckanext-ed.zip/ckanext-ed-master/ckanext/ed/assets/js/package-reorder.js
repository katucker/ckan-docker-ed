$(()=>{
  //TEMPLATE VARIABLES
  const reorderButton = `
  <button class="btn btn-default" id="order">
    <i class="fa fa-bars"></i>
    <span>Re-order</span>
  </button>
  `
  const headerText = `
    <h1>Re-order Data Profiles</h1>
    <p> Drag Data Profile to re-order the sequence</p>
  `

  const formActions = `
    <div class="form-actions">
      <button class="cancel btn btn-danger pull-left">Cancel</button>
      <button class="save btn btn-primary">Save Order</button>
    </div>
  `

  function listTemplate(pkg){

    let quality = []

    let qualityFn = quality_mark(pkg)
    let qualityTemplateM = `
        <span>
          <img src="/base/images/checked.png" alt="checked"/>
          Machine Readable &nbsp;
        </span>
    `
    let qualityTemplateDoc = `
        <span>
          <img src="/base/images/checked.png" alt="checked"/>
          Documentation &nbsp;
        </span>
    `

    if(qualityFn['machine']) {
      quality.push(qualityTemplateM)
    }
    else if(qualityFn['doc']) {
      quality.push(qualityTemplateDoc)
    }
    else {
      quality.push(" ")
    }

    quality = quality.join("\n")

    const dataProflieList = `
        <li class="dataset-item cursor-move" id="${pkg.id}">
        <div class="card-custom package-item">
          <a href="/dataset/${pkg.name}">
            <p class="font-body-lg">
              <span>${pkg.title}</span>
            </p>
            <div>${pkg.notes}</div>
            <div class="dataset-total-views">
              ${quality}
            </div>
          </a>
        </div>
      </li>
    `
    return dataProflieList
  }

  const alphaSort = `
    <div style="margin-buttom:20px;padding-buttom:12px;" >
    <select id="alphasort" class="form-control" style="width:50%;">
      <option value="asc">Alphabetical Ascending (A to Z)</option>
      <option value="desc">Alphabetical Descending (Z to A)</option>
      <option value='custom'>Custom sorting</option>
    </select>
   <div>
  `
  
  function quality_mark(pkg){
    if(!(Object.keys(pkg).includes('resources'))) {
      return {
        machine: false,
        doc: false
      }
    }

    let alLeastOneMachineResource;
    let atLeastOneDocumentResource;
    for( let r of pkg['resources']) {
      let format = r['format'] === "CSV" || r["format"] === "XML"
      let mimetype = r['mimetype'] === "text/csv" || r['mimetype'] === "text/json"
      mimetype = mimetype || r['mimetype'] === "application/json"
      let urltype = r['url_type'] != 'upload' && r['url_type'] != 'TXT' && r['url'] != ''
      alLeastOneMachineResource ||= format || mimetype || urltype

      atLeastOneDocumentResource ||= r["resource_type"] === "doc"
    }
    return {
      machine: alLeastOneMachineResource,
      doc: atLeastOneDocumentResource
    }

  }

  //GLOBAL VARIABLES
  let prevElement;
  let el;
  let sortBy;

  
  
  $(".page_primary_action").on("click","#order",()=>{
    $(".page_primary_action").html(headerText)
    el = $('#sortable').sortable()

    let defaultOrder = $('#childOrder').val()
    prevElement = el.html()
    $(".page_primary_action").append(alphaSort)
    $(formActions).insertAfter($('#sortable'))
    $('.cancel').click(handleCancel)
    $('.save').click(handleSubmit)
    
    if (defaultOrder === "None") {
      $('#alphasort option[value=asc]').attr('selected','selected');
    }
    else {
      $(`#alphasort option[value=${defaultOrder}]`).attr('selected','selected');
    }
    $('#alphasort').change(()=>{
      sortBy = $('#alphasort').val()
      if (sortBy === "custom") {
        el.addClass('sorting').sortable('enable')
      }
      else {
        let sortPackage = sort(sortBy)
        let dataList = []

        for(let pkg of sortPackage) {
            dataList.push(listTemplate(pkg))
        }
        dataList = dataList.join("\n")
        $("#sortable").html(dataList)
      }
      

    })
    

  })

  function handleCancel(){
    $(".page_primary_action").html(reorderButton)
    $("#sortable").html(prevElement)
    $(".sorting").sortable().sortable('disable')
    $(".form-actions").remove()
    $("#alphasort").remove()
  }

  function handleSubmit(){
    let childs = el.sortable('enable').sortable("toArray")
    let data = {
      'object_id': $('#pkg_id').val(),
      'subject_ids': childs,
    }
    $.ajax({
      type: "POST",
      contentType: 'application/json',
      url: `${window.location.origin}/api/action/package_update_multiple_relationship`,
      dataType: 'json',
      processData: false,
      data: JSON.stringify(data),
      success: ()=> {
        $(".page_primary_action").html(reorderButton)
        $("#sortable").html(el.html())
        $(".sorting").sortable().sortable('disable')
        $(".form-actions").remove()
        $("#alphasort").remove()
        $('#childOrder').val(sortBy)
      },
      error: (e)=>{
        console.log(e)
      }
    })
  }

  function sort(ascending) {
    let package = [...JSON.parse($("#pkg").val())]
    
    return package.sort((a,b) => {
      if (ascending === "asc") {
        return a.name.localeCompare(b.name)
      } 
      else {
        return b.name.localeCompare(a.name)
      }
    })
  }
})

