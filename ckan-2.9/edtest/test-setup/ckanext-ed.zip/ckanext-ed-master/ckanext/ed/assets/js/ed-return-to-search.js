/**
 * Check if a user just came from the dataset search page.
 * 
 * @returns `true` if the user came from the dataset search page
 */
const isFromSearchPage = () => {
    // Get referrer url object
    try {
        const referrer = new URL(document.referrer);

        /* Check that the referrer is from the within the site and
        Check that it was referred from the dataset search page and
        Check that there was actually a search */
        if (referrer.origin === document.location.origin &&
            referrer.pathname.replace(/[/]/g, '') === 'dataset' &&
            referrer.search
        ) {
            return true;
        }
        
        return false;
    } catch (e) {
        return false;
    }
}

/**
 * If the user is coming from the dataset search page, adds a `Return to Search
 * Results` button
 * 
 * @returns nothing
 */
const addReturnButton = () => {
    if (!isFromSearchPage()) {
        return
    }

    // create Button element
    let returnButton = document.createElement('button');
    returnButton.className = 'btn btn-primary btn-manage dataset-btn';
    returnButton.id = 'return-to-search-results';
    returnButton.onclick = e => {
        history.back();
    }

    let returnButtonICon = document.createElement('i');
    returnButtonICon.className = 'fa fa-arrow-left custom22';

    returnButton.innerText = 'Return to Search Results';
    returnButton.insertBefore(returnButtonICon, returnButton.childNodes[0])

    // Insert the return button just before the copy button
    const parentElement = document.querySelector('header > .content_action')
    parentElement.insertBefore(returnButton, parentElement.childNodes[0])
}

addReturnButton();