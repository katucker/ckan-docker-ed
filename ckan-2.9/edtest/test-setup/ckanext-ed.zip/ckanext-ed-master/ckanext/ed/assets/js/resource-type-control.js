$(document).ready(function() {
    var downloadable_resource = document.getElementsByClassName('image-upload')[0];
    var indirect_resource = document.getElementsByClassName('image-upload')[1];

    if (![downloadable_resource, indirect_resource].includes(undefined)) {

      if ($("input[id='downloadable']").prop("checked") == true){
          downloadable_resource.style.display='';
          indirect_resource.style.display='none';
      }
      else if ($("input[id='indirect']").prop("checked") == true){
          downloadable_resource.style.display='none';
          indirect_resource.style.display='';
      }
      else {
          downloadable_resource.style.display='';
          indirect_resource.style.display='none';
      }
      

      $("input[id='downloadable']").change(function(){
          downloadable_resource.style.display='';
          indirect_resource.style.display='none';

          // fix input field upload width
          var button_upload = $("a.file-upload-button")
          $("input[id='field-image-upload']").css('width', button_upload.outerWidth());
      });

      $("input[id='indirect']").change(function(){
          downloadable_resource.style.display='none';
          indirect_resource.style.display='';
      });
    }


    $("input[id='field-image-upload']").change(function(){

        if($("input[id='field-name']").prop('required') == false){
            $("input[id='field-name']").prop('required', true);
            $("label[for='field-name']").prepend(`<span class="control-required" aria-hidden="true">*</span>&nbsp;`);
            $("label[for='field-name']").append(`<span class="offscreen" >Required</span>`);
        }
        
    });


    $("input[id='field-name']").on('invalid', function(){
        if (!this.value){
            if ($("span[id='field-name-error']").length == 0){
                $("input[id='field-name']").after(`<span id="field-name-error"></span>`);
                $("span[id='field-name-error']").css('display', 'inline-block');
                $("span[id='field-name-error']").text("Please enter a name for the resource");
                $("span[id='field-name-error']").css('color', '#9B2622');
                $("span[id='field-name-error']").css('font-size', '11px');
            }
        }
        else {
            $("span[id='field-name-error']").css('display', 'none');
        }
    });


    function monitorRemove(element, mutationCallback) {
        let config = { attributes: true, attributeFilter: ['style'] };
        let callback = function(mutationsList, observer) {
            for(var mutation of mutationsList) {
                console.log("mutation.type: " + mutation.type)
                if (mutation.type == 'attributes') {
                    console.log('The ' + mutation.attributeName + ' attribute was modified.');
                    // check if display:none is remove from style
                    if (mutationCallback(mutation) == true){
                        $("input[id='field-name']").prop('required', false);
                        $("span[class='control-required']").remove();
                        $("span[class='offscreen']").remove();
                        // remove span control-required
                        $("label[for='field-name']").html(function (i, html) {
                            return html.replace(/&nbsp;/g, '');
                        });

                    }
                }
            }
        };
        let observer = new MutationObserver(callback);
        observer.observe(element, config);
    }

    let targetNode = document.getElementsByClassName('image-upload');
    let targetImageUpload = targetNode[0].children[0];
    monitorRemove(targetImageUpload, function(mutation) {
        return mutation.target.style.display == "none"
    });


    $("input[id='indirect']").change(function(){
        let targetNode1 = document.getElementsByClassName('image-upload');
        let targetAccessUrl1 = targetNode1[1].children[0];
        monitorRemove(targetAccessUrl1, function(mutation) {
            return !mutation.target.style.display
        });
    });

    function manageNameField(self) {
        if (self.value != "" && $("input[id='field-name']").prop('required') == false){
            $("input[id='field-name']").prop('required', true);
            $("label[for='field-name']").prepend(`<span class="control-required" aria-hidden="true">*</span>&nbsp;`);
            $("label[for='field-name']").append(`<span class="offscreen" >Required</span>`);
        }
        else if(self.value == "" && $("input[id='field-name']").prop('required') == true){
            $("input[id='field-name']").prop('required', false);
            $("span[class='control-required']").remove();
            $("span[class='offscreen']").remove();
            // remove span control-required
            $("label[for='field-name']").html(function (i, html) {
                return html.replace(/&nbsp;/g, '');
            });
        }
    }

    $("input[id='field-access-url']").change(function(){
        manageNameField(this);
    });
    //field-api-url
    $("input[id='field-api-url']").change(function(){
        manageNameField(this);
    });

    //field-image-url
    $("input[id='field-image-url']").change(function(){
        manageNameField(this);
    });


    if($(".field-image-url").val() != ""){
        $("input[id='field-name']").prop('required', true);
        $("label[for='field-name']").prepend(`<span class="control-required" aria-hidden="true">*</span>&nbsp;`);
        $("label[for='field-name']").append(`<span class="offscreen" >Required</span>`);
    }
}); 