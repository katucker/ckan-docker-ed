$(document).ready(function() {
    var organizations = []
    
    $.ajax({
        url: "/api/action/group_tree",
        data: {
          'type' : 'organization'
        }, 
        success: function(result){
          organizations = result.result;
        }
    });

    function get_suborganizations(publisher_name){
        var suborganizations = [];
        organizations.forEach(function (organization, org_index) {

          if (organization.name === publisher_name){
            suborganizations = organization.children
          }
        });
        return suborganizations
    };

    function onOrganizationChange(){
        var publisher_name = $("#field-organizations").val();
        var suborganizations = get_suborganizations(publisher_name);
        
        var current_value = $('#field-suborganizations').val();
        var selected_value = ""

        $('#field-suborganizations').children().remove().end();
        $('#field-suborganizations').append($('<option>', { 
            value: "",
            text : "No Organization"
        }));

        suborganizations.forEach(function(suborg, suborg_index){
          $('#field-suborganizations').append($('<option>', { 
            value: suborg.name,
            text : suborg.title 
          }));
          if (current_value === suborg.name){
            selected_value = suborg.name;
          }
        });

        $('#field-suborganizations').val(selected_value).change();
    };

    $("#field-organizations").change(function() {
        onOrganizationChange();
    });
}); 