// String constants
const localStorageKeyName = 'changeOwnerGroupList'; // object key for group ids in local storage
const localStorageTypeKeyName = 'changeOwnerGroupListType'; // object key to store the current group type
const followerCheckboxClass = 'follower-checkbox'; // class name for iidentifying follower checkboxes
const pageURL = document.location.href; // page url
const packageCounterElementId = 'bulk-change-group-ownership-count'; // element id for span class containing package list count
const errorMessageElementId = 'bulk-change-group-ownership-error'; // element id for span class showing error messages
const masterCheckboxId = 'change-ownership-master-checkbox'; // element id for master checkbox
const changeAndCancelButtonId = 'bulk-change-group-ownership-btn'; // id for the change ownership button which is also used as the cancel button


// If the user is not coming from within the portal, clear the localstorage
let referrer;
try {
    referrer = new URL(document.referrer);
    if (referrer && referrer.hostname != document.location.hostname) {
        localStorage.removeItem(localStorageKeyName);
    }
} catch (e) {
    localStorage.removeItem(localStorageKeyName);
}

// Get the change button
const changeButton = document.getElementById(changeAndCancelButtonId);

let isChangeOwnershipInterfaceActive = false;
let currentList = JSON.parse(localStorage.getItem(localStorageKeyName));
let currentGroupType = localStorage.getItem(localStorageTypeKeyName);

/* If there was an existing value in the local storage, and the grouptype is the same
indicate that the interface should be generated */
if (currentList && currentList.length && currentGroupType == changeButton.dataset['grouptype']) {
    isChangeOwnershipInterfaceActive = true;
}

// Set variable selectors depending on the group type
let itemsQuerySelector = 'li.dataset-item .card-custom.package-item'; // queryselector for group items
let itemsownerTextSelector = 'dataset-total-views'; // classname for owner text box within item selector
let itemsUlElementSelector = 'ul.dataset-list'; // query selector for element wrapping group items
if (changeButton?.dataset['grouptype'] == 'data_explorer') {
    itemsQuerySelector = 'div.data-explorer-item';
    itemsownerTextSelector = 'data-explorer-item-link';
    itemsUlElementSelector = '#data-explorer-items-wrapper';
} else if (['category', 'group', 'topic'].includes(changeButton?.dataset['grouptype'])) {
    itemsQuerySelector = 'div.data-explorer-item';
    itemsownerTextSelector = 'count';
    itemsUlElementSelector = '#category-items-wrapper';
}

/**
 * Checkbox element for each checkbox that would be generated beside
 * the group items.
 * 
 * @param {String} groupName the package id, will also be used as the checkbox name
 * @param {String} size the checkbox css width and height
 * @returns {HTMLInputElement} the generated checkbox element
 */
const checkboxElement = (groupName, grouptitle, size) => {
    const checkbox = document.createElement('input');
    checkbox.setAttribute('type', 'checkbox');
    checkbox.setAttribute('aria-label',`Select ${grouptitle}`);
    checkbox.setAttribute('tabindex', '0');
    checkbox.name = groupName;
    checkbox.style.width = size;
    checkbox.style.height = size;
    checkbox.classList.add(followerCheckboxClass);

    /* If the checkbox was selected in the localstorage, 
    set it to checked at creation */
    if (currentList && currentList.includes(groupName)){
        checkbox.checked = true;
    }

    // Add event listener for click events
    checkbox.addEventListener('click', e => {
        /* On click, if the checkbox was clicked, add the package id to 
        the localstorage. If not, remove it from the local storage */
        currentList = JSON.parse(localStorage.getItem(localStorageKeyName));
        if (checkbox.checked) {
            currentList.push(groupName);
            document.getElementById(errorMessageElementId)
                .innerText = '';
        } else {
            const index = currentList.indexOf(groupName);
            if (index > -1) {
                currentList.splice(index, 1);
            }
        }
        localStorage.setItem(localStorageKeyName, JSON.stringify(currentList));
        document.getElementById(packageCounterElementId)
            .innerText = `${currentList.length} selected`;

        // call function handling master checkbox state
        controlMasterCheckboxState();
    })

    return checkbox;
}

/**
 * Handles the master checkbox checked state.
 * When the follower checkboxes don't all have the same checked state,
 * this sets the master indeterminate state to true.
 */
const controlMasterCheckboxState = () => {
    const master = document.getElementById(masterCheckboxId);
    // Check if all the checkboxes on the have the same check state
    let states = [];
    document.getElementsByClassName(followerCheckboxClass).forEach(c => {
        states.push(c.checked);
    })

    if (states.every((val, i, arr) => val === arr[0])) {
        // All states are the same
        master.indeterminate = false;
        if (master.checked != states[0]) {
            master.checked = states[0];;
        }
    } else {
        // The states are not all the same
        master.indeterminate = true;
    }
}

/**
 * Generates the list item for the master checkbox
 * 
 * @param {String} size the width and height of the checkbox to pass to CSS
 * @returns {HTMLLIElement} the list element containing the master checkbox
 */
const masterCheckboxListItem = (size) => {
    const checkbox = document.createElement('input');
    checkbox.setAttribute('type', 'checkbox');
    checkbox.setAttribute('aria-label','Select all items in this page')
    checkbox.style.width = size;
    checkbox.style.height = size;
    checkbox.id = masterCheckboxId;

    checkbox.addEventListener('click', e => {
        document.getElementsByClassName(followerCheckboxClass).forEach(c => {
            if (c.checked != checkbox.checked) {
                c.click()
            }
        })
    })

    const listItem = document.createElement('li');
    listItem.classList.add('dataset-item');
    listItem.style.display = 'flex';
    listItem.style.flexDirection = 'row';
    listItem.style.gap = '16px';
    listItem.style.marginBottom = '16px'

    const textDiv = document.createElement('div');
    textDiv.innerText = 'Select all items in this page';

    listItem.appendChild(checkbox);
    listItem.appendChild(textDiv);

    return listItem;
}

/**
 * Generates the interface to allow bulk ownership change
 * 
 * @param {Boolean} expandForm when true, the owner selection form would be expanded
 */
const generateChangeOwnershipInterface = (expandForm) => {
    isChangeOwnershipInterfaceActive = true;

    // Modify the change ownership buttom into a cancel button
    changeButton.className = 'btn btn-danger';
    changeButton.innerText = 'Cancel Ownership Changes';

    // Hide add data profile button
    document.querySelectorAll('a.btn.btn-primary')[0].style.display = 'none';

    // Update selected count
    currentList = JSON.parse(localStorage.getItem(localStorageKeyName));
    document.getElementById(packageCounterElementId)
        .innerText = `${currentList ? currentList.length : 0} selected`;
    
    // expand form when the user arrives from another page and has data in the 
    // local storage
    if (expandForm) {
        document.getElementById('bulk-change-group-ownership-collapsible')
            .classList.add('in')
    }

    // Generate the checkboxes
    document
    .querySelectorAll(itemsQuerySelector)
    .forEach( item => {
        const groupName = item.dataset['groupid'];
        const currentOwner = item.dataset['currentowner'];


        // Modify the element styles
        let listItem = item.parentElement;
        $(listItem).attr("tabindex", "-1")
        listItem.children[0].setAttribute('tabindex', '0')
        listItem.style.display = 'flex';
        listItem.style.flexDirection = 'row';
        listItem.style.gap = '16px';
        item.style.width = '100%';

        // Show the current owner
        const ownerText = item.getElementsByClassName(itemsownerTextSelector)[0];
        ownerText.innerHTML = `<span>Current Owner: ${currentOwner}</span>`

        // Insert checkboxes
        const checkbox = checkboxElement(groupName, item.dataset['title'], '24px');
        listItem.insertBefore(checkbox, listItem.firstChild);
    })

    if (['category', 'group', 'topic'].includes(changeButton.dataset['grouptype'])) {
        // Remove wrapping anchor links in categories
        document.querySelectorAll('a.custom44.media-view').forEach(item => {
            item.remove();
        })
    }

    // Insert master checkbox
    const ulElement = document.querySelector(itemsUlElementSelector);
    const masterCheckbox  = masterCheckboxListItem('24px');
    ulElement.insertBefore(
        masterCheckbox, ulElement.firstChild
    )
    controlMasterCheckboxState();

}

/**
 * Clear out the cange ownership interface
 * @param {String} url url te redirect the page after clearing the interface
 */
const cancelOwnershipChanges = url => {
    document.getElementById(changeAndCancelButtonId).remove();
    localStorage.removeItem(localStorageKeyName);
    localStorage.removeItem(localStorageTypeKeyName);
    isChangeOwnershipInterfaceActive = false;
    if (url) document.location.href = url
}

/**
 * Submits the selected groups to the backend to have their owners changed
 *
 * @returns {void}
 */
const handleSubmitChangeOwners = (e) => {

    const finalList = JSON.parse(localStorage.getItem(localStorageKeyName));
    if (finalList.length) {
        const selectedGroupsInputField = document.getElementById('selected_bulk_change_groups')
        for (let i=0;i<finalList.length;i++) {
            selectedGroupsInputField.value += i + 1 == finalList.length ? finalList[i] : `${finalList[i]},`;
        }
        cancelOwnershipChanges(undefined);
    } else {
        e.preventDefault()
        document.getElementById(errorMessageElementId)
            .innerText = `No ${localStorage.getItem(localStorageTypeKeyName)} has been selected`;
        return
    }
}

/**
 * Generates the list of organizations for each user
 * 
 * @param {Array} userOrgs array of the org details for the user
 * @param {Boolean} showFull if true all the user organizations will be shown
 *  else only 10 would be shown
 */
const generateListOfUserOrgs = (userOrgs, showFull) => {
    let adminOrgsText = "<em><b>Organizations:</b></em>";
    for (let i=0; i<userOrgs.length;i++) {
        if (!showFull && i == 9 && userOrgs.length > 10) {
            adminOrgsText += ` ${userOrgs[i]['title']}`;
            adminOrgsText += ` ... <em><b><a href="#" id="toggleShowFullOrganizations" data-full="false">and ${userOrgs.length - 10} more.</a></b></em>`;
            break;
        } else if (showFull && i == userOrgs.length - 1) {
            adminOrgsText += ` ${userOrgs[i]['title']}`;
            adminOrgsText += `  <em><b><a href="#" id="toggleShowFullOrganizations" data-full="true">Show Less</a></b></em>`;
            break;
        } else if (i == userOrgs.length - 1) {
            adminOrgsText += ` ${userOrgs[i]['title']}.`;
        } else {
            adminOrgsText += ` ${userOrgs[i]['title']},`;
        }
    }
    document.getElementById('field-old-admin-orgs-text').innerHTML = adminOrgsText;

    // Onclick function to toggle showing all organizations or just 10
    let toggleShowFullAnchor = document.getElementById('toggleShowFullOrganizations');
    // If statement to avoid errors when the toggleShowFullOrganizations is not rendered
    if (toggleShowFullAnchor) {
        toggleShowFullAnchor.onclick = e => {
            const anchorToggle = e.target;
            if (anchorToggle.dataset['full'] == 'false') {
                generateListOfUserOrgs(userOrgs, true);
            } else {
                generateListOfUserOrgs(userOrgs, false);
            }
        }
    }
}

// Run when the page is loaded
$(() => {

    $("#bulk-change-group-ownership-btn").on("keydown", function(e) {
        // check if enter key is pressed
        if (e.keyCode == 13) {
            e.preventDefault();
            $(this).click();
        }
    });

    // For organization bulk change alone
    if ('organization' === changeButton?.dataset['grouptype']) {

        // Change the update button to a cancel button and back when the user clicks it
        changeButton.onclick = e => {
            if (changeButton.getAttribute('aria-expanded') == 'false') {
                changeButton.innerText = 'Cancel';
                changeButton.style.backgroundColor = '#d9534f';
            } else if (changeButton.getAttribute('aria-expanded') == 'true') {
                changeButton.innerText = 'Update Admin';
                changeButton.style.backgroundColor = '#2378c3';
            } else {
                changeButton.innerText = 'Cancel';
                changeButton.style.backgroundColor = '#d9534f';
            }
        }

        // Get the strigified object of admins and their organizations from the 
        // data-adminorgs value
        const oldAdminSelect = document.getElementById('field-old-admin');
        // Get the user's and organizations object from the element data
        const adminOrgs = JSON.parse(oldAdminSelect.dataset['adminorgs']);
        oldAdminSelect.onchange = e => {
            let userOrgs = adminOrgs[e.target.value];
            generateListOfUserOrgs(userOrgs, false);
        }

        // Remove the admin replace interface when submit button is clicked
        $('#bulk-replace-admin-submit-btn').click( e => {

            // check that old admin field is not empty
            if (document.getElementById('field-old-admin').value == '') {
                document.getElementById('field-old-admin-error').innerText = 'You must select an admin to remove';
                e.preventDefault();
                return
            }
            changeButton.click()
            changeButton.style.display = 'none';
        })

        return
    }

    // Generate the interface if there is existing data
    if (isChangeOwnershipInterfaceActive) {
        generateChangeOwnershipInterface(true);
    }

    $(`#${changeAndCancelButtonId}`).click(e => {
        localStorage.setItem(localStorageKeyName, JSON.stringify([]));
        localStorage.setItem(localStorageTypeKeyName, changeButton.dataset['grouptype']);

        isChangeOwnershipInterfaceActive
            ? cancelOwnershipChanges(pageURL)
            : generateChangeOwnershipInterface();
    })

    $('#bulk-change-group-ownership-form').submit(e => {
        handleSubmitChangeOwners(e);
    })
})