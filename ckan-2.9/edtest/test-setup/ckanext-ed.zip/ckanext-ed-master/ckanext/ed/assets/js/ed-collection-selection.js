/**
 * Add a list item to the select2 dummy display
 * 
 * @param {string[]} text The text to be displayed in the list item
 * 
 * @returns nothing
 */
const addSelectListItems = (text) => {
  let ulElement = document.createElement('ul');
  for (var i=0; i<text.length; i++) {
    // construct text div
    let divElement = document.createElement('div');
    divElement.innerText = text[i];
    // construct list item
    let listItem = document.createElement('li');
    listItem.classList.add('select2-search-choice');
    listItem.style.padding = '5px 8px';
    listItem.appendChild(divElement);

    ulElement.appendChild(listItem);
  }

  document.getElementById('field-collections-select2-list')
    .innerHTML = ulElement.innerHTML;
}

/**
 * Launches the collection modal
 * 
 * Returns nothing
 */
const launchCollectionSelectionModal = () =>   {
  // clear the search input field when the modal is launched
  $('#filter-collections-option-list').val('');
  populateModalSelectOptions();

  $('#field-collection-modal').modal();
}

/**
 * Gets the options in the selected column and sets them to selected in the
 * collection select form element
 * 
 * Returns nothing
 */
const getAllSelectedCollections = () => {
  const selectedColumn = document.getElementById('field-collection-selected-column');

  let selectedList = [];
  let selectedListText = [];

  for (let i = 0; i < selectedColumn.options.length; i++) {
    selectedList.push(selectedColumn.options[i].value);
    selectedListText.push(selectedColumn.options[i].text);
  }

  $('#field-collections').val(selectedList);
  // trigger a change so that select2 can detect the update
  $('#field-collections').trigger('change');
  addSelectListItems(selectedListText);

  closeCollectionModal();
}

/**
 * Populates the collection selection modal.
 * 
 * Puts selected fields in the selected column and unselected in the
 * unselected column.
 * 
 * Returns nothing
 */
const populateModalSelectOptions = () => {
  
  // Get the HTMLSelectElement objects 
  const selectField = document.getElementById('field-collections');
  const selectedColumn = document.getElementById('field-collection-selected-column');
  const unselectedColumn = document.getElementById('field-collection-unselected-column');

  // clear the select elements before adding new ones
  clearModalCollectionSelections();

  for (let i = 0; i < selectField.options.length; i++) {
    if (selectField.options[i].selected) {
      // new HTMLOptionElements are created to prevent the add method from
      // moving the existing object out of the selectField
      let option = new Option(
        selectField.options[i].text,
        selectField.options[i].value, false, false)

      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', 'false');
      option.setAttribute('id', `ms_opt${i}`);
      // option.setAttribute('tabindex', '0');
      selectedColumn.add(option);
    } else {
      let option = new Option(
        selectField.options[i].text,
        selectField.options[i].value, false, false)

      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', 'false');
      option.setAttribute('id', i);
      // option.setAttribute('tabindex', '0');
      unselectedColumn.add(option);
    }
  }
}

/**
 * Clears the options in the select elements
 * 
 * Returns nothing
 */
const clearModalCollectionSelections = () => {
  $('#field-collection-selected-column').find('option').remove();
  $('#field-collection-unselected-column').find('option').remove();
}

/**
 * Closes the modal
 * 
 * Returns nothing
 */
const closeCollectionModal = () => {
  $('#field-collection-modal').modal('hide');
}

/**
 * Accessibility function to announce the number of items added or removed to collections
 * @param {*} event 
 * @param {*} items 
 */
function voiceOutOnAddandRemove(event, items) {
  var updateText = '';
  var itemText = items.length === 1 ? '1 collection' : items.length + ' collections';

  switch (event) {
    case 'added':
      updateText = 'Added ' + itemText + ' to selected collections list.';
      break;
    case 'removed':
      updateText = 'Removed ' + itemText + ' from selected collections list.';
      break;
  }

  if (updateText) {
    var ex1LiveRegion = document.getElementById('ms_live_region');
    ex1LiveRegion.innerText = updateText;
  }
}

/**
 * Move Options from the column for all collections to the column for selected
 * collections.
 * 
 * Returns nothing
 */
const moveUnselectedToSelectedColumn = () => {
  const selectedColumn = document.getElementById('field-collection-selected-column');
  const unselectedColumn = document.getElementById('field-collection-unselected-column');

  let selectedOptions = unselectedColumn.selectedOptions;
  let optionDetails = [];

  selectedOptions.forEach(option => {
    optionDetails.push({
      optionObject: option
    });
  });
  for (i=0; i<optionDetails.length;i++) {
    optionDetails[i].optionObject.selected = false;
    selectedColumn.add(optionDetails[i].optionObject);
  }
  voiceOutOnAddandRemove('added', optionDetails);
}

$("#toright").keypress(function(e) {
  //check if enter key is pressed
  e.preventDefault()
  if (e.key === 'Enter') {
    moveUnselectedToSelectedColumn();
  }
});

$("#toright").on("click", function(e) {
  //check if enter key is pressed
  e.preventDefault()
  moveUnselectedToSelectedColumn();
});

$('#field-collection-unselected-column').keypress(function(e) {
  if (e.shiftKey && e.key === 'Enter') {
    if($('#field-collection-unselected-column').val().length >0) {
      //check if shift+enter key is pressed
      moveUnselectedToSelectedColumn();
    }
  }

  if(e.key === 'Enter') {
    if($('#field-collection-unselected-column').val().length >0) {
      //check if enter key is pressed
      moveUnselectedToSelectedColumn();
    }
  }
});

/**
 * Move Options from the column for selected collections to the column for all
 * unselected collections.
 * 
 * Returns nothing
 */
const moveSelectedToUnselectedColumn = () => {
  const selectedColumn = document.getElementById('field-collection-selected-column');
  const unselectedColumn = document.getElementById('field-collection-unselected-column');

  let selectedOptions = selectedColumn.selectedOptions;
  let optionDetails = [];

  selectedOptions.forEach(option => {
    optionDetails.push({
      optionObject: option
    });
  });
  for (i=0; i<optionDetails.length;i++) {
    optionDetails[i].optionObject.selected = false;
    unselectedColumn.add(optionDetails[i].optionObject);
  }
  voiceOutOnAddandRemove('removed', optionDetails);
}

$("#toleft").keypress(function(e) {
  //check if enter key is pressed
  e.preventDefault()
  if (e.key === 'Enter') {
    //check if value are selected in field-collection-unselected-column 
    moveSelectedToUnselectedColumn();
  }
});

$("#toleft").on("click", function(e) {
  //check if enter key is pressed
  e.preventDefault()
  moveSelectedToUnselectedColumn();
});


$('#field-collection-selected-column').keydown(function(e) {
  if (e.shiftKey && (e.key === 'Backspace' || e.key === 'Delete')) {
    if($('#field-collection-selected-column').val().length >0) {
      //check if shift+delete key is pressed
        moveSelectedToUnselectedColumn();
      }
  }
})


/**
 * Filter displayed options based on the value in the search box
 *
 * Returns nothing
 */
const filterCollectionsOptionsList = (e) => {
  let inputValue = e.value;
  
  if (inputValue.length == 0) {
    $('#field-collection-unselected-column').find('option:hidden').show();
  } else {
    $('#field-collection-unselected-column').find('option')
      .each((i, element) => {
        if (element.text.includes(inputValue)) {
          $(element).show();
        } else {
          $(element).hide();
        }
      });
  }
}

// Event listener for changes to collection search box
$('#filter-collections-option-list').on('change keyup paste', (event) => {
  filterCollectionsOptionsList(event.target);
})

// populate the select2 dummy display
$(document).ready(() => {
  let selectedList = [];
  $('#field-collections').find('option:selected').each((i, e) => {
    selectedList.push(e.text);
  });
  addSelectListItems(selectedList);
});
