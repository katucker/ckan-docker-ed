this.ckan.module('ed_descrp_popover', ($) => {
  return {
    initialize: function () {
      //data storage
      const metadatas = {
        description: 'Human-readable description (e.g., an abstract) with sufficient detail to enable a user to quickly understand whether the asset is of interest.',
        title: 'Human-readable name of the asset. Should be in plain English and include sufficient detail to facilitate search and discovery.',
        tags: 'Tags (or keywords) help users discover your dataset; please include terms that would be used by technical and non-technical users.',
        lastupdate: 'Most recent date on which the dataset was changed, updated or modified.',
        publisher: 'The publishing entity and optionally their parent organization(s).',
        contactperson: 'Contact person’s name and email for the asset.',
        identifier: 'A unique identifier for the dataset or API as maintained within an Agency catalog or database.',
        accessLevel: 'The degree to which this dataset could be made publicly-available, regardless of whether it has been made available. Choices: public (Data asset is or could be made publicly available to all without restrictions), restricted public (Data asset is available under certain use restrictions), or non-public (Data asset is not available to members of the public).',
        bureaucode: 'Federal agencies, combined agency and bureau code from OMB Circular A-11, Appendix C; in the format of 015:11.',
        programcode: 'Federal agencies, list the primary program related to this data asset, from the Federal Program Inventory. Use the format of 015:001.',
        rights: 'This may include information regarding access or restrictions based on privacy, security, or other policies. This should also serve as an explanation for the selected “accessLevel” including instructions for how to access a restricted file, if applicable, or explanation for why a “non-public” or “restricted public” data asset is not “public,” if applicable. Text, 255 characters.',
        accessurl: 'URL providing indirect access to a dataset, for example via API or a graphical interface.',
        downloadurl: 'URL providing direct access to a downloadable file of a dataset.',
        format: 'A human-readable description of the file format of a distribution.',
        resourcetitle: 'Human-readable name of the distribution.'

      }

      //options
      const field = this.options.field;
      const fieldType = this.options.type || ''
      const content = `
        ${metadatas[field]} 
        <br />
        ${fieldType ? '<strong>Required</strong>: Applicable, if adding a resource' : '<strong>Required</strong>: Always' }
        
      `
      
      this.el.popover({title: "DCAT Schema",
        content: content,
        html: true,
        placement: 'right',
        trigger : 'hover'});
    }
  }
})