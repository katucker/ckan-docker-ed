// Main Javascript file for  ed portal

//Adding scrollspy to the pages like about
$('body').scrollspy({ target: '#spy', offset:280});

//Calculate the position of scroll for
$(window).on('load',function(){
    calcScrollLocation();
});

$(window).scroll(function() {    
    calcScrollLocation();
}); 

function calcSidebarHeight(){
    var height = $(".module-content").outerHeight();
    $(".sidebar").height(height);
};

function calcScrollLocation(){
    var scroll = $(window).scrollTop();
}

$('a.feedback_mail').on('click', function(){
    window.location.href = "mailto:odpfeedback@ed.gov";
});

$(document).ready(function(){

    //Checks the page name via page tag
    var page = $('body').find('.page-home').text();

    /* Particles js for homepage */
    if(page=="home"){
        renderParticles();
    }


    //Showing scrollbar on specific page for devices larger than 768px
    if(page=="search" || page=="publisher_listing"){
        if ($(window).width() >= 768) {
            new SimpleBar($('#scrollbar')[0]);
        }

        $("p.module-content.empty").attr("tabindex","0");
    }

    if(page=="dataset"){
        //Changing navicons programatiically 
        $(".view_list").html("view_list").removeClass("fa fa-");
        $(".info").html("info");
        $(".add_comment").html("add_comment").removeClass("fa fa-");
        $(".bar_chart").html("bar_chart").removeClass("fa fa-");
        $(".supervisor_account").html("supervisor_account").removeClass("fa fa-");
        $(".manage_accounts").html("manage_accounts").removeClass("fa fa-");
    }


    //Subpage 
    var subpage = $('body').find('.page-name-sub').text();

    if(subpage=="data"){
        $(".nav-tabs > li:first-child").addClass("active");
    }

    var navHeight = $("#nav-wrapper").outerHeight();
    $("body").css("paddingTop",navHeight);


    /* Tab fixes */
    $('a[data-module="api-info"]').click(function(event) {
        restrictTab();
    });

    $("body").on('click','button[data-dismiss="modal"]', function(event){
        continueTab();
    })
}); 

//Escape button for modal close - Tab fixes
$(document).on( 'keydown', function ( e ) {
    if ( e.keyCode === 27 ) { // ESC
        continueTab();
    }
});

//Backdrop click for modal close - Tab fixes
$(document).click(function (e) {
    if (e.target === $('.modal')[0] && $('body').hasClass('modal-open')) {
        continueTab();
    }
});


//Restricting tab to circle inside modal
function restrictTab(){
    $('a').attr("tabindex","-1");
    $('input').attr("tabindex","-1");
    $('button').attr("tabindex","-1");

    $('.modal a').attr("tabindex","1");
    $('.modal input').attr("tabindex","-1");
    $('.modal button').attr("tabindex","1");
}

function continueTab(){
    $('a').attr("tabindex","1");
    $('button').attr("tabindex","1");
    $('input').attr("tabindex","1");

    $('.modal').modal('hide');
}

//Using Particles.js for homepage
function renderParticles(){
    particlesJS("hero", {
        "particles": {
            "number": {
                "value":20, "density": {
                    "enable": true, "value_area": 1000
                }
            }
            , "color": {
                "value": ["#3da650", "#0372e4"]
            }
            , "shape": {
                "type":"edge", "stroke": {
                    "width": 0, "color": "#000000"
                }
                , "polygon": {
                    "nb_sides": 10
                }
                , "image": {
                    "src": "img/github.svg", "width": 100, "height": 100
                }
            }
            , "opacity": {
                "value":1, "random":false, "anim": {
                    "enable": false, "speed": 1, "opacity_min": 0, "sync": false
                }
            }
            , "size": {
                "value":5.5, "random":true, "anim": {
                    "enable": false, "speed": 4, "size_min": 3.5, "sync": false
                }
            }
            , "line_linked": {
                "enable": false, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1
            }
            , "move": {
                "enable":true, "speed":1, "direction":"none", "random":true, "straight":false, "out_mode":"out", "bounce":false, "attract": {
                    "enable": false, "rotateX": 600, "rotateY": 600
                }
            }
        }
        , "interactivity": {
            "detect_on":"canvas", "events": {
                "onhover": {
                    "enable": false, "mode": "bubble"
                }
                , "onclick": {
                    "enable": false, "mode": "repulse"
                }
                , "resize":true
            }
            , "modes": {
                "grab": {
                    "distance":400, "line_linked": {
                        "opacity": 1
                    }
                }
                , "bubble": {
                    "distance": 85.26810729164123, "size": 0, "duration": 2, "opacity": 0, "speed": 3
                }
                , "repulse": {
                    "distance": 400, "duration": 0.4
                }
                , "push": {
                    "particles_nb": 4
                }
                , "remove": {
                    "particles_nb": 2
                }
            }
        }
        , "retina_detect":true
    });

    //Calculating the canvas height to ensure particles take up full space
    function calcCanvasHeight(){
        setTimeout(function() { 
            $(".hero > canvas").height("400px");
            $(".hero > canvas").attr("height",400);
         },1);
    }
    

}

//User Create Validation
$(document).ready(function(){
    var isValid = false;

    var isUsername = false;
    $("#field-username-new").after("<p id='field-username-new-err' class='form-err hidden'>Error: Username is invalid. Usernames must be distinct and contain only lowercase letters, numbers, - (dash) and _ (underscore).</p>");

    var isEmail = false;
    $("#field-email-new").after("<p id='field-email-new-err' class='form-err hidden'>Error: Invalid email format.  </p>");

    $("#user-register-form").submit(function(event){
        var username=$("#field-username-new").val();

        if (username.length > 0 && username.search(/^[a-z0-9-_]+$/) === 0) {
            isUsername = true;
            $("#field-username-new-err").addClass('hidden');
        }
        else{
            isUsername = false;
            $("#field-username-new-err").removeClass('hidden');
        }

        var email=$("#field-email-new").val();
        // Regex from https://html.spec.whatwg.org/#email-state-(type=email)
        const emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

        if (email.length > 0 && email.search() === 0) {
            isEmail = true;
            $("#field-email-new-err").addClass('hidden');
        }
        else {
            isEmail = false;
            $("#field-email-new-err").removeClass('hidden');
        }

        //Validate Final
        if (isEmail == true && isUsername == true) {
            isValid = true;
        }

        //Final Submission
        if (isValid==false) {
            event.preventDefault();

            setTimeout(function(){ 
                $("button[name='save']").removeAttr("disabled");
                $("button[name='save']").attr("enabled","enabled");
            }) 
        }
    })
})

//  Form validation util functions
const createErrorEl = (afterEl, id, message) => {
    const field = $(`${afterEl}`);
    field.after(`<p id='${id}' class='form-err hidden' style='padding-top: 0'>Error: ${message}.  </p>`);
    return $('#' + id);
}

//  Form Image Validation
$(document).ready(function(){
    const userEditFormExists = $('#user-edit-form').length && location.href.includes('user');
    const dataExplorerEditFormExists = $('#group-edit').length && location.href.includes('data_explorer');

    //  Execute only on these forms
    if(!(userEditFormExists || dataExplorerEditFormExists)) {
        return;
    }

    //  Fields and errors elements
    const imageFileField = $('#field-image-upload');
    const imageFileError = createErrorEl('#field-image-upload', 'image-upload-err', 'Chosen file is not an image');

    //  Validate image, clear input and display errors
    const validateImage = () => {
        const files = imageFileField.prop('files');

        //  If there are no files, proceed
        if(!files)
            return true;

        const file = files[0];

        if (!file.type.includes('image')) {
            imageFileError.removeClass('hidden');
            setTimeout(() => $('.input-url-remove').click(), 1000)
            return false
        }

        $("#field-image-new-err").addClass('hidden');
        return true
    }

    //  Validate file on change
    imageFileField.change((e) => {
        validateImage();
    })

})

//Dataset Validation
$(document).ready(function(){

    $("#dataset-edit").submit(function(event){
    
        // Form valid flag
        var isValid = false;

        var isDesc = false;
        $(".editor-info-block").after("<p id='field-notes-err' class='form-err hidden' role='alert'>Error: Description cannot be empty.</p>");

        var isName = false;
        $("#field-name").parent().after("<p id='field-name-err' class='form-err hidden' role='alert'>Error: URL Name cannot be empty.</p>");

        var isOrg = false;
        $("#field-organizations").after("<p id='field-organizations-err' class='form-err hidden' role='alert'>Error: Select Publisher.</p>");

        var isSingleParent = false;
        $("#field-relationship-parent").after("<p id='field-relationship-single-parent-err' class='form-err hidden' role='alert'>Error: Only one parent is allowed.</p>");

        var isNotParentOfNewParent = false;
        $("#field-relationship-parent").after("<p id='field-relationship-parallel-parent-err' class='form-err hidden' role='alert'>Error: The parent you selected is already a child of this Data Profile.</p>");

        var isNotSelfParent = false;
        $("#field-relationship-parent").after("<p id='field-relationship-self-parent-err' class='form-err hidden' role='alert'>Error: You can't set a Data Profile as its own parent.</p>");

        var isParentExists = false;
        $("#field-relationship-parent").after("<p id='field-relationship-parent-exists-err' class='form-err hidden' role='alert'>Error: Parent Data Profile doesn't exist.</p>");

        var isLicense = false;
        $("#field-license").after("<p id='field-license-err' class='form-err hidden' role='alert'>Error: Enter license.</p>");

        var isRights = false;
        $("#rights").after("<p id='rights-err' class='form-err hidden' role='alert'></p>");

        var isAllResourcesUrl = false;
        $("#field-url").after("<p id='field-url-err' class='form-err hidden' role='alert'>Error: Missing protocol (\"http://\" or \"https://\").</p>");

        var isSystemOfRecordsURL = false;
        $("#field-system-of-records").after("<p id='field-system-of-records-err' class='form-err hidden' role='alert'>Error: Missing protocol (\"http://\" or \"https://\").</p>");

        var isUii = false;
        $("#field-primary-it-investment-uii").after("<p id='field-primary-it-investment-uii-err' class='form-err hidden' role='alert'>Error: Invalid format. Must be agency code (3 digits), hyphen, and unique identifier (9 digits). </br>Example: 012-123456789.</p>");

        var isDependSelf = false;
        $("#field-relationship-dependency-of").after("<p id='field-relationship-dependency-of-err' class='form-err hidden' role='alert'>Error: You can't set a Data Profile as a dependency of itself.</p>");

        var isDeriveSelf = false;
        $("#field-relationship-derives-from").after("<p id='field-relationship-derives-from-err' class='form-err hidden' role='alert'>Error: You can't set a Data Profile as derived from itself.</p>");

        var currentProfileName=document.getElementsByClassName('slug-preview-value')[0].textContent;

        if (currentProfileName == '<data profile>') {
            isName = false;
            $("#field-name-err").removeClass('hidden');
        } else {
            isName = true;
            $("#field-name-err").addClass('hidden');
        }

        //Validate Description
        var description=$("#field-notes").val().replace(/^\s+|\s+$/g, "").length != 0;
        if(description){
            isDesc = true;
            $("#field-notes-err").addClass('hidden');
        }
        else{
            isDesc = false;
            $("#field-notes-err").removeClass('hidden');
        }
       

        // Validate Owner Org
        var ownerOrg=$("#field-organizations").val();
        if(ownerOrg){
            isOrg = true;
            $("#field-organizations-err").addClass('hidden');
        }
        else{
            isOrg = false;
            $("#field-organizations-err").removeClass('hidden');
        }

        // Validate Single Parent
        var relationshipParent=$("#field-relationship-parent").val().split(',');

        if(relationshipParent && relationshipParent.length < 2){
            isSingleParent = true;
            $("#field-relationship-single-parent-err").addClass('hidden');

            var parentName = relationshipParent[0];

            if(parentName !== currentProfileName){
                isNotSelfParent = true;
                $("#field-relationship-self-parent-err").addClass('hidden');
            }
            else{
                isNotSelfParent = false;
                $("#field-relationship-self-parent-err").removeClass('hidden');
            }

            function isChild(currentProfileName) {
                const response = $.ajax({
                    async: false,
                    url: window.location.origin + `/api/action/package_relationships_list`,
                    data: {'id': `${currentProfileName}`},
                    type: "GET",
                    error: function (e) {
                        console.dir(e);
                    }
                });
                return response.responseJSON;
            }

            var relationship = isChild(currentProfileName).result;
            var parentRelationship = null;

            if (relationship){
                parentRelationship = relationship.find(el => el.type == 'parent_of' && el.object == parentName);
            }

            if(!parentRelationship){
                isNotParentOfNewParent = true;
                $("#field-relationship-parallel-parent-err").addClass('hidden');
            }
            else{
                isNotParentOfNewParent = false;
                $("#field-relationship-parallel-parent-err").removeClass('hidden');
            }

            function notProfile(parentName) {
                const response = $.ajax({
                    async: false,
                    url: window.location.origin + `/api/action/package_show`,
                    data: {'id': `${parentName}`},
                    type: "GET",
                    error: function (e) {
                        console.dir(e);
                    }
                });
                return response.responseJSON.success;
            }

            const parentExists = notProfile(parentName);

            if(parentExists || !parentName){
                isParentExists = true;
                $("#field-relationship-parent-exists-err").addClass('hidden');
            }
            else{
                isParentExists = false;
                $("#field-relationship-parent-exists-err").removeClass('hidden');
            }

        }
        else{
            isSingleParent = false;
            $("#field-relationship-single-parent-err").removeClass('hidden');
        }

        // Validate Rights field
        var rightsField = $("#rights").val();
        if (!['restricted-public', 'non-public'].includes($('#access_level').val())) {
            isRights = true;
            $("#rights-err").addClass('hidden');
            // Empty the rights field if access level is public
            $("input#rights").prop('disabled', false);
            $("input#rights").val('').trigger('change');
        } else {
            if (rightsField.length < 1) {
                isRights = false;
                $("#rights-err").text('Error: The rights field cannot be empty when the access level is set to either restricted-public or non-public')
                $("#rights-err").removeClass('hidden');
            } else if (rightsField.length > 255) {
                isRights = false;
                $("#rights-err").text('Error: The rights field cannot have more than 255 characters.')
                $("#rights-err").removeClass('hidden');
            } else {
                isRights = true;
                $("#rights-err").addClass('hidden');
            }
        }

        var licenseField = $("#field-license").val();
        if ($('#access_level').val() === "public") {
            if (licenseField.length > 0) {
                isLicense = true;
                $("#field-license-err").addClass('hidden');
            }
            else {
                isLicense = false;
                $("#field-license-err").removeClass('hidden');
            }
            
        } 
        else {
            isLicense = true;
            $("#field-license-err").addClass('hidden');
        }

        // Validate URL of page containing all Resources
        var allResourcesUrl=$("#field-url").val();

        if(allResourcesUrl.length == 0 || allResourcesUrl.includes('http://') || allResourcesUrl.includes('https://')){
            isAllResourcesUrl = true;
            $("#field-url-err").addClass('hidden');
        }
        else{
            isAllResourcesUrl = false;
            $("#field-url-err").removeClass('hidden');
        }

        // Validate System of Records URL
        var systemOfRecords=$("#field-system-of-records").val();

        if(systemOfRecords.length == 0 || systemOfRecords.includes('http://') || systemOfRecords.includes('https://')){
            isSystemOfRecordsURL = true;
            $("#field-system-of-records-err").addClass('hidden');
        }
        else{
            isSystemOfRecordsURL = false;
            $("#field-system-of-records-err").removeClass('hidden');
        }

        // Validate Primary IT UII
        var primaryITInvestmentUII=$("#field-primary-it-investment-uii").val();
        let re = new RegExp('[0-9]{3}[-][0-9]{9}$')

        if(primaryITInvestmentUII.length == 0 || re.test(primaryITInvestmentUII)){
            isUii = true;
            $("#field-primary-it-investment-uii-err").addClass('hidden');
        }
        else{
            isUii = false;
            $("#field-primary-it-investment-uii-err").removeClass('hidden');
        }

        // Validate Dependencies
        var dependenciesOf=$("#field-relationship-dependency-of").val();
        dependenciesOf=dependenciesOf.split(',')
        
        if(!dependenciesOf.includes(currentProfileName)){
            isDependSelf = true;
            $("#field-relationship-dependency-of-err").addClass('hidden');
        }
        else{
            isDependSelf = false;
            $("#field-relationship-dependency-of-err").removeClass('hidden');
        }

        // Validate Derivations
        var derivesFrom=$("#field-relationship-derives-from").val();
        derivesFrom=derivesFrom.split(',')
        
        if(!derivesFrom.includes(currentProfileName)){
            isDeriveSelf = true;
            $("#field-relationship-derives-from-err").addClass('hidden');
        }
        else{
            isDeriveSelf = false;
            $("#field-relationship-derives-from-err").removeClass('hidden');
        }

        //Validate Final
        if(isDesc == true && isOrg == true && isSingleParent == true && isNotParentOfNewParent == true && isNotSelfParent == true && isParentExists == true && isAllResourcesUrl  == true && isSystemOfRecordsURL == true && isUii == true && isDependSelf == true && isDeriveSelf == true && isRights == true
            && isLicense == true && isName == true){
            isValid = true;
        }

        //Final Submission
        if(isValid==false){
            event.preventDefault();

            setTimeout(function(){ 
                $("button[name='save']").removeAttr("disabled");
                $("button[name='save']").attr("enabled","enabled");

                if(isOrg == false){
                    $("#field-organizations").focus();
                }

                if(isDesc == false){
                    $("#field-notes").focus();
                }

                if(isSingleParent == false){
                    $("#field-relationship-parent").show();
                    $("#field-relationship-parent").focus();
                    $("#field-relationship-parent").hide();
                }

                if(isNotParentOfNewParent == false){
                    $("#field-relationship-parent").show();
                    $("#field-relationship-parent").focus();
                    $("#field-relationship-parent").hide();
                }

                if(isNotSelfParent == false){
                    $("#field-relationship-parent").show();
                    $("#field-relationship-parent").focus();
                    $("#field-relationship-parent").hide();
                }

                if(isParentExists == false){
                    $("#field-relationship-parent").show();
                    $("#field-relationship-parent").focus();
                    $("#field-relationship-parent").hide();
                }

                if (isLicense = false) {
                    $("label[for='field-license']").get(0).scrollIntoView({behavior: 'smooth', block: 'center'});
                }
                if(isRights == false){
                    $("label[for='rights']").get(0).scrollIntoView({behavior: 'smooth', block: 'center'});
                }
                // The rights field is enabled to remove the data within the rights field if it is public on submit
                // In a case where there is an error and the submit doesn't succeed, disable the rights field
                if (!['restricted-public', 'non-public'].includes($('#access_level').val())) {
                    $("input#rights").prop('disabled', true);
                }

                if(isAllResourcesUrl == false){
                    $("#field-url").show();
                    $("#field-url").focus();
                }

                if(isSystemOfRecordsURL == false){
                    $("#field-system-of-records").show();
                    $("#field-system-of-records").focus();
                }

                if(isUii == false){
                    $("#field-primary-it-investment-uii").show();
                    $("#field-primary-it-investment-uii").focus();
                }

                if(isDependSelf == false){
                    $("#field-relationship-dependency-of").show();
                    $("#field-relationship-dependency-of").focus();
                    $("#field-relationship-dependency-of").hide();
                }

                if(isDeriveSelf == false){
                    $("#field-relationship-derives-from").show();
                    $("#field-relationship-derives-from").focus();
                    $("#field-relationship-derives-from").hide();
                }

                if(isName == false){
                    $("#field-name").focus();
                }

            }, 100);
        }
        
    })

    $('#organization-edit-form').submit(function(event){
        validateGroupURL(event);
    })

    $('#group-edit').submit(function(event){
        validateGroupURL(event);
    })

    //Tooltip
    $('[data-toggle="tooltip"]').tooltip();   

    //infopopup
    //$("#close-btn").click(function(event){
      //  $(".info-popup").hide()
    // })
});

function validateGroupURL(event) {
    $("#field-url").parent().after("<p id='field-url-err' class='form-err hidden' role='alert'>Error: URL Name cannot be empty.</p>");
    
    var isURL = false;
    var groupURL = $("#field-url").val();

    if(groupURL.length == 0){
        $("#field-url-err").removeClass('hidden');
        console.log('URL is empty');
    } else {
        isURL = true;
        $("#field-url-err").addClass('hidden');
    }

    if(isURL == false){
        event.preventDefault();

        setTimeout(function(){
            $("#field-url").focus();
        }, 100);
    }
}

function closeInfoBox(){
    days=3; 
    myDate = new Date();
    myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
    document.cookie = 'infoPopup=close; path=/; expires=' + myDate.toGMTString();

    document.getElementById("infoPopup").style.display = "none";
}

function dontOpenInfoPopup(){

    if (document.cookie.includes("infoPopup=close")) {

        document.getElementById('infoPopup').style.display = 'none';
    }
    else {
        document.getElementById('infoPopup').style.display = 'block';
    }
 }

 try{
   dontOpenInfoPopup();
 }catch(error){
   console.log(`Popup not displayed. Make sure the popup config variable is set correctly.`)
 }

// Survey functions

var results = {
  'package_id': '',
  'question_1': '',
  'question_2': '',
  'question_3': ''
};

function setPackageId(id){
  results.package_id = id;
}

function getAnswers(page){
  var selections = document.getElementsByName(`answer-p-${page}`);
  var selection;

  for(var i = 0; i < selections.length; i++){
    if(selections[i].checked){
      selection = selections[i].value;
    }
  }
  return selection;
}

function toggleElement(page, toggle=false){
  const el = document.getElementById(`${page}`);
  if(toggle){
    el.style.display = "block";
    el.ariaHidden = "false";
  }else{
    el.style.display = "none";
    el.ariaHidden = "true";
  }
}

function page1(){
  var selection = getAnswers('1');
  results.question_1 = selection;
  toggleElement('survey-page-1');

  if(selection == 'Yes'){
    toggleElement('survey-page-2', true);
    document.getElementsByName('answer-p-2')[0].focus();
  }else if(selection == 'No'){
    toggleElement('survey-page-4', true);
    toggleElement('survey-not-used', true);
    switchText();
    document.getElementById('survey-final-message').focus();
  }else{
    toggleElement('survey-page-1', true);
    toggleElement('survey-page-1-no-response', true);
    document.getElementById('survey-page-1-no-response').focus();
    return;
  }
}

function page2(){
  var selection = getAnswers('2');
  results.question_2 = selection;
  toggleElement('survey-page-2');

  if(selection == 'Yes'){
    toggleElement('survey-page-4', true);
    toggleElement('survey-used', true);
    switchText();
    document.getElementById('survey-final-message').focus();
  }else if(selection == 'No'){
    toggleElement('survey-page-3', true);
    document.getElementsByName('answer-p-3')[0].focus();
  }else{
    toggleElement('survey-page-2', true);
    toggleElement('survey-page-2-no-response', true);
    document.getElementById('survey-page-2-no-response').focus();
    return;
  }
}

function page3(){
  var selection = getAnswers('3');
  var comment = document.getElementById('comment').value;
  if(selection == 'Other:' && comment){
    selection = selection + ' ' + comment;
  }
  results.question_3 = selection;

  if(!selection){
    toggleElement('survey-page-3-no-response', true);
    document.getElementById('survey-page-3-no-response').focus();
    return;
  }
  toggleElement('survey-page-3');
  toggleElement('survey-page-4', true);
  toggleElement('survey-feedback', true);
  switchText();
  document.getElementById('survey-final-message').focus();
}

function page4(){
  toggleElement('survey-page-4');
}

function showSummary(isPublic, package_id){
  var summary;
  var getSummary = $.ajax({
    url: `/get_survey_summary/${package_id}`,
    type: 'GET',
    async: false,
    success: function (data){
      summary = JSON.parse(data);

      if (summary != null) {
        var totalTaken = summary.helpful + summary.not_helpful;
      } else {
        var totalTaken = 0;
      }

      if(totalTaken >= 3){
        var summaryText = `${totalTaken} people have used this data set and ${summary.percentage_helpful}% found it useful.`;

        if(isPublic){
          $('.survey-results').text(summaryText);
          toggleElement('survey-results', true);
        }else{
          $('.survey-results-non-public').text(summaryText);
          toggleElement('survey-results-non-public', true)
        }
      }else{
        console.log('Surveys taken is less than 3. Not displaying results.')
      }
    }
  });
}

function submitSurvey(){
  $.ajax({
    url: '/submit_survey',
    type: 'post',
    async: false,
    dataType: 'json',
    contentType: 'application/json',
    success: function (data){
      console.log(data.msg);
    },
    data: JSON.stringify(results)
  });
}

function switchText(){
  submitSurvey();
  showSummary(true, results.package_id);
  toggleElement('submitting');
  toggleElement('submit-button', true)
  toggleElement('survey-button');
}

$(document.getElementById('dependency-of-button')).click(function() {
  $('#dependency-of-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('dependency-button')).click(function() {
  $('#dependencies-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('dependency-tree-button')).click(function() {
  $('#dependency-tree-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('derivation-of-button')).click(function() {
  $('#derivation-of-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('derivations-button')).click(function() {
  $('#derivations-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('derivations-tree-button')).click(function() {
  $('#derivations-tree-icon').toggleClass('fa fa-minus fa fa-plus')
});

$(document.getElementById('hierarchy-button')).click(function() {
  $('#hierarchy-tree-icon').toggleClass('fa fa-minus fa fa-plus')
});


/* Multilevel Heirarchy */
var toggler = document.getElementsByClassName("caret");
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() {
    this.parentElement.querySelector(".nested").classList.toggle("active");
    this.classList.toggle("caret-down");
  });
}

$(".caret").click(function(){
    var left = $('.package-hierarchy').width();
    $('.package-hierarchy').scrollLeft(left);
})

/**
 * Scroll to the element whose id is referenced the URL hash fragment if any
 * @param {*} e Optional HTMLEvent
 */
const scrollToFragment = () => {
    if (document.location.hash) {
        const targetElement = document.getElementById(document.location.hash.split('#')[1]);
        if (targetElement) {
            const navbarOffset = document.getElementById('nav-wrapper').clientHeight + 20;
            const hashScrollY = targetElement.getBoundingClientRect().top + window.scrollY - navbarOffset;

            window.scrollTo({top: hashScrollY, behavior: 'smooth'});
        }
    }
}

$(document).ready(function(){

    $('.package-hierarchy').scrollLeft($(this).width());

    // Get all anchor tags with href starting with # and override the default
    // behaviour
    $('a[href^="#"]').click(e => {
        e.preventDefault();
        document.location.hash = e.target.hash;
        scrollToFragment();
    })
})

$(window).on('load', () => {
    // Scroll to the hashurl element after everything else on the page has 
    // been fully loaded.
    scrollToFragment();
})

$('#bulk-approval-checkbox').click(function () {
  if (this.checked) {
    $(':checkbox').each(function () {
      this.checked = true
    })
  } else {
    $(':checkbox').each(function () {
      this.checked = false
    })
  }
})

// User delete change ownership functions

$("#field-change-owner").click(function(){
    $('#owner-change-delete-error').hide()
})

var ownerChange = {
    new_owner: '',
    old_owner: ''
}

function toggleOwnershipElement(toggle=false){
    if(toggle){
      document.getElementById('ownership-popup').style.display = "block";
      document.getElementById('user-owner-backdrop').hidden=false;
    }else{
      document.getElementById('ownership-popup').style.display = "none";
      document.getElementById('user-owner-backdrop').hidden=true;
    }
}

function getNewOwner(userName=''){
    var newOwner = $('#field-change-owner :selected').val();
    var oldOwner = userName;
    ownerChange.new_owner = newOwner
    ownerChange.old_owner = oldOwner

    if (newOwner == '') {
        $('#owner-change-delete-error').show();
        event.preventDefault();
        return;
    }

    submitNewOwner(ownerChange)
  }

function submitNewOwner(ownerChange){
  event.preventDefault();
  $.ajax({
      url: '/user/change_owner_delete',
      type: 'post',
      dataType: 'json',
      contentType: 'application/json',
      success: function (e){
        window.location.href = `/user/change_owner_delete_success/${ownerChange.old_owner}`
      },
      error: function (error){
        console.log(error.responseJSON.error)
        window.location.href = `/user/change_owner_delete_failure/${error.responseJSON.error}`
      },
      data: JSON.stringify(ownerChange)
  });

  document.getElementById('user-delete-cancel').setAttribute('disabled', true);
  document.getElementById('user-delete-confirm').textContent = 'Submitting...';
  document.getElementById('user-delete-confirm').setAttribute('disabled', true);
  document.getElementById('user-delete-x').setAttribute('disabled', true);
  document.getElementById('field-change-owner').setAttribute('disabled', true);

}

$('#field-private-toggle.toggle-switch').click(function(e){
    $('#toggle-form').submit();
});

// $('#user-default-toggle.toggle-switch').click(function(e){
//     $('#default-form').submit();
// });

function toggleCoordinatorSpinner(){
    $('.coordinator-loader').show()
};

$('#field-relationship-parent').on('change', function(e) {
    var values = $(this).val().split(',');

    if (values.length == 1 && !values[0] == '') {
        $('#s2id_autogen4').attr('readonly', true);
    }
    else {
        $('#s2id_autogen4').attr('readonly', false);
    }
});

$('form#dataset-edit.bulk-form').submit(function(){
    $(this).find(':input[type=submit]').text('Submitting...')
    $(this).find(':input[type=submit]').prop('disabled', true);
});

function toggleHierarchySpinner(){
    $('.hierarchy-loader').show()
};

// Get 'hierarchy-open' by name on page load. Add a minimal html spinner to the element
$(document).ready(function(){
    var hierarchyOpen = document.getElementsByName('hierarchy-open')[0];
    //toggleHierarchySpinner();
    // retrieve the API call for /api/3/action/package_hierarchy_html?id=${dataset_id} where dataset_id is the dataset id is the last part of the url
    if (hierarchyOpen) {
        var dataset_id = window.location.pathname.split('/').pop();
        var url = `/api/3/action/package_hierarchy_html?id=${dataset_id}`;
        // make the API call
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                // if the API call is successful, replace the spinner with the returned html
                hierarchyOpen.innerHTML = data.result;
                /* Multilevel Heirarchy */
                var toggler = document.getElementsByClassName("caret");
                var i;
                for (i = 0; i < toggler.length; i++) {
                  toggler[i].addEventListener("click", function() {
                    this.parentElement.querySelector(".nested").classList.toggle("active");
                    this.classList.toggle("caret-down");
                  });
                }
            },
            error: function (error) {
                // if the API call is unsuccessful, replace the spinner with an error message
                hierarchyOpen.innerHTML = '';
            }
        });
    }
});

$(document).ready(function(){
    $("label").each(function(){
        if ($(this).text().includes("*")) {
            $(this).append(`<span class="offscreen" >Required</span>`);
        }
    });
    $("label span:contains('*')").each(function(){
        $(this).attr('aria-hidden', 'true');
    })
});

// 508: Add keyboard support for Data Profile form relationships section
$(document).ready(function(){
    $('#relationships-form-collapse-toggle').keypress(function(e){
        if(e.which == 13){
            if ($('#relationships-form-collapse-toggle').hasClass('collapsed')){
                $('#relationships-form-collapse-toggle').removeClass('collapsed');
                $('#collapsible-checkbox-for-field-relationship').removeClass('collapse');
            } else {
                $('#relationships-form-collapse-toggle').addClass('collapsed')
                $('#collapsible-checkbox-for-field-relationship').addClass('collapse');
            }
        }
    });
});

function removeHeading(selector) {
    let heading = $(selector).text().replace(/(\r\n|\n|\r)/gm, "");
    if (heading.trim().length == 0) {
        $(selector).remove();
    }
}

// 508: Add accessibility for flash messages
$(document).ready(function(){
    // Add tabindex and focus to flash messages
    $('.alert').attr('tabindex', -1).focus();
    $('.alert').attr('role', 'status');

    // Ignore the close button 'x' text in screen readers
    $('.alert').each(function() {
        var alertText = $(this).text();
        var alertClose = $(this).find('.close').text();
        var alertLabel = alertText.replace(alertClose, '');

        $(this).attr('aria-label', alertLabel);
    });

    // Add helpful text to close button
    $('.alert .close').attr('aria-label', 'Close status message');

    // Add helpful text to API key copy button and replace data-module with ed-copy-into-buffer
    var copyAPIKey = $(this).find("[data-module='copy-into-buffer']");
    copyAPIKey.attr('aria-label', 'Copy API key to clipboard');
    copyAPIKey.attr('role', 'button');
    copyAPIKey.attr('data-module', 'ed-copy-into-buffer');

    $("td > a").each(function () {
        if ($(this).is(':empty')) {
            $(this).remove();
        }
    })

    let heading = $('.heading').text().replace(/(\r\n|\n|\r)/gm, "");
    if (heading.trim().length == 0) {
        $('.heading').remove();
    }

    // check if check box exists in table header on organization bulk process page
    // if it does, add aria-label to it and if not wait for the page to load
    if ($('.table-bulk-edit thead tr th input').length) {
        $('.table-bulk-edit thead tr th input').attr('aria-label', 'Select all');
    }
    else {
        $(document).ajaxComplete(function() {
            $('.table-bulk-edit thead tr th input').attr('aria-label', 'Select all');
        });
    }

    removeHeading('.heading')
    removeHeading('.inner-primary h1')

});

try {
    // Workaround for saml2auth login redirect with SameSite set to Strict
    window.onload = function() {
        if (window.location.href.includes('user/login?__no_cache__=True')) {
            $('html').hide();
            window.location.href = '/dashboard';
        }
    }
} catch (e) {
    console.log(e);
}

// Remove disabled from '#follow_button's child '<a href' only after everything else has loaded and re-enable pointer events
$(document).ready(function(){
    $('.follow_button').find('a').removeAttr('disabled');
    $('.follow_button').find('a').css('pointer-events', 'auto');

});
