const pkgImg = document.getElementById('pkgg')
if(pkgImg)
    pkgImg.style.backgroundImage= `url(${pkgImg.getAttribute('im')})` ;
