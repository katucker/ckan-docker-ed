/**
 * Launches a modal
 *
 * Returns nothing
 */
const launchModal = (selector) => {
  $(selector).modal();
  console.log("3");
  $(selector).on("shown.bs.modal", function () {
    $(selector + " " + '[role="dialog"]')
      .first()
      .focus();
  });
};

/**
 * Closes a modal
 *
 * Returns nothing
 */
const closeModal = (selector) => {
  $(selector).modal("hide");
};
