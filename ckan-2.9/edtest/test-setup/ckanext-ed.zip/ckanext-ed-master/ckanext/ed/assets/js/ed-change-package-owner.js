// String constants
const localStorageKeyName = 'changeOwnerPackageList'; // object key for package ids in local storage
const followerCheckboxClass = 'follower-checkbox'; // class name for iidentifying follower checkboxes
const pageURL = document.location.href; // page url
const packageCounterElementId = 'bulk-change-dataset-ownership-count'; // element id for span class containing package list count
const errorMessageElementId = 'bulk-change-dataset-ownership-error'; // element id for span class showing error messages
const masterCheckboxId = 'change-ownership-master-checkbox'; // element id for master checkbox
const changeAndCancelButtonId = 'bulk-change-dataset-ownership-btn'; // id for the change ownership button which is also used as the cancel button

// If the user is not coming from within the portal, clear the localstorage
let referrer;
try {
    referrer = new URL(document.referrer);
    if (referrer && referrer.hostname != document.location.hostname) {
        localStorage.removeItem(localStorageKeyName);
    }
} catch (e) {
    localStorage.removeItem(localStorageKeyName);
}

let isChangeOwnershipInterfaceActive = false;
let currentList = JSON.parse(localStorage.getItem(localStorageKeyName));

/* If there was an existing value in the local storage, indicate that the
 interface should be generated */
if (currentList && currentList.length) {
    isChangeOwnershipInterfaceActive = true;
}

/**
 * Checkbox element for each checkbox that would be generated beside
 * the data profiles.
 * 
 * @param {String} packageName the package id, will also be used as the checkbox name
 * @param {String} size the checkbox css width and height
 * @returns {HTMLInputElement} the generated checkbox element
 */
const checkboxElement = (packageName, size) => {
    const checkbox = document.createElement('input');
    checkbox.setAttribute('type', 'checkbox');
    checkbox.name = packageName;
    checkbox.style.width = size;
    checkbox.style.height = size;
    checkbox.classList.add(followerCheckboxClass);

    /* If the checkbox was selected in the localstorage, 
    set it to checked at creation */
    if (currentList && currentList.includes(packageName)){
        checkbox.checked = true;
    }

    // Add event listener for click events
    checkbox.addEventListener('click', e => {
        /* On click, if the checkbox was clicked, add the package id to 
        the localstorage. If not, remove it from the local storage */
        currentList = JSON.parse(localStorage.getItem(localStorageKeyName));
        if (checkbox.checked) {
            currentList.push(packageName);
            document.getElementById(errorMessageElementId)
                .innerText = '';
        } else {
            const index = currentList.indexOf(packageName);
            if (index > -1) {
                currentList.splice(index, 1);
            }
        }
        localStorage.setItem(localStorageKeyName, JSON.stringify(currentList));
        document.getElementById(packageCounterElementId)
            .innerText = `${currentList.length} data profiles selected`;

        // call function handling master checkbox state
        controlMasterCheckboxState();
    })

    return checkbox;
}

/**
 * Handles the master checkbox checked state.
 * When the follower checkboxes don't all have the same checked state,
 * this sets the master indeterminate state to true.
 */
const controlMasterCheckboxState = () => {
    const master = document.getElementById(masterCheckboxId);
    // Check if all the checkboxes on the have the same check state
    let states = [];
    document.getElementsByClassName(followerCheckboxClass).forEach(c => {
        states.push(c.checked);
    })

    if (states.every((val, i, arr) => val === arr[0])) {
        // All states are the same
        master.indeterminate = false;
        if (master.checked != states[0]) {
            master.checked = states[0];;
        }
    } else {
        // The states are not all the same
        master.indeterminate = true;
    }
}

/**
 * Generates the list item for the master checkbox
 * 
 * @param {String} size the width and height of the checkbox to pass to CSS
 * @returns {HTMLLIElement} the list element containing the master checkbox
 */
const masterCheckboxListItem = (size) => {
    const checkbox = document.createElement('input');
    checkbox.setAttribute('type', 'checkbox');
    checkbox.style.width = size;
    checkbox.style.height = size;
    checkbox.id = masterCheckboxId;

    checkbox.addEventListener('click', e => {
        document.getElementsByClassName(followerCheckboxClass).forEach(c => {
            if (c.checked != checkbox.checked) {
                c.click()
            }
        })
    })

    const listItem = document.createElement('li');
    listItem.classList.add('dataset-item');
    listItem.style.display = 'flex';
    listItem.style.flexDirection = 'row';
    listItem.style.gap = '16px';
    listItem.style.marginBottom = '16px'

    const textDiv = document.createElement('div');
    textDiv.innerText = 'Select all items in this page';

    listItem.appendChild(checkbox);
    listItem.appendChild(textDiv);

    return listItem;
}

/**
 * Generates the interface to allow bulk ownership change
 * 
 * @param {Boolean} expandForm when true, the owner selection form would be expanded
 */
const generateChangeOwnershipInterface = (expandForm) => {
    isChangeOwnershipInterfaceActive = true;

    // Modify the change ownership buttom into a cancel button
    const changeButton = document.getElementById(changeAndCancelButtonId);
    changeButton.className = 'btn btn-danger';
    changeButton.innerText = 'Cancel Ownership Changes';

    // Hide add data profile button
    document.querySelectorAll('a.btn.btn-primary')[0].style.display = 'none';

    // Update selected count
    document.getElementById(packageCounterElementId)
        .innerText = `${currentList ? currentList.length : 0} data profiles selected`;
    
    // expand form when the user arrives from another page and has data in the 
    // local storage
    if (expandForm) {
        document.getElementById('bulk-change-dataset-ownership-collapsible')
            .classList.add('in')
    }

    // Generate the checkboxes
    document
    .querySelectorAll('div.dataset-item > .card-custom.package-item')
    .forEach( item => {
        const packageName = item.dataset['packagename'];
        const currentOwner = item.dataset['currentowner'];

        // Modify the element styles
        const listItem = item.parentElement;
        listItem.style.display = 'flex';
        listItem.style.flexDirection = 'row';
        listItem.style.gap = '16px';
        item.style.width = '100%';

        // Show the current owner
        const ownerText = item.getElementsByClassName('dataset-total-views')[0];
        ownerText.innerHTML = `<span>Current Owner: ${currentOwner}</span>`

        // Insert checkboxes
        const checkbox = checkboxElement(packageName, '24px');
        listItem.insertBefore(checkbox, listItem.firstChild);
    })

    // Insert master checkbox
    const ulElement = document.querySelector('ul.dataset-list');
    const masterCheckbox  = masterCheckboxListItem('24px');
    ulElement.insertBefore(
        masterCheckbox, ulElement.firstChild
    )
    controlMasterCheckboxState();

}

/**
 * Clear out the cange ownership interface
 * @param {String} url url te redirect the page after clearing the interface
 */
const cancelOwnershipChanges = url => {
    document.getElementById(changeAndCancelButtonId).remove();
    localStorage.removeItem(localStorageKeyName);
    isChangeOwnershipInterfaceActive = false;
    document.location.href = url
}

/**
 * Submits the selected data profiles to the backend to have their data profiles changed
 *
 * @returns {void}
 */
const handleSubmitChangeOwners = () => {

    // Get list of packages to submit
    const finalList = JSON.parse(localStorage.getItem(localStorageKeyName));
    if (!finalList.length) {
        document.getElementById(errorMessageElementId)
            .innerText = 'No data profiles have been selected';
        return
    }

    const selectField = document.getElementById('field-change-owner');
    const organizationId = document.getElementById(changeAndCancelButtonId).dataset['organizationid']

    // Generate the request details
    const settings = {
        "url":`/dataset/admin/bulk/${organizationId}`,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            'packageList': finalList,
            'new_owner': selectField.value,
            'new_owner_name': selectField.options[selectField.selectedIndex].text
        })
    }
    
    // Send the request and cancel the change ownership interface
    $.ajax(settings).done(response => {});
    cancelOwnershipChanges(document.location.href);
}

// Run when the page is loaded
$(() => {

    // Generate the interface if there is existing data
    if (isChangeOwnershipInterfaceActive) {
        generateChangeOwnershipInterface(true);
    }

    $(`#${changeAndCancelButtonId}`).click(e => {
        localStorage.setItem(localStorageKeyName, JSON.stringify([]));

        isChangeOwnershipInterfaceActive
            ? cancelOwnershipChanges(pageURL)
            : generateChangeOwnershipInterface();
    })

    $('#bulk-change-dataset-ownership-submit-btn').click(e => {
        handleSubmitChangeOwners();
    })

    // Fix for the flash messages UI issue
    // When messages are flashed they are below the sidebar which has a fixed display
    if (document.contains(document.getElementById('alert_message'))) {
        let sidebarOffset = document.getElementById('nav-wrapper').clientHeight + 
        document.querySelector('div.flash-messages').clientHeight
        document.getElementById('scrollbar').style.top = `${sidebarOffset}px`
    }
})