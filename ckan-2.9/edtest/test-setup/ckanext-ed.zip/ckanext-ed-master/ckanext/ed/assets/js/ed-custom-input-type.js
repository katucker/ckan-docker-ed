/**
 * Displays information on the state of the checkbox
 * 
 * @param {boolean} checkedState The state of the checkbox
 * 
 * Returns nothing
 */
const setFieldTextAndIcon = (checkedState) => {
    if (checkedState) {
        $('#field-private-toggle-icon').addClass('fa-unlock');
        $('#field-private-toggle-icon').removeClass('fa-lock');
        $('#field-private-toggle-text').text('Public');
    } else {
        $('#field-private-toggle-icon').addClass('fa-lock');
        $('#field-private-toggle-icon').removeClass('fa-unlock');
        $('#field-private-toggle-text').text('Hidden');        
    }
}

// set the initial checkbox state based on the value from the select element
if ($('#field-private').val() == 'False') {
    $('#field-private-checkbox').attr('checked', true);
    setFieldTextAndIcon(true);
} else {
    $('#field-private-checkbox').attr('checked', false);
    setFieldTextAndIcon(false);
}

if ($('#field-member-private').val() == 'False') {
    $('#field-private-checkbox').attr('checked', false);
} else {
    $('#field-private-checkbox').attr('checked', true);
}


// Update the select element based on changes in the checkbox toggle
$('#field-private-checkbox').on('change', () => {
    if ($('#field-private-checkbox').is(':checked')) {
        $('#field-private').val('False').change();
        setFieldTextAndIcon(true);
    } else {
        $('#field-private').val('True').change();
        setFieldTextAndIcon(false);
    }
});

$('#field-private-member-checkbox').on('change', () => {
    if ($('#field-private-member-checkbox').is(':checked')) {
        $('#field-member-private').val('True').change();
    } else {
        $('#field-member-private').val('False').change();
    }
});


if ($('#user-default').val() == 'True') {
    $('#field-user-checkbox').attr('checked', true);
} else {
    $('#field-user-checkbox').attr('checked', false);
}

$('#field-user-checkbox').on('change', () => {
    if ($('#field-user-checkbox').is(':checked')) {
        $('#user-default').val('True').change();
        if ($('#default-form').length)  {   
            $('#default-form').submit();
        }
        else {
            $(window).off('beforeunload');
            let url = window.location.href;
            if (url.includes('user_default')) {
                url = url.split('?user_default')[0];
            }
            if (url.includes('?')) {
                window.location.href = `${url}&user_default=True`;
            }
            window.location.href = `${url}?user_default=True`;
            
        }
    } else {
        $('#user-default').val('False').change();
        if ($('#default-form').length)  {   
            $('#default-form').submit();
        }
        else {
            $(window).off('beforeunload');
            let url = window.location.href;
            if (url.includes('user_default')) {
                url = url.split('?user_default')[0];
            }
            if (url.includes('?')) {
                window.location.href = `${url}&user_default=False`;
            }
            window.location.href = `${url}?user_default=False`;
        }
    }
});

/**
 * Enable or disable the rights field based on the access level value
 */
const setRightsFieldVisibility = () => {
    if (['restricted-public', 'non-public'].includes($('#access_level').val())) {
        $("input#rights").prop('disabled', false);
        $("#asterik").text('* ')
        $('#asterik').attr('aria-hidden', true);
        $("#dcatright").css('display', 'inline')
        $("#license-req").css('display', 'none')
        $("label[for='rights']").append(`<span class="offscreen" >Required</span>`);
    } else {
        $("input#rights").prop('disabled', true);
        $("#asterik").text('')
        $("#dcatright").css('display', 'none')
        $("#license-req").css('display', 'inline')
    }
}

/****************************
* Access level Radio Buttons *
*****************************/
$('input[type=radio][name=access_level_radios]').change(() => {
    const radioValue = $('input[type=radio][name=access_level_radios]:checked').val();
    $('#access_level').val(radioValue).change();

    setRightsFieldVisibility();
});

$(document).ready(() => {
    setRightsFieldVisibility();
})
