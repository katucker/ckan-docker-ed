var tagsToShow = 3;
var hideTags = function() {
   [].forEach.call(document.querySelectorAll('.tag-list-item'), function (el, i) {
     if (i >= tagsToShow) {
       el.style.cssText = 'display: none !important';
     }
   });
 }
 var showTags = function() {
   [].forEach.call(document.querySelectorAll('.tag-list-item'), function (el) {
     el.style.cssText = 'display: inline-table !important';
   });
 }

if (document.getElementById('tag-list-toggle')) {
  document.getElementById('tag-list-toggle').onclick = function toggleTags() {

    if (document.getElementById("tag-list").children[tagsToShow+1].style.display == 'none') {
      showTags();
      document.getElementById('tag-list-toggle').innerHTML = 'Show less'
    } else {
      hideTags();
      document.getElementById('tag-list-toggle').innerHTML = 'Show more'
    }
  }
}
 hideTags();