$(document).ready(function() {

  function templateHead(org, org_title) {
      return ` <div id="data-${org}" class="custom-mb">
                <h4 tabindex="0" aria-label="list of selected dataset for ${org_title} organization">${org_title}</h4>
            <ul id="list-${org}" class="custom-org-list">`
  }

  function templateBody(title, checkbox, org, pkg_name, org_title) {
      return `
    <li id="datap-${pkg_name}">
      <span style="margin-right: 6px; margin-bottom:10px;" >${title}</span><button id="data-remove"
      data-org=${org} data-org-title="${org_title}" data-title="${title}" data-checkbox=${checkbox} data-pkg-name=${pkg_name} class="custom-remove" aria-label="remove ${title}">X</button>
    </li>
  `
  }

  function templateTail() {
      return `</ul></div>`
  }

  function add2Total() {
      let total = parseInt($('#total').text());
      $('#total').text(total + 1);
  }

    function remove2Total() {
        let total = parseInt($('#total').text());
        $('#total').text(total - 1);
    }

  function createTemplate(data, total) {
      let template = `<div id="data_list" class="custom-side"> <h3 tabindex="0">Selected Data Profiles (<span id="total">${total}</span>)</h3><br/>`
      for (org of Object.keys(data)) {
          template += templateHead(org, data[org][0].org_title);
          for (let i = 0; i < data[org].length; i++) {
              template += templateBody(data[org][i].title, data[org][i].checkbox, org, data[org][i].pkg_name, data[org][i].org_title);
          }
          template += templateTail();
      }
      template += `</div>`
      return template;
  }

  function storeInStorage() {
      let pagedataId = `page${window.location.href.split('page=')[1]?.split("&")[0] || 1}`;
      let pageData = JSON.parse(sessionStorage.getItem(pagedataId)) || [];
      $('input[type=checkbox]').each(function() {
          if (this.checked) {
              check = [];
              let index = pageData.findIndex((el) => el[0] === $(this).attr('data-approval-id'));
              if (index === -1) {
                  if (!$(this).attr('data-approval-title')) return;
                  check.push($(this).attr('data-approval-id'));
                  check.push($(this).attr('data-approval-title'));
                  pageData.push(check);
              }
          } else {
              let index = pageData.findIndex((el) => el[0] === $(this).attr('data-approval-id'));
              if (index !== -1) {
                  pageData.splice(index, 1);
              }
          }
      });

      // save side data
      if ($('#data_list').length) {
          let side_data = {};
          let current;
          let total = 0;
          $('#data_list div[id^="data-"]').children().each(function() {
              if ($(this).find("li").length === 0) {
                  current = $(this).parent().attr("id").split(/-(.*)/s)[1];
                  side_data[current] = []
              } else {
                  let button = $(this).find("button")
                  for (btn of button) {
                      let title = $(btn).attr("data-title")
                      let org_title = $(btn).attr("data-org-title")
                      let checkbox = $(btn).attr("data-checkbox")
                      let pkg_name = $(btn).attr("data-pkg-name")
                      side_data[current].push({
                          title,
                          checkbox,
                          pkg_name,
                          org_title
                      })
                      total +=1;
                  }
              }
          });
          sessionStorage.setItem('total', JSON.stringify(total));
          sessionStorage.setItem('side_data', JSON.stringify(side_data));
      }
      sessionStorage.setItem(pagedataId, JSON.stringify(pageData));
  }

  function removeDataFromStorageSideBar(self) {
      let side_data = JSON.parse(sessionStorage.getItem('side_data'));
      let org = $(self).attr('data-org');
      let checkbox = $(self).attr('data-checkbox');
      let pkg_name = $(self).attr('data-pkg-name');
      if (side_data && org in side_data) {
          let index = side_data[org].findIndex(x => x.checkbox === checkbox);
          side_data[org].splice(index, 1);
          if (!side_data[org].length) {
              delete side_data[org];
          }
          sessionStorage.setItem('side_data', JSON.stringify(side_data));
      }

      // remove from page session storage
      let pageData = {};
      for (let i = 0; i < sessionStorage.length; i++) {
          let key = sessionStorage.key(i);
          if (key.startsWith('page')) {
              pageData[key] = JSON.parse(sessionStorage.getItem(key));
          }
      }
      for (let key in pageData) {
        
          let index = pageData[key].findIndex(x => x[0] === pkg_name);
          if (index > -1) {
              pageData[key].splice(index, 1);
              sessionStorage.setItem(key, JSON.stringify(pageData[key]));
              if (!pageData[key].length) {
                  sessionStorage.removeItem(key);
              }
              break;
          }
      }
     
      $(`#datap-${$(self).attr("data-pkg-name")}`).remove();
      if (!$('#list-' + $(self).attr('data-org')).children().length) {
          $(`#data-${$(self).attr('data-org')}`).remove();
      }
      if ($('#data_list').children().length < 3) {
          $('#data_list').remove();
          //clear side data
          sessionStorage.removeItem('side_data');
      }
  }



  let side_data = JSON.parse(sessionStorage.getItem('side_data'));
  let total = JSON.parse(sessionStorage.getItem('total'));
  if (side_data) {
      let template = createTemplate(side_data, total);
      $('.side-content').append(template);
  }

  $('input[data-type="checkbox-package"]').change(function() {
      let org = $(this).attr('data-org');
      let org_title = $(this).attr('data-org-title');
      let title = $(this).attr('data-approval-title');
      let checkbox = $(this).attr('id');
      let pkg_name = $(this).attr('data-approval-id');
      if ($(this).is(':checked')) {
          if ($('#data_list').length) {
              // get total from total id and add 1
              let total = parseInt($('#total').text()) + 1;
              if ($('#data-' + org).length) {
                  let template = templateBody(title, checkbox, org, pkg_name, org_title);

                  $('#list-' + org).append(template);
              } else {
                  let template = templateHead(org, org_title) + templateBody(title, checkbox, org, pkg_name, org_title) + templateTail();
                  $('#data_list').append(template);
              }
              $('#total').text(total);
          } else {
              let data = {
                  [org]: [{
                      title: title,
                      checkbox: checkbox,
                      pkg_name: pkg_name,
                      org_title: org_title
                  }]
              }

              let template = createTemplate(data, 1);
              $('.side-content').append(template);
          }
      } else {
          $(`#datap-${pkg_name}`).remove();
          if (!$('#list-' + org).children().length) {
              $(`#data-${org}`).remove();
          }
          if ($('#data_list').children().length < 3) {
              $('#data_list').remove();
          }
          if ($('#checkbox-select').is(':checked')) {
              $('#checkbox-select').prop('checked', false);
          }
          remove2Total();
          
      }
  });

  $(document).on('click', '#data-remove', function() {
      let checkbox = $(this).attr('data-checkbox');
      // check if checkbox id exist
      if ($(`#${checkbox}`).length) {
          $(`#${checkbox}`).prop('checked', false);
          if ($('#checkbox-select').is(':checked')) {
              $('#checkbox-select').prop('checked', false);
          }
          removeDataFromStorageSideBar(this)
          remove2Total();
      } else {
          // remove from session storage
          removeDataFromStorageSideBar(this);
          remove2Total();
      }

  });




  $('#checkbox-select').click(function() {
      if ($(this).is(':checked')) {
          let data = {}
          let total = 0;
          $('input[type=checkbox]').each(function() {
              $(this).prop('checked', true);
              let org = $(this).attr('data-org');
              let org_title = $(this).attr('data-org-title');
              let title = $(this).attr('data-approval-title');
              let checkbox = $(this).attr('id');
              let pkg_name = $(this).attr('data-approval-id');

              if (typeof org !== 'undefined') {
                  if ($('#data_list').length) {
                      if ($('#data-' + org).length) {
                          if (!$("#data_list").find(`#datap-${pkg_name}`).length) {
                              let template = templateBody(title, checkbox, org, pkg_name, org_title);
                              $('#list-' + org).append(template);
                              add2Total();
                          }
                      } else {
                          let template = templateHead(org, org_title) + templateBody(title, checkbox, org, pkg_name, org_title) + templateTail();
                          $('#data_list').append(template);
                          add2Total();
                      }

                  } else {
                      if (org in data) {
                          data[org].push({
                              checkbox,
                              pkg_name,
                              title,
                              org_title
                          });
                      } else {
                          data[org] = [{
                              checkbox,
                              pkg_name,
                              title,
                              org_title
                          }];
                      }
                    total +=1;
                  }
              }
          });
          if (!$('#data_list').length) {
              let template = createTemplate(data, total);
              $('.side-content').append(template);
          }
      } else {
          $('input[type=checkbox]').each(function() {
              let title = $(this).attr('data-approval-id');
              $(`#datap-${title}  #data-remove`).click();
          });
      }
  });

  let pagedataId = `page${window.location.href.split('page=')[1]?.split("&")[0] || 1}`;

  if (pagedataId in sessionStorage) {
      let pageData = JSON.parse(sessionStorage.getItem(pagedataId));
      // checked checkbox contain pageData value
      for (let i = 0; i < pageData.length; i++) {
          $(`input[data-approval-id=${pageData[i][0]}]`).prop('checked', true);
      }
  }

  // on pagination click add storeInStorage and redirect to next page
  $('.pagination a').click(function(e) {
      e.preventDefault();
      storeInStorage();
      window.location = $(this).attr('href');

  });


  // on organization select change add storeInStorage and submit form
  $('#field-organizations').change(function() {
      storeInStorage();
      $("#filter-org").submit();
  });

  // on bulk-submit button click prevent default , add
  // storeinStorage and submit form
  $("#bulk-submit").click(function(e) {
      e.preventDefault();
      storeInStorage();
      $("#bulk-search").submit();
  });

  // on bulk-input field enter prevent default , add 
  // storeinStorage and submit form
  $("#bulk-input").keypress(function(e) {
      if (e.which == 13) {
          e.preventDefault();
          storeInStorage();
          $("#bulk-search").submit();
      }
  });

  // check if all checkboxes are checked
  if ($('input[type=checkbox]').length === $('input[type=checkbox]:checked').length + 1) {
      $('#checkbox-select').prop('checked', true);
  }

});