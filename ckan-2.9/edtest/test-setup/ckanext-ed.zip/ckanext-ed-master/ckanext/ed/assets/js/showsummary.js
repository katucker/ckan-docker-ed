try {
  let id = document.getElementById('showsdiv')
  let pkgId = id.getAttribute('pkg')

  showSummary(false, pkgId)
} catch (e) {
  console.log('No survey summary to display yet.')
}

function showSummary(isPublic, package_id){
  var summary;
  var getSummary = $.ajax({
    url: `/get_survey_summary/${package_id}`,
    type: 'GET',
    async: false,
    success: function (data){
      summary = JSON.parse(data);

      if (summary != null) {
        var totalTaken = summary.helpful + summary.not_helpful;
      } else {
        var totalTaken = 0;
      }

      if(totalTaken >= 3){
        var summaryText = `${totalTaken} people have used this data set and ${summary.percentage_helpful}% found it useful.`;

        if(isPublic){
          $('.survey-results').text(summaryText);
          toggleElement('survey-results', true);
        }else{
          $('.survey-results-non-public').text(summaryText);
          toggleElement('survey-results-non-public', true)
        }
      }else{
        console.log('Surveys taken is less than 3. Not displaying results.')
      }
    }
  });
}
