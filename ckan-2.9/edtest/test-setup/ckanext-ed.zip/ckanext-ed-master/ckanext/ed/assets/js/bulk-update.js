this.ckan.module('bulk-update', function (jQuery) {
  return {
    /* An object of module options */
    options: {
      content: '',
      i18n: {
        content: '',
      },

      template: [
        '<div class="modal fade">',
        '<div class="modal-dialog">',
        '<div class="modal-content">',
        '<div class="modal-header">',
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>',
        '<h3 class="modal-title"></h3>',
        '</div>',
        '<div class="modal-body"></div>',
        '<div class="modal-footer">',
        '<button class="btn btn-default btn-cancel" id="bulk-cancel-button"></button>',
        '<button class="btn btn-primary" id="bulk-confirmation-button"></button>',
        '</div>',
        '</div>',
        '</div>',
        '</div>'
      ].join('\n')
    },

    initialize: function () {
      jQuery.proxyAll(this, /_on/);
      this.el.on('click', this._onClick);
    },
  confirm: function () {
      this.sandbox.body.append(this.createModal());
      this.modal.modal('show');

      // Center the modal in the middle of the screen.
      this.modal.css({
        'margin-top': this.modal.height() * -0.5,
        'top': '50%'
      });
    },

    performAction: function () {
      $('#bulk-confirmation-button').text(this._('Submitting...'))
      $('#bulk-confirmation-button').prop('disabled', true)
      $('#bulk-cancel-button').prop('disabled', true)

      let pagedataId = `page${window.location.href.split('page=')[1]?.split("&")[0] || 1}`;
      let pageData = JSON.parse(sessionStorage.getItem(pagedataId)) || [];
      $('input[type=checkbox]').each(function() {
        if (this.checked) {
          check = [];
          let index = pageData.findIndex((el) => el[0] === $(this).attr('data-approval-id'));
          if (index === -1) {
            if (!$(this).attr('data-approval-title')) return;
            check.push($(this).attr('data-approval-id'));
            check.push($(this).attr('data-approval-title'));
            pageData.push(check);
          }
        } else {
          let index = pageData.findIndex((el) => el[0] === $(this).attr('data-approval-id'));
          if (index !== -1) {
            pageData.splice(index, 1);
          }
        }
      });

      sessionStorage.setItem(pagedataId, JSON.stringify(pageData));
      // fetch all keys and value in seesionStorage and store in a variable
      let datapage = {}

      for (let i = 0; i < sessionStorage.length; i++) {
       let key = sessionStorage.key(i);
       if (key.startsWith('page')) {
          let value = sessionStorage.getItem(key);
          datapage[key] = JSON.parse(value);
        }
      }

      let checkdata = Object.values(datapage)
      let someTrue = checkdata.some(function (el) {
        return el.length > 0;
      });

    
      //create a form and  hidden input and append to body
      var form = jQuery('<form/>', {
        action: this.el.attr('href'),
        method: 'POST'
      });
      var input = jQuery('<input/>', {
        type: 'hidden',
        name: 'datavalues',
        value: someTrue ? JSON.stringify(datapage): ''
      });
      form.append(input);
      this.sandbox.body.append(form);
      sessionStorage.clear();
      form.submit();
    },

    createModal: function () {
      if (!this.modal) {
        var element = this.modal = jQuery(this.options.template);
        element.on('click', '.btn-primary', this._onConfirmSuccess);
        element.on('click', '.btn-cancel', this._onConfirmCancel);
        element.modal({show: false});

        element.find('.modal-title').text(this._('Please Confirm Action'));
        var content = this.options.content ||
                      this.options.i18n.content || /* Backwards-compatibility */
                      this._('Are you sure you want to perform this action?');

        
        element.find('.modal-body').html(content);
        element.find('.btn-primary').text(this._('Update'));
        element.find('.btn-cancel').text(this._('Cancel'));
      }
      return this.modal;
    },

    /* Event handler that displays the confirm dialog */
    _onClick: function (event) {
      event.preventDefault();
      this.confirm();
    },

    /* Event handler for the success event */
    _onConfirmSuccess: function (event) {
      this.performAction();
    },

    /* Event handler for the cancel event */
    _onConfirmCancel: function (event) {
      this.modal.modal('hide');
    }
  };
});
