/* module to manage the resource API urls */
this.ckan.module('resource-urls', function($) {
  return {
    /* options object can be extended using data-module-* attributes */
    options: {
        field_access_url: 'access_url',
        field_api_url: 'api_url',
        field_url: 'url',
    },

    /* Should be changed to true if user modifies resource's name
     *
     * @type {Boolean}
     */
    _nameIsDirty: false,

    initialize: function () {
      $.proxyAll(this, /_on/);
      var options = this.options;

      var field_access_url = 'input[name="' + options.field_access_url + '"]';
      var field_api_url = 'input[name="' + options.field_api_url + '"]';
      var field_url = 'input[name="' + options.field_url + '"]';
      var field_name = 'input[name="name"]';
      var field_url_input_remove_bt = 'a.input-url-remove'

      this.input_access_url = $(field_access_url, this.el);
      this.input_api_url = $(field_api_url, this.el);
      this.field_url_input = $(field_url);
      this.field_url_input_remove_bt = $(field_url_input_remove_bt);

      this.input_name = this.el.parents('form').find(field_name);
      this.form_group = $(this.input_access_url, this.el).parents('.form-group');

      this.button_access_url = $('<a href="javascript:;" class="btn btn-default">' +
            '<i class="fa fa-globe"></i>' +
            this._('Access URL') + '</a>')
            .prop('title', this._('Link to a URL on the internet.'))
            .on('click', this._onAccessUrlButtonClick)
            .insertAfter(this.input_access_url);

      this.button_api_url = $('<a href="javascript:;" class="btn btn-default">' +
            '<i class="fa fa-globe"></i>' +
            this._('API URL') + '</a>')
            .prop('title', this._('Link to an API endpoint on the internet.'))
            .on('click', this._onAPIUrlButtonClick)
            .insertAfter(this.button_access_url);

      this.label_access_url = $('label[for=field-access-url]', this.el);
      this.label_api_url = $('label[for=field-api-url]', this.el);

      var main_label = "Resource URL"
      this.main_label_el = $('<label id="main-label" class="control-label">'+ main_label + '</label>')
                            .insertBefore(this.form_group);

      // Button for resetting the form when there is a URL set
      var remove_access_url = this._('Remove');
      this.bt_remove_access_url = $('<a href="javascript:;" id="bt-remove-access-url" class="btn btn-danger btn-remove-url">'
        + remove_access_url + '</a>')
        .prop('title', remove_access_url)
        .on('click', this._onRemoveAccessUrl)
        .insertBefore(this.input_access_url);

      var remove_api_url = this._('Remove');
      this.bt_remove_api_url = $('<a href="javascript:;" id="bt-remove-api-url" class="btn btn-danger btn-remove-url">'
          + remove_api_url + '</a>')
          .prop('title', remove_api_url)
          .on('click', this._onRemoveApiUrl)
          .insertBefore(this.input_api_url);
    
      // Disables autoName if user modifies name field
      this.input_name
        .on('change', this._onModifyName);

      if (this.input_name.val()){
        this._nameIsDirty = true;
      }

      this._hideAllElements();
      if (this.input_access_url.val() != ""){
        this._showAccessUrlInput();
      }
      else if(this.input_api_url.val() != ""){
        this._showApiUrlInput();
      }
      else {
        this._showOnlyButtons();  
      }
      
      this.input_access_url.focus()
      .on('blur', this._onFromWebBlurAccessURL);

      this.input_api_url.focus()
        .on('blur', this._onFromWebBlurApiURL);

    },

    _showOnlyButtons: function() {
        this.input_access_url.hide();
        this.input_api_url.hide();
        this.label_access_url.hide();
        this.label_api_url.hide();
        this.bt_remove_access_url.hide();
        this.bt_remove_api_url.hide();
        this.button_access_url.show();
        this.button_api_url.show();
        this.main_label_el.show();
    },

    _hideAllElements: function() {
      this.input_access_url.hide();
      this.input_api_url.hide();
      this.label_access_url.hide();
      this.label_api_url.hide();
      this.bt_remove_access_url.hide();
      this.bt_remove_api_url.hide();
      this.button_access_url.hide();
      this.button_api_url.hide();
      this.main_label_el.hide();
    },

    _showAccessUrlInput: function() {
      this.input_access_url.show();
      this.label_access_url.show();
      this.bt_remove_access_url.show();
    },

    _showApiUrlInput: function() {
      this.input_api_url.show();
      this.label_api_url.show();
      this.bt_remove_api_url.show();
    },

    _onAccessUrlButtonClick: function() {
      this._hideAllElements();
      this._showAccessUrlInput();
    },

    _onAPIUrlButtonClick: function() {
      this._hideAllElements();
      this._showApiUrlInput();
    },

    _onRemoveAccessUrl: function() {
      this.input_access_url.val('');
      this.field_url_input.val('');
      this.field_url_input_remove_bt.click();
      this._showOnlyButtons();
    },

    _onRemoveApiUrl: function() {
      this.input_api_url.val('');
      this.field_url_input.val('');
      this.field_url_input_remove_bt.click();
      this._showOnlyButtons();
    },

    _onModifyName: function() {
      this._nameIsDirty = true;
    },

    /* Event listener for when someone loses focus of URL field
     *
     * Returns nothing
     */
    _onFromWebBlurAccessURL: function() {
      var url = this.input_access_url.val().match(/([^\/]+)\/?$/)
      if (url) {
        this._autoName(url.pop());
      }
    },

    _onFromWebBlurApiURL: function() {
      var url = this.input_api_url.val().match(/([^\/]+)\/?$/)
      if (url) {
        this._autoName(url.pop());
      }
    },

    /* Automatically add file name into field Name
    *
    * Select by attribute [name] to be on the safe side and allow to change field id
    * Returns nothing
    */
    _autoName: function(name) {
      if (!this._nameIsDirty){
        this.input_name.val(name);
      }
    }
  };
});