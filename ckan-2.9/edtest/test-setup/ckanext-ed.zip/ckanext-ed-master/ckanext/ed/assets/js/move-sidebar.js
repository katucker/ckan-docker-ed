$(document).ready(function (e) {
    if(document.getElementById("alert_message")){
        document.getElementById('scrollbar').style.top = '130px'
    }
});

