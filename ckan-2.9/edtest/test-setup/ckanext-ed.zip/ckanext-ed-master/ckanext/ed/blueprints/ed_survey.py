from flask import Blueprint
import json
import logging

from ckan.common import request
import ckan.lib.helpers as h

from ckanext.ed.model import update_survey_results, retrieve_survey_summary
from ckanext.ed import mailer
from ckanext.ed.helpers import validate_survey_data

log = logging.getLogger(__name__)

ed_survey_blueprint = Blueprint(u'ed_survey', __name__, url_prefix=u'/')


def get_survey():
    survey_results = {}

    try:
        survey_results = json.loads(request.data)
    except Exception as e:
        log.error('Unexpected object passed from ajax: {}'.format(e))
        return h.redirect_to(request.referrer)

    if validate_survey_data(survey_results):
        question_3 = survey_results['question_3']
        survey_results['question_3'] = question_3 \
            if len(question_3) < 300 else question_3[:299]
        update_survey_results(survey_results)

        if survey_results['question_1'] == 'Yes' \
           and survey_results['question_2'] == 'No':
            mailer.mail_survey_feedback(
                survey_results['package_id'],
                survey_results['question_3'])
    else:
        log.error('Incorrect fields passed to the survey: {}\nAborting DB '
                  'update...'.format(survey_results))
    return h.redirect_to(request.referrer)


def get_survey_summary(id):
    summary = retrieve_survey_summary(id)

    try:
        return json.dumps(summary)
    except Exception as e:
        log.error('Unexpected object passed to ajax: {}'.format(e))
        return


ed_survey_blueprint.add_url_rule(
    '/submit_survey',
    methods=[u'POST'],
    view_func=get_survey
)

ed_survey_blueprint.add_url_rule(
    '/get_survey_summary/<id>',
    methods=[u'GET'],
    view_func=get_survey_summary
)
