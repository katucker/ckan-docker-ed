import logging
from flask import g, request

from ckan.common import _
import ckan.lib.base as base

from ckanext.ed import helpers as ed_helpers

from .organization import organization_blueprint
from .ed_user import ed_user_blueprint
from .ed_datajson import ed_datajson_blueprint
from .ed_harvest import ed_harvest_blueprint
from .ed_api import ed_api_blueprint
from .ed_home import ed_home_blueprint
from .ed_group import ed_group_blueprint
from .ed_workflow_activity import ed_workflow_activity_blueprint
from .ed_tags import ed_tags_blueprint
from .ed_survey import ed_survey_blueprint
from .ed_roles import ed_roles_blueprint
from .ed_group_admin import ed_group_admin_blueprint
from .ed_forgot_password import ed_forgot_password_blueprint
from .ed_collections import ed_collections_blueprint
from .ed_approval_workflow import ed_approval_workflow_blueprint
from .ed_data_explorer import ed_data_explorer_blueprint
from .ed_source import ed_source_blueprint
from .ed_package import ed_dataset_blueprint
from .ed_documentation import ed_documentation_blueprint
from .ed_dashboard import ed_dashboard


log = logging.getLogger(__name__)


@ed_user_blueprint.before_request
@ed_roles_blueprint.before_request
def check_user_access():
    # Ignore login and logout pages
    is_login = any([
        p in request.path for p in [
            '/login', '/logged_in', '/_logout',
            '/logged_out', '/logged_out_redirect',
            '/user/reset', '/user/reset_password',
            '/user/me'
        ]]
    )

    if not is_login:
        cur_user_id = g.user
        user_id = request.view_args.get(u'id')
        cur_user_roles = ed_helpers.get_roles(cur_user_id)

        # If user has no roles, they can only see their own profile
        if cur_user_id != user_id and len(cur_user_roles) == 0:
            base.abort(403, _(u'Not authorized to see this page'))
