import logging
from flask import Blueprint

import ckan.lib.base as base
import ckan.model as model
from ckan.common import c, _
from ckan.views.user import _extra_template_variables

log = logging.getLogger(__name__)

ed_roles_blueprint = Blueprint(u'ed_roles', __name__, url_prefix=u'/')


def get_org_roles(id):
    if not c.userobj:
        base.abort(403, _(u'Not authorized to see this page'))

    context = {
        u'model': model,
        u'session': model.Session,
        u'user': c.user,
        u'auth_user_obj': c.userobj,
        u'for_view': True
    }
    data_dict = {
        u'id': id,
        u'user_obj': c.userobj,
        u'include_datasets': True,
        u'include_num_followers': True
    }

    extra_vars = _extra_template_variables(context, data_dict)

    return base.render(u'user/organization_roles.html', extra_vars)


ed_roles_blueprint.add_url_rule(
    u'/user/roles/<id>',
    'roles',
    methods=['GET'],
    view_func=get_org_roles
)
