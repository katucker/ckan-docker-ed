"""Functions used by multiple blueprints

TODO: This is mainly to keep functions that were available in ckan controllers \
in python but no longer available in python 3.
"""
import ckan.model as model
import ckan.lib.base as base
from ckan.common import _

def _ensure_controller_matches_group_type(id, group_types):
    group = model.Group.get(id)
    if group is None:
        base.abort(404, _('Group not found'))
    if group.type not in group_types:
        base.abort(404, _('Incorrect group type'))
    return group.type