import logging
import re
from flask import Blueprint

import ckan.lib.base as base
import ckan.logic as logic
from ckan import model
from ckan.common import c, request, _
import ckan.lib.helpers as h

from ckanext.ed.helpers import (
    get_all_users,
    get_user_by_id,
    get_organization_editors
)

log = logging.getLogger(__name__)

ed_group_admin_blueprint = Blueprint(
    u'ed_group_admin',
    __name__,
    url_prefix=u'/'
)

render = base.render
abort = base.abort

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
check_access = logic.check_access
get_action = logic.get_action


GROUP_DISPLAY_NAME = {
    u'organization': u'Organization',
    u'collection': u'Collection',
    u'ed_source': u'Source',
    u'data_explorer': u'Data Explorer',
    u'group': u'Category',
    u'category': u'Category'
}
GROUP_OBJECTS = [
    u'group',
    u'category',
    u'collection',
    u'ed_source',
    u'data_explorer'
]


def _get_group_and_owner_dict(context, group_type, group_id, allowed_users):
    """
    Returns the group and owner dictionaries for the group.
    """
    try:
        data_dict = {
            u'id': group_id, u'type': group_type,
            u'include_datasets': False, u'include_users': True
        }
        group_dict = get_action(u'group_show')(context, data_dict)
    except NotFound:
        abort(404, _(u'{} not found'.format(group_type)))
    except NotAuthorized:
        abort(403, _(u'Not authorized'))

    owner_dict = {}

    for m in group_dict[u'users']:
        for u in allowed_users:
            if m[u'name'] == u[u'name']:
                owner_dict = u
                break

    # Handle edge cases where the owner dict is empty
    if not owner_dict:
        owner_dict[u'id'] = None

    return group_dict, owner_dict


def _replace_group_owner(context, group_id, old_owner=None,
                         new_owner=None, remove_all=False):
    """
    Deletes the owner admin from a group and sets a new admin

    context: dict
        Session context
    group_id: str
        The group id
    old_owner: str optional
        id or name of old user to remove
    new_owner: str optional
        id or name of new user to add
    remove_all: bool optional
        if true, removes all older admins of the group so the \
        new admin would be the only admin of the group.
        Not recommended for organization group types.
    """

    owners_to_remove = []

    if remove_all:
        all_existing_members = get_action(u'member_list')(
            context, 
            {u'id': group_id, u'object_type': u'user'}
        )

        for member in all_existing_members:
            owners_to_remove.append(member[0])

    elif old_owner:
        owners_to_remove.append(old_owner)

    # Delete old owner
    for user_id in owners_to_remove:
        get_action(u'member_delete')(context, {
            u'id': group_id,
            u'object': user_id,
            u'object_type': u'user'
        })
    # Create new owner
    if new_owner:
        get_action(u'member_create')(context, {
            u'id': group_id,
            u'object': new_owner,
            u'object_type': u'user',
            u'capacity': u'admin'
        })


def change_owner(group_type, group_id):
    """
    Change a group objects owner
    """
    try:
        user_list = get_organization_editors(group_id, admin_only=True)
        auth_user = [a for a in user_list if a[u'name'] == c.user]
    except NotAuthorized:
        abort(403, u'Not authorized to view the page')

    if not auth_user:
        abort(403, _(u'Not authorized to see this page'))

    if group_type == u'category':
        group_type = u'group'
    context = {u'model': model, u'session': model.Session, u'user': c.user}

    c.group_dict, owner_dict = _get_group_and_owner_dict(
        context, group_type, group_id, user_list)

    ### Handle form submit
    if request.method == u'POST':
        new_user_id = request.form.get(u'new_owner')
        user_dict = get_user_by_id(new_user_id)

        try:
            # Remove all the previous admins within the group to make sure
            # there is only one admin in the group
            _replace_group_owner(
                context=context,
                group_id=c.group_dict[u'id'],
                old_owner=owner_dict[u'id'],
                new_owner=new_user_id,
                remove_all=True
            )
            h.flash_success(_(
                u'The {} owner has been changed to {}.'
                .format(
                    GROUP_DISPLAY_NAME[group_type],
                    user_dict[u'display_name']
                )
            ))
            owner_dict = user_dict
        except Exception as e:
            h.flash_error(
                u'Unable to change the {} owner to {}'
                .format(
                    GROUP_DISPLAY_NAME[group_type],
                    user_dict[u'display_name']
                ))
            log.error(
                u'Error occured while trying to change the {} owner'
                .format(group_type)
            )
            log.error(e)

    extra_vars = {
        u'group_dict': c.group_dict,
        u'user_list': get_all_users(),
        u'group_type': group_type,
        u'current_owner': owner_dict
    }

    return render(
        u'{}/change_owner.html'.format(group_type),
        extra_vars=extra_vars
    )


def bulk_change_owner(group_type='organization'):
    """
    Change the owners of multiple group objects
    """

    if group_type == u'category':
        group_type = u'group'

    if not h.check_access(u'sysadmin'):
        abort(403, _(u'Not authorized to see this page'))

    context = {u'model': model, u'session': model.Session, u'user': c.user}

    if request.method == u'POST':
        if group_type == u'organization':
            new_admin = request.form.get(u'new_admin')
            old_admin = request.form.get(u'old_admin')

            return _replace_organization_admin(
                old_admin,
                new_admin,
                group_type
            )

        new_user_id = request.form.get(u'new_owner')
        new_user_dict = get_user_by_id(new_user_id)
        selected_groups = request.form.get(u'selected_groups').split(u',')

        success_count = 0
        failed_count = 0

        for group_id in selected_groups:
            user_list = get_organization_editors(group_id, admin_only=True)
            c.group_dict, owner_dict = _get_group_and_owner_dict(
                context,
                group_type,
                group_id,
                user_list
            )

            try:
                # Remove all the previous admins within the group to make sure 
                # there is only one admin in the group
                _replace_group_owner(
                    context,
                    group_id,
                    owner_dict[u'id'],
                    new_user_dict[u'id'],
                    True
                )
                success_count += 1

            except Exception as e:
                failed_count += 1
                log.error(
                    'Error occured while trying to change the {}: {} \
                     owner to {}'
                    .format(
                        GROUP_DISPLAY_NAME[group_type],
                        c.group_dict['name'], new_user_id
                    )
                )
                log.error(e)

        if failed_count:
            h.flash_error(
                u'Could not change ownership to {} for {} {} groups'
                .format(
                    new_user_dict[u'display_name'],
                    failed_count,
                    GROUP_DISPLAY_NAME[group_type]
                ))

        if success_count:
            h.flash_success(
                u'Successfully changed ownership to {} for {} {} groups'
                .format(
                    new_user_dict[u'display_name'],
                    success_count,
                    GROUP_DISPLAY_NAME[group_type]
                ))

    return h.redirect_to(u'/' + group_type)


def _replace_organization_admin(old_admin, new_admin,
                                group_type=u'organization'):
    """
    Handles bulk admin replacement for organizations
    """

    old_user_dict = get_user_by_id(old_admin)

    if new_admin:
        new_user_dict = get_user_by_id(new_admin)
    else:
        new_user_dict = {u'display_name': u'None'}

    context = {u'model': model, u'session': model.Session}
    data_dict = {u'id': old_admin}

    organization_list = logic.get_action(u'organization_list_for_user')(
        context,
        data_dict
    )

    success_count = 0
    failed_count = 0
    is_listed = False

    for org in organization_list:
        group_dict = get_action(u'organization_show')(context, {
            u'id': org[u'id'], u'include_users': True})
        org_user_ids = []

        for user in group_dict[u'users']:
            org_user_ids.append(user[u'id'])

        # skip users that have permissions but aren't listed
        # as part of the organization admins
        if old_admin not in org_user_ids:
            continue

        is_listed = True

        try:
            _replace_group_owner(context, org[u'id'], old_admin, new_admin)
            success_count += 1
        except Exception as e:
            failed_count += 1
            log.error(
                u'Error occured while trying to replace the organization: \
                {} admin {} with {}'.format(
                    org[u'name'],
                    old_user_dict[u'display_name'],
                    new_user_dict[u'display_name']
                ))
            log.error(e)

    if failed_count:
        h.flash_error(
            u'Could replace {} with {} for {} organizations'.format(
                old_user_dict[u'display_name'],
                new_user_dict[u'display_name'],
                failed_count
            ))
    if success_count:
        h.flash_success(
            'Successfully replaced admin user: {} with {} for {} organizations'
            .format(
                old_user_dict[u'display_name'],
                new_user_dict[u'display_name'],
                success_count
            ))

    if not is_listed:
        h.flash_success(
            u'User {} is not listed as an admin in any organizations'
            .format(old_user_dict[u'display_name']))

    return h.redirect_to(u'/organization')


ed_group_admin_blueprint.add_url_rule(
    u'/<group_type>/change_owner/<group_id>',
    methods=['GET','POST'],
    view_func=change_owner
)

ed_group_admin_blueprint.add_url_rule(
    u'/<group_type>/bulk_change_owner',
    methods=['GET','POST'],
    view_func=bulk_change_owner
)

ed_group_admin_blueprint.add_url_rule(
    u'/organization/bulk_change_owner',
    methods=[u'POST'],
    view_func=bulk_change_owner
)
