import os
import sys
import logging
from io import StringIO
from flask import Blueprint

from ckanext.ed.datajson.package2pod import Package2Pod
from ckanext.ed.helpers import get_export_map_json

from ckanext.datajson.helpers import detect_publisher
from ckanext.datajson.views import DataJsonViews
from ckanext.datajson.plugin import DataJsonPlugin

from ckan.plugins.toolkit import config

log = logging.getLogger(__name__)

ed_datajson_blueprint = Blueprint(u'ed_datajson', __name__, url_prefix=u'/')


class EdDataJson(DataJsonViews):

    def make_json(self, export_type='datajson', owner_org=None):
        # Error handler for creating error log
        stream = StringIO()
        eh = logging.StreamHandler(stream)
        eh.setLevel(logging.WARN)
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        eh.setFormatter(formatter)
        log.addHandler(eh)

        data = ''
        output = []
        errors_json = []
        Package2Pod.seen_identifiers = set()

        try:
            # Build the data.json file.
            if owner_org:
                if 'datajson' == export_type:
                    # we didn't check ownership for this type of export, so never load private datasets here
                    packages = self._get_ckan_datasets(
                        org=owner_org
                    )
                    if not packages:
                        packages = self.get_packages(
                            owner_org=owner_org, with_private=False
                        )
                else:
                    packages = self.get_packages(
                        owner_org=owner_org, with_private=True
                    )
            else:
                # TODO: load data by pages
                # packages = p.toolkit.get_action("current_package_list_with_resources")(
                # None, {'limit': 50, 'page': 300})
                packages = self._get_ckan_datasets()
                # packages = p.toolkit.get_action("current_package_list_with_resources")(None, {})

            json_export_map = get_export_map_json(
                config.get('ckanext.datajson.map_filename')
            )

            if json_export_map:
                for pkg in packages:
                    if json_export_map.get('debug'):
                        output.append(pkg)
                    # logger.error('package: %s', json.dumps(pkg))
                    # logger.debug("processing %s" % (pkg.get('title')))
                    extras = dict(
                        [(x['key'], x['value']) for x in pkg.get('extras', {})]
                    )

                    # unredacted = all non-draft datasets (public + private)
                    # redacted = public-only, non-draft datasets
                    if export_type in ['unredacted', 'redacted']:
                        if 'Draft' == extras.get('publishing_status'):
                            # publisher = detect_publisher(extras)
                            # logger.warn("Dataset id=[%s], title=[%s], organization=[%s] omitted (%s)\n",
                            #             pkg.get('id'), pkg.get('title'), publisher,
                            #             'publishing_status: Draft')
                            # self._errors_json.append(OrderedDict([
                            #     ('id', pkg.get('id')),
                            #     ('name', pkg.get('name')),
                            #     ('title', pkg.get('title')),
                            #     ('errors', [(
                            #         'publishing_status: Draft',
                            #         [
                            #             'publishing_status: Draft'
                            #         ]
                            #     )])
                            # ]))

                            continue
                            # if 'redacted' == export_type and re.match(r'[Nn]on-public', extras.get('public_access_level')):
                            #     continue
                    # draft = all draft-only datasets
                    elif 'draft' == export_type:
                        if 'publishing_status' not in extras.keys() \
                           or extras.get('publishing_status') != 'Draft':
                            continue

                    redaction_enabled = ('redacted' == export_type)
                    datajson_entry = Package2Pod.convert_package(
                        pkg, json_export_map, redaction_enabled
                    )
                    errors = None

                    if 'errors' in datajson_entry.keys():
                        errors_json.append(datajson_entry)
                        errors = datajson_entry.get('errors')
                        datajson_entry = None

                    if datajson_entry and \
                            (not json_export_map.get('validation_enabled')
                             or self.is_valid(datajson_entry)):

                        output.append(datajson_entry)
                    else:
                        publisher = detect_publisher(extras)
                        if errors:
                            log.warn(
                                "Dataset id=[%s], title=[%s], organization=[%s] omitted, reason below:\n\t%s\n",
                                pkg.get('id', None), pkg.get('title', None), publisher, errors
                            )
                        else:
                            log.warn(
                                "Dataset id=[%s], title=[%s], organization=[%s] omitted, reason above.\n",
                                pkg.get('id', None), pkg.get('title', None), publisher
                            )

                data = Package2Pod.wrap_json_catalog(output, json_export_map)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            filename = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            log.error("%s : %s : %s : %s", exc_type,
                      filename, exc_tb.tb_lineno, e)
        # Get the error log
        eh.flush()
        error = stream.getvalue()
        eh.close()
        log.removeHandler(eh)
        stream.close()

        # Skip compression if we export whole /data.json catalog
        if 'datajson' == export_type:
            return data

        return self.write_zip(data, error, errors_json, zip_name=export_type)


# Calls to datajson_plugin are bypassed for now
# pending resolution of env variable issues
datajson_plugin = DataJsonPlugin()
ed_datajson = EdDataJson()


if True: #datajson_plugin.route_path:
    # /data.json and /data.jsonld (or other path as configured by user)

    datajson_path = config.get('ckanext.datajson.path', '/data.json')

    ed_datajson_blueprint.add_url_rule(
        datajson_path,
        view_func=ed_datajson.generate_json,
        methods=['GET', 'POST']
    )

    ed_datajson_blueprint.add_url_rule(
        '/organization/<org_id>/data.json',
        view_func=ed_datajson.generate_org_json,
        methods=['GET', 'POST']
    )

if True: #datajson_plugin.inventory_links_enabled:
    ed_datajson_blueprint.add_url_rule(
        '/organization/<org_id>/redacted.json',
        view_func=ed_datajson.generate_redacted,
        methods=['GET', 'POST']
    )

    ed_datajson_blueprint.add_url_rule(
        '/organization/<org_id>/unredacted.json',
        view_func=ed_datajson.generate_unredacted,
        methods=['GET', 'POST']
    )

    ed_datajson_blueprint.add_url_rule(
        '/organization/<org_id>/draft.json',
        view_func=ed_datajson.generate_draft,
        methods=['GET', 'POST']
    )

ed_datajson_blueprint.add_url_rule(
    '/pod/validate',
    view_func=ed_datajson.validator,
    methods=['GET', 'POST']
)

ed_datajson_blueprint.add_url_rule(
    '/harvester_versions',
    view_func=ed_datajson.get_versions,
    methods=['GET', 'POST']
)
