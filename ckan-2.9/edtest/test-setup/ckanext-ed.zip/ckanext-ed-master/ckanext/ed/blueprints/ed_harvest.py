import logging

from flask import Blueprint

import ckan.lib.helpers as h
import ckan.model as model
import ckan.plugins as p
from ckan.common import c, _
from ckan.lib.base import render, abort

log = logging.getLogger(__name__)

new_user_form = u'user/add_user.html'

ed_harvest_blueprint = Blueprint(u'ed_harvest', __name__, url_prefix=u'/')

get_action = p.toolkit.get_action


def clear(id):
    try:
        context = {
            u'model': model,
            u'user': c.user,
            u'session': model.Session
        }
        get_action('harvest_source_clear')(context, {'id': id})
        h.flash_success(_('Harvest source cleared'))
    except p.toolkit.ObjectNotFound:
        abort(404, _('Harvest source not found'))
    except p.toolkit.NotAuthorized:
        abort(401, p.toolkit._('Not authorized to see this page'))
    except Exception as e:
        msg = 'An error occurred: [%s]' % str(e)
        h.flash_error(msg)

    return h.redirect_to(h.url_for('harvest_admin', id=id))


def collection_index(id):
    return group_index(id, 'collection')


def group_index(id, group_type='collection'):

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user,
        'for_view': True,
        'with_private': False
    }

    harvest_source = get_action('harvest_source_show')(context, {'id': id})

    return render(
        'source/{}_index.html'.format(group_type),
        extra_vars={'harvest_source': harvest_source}
    )


ed_harvest_blueprint.add_url_rule(
    '/harvest/clear/<id>',
    view_func=clear,
    methods=[u'GET', u'POST']
)

ed_harvest_blueprint.add_url_rule(
    '/harvest/<id>/collection',
    view_func=collection_index,
    methods=[u'GET']
)
