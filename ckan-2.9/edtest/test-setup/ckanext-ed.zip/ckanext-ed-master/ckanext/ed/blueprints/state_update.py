from ckan import model, logic
from ckan.lib import base
import ckan.lib.helpers as h
from ckan.common import  request, c
import ckan.plugins as p
from flask import Blueprint

from ckanext.ed.mailer import mail_package_publish_update_to_user, mail_package_publish_request_to_admins
from ckanext.ed.helpers import is_admin
from ckanext.ed.activity_streams import workflow_activity_create


abort = base.abort
render = base.render

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
ObjectNotFound = p.toolkit.ObjectNotFound

get_action = logic.get_action
check_access = logic.check_access
parse_params = logic.parse_params
clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict

redirect_to = h.redirect_to

ed_state_update_blueprint = Blueprint(
    'ed_state_update', __name__,
    url_prefix='/dataset-publish'
)

def _raise_not_authz(id, action='reject'):
    '''Raises NotAuthorized if user is not the admin of the dataset
    '''
    if action == 'resubmit':
        check_access(
            'package_update', {
                'model': model, 'user': c.user}, {'id': id})
    else:
        # Check user is admin of the org pakcage is created for
        try:
            package_dict = get_action('package_show')(
                {'model': model, 'user': c.user}, {'id': id}
            )
        except ObjectNotFound:
            # We don't need ObjectNotFound here
            raise NotAuthorized

        is_admin_ = is_admin(c.user, package_dict['owner_org'])
        if not is_admin_:
            raise NotAuthorized

def _make_action(package_id, action='reject', feedback=None, make_public=None):
    '''Makes actions. One of reject, approve, resubmit. Checks authorized,
    Update package metadata appropriatelly and sends emails

    Note: Not used ATM
    '''
    action_props = {
        'reject': {
            'state': 'rejected',
            'message': 'Dataset "{0}" rejected',
            'event': 'rejection',
            'mail_func': mail_package_publish_update_to_user,
            'flash_func': h.flash_error,
            'activity': 'dataset_rejected'
        },
        'approve': {
            'state': 'approved',
            'message': ('Dataset "{0}" approved and made public'
                        if make_public else 'Dataset "{0}" approved'),
            'event': 'approval',
            'mail_func': mail_package_publish_update_to_user,
            'flash_func': h.flash_success,
            'activity': 'dataset_approved'
        },
        'resubmit': {
            'state': 'approval_pending',
            'message': 'Dataset "{0}" submitted',
            'event': 'request',
            'mail_func': mail_package_publish_request_to_admins,
            'flash_func': h.flash_success,
            'activity': 'resubmitted_for_review'
        }
    }
    # check access and state
    _raise_not_authz(package_id, action=action)
    context = {'model': model, 'user': c.user}
    patch_data = {
        'id': package_id, 'approval_state': action_props[action]['state']
    }
    if make_public:
        patch_data['private'] = False
    data_dict = get_action('package_patch')(context, patch_data)
    action_props[action]['mail_func'](
        context,
        data_dict,
        event=action_props[action]['event'],
        feedback=feedback
    )
    action_props[action]['flash_func'](
        action_props[action]['message'].format(data_dict['title']))
    workflow_activity_create(
        activity=action_props[action]['activity'],
        dataset_id=data_dict['id'],
        dataset_name=data_dict['name'],
        user=c.user,
        feedback=feedback
    )
    redirect_to(
        controller='package', action='read', id=data_dict['name'])

def approve(id):
    '''Approves dataset for publishing
    '''
    make_public = request.form.get(
        'make_public') == 'true'

    _make_action(id, 'approve', make_public=make_public)

def reject( id):
    '''Rejects dataset for publishing
    '''
    feedback = request.form.get(
        'feedback', 'No feedback provided')
    _make_action(id, 'reject', feedback=feedback)

def resubmit(self, id):
    '''Tesubmits dataset for publishing
    '''
    _make_action(id, 'resubmit')


ed_state_update_blueprint.add_url_rule(
    '/<id>/approve',
    view_func=approve
)
ed_state_update_blueprint.add_url_rule(
    '/<id>/reject',
    view_func=reject
)
ed_state_update_blueprint.add_url_rule(
    '/<id>/resubmit',
    view_func=resubmit
)
