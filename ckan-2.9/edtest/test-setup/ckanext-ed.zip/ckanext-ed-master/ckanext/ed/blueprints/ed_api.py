from flask import Blueprint
import logging
import urllib

from ckan import model, logic
from ckan.common import request, c
from ckan.views.api import _finish_ok

log = logging.getLogger(__name__)

check_access = logic.check_access
get_action = logic.get_action
NotAuthorized = logic.NotAuthorized


ed_api_blueprint = Blueprint(u'ed_api', __name__, url_prefix=u'/')


def dataset_autocomplete():
    q = request.form.get(u'incomplete', u'')
    limit = request.form.get(u'limit', 15)
    package_dicts = []

    if q:
        context = {
            u'model': model,
            u'session': model.Session,
            u'user': c.user,
            u'auth_user_obj': c.userobj
        }

        data_dict = {u'q': q, u'limit': limit}

        all_package_dicts = get_action(
            u'package_autocomplete')(context, data_dict)

        # Check that the user has permission to update the packages
        for item in all_package_dicts:
            try:
                pkg = get_action(u'package_show')(
                    context, {u'id': item[u'name']}
                )
                check_access(u'package_update', context, pkg)

            except NotAuthorized:
                continue

            package_dicts.append(item)

    resultSet = {u'ResultSet': {u'Result': package_dicts}}

    return _finish_ok(resultSet)


def tag_autocomplete(vocabulary):
    q = request.form.get(u'q', '')
    q = urllib.parse.unquote(q)
    limit = request.form.get(u'limit', 10)
    tag_names = []

    if q:
        context = {
            u'model': model,
            u'session': model.Session,
            u'user': c.user,
            u'auth_user_obj': c.userobj
        }

        data_dict = {u'q': q, u'limit': limit, u'vocabulary_id': vocabulary}

        tag_names = get_action(u'tag_autocomplete')(context, data_dict)

    resultSet = {
        u'ResultSet': {
            u'Result': [{u'Name': tag} for tag in tag_names]
        }
    }

    return _finish_ok(resultSet)


def spatial_autocomplete():
    return tag_autocomplete(u'spatial')


def level_of_data_autocomplete():
    return tag_autocomplete(u'level_of_data')


ed_api_blueprint.add_url_rule(
    u'/api/2/util/dataset/ed_autocomplete',
    view_func=dataset_autocomplete
)

ed_api_blueprint.add_url_rule(
    u'/api/2/util/tag/spatial_autocomplete',
    view_func=spatial_autocomplete
)

ed_api_blueprint.add_url_rule(
    u'/api/2/util/tag/level_of_data_autocomplete',
    view_func=level_of_data_autocomplete
)
