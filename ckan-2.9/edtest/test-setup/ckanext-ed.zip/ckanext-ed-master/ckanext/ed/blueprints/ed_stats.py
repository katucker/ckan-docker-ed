# encoding: utf-8

import json
import logging
from flask import Blueprint
import datetime
import enum

from ckan.lib.base import render
import ckanext.stats.stats as ckan_stats
import ckan.model as model

import logging
log = logging.getLogger(__name__)

stats_blueprint = Blueprint('ed_stats', __name__)

class ObjectType(enum.Enum):
    NEW_PACKAGES = 'new_packages'
    DELETED_PACKAGES = 'deleted_packages'
    PACKAGE_REVISIONS = 'package_revisions'

    @classmethod
    def is_enum_value(cls, value):
        """Check if a string is a value in this enum

        Returns:
            bool: True if it is a value, False if it is not
        """
        values = set(item.value for item in cls)
        if value in values:
            return True
        return False

class EdStats():

    def __init__(self):
        self.DATE_FORMAT = '%Y-%m-%d'
        self.session = model.meta.Session
        self._cumulative_num_pkgs = 0
        self._cumulative_new_pkgs = 0
        self._cumulative_del_pkgs = 0
        self._cumulative_pkg_revisions = 0
        self._earliest_date = None

        # TODO: Caching previously depended on pylons caching, which is no
        # longer available in python 3. An implementation would be needed to
        # have caching done with flask. For now this is manually disabled.
        # self.cache_enabled = p.toolkit.asbool(config.get('ckanext.stats.cache_enabled', 'True'))
        self.cache_enabled = False

        # Since we don't have caching, everything is wrapped in a class so
        # these request would be made more than once. This isn't as good as
        # caching, but should help performance
        self.package_revisions_by_week = self.get_by_week(ObjectType.PACKAGE_REVISIONS.value)
        self.deleted_packages_by_week = self.get_by_week(ObjectType.DELETED_PACKAGES.value)

        earliest_date = min(
            datetime.datetime.strptime(self.deleted_packages_by_week[0][0], self.DATE_FORMAT),
            datetime.datetime.strptime(self.package_revisions_by_week[0][0], self.DATE_FORMAT)
        )
        self._earliest_date = earliest_date.date()

        self.new_packages_by_week = self.get_by_week(ObjectType.NEW_PACKAGES.value)

        self._objects = {
            ObjectType.NEW_PACKAGES.value: self.new_packages_by_week,
            ObjectType.DELETED_PACKAGES.value: self.deleted_packages_by_week,
            ObjectType.PACKAGE_REVISIONS.value: self.package_revisions_by_week
        }
    
    def _parse_activity_data(self, data):
        """Parse the values from an activity data text
        This checks that it is a dataset and is public

        Args:
            data (str): text from data column on activity

        Returns:
            str: the package name if it meets the criteria or `None` if not
        """
        data_dict = json.loads(data)
        pkg_type = data_dict['package'].get('type', '')
        pkg_name = data_dict['package'].get('name', '')
        pkg_private = data_dict['package'].get('private', False)
        if str(pkg_type) == 'dataset' and not pkg_private:
            return pkg_name
        return None

    def get_date_week_started(self, date):
        """Get the first date of the week

        Args:
            date (`datetime` | `date`): the datetime or date object of the \
            current date 

        Returns:
            (`datetime` | `date`): returns a `date` or `datetime` object of \
            the first week day
        """
        return date - datetime.timedelta(days=date.weekday())
    
    def get_largest_categories(self, limit=10):
        """Get the largest categories

        Args:
            limit (int): the max number of rows to return

        Returns:
            `list`: A list of tuples in the form:
                (
                    (dict) {'id', 'type', 'name', 'title'},\n
                    (int) number of datasets in the group\n
                ) 
        """
        sql = """
            SELECT g.id, g.type, g.name, g.title, m.count
            FROM public.group g
            JOIN (
                SELECT m.group_id, COUNT(*) as count
                FROM member m JOIN package p
                ON m.table_id=p.id
                WHERE m.table_name = 'package'
                AND  m.state = 'active'
                AND p.type = 'dataset'
                AND p.state = 'active'
                AND p.private = false
                GROUP BY m.group_id
                ORDER BY COUNT DESC
            ) m
            ON g.id=m.group_id
            WHERE g.type = 'group'
            AND g.state = 'active'
            AND g.approval_status = 'approved'
            ORDER BY count DESC
            LIMIT :limit;
        """
        result_proxy = self.session.execute(sql, { "limit": limit })
        result = []
        for id, type, name, title, count in result_proxy:
            group = {
                'id': id,
                'type': type,
                'name': name,
                'title': title
            }
            result.append((group, int(count)))
        return result
    
    def get_top_tags(self, limit=10):
        """Get the tags with the most datasets

        Args:
            limit (int): the max number of rows to return

        Returns:
            `list`: A list of tuples in the form:
                (
                    (dict) {'id', 'name'},\n
                    (int) number of datasets in the tag\n
                ) 
        """
        sql = """
            SELECT t.id, t.name, pt.count
            FROM tag t
            JOIN (
                SELECT pt.tag_id, COUNT(*)
                FROM package_tag pt
                JOIN package p
                ON pt.package_id=p.id
                WHERE p.private = false
                AND p.type = 'dataset'
                AND p.state = 'active'
                AND pt.state = 'active'
                GROUP BY pt.tag_id
            ) pt
            ON t.id = pt.tag_id
            WHERE t.vocabulary_id IS NULL
            ORDER BY pt.count DESC
            LIMIT :limit;
        """
        result_proxy = self.session.execute(sql, { "limit": limit })
        result = []
        for id, name, count in result_proxy:
            tag = {
                'id': id,
                'name': name
            }
            result.append((tag, int(count)))
        return result

    def get_new_packages(self):
        """Get new packages

        Returns:
            Iterable object of python tuples of (`str`) package ids and \
            (`datetime.datetime`) dates of when the packages were created:\n
            [
                (
                    u'05f0332e-c926-4e78-b65f-d8d24d267a47',
                    datetime.datetime(2022, 6, 23, 12, 45, 55, 529451),
                    (str) package name
                )
                ...
            ]
        """
        if self.cache_enabled:
            return []
        else:
            # Get all non-draft public datasets and the dates they were created
            sql = """
                SELECT id, metadata_created
                FROM package
                WHERE private = false
                AND type = 'dataset'
                AND state in ('active', 'deleted')
                ORDER BY metadata_created ASC;
            """
            resultProxy =  self.session.execute(sql)
            result = []
            for pkg_id, _date in resultProxy:
                result.append((pkg_id, _date))
            return result

    def get_deleted_packages(self):
        """Get deleted packages

        Returns:
            Iterable object of python tuples of (`str`) package ids and \
            (`datetime.datetime`) dates of when the packages were deleted:\n
            [
                (
                    u'05f0332e-c926-4e78-b65f-d8d24d267a47',
                    datetime.datetime(2022, 6, 23, 12, 45, 55, 529451),
                    (str) package name
                )
                ...
            ]
        """
        if self.cache_enabled:
            return []
        else:
            # Get all deleted public datasets and the dates they were modified last
            sql = """
                SELECT id, metadata_modified
                FROM package
                WHERE private = false
                AND type = 'dataset'
                AND state = 'deleted'
                ORDER BY metadata_modified ASC;
            """
            resultProxy =  self.session.execute(sql)
            result = []
            for pkg_id, _date in resultProxy:
                result.append((pkg_id, _date))
            return result

    def get_package_revisions(self, start=None, end=None, order='ASC'):
        """Get all package revisions.
        This includes all package creation, updates and deletion.

        Args:
            start (`str`, optional): The earliest date to get the data from (YYYY-MM-DD)
            end (`str`, optional): The day after the latest date to get data for (YYYY-MM-DD)

        If both `start` and `end` are empty, all package revisions are returned.

        Returns:
            Iterable object of python tuples of (`str`) package ids and \
            (`datetime.datetime`) dates of when the packages were deleted:\n
            [
                (
                    u'05f0332e-c926-4e78-b65f-d8d24d267a47',
                    datetime.datetime(2022, 6, 23, 12, 45, 55, 529451),
                    (str) package name
                )
                ...
            ]
        """
        if self.cache_enabled:
            return []
        else:
            sql = """
                SELECT object_id, timestamp, data
                FROM activity
                WHERE activity_type in ('new package', 'changed package', 'deleted package')
            """
            if start:
                sql += " AND timestamp >= '{}' ".format(start)
            if end:
                sql += " AND timestamp < '{}' ".format(end)
            sql += """
                ORDER BY timestamp {};
            """.format(order)
            resultProxy =  self.session.execute(sql)
            result = []
            for pkg_id, timestamp, data in resultProxy:
                pkg_name = self._parse_activity_data(data)
                if pkg_name:
                    result.append((pkg_id, timestamp))
            return result

    def build_object_weekly_stats(self, object_type, week_commences, ids):
        """Build an iterable of tuples containing the weekly stats

        Args:
            object_type (ObjectType): new_packages | deleted packages | package_revisions
            week_commences (`datetime.date`): first week date
            ids (`list`): list of ids of the objects

        Returns:
            `tuple`: (
                week_commences (str) in format `YYYY-MM-DD`,\n
                ids (list),\n
                num (int) length of ids,\n
                _cumulative_new_pkgs (int) total number up to this week\n
            ) 
        """
        num = len(ids)
        cummulative = 0

        if object_type == ObjectType.NEW_PACKAGES.value:
            self._cumulative_new_pkgs += num
            cummulative = self._cumulative_new_pkgs
        if object_type == ObjectType.DELETED_PACKAGES.value:
            self._cumulative_del_pkgs += num
            cummulative = self._cumulative_del_pkgs
        if object_type == ObjectType.PACKAGE_REVISIONS.value:
            self._cumulative_pkg_revisions += num
            cummulative = self._cumulative_pkg_revisions

        return (week_commences.strftime(self.DATE_FORMAT),
                ids, num, cummulative)

    def get_by_week(self, object_type):
        """Get a list of the objects by week

        Args:
            object_type (ObjectType): new_packages | deleted packages | package_revisions

        Returns:
            `list`: A list of tuples in the form:
                (
                    week_commences (str) in format `YYYY-MM-DD`,\n
                    ids (list),\n
                    num (int) length of ids,\n
                    _cumulative_new_pkgs (int) total number up to this week\n
                ) 
        """
        if self.cache_enabled:
            return []

        if not ObjectType.is_enum_value(object_type):
            return []

        if object_type == ObjectType.NEW_PACKAGES.value:
            resultProxy = self.get_new_packages()
        if object_type == ObjectType.DELETED_PACKAGES.value:
            resultProxy = self.get_deleted_packages()
        if object_type == ObjectType.PACKAGE_REVISIONS.value:
            resultProxy = self.get_package_revisions()
        objects = [] # [[u'05f0332e-c926-4e78-b65f-d8d24d267a47',datetime.date(2022, 6, 23)]...]
        for pkg_id, _datetime in resultProxy:
            objects.append([pkg_id, _datetime.date()])

        first_date = objects[0][1] if objects else datetime.date.today()
        # Start from the earliest date a package was either changed or
        # deleted in the activity if it is earlier than the first time a package
        # was created. This would be an effect of a previous bug where some
        # created datasets were never marked in the activities
        # Not an expected bug, but could happen
        if object_type == ObjectType.NEW_PACKAGES.value and self._earliest_date and self._earliest_date < first_date:
            first_date = self._earliest_date

        week_commences = self.get_date_week_started(first_date)
        week_ends = week_commences + datetime.timedelta(days=7)

        # [(week_commences, [pkg_id1, pkg_id2, ...], num_pkgs, _cumulative_new_pkgs)]
        weekly_pkg_ids = []
        pkg_id_stack = []
        
        for pkg_id, _date in objects:
            if _date >= week_ends:
                while week_ends <= _date:
                    weekly_pkg_ids.append(self.build_object_weekly_stats(object_type, week_commences, pkg_id_stack))
                    pkg_id_stack = []
                    week_commences = week_ends
                    week_ends = week_commences + datetime.timedelta(days=7)
            pkg_id_stack.append(pkg_id)
        weekly_pkg_ids.append(self.build_object_weekly_stats(object_type, week_commences, pkg_id_stack))
        today = datetime.date.today()

        while week_ends <= today:
            week_commences = week_ends
            week_ends = week_commences + datetime.timedelta(days=7)
            weekly_pkg_ids.append(self.build_object_weekly_stats(object_type, week_commences, []))
        return weekly_pkg_ids        

    def get_num_packages_by_week(self):
        """Get the aggregate number of packages each week

        Returns:
            list: [(week_commences, num_packages, cumulative_num_pkgs])...]
        """
        new_packages_by_week = self.new_packages_by_week
        deleted_packages_by_week = self.deleted_packages_by_week

        min_date = min(
            datetime.datetime.strptime(new_packages_by_week[0][0], self.DATE_FORMAT),
            datetime.datetime.strptime(deleted_packages_by_week[0][0], self.DATE_FORMAT))
        first_date = min_date.date()

        self._cumulative_num_pkgs = 0

        week_ends = first_date
        today = datetime.date.today()
        new_package_week_index = 0
        deleted_package_week_index = 0
        weekly_numbers = [] # [(week_commences, num_packages, cumulative_num_pkgs])]
        while week_ends <= today:
            week_commences = week_ends
            week_ends = week_commences + datetime.timedelta(days=7)
            if datetime.datetime.strptime(new_packages_by_week[new_package_week_index][0], self.DATE_FORMAT).date() == week_commences:
                new_pkg_ids = new_packages_by_week[new_package_week_index][1]
                new_package_week_index += 1
            else:
                new_pkg_ids = []
            if datetime.datetime.strptime(deleted_packages_by_week[deleted_package_week_index][0], self.DATE_FORMAT).date() == week_commences:
                deleted_pkg_ids = deleted_packages_by_week[deleted_package_week_index][1]
                deleted_package_week_index += 1
            else:
                deleted_pkg_ids = []

            num_pkgs = len(new_pkg_ids) - len(deleted_pkg_ids)
            self._cumulative_num_pkgs += num_pkgs
            weekly_numbers.append((week_commences.strftime(self.DATE_FORMAT),
                    num_pkgs, self._cumulative_num_pkgs))
        # just check we got to the end of each count
        assert new_package_week_index == len(new_packages_by_week)
        assert deleted_package_week_index == len(deleted_packages_by_week)
        return weekly_numbers

    def most_edited_packages(self, limit=10):
        """Get the active public datasets with the most edits

        Args:
            limit (int): the max number of rows to return

        Returns:
            `list`: A list of tuples in the form:
                (
                    (dict) {'id', 'name', 'title'},\n
                    (int) number of edits of the dataset\n
                ) 
        """
        sql = """
            SELECT r.object_id, r.count, d.name, d.title
            FROM (
                SELECT a.object_id, count(*) as count
                FROM activity a JOIN package p
                ON a.object_id=p.id
                WHERE a.activity_type = 'changed package'
                AND p.state = 'active'
                AND p.private != true
                AND p.type = 'dataset'
                GROUP BY object_id
                ORDER BY count DESC
                LIMIT :limit
            ) r JOIN package d
            ON r.object_id=d.id
            ORDER BY count DESC;
        """
        result_proxy = self.session.execute(sql, { "limit": limit })
        result = []
        for id, count, name, title in result_proxy:
            package = { 'id': id, 'name': name, 'title': title }
            result.append((package, int(count)))
        return result

##################################################################################
##################################################################################
@stats_blueprint.route('/stats')
def index():
    stats = ckan_stats.Stats()
    ed_stats = EdStats()

    num_packages_by_week = ed_stats.get_num_packages_by_week()
    most_edited_packages = ed_stats.most_edited_packages()
    package_revisions_by_week = ed_stats.get_by_week('package_revisions')

    raw_packages_by_week = []
    for week_date, num_packages, cumulative_num_packages in num_packages_by_week:
        raw_packages_by_week.append({
            'date': datetime.datetime.strptime(week_date, ed_stats.DATE_FORMAT).date(),
            'date_text': week_date,
            'total_packages': cumulative_num_packages
        })

    raw_all_package_revisions = []
    for week_date, revs, num_revisions, cumulative_num_revisions in package_revisions_by_week:
        raw_all_package_revisions.append({
            'date': datetime.datetime.strptime(week_date, ed_stats.DATE_FORMAT).date(),
            'total_revisions': num_revisions
        })

    raw_new_datasets = []
    for week_date, pkgs, num_packages, cumulative_num_packages in ed_stats.new_packages_by_week:
        raw_new_datasets.append({
            'date': datetime.datetime.strptime(week_date, ed_stats.DATE_FORMAT).date(),
            'new_packages': num_packages
        })

    extra_vars = {
        'top_rated_packages': stats.top_rated_packages(),
        'largest_groups': ed_stats.get_largest_categories(),
        'top_tags': ed_stats.get_top_tags(),
        'raw_packages_by_week': raw_packages_by_week,
        'most_edited_packages': most_edited_packages,
        'raw_all_package_revisions': raw_all_package_revisions,
        'raw_new_datasets': raw_new_datasets
    }
    return render(u'ckanext/stats/index.html', extra_vars)