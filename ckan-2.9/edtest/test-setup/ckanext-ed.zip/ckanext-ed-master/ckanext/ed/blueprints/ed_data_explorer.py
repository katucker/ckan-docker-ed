import logging
import ckan.lib.helpers as h
import ckan.lib.navl.dictization_functions as dict_fns

from ckan import model, logic
from ckan.lib import base
from ckan.common import request, c, _, g
from ckan.logic import NotFound
from ckan.views.home import CACHE_PARAMETERS
from flask import Blueprint
from flask.views import MethodView
from ckanext.ed import activity_streams
from ckanext.ed.mailer import mail_data_explorer_to_user, mail_data_explorer_to_sysadmins
from ckan.views.group import (
    _get_group_template, CreateGroupView, read, EditGroupView,
    DeleteGroupView, _guess_group_type, _setup_template_variables, _get_group_template,
    _check_access, index, set_org
)

from ckanext.ed.blueprints.utils import _ensure_controller_matches_group_type

render = base.render
abort = base.abort

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
check_access = logic.check_access
get_action = logic.get_action
tuplize_dict = logic.tuplize_dict
clean_dict = logic.clean_dict
parse_params = logic.parse_params
flatten_to_string_key = logic.flatten_to_string_key

log = logging.getLogger(__name__)

abort = base.abort
render = base.render
check_access = logic.check_access

ed_data_explorer_blueprint = Blueprint(
    'ed_data_explorer', __name__,
    url_prefix='/',
    url_defaults={
        'group_type': 'data_explorer',
        'is_organization': False
    }
)

group_types = ['data_explorer']

def _guess_group_type(expecting_name=False):
    """
        The base CKAN function gets the group_type from the URL,
        this is a problem in the case when the URL mapping is changed
        and instead of group we use something else.
    """
    gt = group_types[0]
    return gt


def index(group_type, is_organization=False):

    # group_type = _guess_group_type()

    page = h.get_page_number(request.params) or 1
    items_per_page = 10

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj,
                'for_view': True, 'ignore_auth' : True}

    data_dict_page_results = {
        'all_fields': True,
        'type' : group_type,
        'approval_status' : 'approved',
        'limit': items_per_page,
        'offset': items_per_page * (page - 1),
        'include_extras': True
    }

    data_dict_global_results = {
            'all_fields': True,
            'approval_status' : 'approved',
            'type': group_type,
            'include_extras': True
    }

    try:
        global_results = get_action('group_list')(
                    context, data_dict_global_results)

        global_results = _filter_non_approved(global_results)

        # Commenting out this method because the 
        # _filter_non_approved(page_results) would return less than the
        # items per page when there are non approved items from the
        # group_list page_result
        # page_results = logic.get_action('group_list')(context,
        #                                     data_dict_page_results)
        # page_results = self._filter_non_approved(page_results)

        # Get page_results from global_results instead
        page_results = get_page_results_from_global(
            global_results, page, items_per_page
        )

        c.page = h.Page(
            collection=global_results,
            page=page,
            url=h.pager_url,
            items_per_page=items_per_page,
        )

        c.page.items = page_results

        group_list = global_results
        group_count = len(group_list)

        data_explorer = []

        for group in page_results:
            data_explorer.append({
                'id':group['id'], 
                'name':group['name'], 
                'title': group['title'], 
                'description':group['description'],
                'url':group.get('url', ''),
                'image_url':group.get('image_url', ''),
                'data_explorer_image':group.get('data_explorer_image', '')

            })

        vars = {}
        vars['data_explorer'] = data_explorer
        vars['group_type'] = _guess_group_type()
        vars['count'] = group_count

        return render(_get_group_template(
            u'index_template', group_type), vars)                  

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Data Explorer not found')) 


def approval(group_type, is_organization=False):
    _raise_not_authz()

    group_type = _guess_group_type()

    context = {'model': model, 'session': model.Session,
               'user': c.user, 'auth_user_obj': c.userobj}

    user_dict = c.user

    data_dict = {
        'all_fields': True,
        'type': group_type,
        'include_extras': True
    }

    try:
        results = logic.get_action('group_list')(context,
                                                data_dict)
        ### filtering by state
        non_approved_data_explorers = []
        for group in results:
            if group['approval_status'] == 'approval_pending':
                non_approved_data_explorers.append(group)
    except (NotFound, NotAuthorized) as e:
        abort(404, _('Data Explorer not found'))

    vars = {}
    vars['user_dict'] = user_dict
    vars['data_explorer'] = non_approved_data_explorers
    vars['group_type'] = group_type
    vars['count'] = len(non_approved_data_explorers)

    template = 'data_explorer/approval.html'
    return render(template, extra_vars=vars)


def item_approval(id, group_type, is_organization=False):
    _raise_not_authz()

    context = {'model': model, 'session': model.Session,
            'user': c.user, 'auth_user_obj': c.userobj}

    data_dict = {
        'id' : id
    }

    if request.method == 'POST':
        return approve(id)

    try:
        group = logic.get_action('group_show')(context, data_dict)
    except (NotFound, NotAuthorized) as e:
        abort(404, _('Data Explorer not found'))

    vars = {}
    vars['data_explorer'] = group

    template = 'data_explorer/item_approval.html'
    return render(template, extra_vars=vars)


def approve(id, group_type, is_organization=False):
    _raise_not_authz()

    context = {'model': model, 'session': model.Session,
            'user': c.user, 'auth_user_obj': c.userobj,
                'for_edit': True}

    data_dict = {
            'id' : id,
            'approval_status' : 'approved'
    }

    try:
        group = logic.get_action('group_patch')(context, data_dict)

        # to get the group in the plugin schema
        group = logic.get_action('group_show')(context, {'id' : group.get('id')})
        
        data_dict = group
        # create activity
        group_type = group_types[0]
        activity_streams.workflow_activity_create(group_type + '_approved', 
            group_type, data_dict, c.user)

        # send email
        mail_data_explorer_to_user(data_dict, 'approval')

        c.group_dict = group
        #h.flash_notice(_('Data Explorer approved.'))
        return h.redirect_to('ed_data_explorer.approval')

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Data Explorer not found'))


def reject(id, group_type, is_organization=False):
    _raise_not_authz()

    context = {'model': model, 'session': model.Session,
            'user': c.user, 'auth_user_obj': c.userobj,
                'for_edit': True}

    data_dict = {
        'id' : id,
        'approval_status' : 'rejected'
    }

    try:
        group = logic.get_action('group_patch')(context, data_dict)

        # to get the group in the plugin schema
        group = logic.get_action('group_show')(context, {'id' : group.get('id')})

        # get feedback
        feedback = request.form.get('feedback', u'')

        data_dict = group
        # create activity
        group_type = group_types[0]
        activity_streams.workflow_activity_create(group_type + "_rejected", 
            group_type, data_dict, c.user, feedback)

        # send email
        mail_data_explorer_to_user(data_dict, 'reject', feedback)

        c.group_dict = data_dict
        #h.flash_notice(_('Data Explorer rejected.'))
        return h.redirect_to('ed_data_explorer.approval')

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Data Explorer not found'))


def _raise_not_authz():
    '''Raises NotAuthorized if user is not a sysadmin
    '''
    if not c.userobj:
        abort(403, _('Unauthorized to see this page.'))

    is_admin = c.userobj.sysadmin
    if not is_admin:
        abort(403, _('Unauthorized to see this page.'))


def _filter_non_approved(data_explorers):

    filtered_data_explorers = []
    for data_explorer in data_explorers:
        if data_explorer['approval_status'] == 'approved':
            filtered_data_explorers.append(data_explorer)
    
    return filtered_data_explorers


def _get_data_explorers_hard_coded():

    data_explorer = []

    data_explorer.append({ 'title' : 'College Scorecard', 
                    'description' : 'The College Scorecard is a US Department of Education data initiative providing transparency and consumer information related to individual institutions of higher education and individual fields of study within those institutions. College Scorecard brings together information on postsecondary costs, graduation rates, student loan debt, post-college earnings, and more.',
                    'url' : 'https://collegescorecard.ed.gov/' })
    data_explorer.append({ 'title' : 'FSA Data Center', 
                    'description' : 'The Federal Student Aid Data Center is the centralized source for information relating to the federal financial assistance programs. The information available in the Data Center is divided into the following four categories: student aid data, school data, Federal Family Education Loan (FFEL) Program Lender and Guaranty Agency Reports, and Business Information Resources.',
                    'url' : 'https://studentaid.gov/data-center' })
    data_explorer.append({ 'title' : 'ED Data Express', 
                    'description' : "ED Data Express is a Web site designed to improve the public's ability to access and explore high-value state- and district-level education data collected by the U.S. Department of Education.",
                    'url' : 'https://eddataexpress.ed.gov/' })  
    data_explorer.append({ 'title' : 'ED Data Inventory', 
                    'description' : 'The ED Data Inventory includes data collected as part of grant activities, along with statistical data collected to allow publication of valuable statistics about the state of education in this country. The ED Data Inventory includes descriptive information about each data collection, along with information on the specific data elements in individual collections.',
                    'url' : 'https://datainventory.ed.gov/' })
    data_explorer.append({ 'title' : 'NAEP Data Explorer', 
                    'description' : 'With the NAEP Data Explorer users can create statistical tables, charts, maps to help you find answers. Explore decades of assessment results, as well as information about factors that may be related to student learning.',
                    'url' : 'https://www.nationsreportcard.gov/ndecore/landing' })
    data_explorer.append({ 'title' : 'Civil Rights Data Collection', 
                    'description' : 'The Civil Rights Data Collection (CRDC) is a biennial (i.e., every other school year) survey required by the U.S. Department of Education&#39s (Department) Office for Civil Rights (OCR) since 1968.  The information collected includes wide-ranging education access and equity data  from the nation&#39s public schools.',
                    'url' : 'https://ocrdata.ed.gov/' })
    data_explorer.append({ 'title' : 'The Database of Postsecondary Institutions and Programs (DAPIP)', 
                    'description' : 'The Database of Accredited Postsecondary Institutions and Programs contains information reported to the U.S. Department of Education directly by recognized accrediting agencies and state approval agencies. The database reflects additional information as it is received from recognized accrediting agencies and state approval agencies. This reported information is not audited. The U.S. Department of Education cannot, therefore, guarantee that the information contained in the database is accurate, current, or complete. For the most accurate and current information, contact the appropriate agency.',
                    'url' : 'https://ope.ed.gov/dapip/#/home' })
    data_explorer.append({ 'title' : 'Campus Safety and Security  Data Analysis Cutting Tool', 
                    'description' : 'This analysis cutting tool was designed to provide rapid customized reports for public inquiries relating to campus crime and fire data.',
                    'url' : 'https://ope.ed.gov/campussafety/' })
    data_explorer.append({ 'title' : 'Equity in Athletics Data Analysis Cutting Tool', 
                    'description' : 'This analysis cutting tool was designed to provide rapid customized reports for public inquiries relating to equity in athletics data.',
                    'url' : 'https://ope.ed.gov/athletics/#/' })
    data_explorer.append({ 'title' : "Education Demographics and Geographic Estimates (EDGE) Open Data", 
                    'description' : 'A geodata initiative from the National Center for Education Statistics.',
                    'url' : 'https://data-nces.opendata.arcgis.com/' })
    data_explorer.append({ 'title' : 'Perkins Data Explorer', 
                    'description' : 'Perkins Data Explorer lets you quickly create custom reports using data reported in the Consolidated Annual Report (CAR).',
                    'url' : 'https://perkins.ed.gov/pims/DataExplorer' })
    data_explorer.append({ 'title' : 'National Reporting System for Adult Education', 
                    'description' : 'The National Reporting System for Adult Education (NRS) is an outcome-based reporting system for the State-administered, federally funded adult education program.',
                    'url' : 'https://nrs.ed.gov/' })
    data_explorer.append({ 'title' : 'Teacher Education Title II Reports', 
                    'description' : 'This website provides information about Title II (Sections 205 through 208) of the Higher Education Act. This website includes public access to data about teacher preparation and certification.',
                    'url' : 'https://title2.ed.gov/Public/Home.aspx' })
    data_explorer.append({ 'title' : 'Common Core of Data', 
                    'description' : 'The primary purpose of the CCD is to provide basic information on public elementary and secondary schools, local education agencies (LEAs), and state education agencies (SEAs) for each state, the District of Columbia, and the outlying territories with a U.S. relationship.',
                    'url' : 'https://nces.ed.gov/ccd/files.asp' })
    data_explorer.append({ 'title' : 'Elementary/Secondary Information System (ELSI)', 
                    'description' : 'The Elementary/Secondary Information System (ELSI) is an NCES web application that allows users to quickly view public and private school data and create custom tables and charts using data from the Common Core of Data (CCD) and Private School Survey (PSS).',
                    'url' : 'https://nces.ed.gov/ccd/elsi/default.aspx?agree=0' })
    data_explorer.append({ 'title' : 'NCES Data Tools', 
                    'description' : 'This landing page has links to multiple data tools and explorers developed by NCES.',
                    'url' : 'https://nces.ed.gov/datatools/' })  
    data_explorer.append({ 'title' : 'Integrated Postsecondary Education Data System (IPEDS)', 
                    'description' : 'Information on U.S. colleges, universities, and technical and vocational institutions. Institutions submit data through 12 interrelated survey components about general higher education topics for 3 reporting periods.',
                    'url' : 'https://nces.ed.gov/ipeds/' })

    return data_explorer


def get_page_results_from_global(global_results, page=1, items_per_page=10):
    # Get starting point
    start = items_per_page * (page - 1)
    # Get ending point
    end = start + items_per_page

    return global_results[start:end]


def edit(id, group_type=None, is_organization=False, data=None, errors=None, error_summary=None):
    group_type = _ensure_controller_matches_group_type(
        id.split('@')[0], group_types)

    context = {
        'model': model, 'session': model.Session,
        'user': c.user,
        'save': 'save' in request.form,
        'for_edit': True
    }
    data_dict = {'id': id, 'include_datasets': False}

    if context['save'] and not data and request.method == 'POST':
        return _save_edit(id, context)

    try:
        data_dict['include_datasets'] = False
        old_data = get_action('group_show')(context, data_dict)
        c.grouptitle = old_data.get('title')
        c.groupname = old_data.get('name')
        data = data or old_data
    except (NotFound, NotAuthorized):
        abort(404, _('Group not found'))

    group = context.get("group")
    c.group = group
    c.group_dict = get_action('group_show')(context, data_dict)

    try:
        _check_access('group_update', context)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))

    errors = errors or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'edit',
            'group_type': group_type}

    _setup_template_variables(context, data, group_type=group_type)
    form = base.render(
            _get_group_template(u'group_form', group_type), vars)
    c.form = form
    vars["form"] = form

    if c.group_dict.get('approval_status') == 'approval_pending':
        mail_data_explorer_to_sysadmins(c.group_dict, 'request')

    return base.render(
        _get_group_template(u'edit_template', group_type), vars)


def _save_edit(id, context):
    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        data_dict.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))

        context['message'] = data_dict.get('log_message', '')
        data_dict['id'] = id
        context['allow_partial_update'] = True

        if not data_dict.get('scraped_from', None):
            data_dict['scraped_from'] = u''

        if not data_dict.get('source_url', None):
            data_dict['source_url'] = u''

        group = get_action('group_update')(context, data_dict)

        #try:
            # FIXME: first save doesn't work, after first attempt it gets an id, then it works
        #    group = ._action('group_update')(context, data_dict)
        #except:
        #    group = ._action('group_update')(context, data_dict)
        #if id != group['name']:
        #    ._force_reindex(group)

        return h.redirect_to('%s.read' % group['type'], id=group['name'])
    except (NotFound, NotAuthorized) as e:
        abort(404, _('Group not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return edit(id, data_dict, errors, error_summary)


class CreateGroupView(MethodView):
    u'''Create group view '''

    def _prepare(self, data=None):
        if data and u'type' in data:
            group_type = data['type']
        else:
            group_type = _guess_group_type()
        if data:
            data['type'] = group_type

        context = {
            u'model': model,
            u'session': model.Session,
            u'user': g.user,
            u'save': u'save' in request.params,
            u'parent': request.params.get(u'parent', None),
            u'group_type': group_type
        }

        try:
            _check_access(u'group_create', context)
        except NotAuthorized:
            base.abort(403, _(u'Unauthorized to create a group'))

        return context

    def post(self, group_type, is_organization):
        set_org(is_organization)
        context = self._prepare()
        try:
            data_dict = clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.form))))
            data_dict.update(clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
            ))
            data_dict['type'] = group_type or u'group'
            context['message'] = data_dict.get(u'log_message', u'')
            data_dict['users'] = [{u'name': g.user, u'capacity': u'admin'}]
            group = get_action(u'group_create')(context, data_dict)
            mail_data_explorer_to_sysadmins(group, 'request')

        except (NotFound, NotAuthorized) as e:
            base.abort(404, _(u'Group not found'))
        except dict_fns.DataError:
            base.abort(400, _(u'Integrity Error'))
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return self.get(group_type, is_organization,
                            data_dict, errors, error_summary)

        return h.redirect_to(group['type'] + u'.read', id=group['name'])

    def get(self, group_type, is_organization,
            data=None, errors=None, error_summary=None):
        extra_vars = {}
        set_org(is_organization)
        context = self._prepare()
        data = data or clean_dict(
            dict_fns.unflatten(
                tuplize_dict(
                    parse_params(request.args, ignore_keys=CACHE_PARAMETERS)
                )
            )
        )

        if not data.get(u'image_url', u'').startswith(u'http'):
            data.pop(u'image_url', None)
        errors = errors or {}
        error_summary = error_summary or {}
        extra_vars = {
            u'data': data,
            u'errors': errors,
            u'error_summary': error_summary,
            u'action': u'new',
            u'group_type': group_type
        }
        _setup_template_variables(
            context, data, group_type=group_type)
        form = base.render(
            _get_group_template(u'group_form', group_type), extra_vars)

        # TODO: Remove
        # ckan 2.9: Adding variables that were removed from c object for
        # compatibility with templates in existing extensions
        g.form = form

        extra_vars["form"] = form
        return base.render(
            _get_group_template(u'new_template', group_type), extra_vars)


ed_data_explorer_blueprint.add_url_rule(
    '/data_explorer',
    view_func=index,
    strict_slashes=False,
    methods=[u'GET', u'POST']
)
ed_data_explorer_blueprint.add_url_rule(
    '/data_explorer/new',
    methods=[u'GET', u'POST'],
    view_func=CreateGroupView.as_view('new')
)
ed_data_explorer_blueprint.add_url_rule(
    '/data_explorer/<id>', view_func=read
)
ed_data_explorer_blueprint.add_url_rule(
    '/data_explorer/edit/<id>',
    methods=['GET', 'POST'],
    view_func=edit
)
ed_data_explorer_blueprint.add_url_rule(
    '/data_explorer/delete/<id>',
    methods=['GET', 'POST'],
    view_func=DeleteGroupView.as_view('delete')
)
ed_data_explorer_blueprint.add_url_rule(
    '/dashboard/approval/data-explorer',
    view_func=approval
)
ed_data_explorer_blueprint.add_url_rule(
    '/dashboard/approval/data-explorer/<id>',
    view_func=item_approval
)
ed_data_explorer_blueprint.add_url_rule(
    '/dashboard/approval/data-explorer/<id>/approve',
    methods=['GET', 'POST'],
    view_func=approve
)
ed_data_explorer_blueprint.add_url_rule(
    '/dashboard/approval/data-explorer/<id>/reject',
    methods=['GET', 'POST'],
    view_func=reject
)
