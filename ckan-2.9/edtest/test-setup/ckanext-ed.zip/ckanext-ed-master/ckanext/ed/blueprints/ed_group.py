from flask import Blueprint
import logging

from ckan import model
from ckan.common import _, c, request
from ckan.lib import base, helpers
from ckan.logic import NotAuthorized, NotFound, ValidationError
from ckan.plugins import toolkit
from ckan.views.group import (
    _check_access, _render_template,
    index as group_index, CreateGroupView,
    EditGroupView, BulkProcessView,
    MembersGroupView, read
)
from ckan.views.user import _extra_template_variables
from ckan.views import group as group_views

log = logging.getLogger(__name__)

ed_group_blueprint = Blueprint(u'ed_group', __name__, url_prefix=u'/',
    url_defaults={
        'group_type': 'group',
        'is_organization': False
    }
)

abort = base.abort
render = base.render
get_action = toolkit.get_action

from ckan.common import config


def _guess_group_type(expecting_name=False):
    return u'group'


def delete(id: str, group_type: str, is_organization=False):
    '''Delete a topic'''
    #group_type = _ensure_controller_matches_group_type(id)
    group_type = _guess_group_type()

    if u'cancel' in request.params:
        helpers.redirect_to(u'group.edit', id=id)

    context = {
        u'model': model,
        u'session': model.Session,
        u'user': c.user
    }

    try:
        _check_access(u'group_delete', context, {'id': id})

    except NotAuthorized:
        abort(403, _(u'Unauthorized to delete category %s') % '')

    try:
        if request.method == u'POST':
            get_action(u'group_delete')(context, {u'id': id})

            if group_type == u'organization':
                helpers.flash_notice(_(u'Organization has been deleted.'))

            elif group_type == u'group':
                helpers.flash_notice(_(u'Category has been deleted.'))

            else:
                helpers.flash_notice(
                    _(u'%s has been deleted.') % _(group_type.capitalize())
                )

            helpers.redirect_to(u'group.index')

        c.group_dict = get_action(u'group_show')(context, {u'id': id})

    except NotAuthorized:
        abort(403, _(u'Unauthorized to delete category %s') % '')

    except NotFound:
        abort(404, _(u'Category not found'))

    except ValidationError as e:
        helpers.flash_error(e.error_dict[u'message'])
        helpers.redirect_to(u'group.read', id=id)

    return _render_template(u'group/confirm_delete.html', group_type)


def list_groups(group_type: str, is_organization: bool = False):
    '''Lists all the topics for an user in the dashboard
    '''
    if not toolkit.c.userobj:
        base.abort(403, _(u'Not authorized to see this page'))

    context = {
        u'for_view': True,
        u'user': c.user,
        u'auth_user_obj': c.userobj
    }
    data_dict = {
        u'user_obj': c.userobj,
        u'include_datasets': True
    }
    extra_vars = _extra_template_variables(context, data_dict)

    return base.render(u'user/dashboard_groups.html', extra_vars)


ed_group_blueprint.add_url_rule(
    u'/dashboard/topics',
    methods=[u'GET', u'POST'],
    view_func=list_groups
)

ed_group_blueprint.add_url_rule(
    u'/category',
    methods=[u'GET'],
    view_func=group_index
)

ed_group_blueprint.add_url_rule(
    u'/category/new',
    methods=[u'GET', u'POST'],
    view_func=CreateGroupView.as_view(str(u'new'))
)

ed_group_blueprint.add_url_rule(
    u'/category/delete/<id>',
    methods=[u'GET', u'POST'],
    view_func=delete
)

ACTIONS = {
    u'about': group_views.about,
    u'activity': group_views.activity,
    u'admins': group_views.admins,
    u'members': group_views.members,
    u'member_new': MembersGroupView.as_view(str(u'member_new')),
    u'member_delete': group_views.member_delete,
    u'history': group_views.history,
    u'followers': group_views.followers,
    u'follow': group_views.follow,
    u'unfollow': group_views.unfollow
}

for action_name, action in ACTIONS.items():
    ed_group_blueprint.add_url_rule(
        f'/category/{action_name}/<id>',
        methods=[u'GET', u'POST'],
        view_func=action
    )


ed_group_blueprint.add_url_rule(
    u'/category/<id>',
    methods=[u'GET'],
    view_func=read
)

ed_group_blueprint.add_url_rule(
    u'/category/edit/<id>',
    view_func=EditGroupView.as_view(str(u'edit'))
)

ed_group_blueprint.add_url_rule(
    u'/category/bulk_process/<id>',
    view_func=BulkProcessView.as_view(str(u'bulk_process'))
)
