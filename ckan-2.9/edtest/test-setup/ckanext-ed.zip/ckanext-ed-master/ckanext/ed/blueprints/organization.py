import ckan.lib.base as base
from ckan.views.dataset import (
    _get_pkg_template, _get_package_type
)

from ckan.views.group import (
    _action, _get_group_template, _db_to_form_schema,
    _update_facet_titles, _setup_template_variables, set_org,
    CreateGroupView, _check_access, _get_search_details, _replace_group_org,

)
import ckan.plugins.toolkit as toolkit
import ckan.logic as logic
from ckanext.ed import helpers
import logging
import datetime as dt
import requests
import os
import csv
from collections import OrderedDict
import ckan.lib.search as search
from io import StringIO
import ckan.lib.plugins as lib_plugins
from ckan import model
import ckan.authz as authz
import ckan.lib.helpers as h
import ckan.lib.mailer as mailer
from ckan.common import c, request, _, config, g
import ckan.lib.navl.dictization_functions as dict_fns
from ckan.views.home import CACHE_PARAMETERS
from flask import Blueprint
from flask.views import MethodView
import six
from urllib.parse import urlencode

from ckanext.ed.helpers import render_markdown
import ckanext.ed.model as ed_model

log = logging.getLogger(__name__)

render = base.render
abort = base.abort

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
check_access = logic.check_access
get_action = logic.get_action
clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict
ValidationError = logic.ValidationError
lookup_group_controller = lib_plugins.lookup_group_controller
parse_params = logic.parse_params

organization_blueprint = Blueprint('ed_organization', __name__, url_prefix=u'/organization',
                                    url_defaults={u'group_type': u'organization',
                                                  u'is_organization': True})

# def _ensure_controller_matches_group_type(id):
#     group = model.Group.get(id)
#     if group is None:
#         abort(404, _('Group not found'))
#     if group.type not in self.group_types:
#         abort(404, _('Incorrect group type'))
#     return group.type

def _guess_group_type(expecting_name=False):
    """
        The base CKAN function gets the group_type from the URL,
        this is a problem in the case when the URL mapping is changed
        and instead of group we use something else.
        That will require overriding the OrganizationController.

    """
    gt = 'organization'

    return gt


def index(group_type, is_organization):
    group_type = _guess_group_type()
    extra_vars = {}
    set_org(is_organization)
    page = h.get_page_number(request.params) or 1
    items_per_page = 100

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'with_private': False}

    q = c.q = request.form.get('q', '')
    sort_by = c.sort_by_selected = request.form.get('sort')
    try:
        check_access('site_read', context)
        check_access('group_list', context)
    except NotAuthorized:
        abort(403, _('Not authorized to see this page'))

    # pass user info to context as needed to view private datasets of
    # orgs correctly
    if c.userobj:
        context['user_id'] = c.userobj.id
        context['user_is_admin'] = c.userobj.sysadmin

    try:
        data_dict_global_results = {
            'all_fields': False,
            'q': q,
            'sort': sort_by,
            'type': group_type or 'group',
        }

        global_results = _action('group_list')(
            context, data_dict_global_results)
    except ValidationError as e:
        if e.error_dict and e.error_dict.get('message'):
            msg = e.error_dict['message']
        else:
            msg = str(e)
        h.flash_error(msg)
        c.page = h.Page([], 0)
        extra_vars["page"] = h.Page([], 0)
        extra_vars["group_type"] = group_type
        return render(
            _get_group_template(u'index_template', group_type), extra_vars)

    data_dict_page_results = {
        'all_fields': True,
        'q': q,
        'sort': sort_by,
        'type': group_type or 'group',
        'limit': items_per_page,
        'offset': items_per_page * (page - 1),
        'include_extras': True
    }
    page_results = _action('group_list')(context,
                                            data_dict_page_results)

    c.page = h.Page(
        collection=global_results,
        page=page,
        url=h.pager_url,
        items_per_page=items_per_page,
    )

    extra_vars["page"] = h.Page(
        collection=global_results,
        page=page,
        url=h.pager_url,
        items_per_page=items_per_page,
    )

    extra_vars["page"].items = page_results
    extra_vars["group_type"] = group_type

    c.page.items = page_results
    return render(
        _get_group_template(u'index_template', group_type), extra_vars)


def _read(id, limit, group_type):
    ''' This is common code used by both read and bulk_process'''
    extra_vars = {}
    context = {'model': model, 'session': model.Session,
                'user': c.user,
                'schema': _db_to_form_schema(group_type=group_type),
                'for_view': True, 'extras_as_string': True}

    q = c.q = request.form.get('q', '')
    # Search within group
    if c.group_dict.get('is_organization'):
        fq = 'owner_org:"{}" || owner_suborg:"{}"'.format(
            c.group_dict.get('id'), c.group_dict.get('id'))
    else:
        fq = 'groups:"%s"' % c.group_dict.get('name')

    extra_vars["q"] = q

    c.description_formatted = \
        render_markdown(c.group_dict.get('description'))

    context['return_query'] = True

    page = h.get_page_number(request.params)

    # most search operations should reset the page counter:
    params_nopage = [(k, v) for k, v in request.form.items(multi=True)
                        if k != 'page']
    sort_by = request.form.get('sort', None)

    def search_url(params):
        controller = lookup_group_controller(group_type)
        action = 'bulk_process' if c.action == 'bulk_process' else 'read'
        url = h.url_for(controller=controller, action=action, id=id)
        params = [(k, v.encode('utf-8') if isinstance(v, six.string_types)
                    else str(v)) for k, v in params]
        return url + u'?' + urlencode(params)

    def drill_down_url(**by):
        return h.add_url_param(alternative_url=None,
                                controller='group', action='read',
                                extras=dict(id=c.group_dict.get('name')),
                                new_params=by)

    c.drill_down_url = drill_down_url
    extra_vars["drill_down_url"] = drill_down_url

    def remove_field(key, value=None, replace=None):
        controller = lookup_group_controller(group_type)
        return h.remove_url_param(key, value=value, replace=replace,
                                    controller=controller, action='read',
                                    extras=dict(id=c.group_dict.get('name')))

    c.remove_field = remove_field
    extra_vars["remove_field"] = remove_field

    def pager_url(q=None, page=None):
        params = list(params_nopage)
        params.append(('page', page))
        return search_url(params)

    try:
        c.fields = []
        c.fields_grouped = {}
        search_extras = {}
        for (param, value) in request.form.items():
            if param not in ['q', 'page', 'sort'] \
                    and len(value) and not param.startswith('_'):
                if not param.startswith('ext_'):
                    c.fields.append((param, value))
                    q += ' %s: "%s"' % (param, value)
                    if param not in c.fields_grouped:
                        c.fields_grouped[param] = [value]
                    else:
                        c.fields_grouped[param].append(value)
                else:
                    search_extras[param] = value

        facets = OrderedDict()

        default_facet_titles = {'organization': _('Organizations'),
                                'groups': _('Groups'),
                                'tags': _('Tags'),
                                'res_format': _('Formats'),
                                'license_id': _('Licenses')}

        for facet in h.facets():
            if facet in default_facet_titles:
                facets[facet] = default_facet_titles[facet]
            else:
                facets[facet] = facet

        # Facet titles
        _update_facet_titles(facets, group_type)

        c.facet_titles = facets

        data_dict = {
            'q': q,
            'fq': fq,
            'include_private': True,
            'facet.field': [facet for facet in facets.keys()],
            'rows': limit,
            'sort': sort_by,
            'start': (page - 1) * limit,
            'extras': search_extras
        }

        context_ = dict((k, v) for (k, v) in context.items()
                        if k != 'schema')
        query = get_action('package_search')(context_, data_dict)

        c.page = h.Page(
            collection=query['results'],
            page=page,
            url=pager_url,
            item_count=query['count'],
            items_per_page=limit
        )

        c.group_dict['package_count'] = query['count']

        c.search_facets = query['search_facets']
        c.search_facets_limits = {}
        for facet in c.search_facets.keys():
            limit = int(request.form.get('_%s_limit' % facet,
                                            config.get('search.facets.default', 10)))
            c.search_facets_limits[facet] = limit
        c.page.items = query['results']

        c.sort_by_selected = sort_by

    except search.SearchError as se:
        log.error('Group search error: %r', se.args)
        c.query_error = True
        c.page = h.Page(collection=[])

    _setup_template_variables(context, {'id': id},
                                    group_type=group_type)
    return extra_vars


def read(group_type='organization', is_organization=True, id=None, limit=20):
    extra_vars = {}
    set_org(is_organization)
    context = {
        u'model': model,
        u'session': model.Session,
        u'user': c.user,
        u'schema': _db_to_form_schema(group_type=group_type),
        u'for_view': True
    }
    data_dict = {u'id': id, u'type': group_type}

    # unicode format (decoded from utf8)
    q = request.form.get(u'q', u'')

    extra_vars["q"] = q

    try:
        # Do not query for the group datasets when dictizing, as they will
        # be ignored and get requested on the controller anyway
        data_dict['include_datasets'] = False

        # Do not query group members as they aren't used in the view
        data_dict['include_users'] = False

        group_dict = _action(u'group_show')(context, data_dict)
        group = context['group']
    except (NotFound, NotAuthorized):
        base.abort(404, _(u'Group not found'))

    # if the user specified a group id, redirect to the group name
    if data_dict['id'] == group_dict['id'] and \
            data_dict['id'] != group_dict['name']:

        url_with_name = h.url_for(u'{}.read'.format(group_type),
                                  id=group_dict['name'])

        return h.redirect_to(
            h.add_url_param(alternative_url=url_with_name))

    # TODO: Remove
    # ckan 2.9: Adding variables that were removed from c object for
    # compatibility with templates in existing extensions
    c.q = q
    c.group_dict = group_dict
    c.group = group

    extra_vars = _read(id, limit, group_type)

    extra_vars["group_type"] = group_type
    extra_vars["group_dict"] = group_dict

    return render(
        _get_group_template(u'read_template', c.group_dict['type']),
        extra_vars)


class CreateGroupView(MethodView):
    u'''Create group view '''

    def _prepare(self, data=None):
        if data and u'type' in data:
            group_type = data['type']
        else:
            group_type = _guess_group_type()
        if data:
            data['type'] = group_type

        context = {
            u'model': model,
            u'session': model.Session,
            u'user': c.user,
            u'save': u'save' in request.params,
            u'parent': request.form.get(u'parent', None),
            u'group_type': group_type
        }

        try:
            _check_access(u'group_create', context)
        except NotAuthorized:
            base.abort(403, _(u'Unauthorized to create a group'))

        return context

    def post(self, group_type, is_organization):
        set_org(is_organization)
        context = self._prepare()
        try:
            data_dict = clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.form))))
            data_dict.update(clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
            ))
            data_dict['type'] = group_type or u'group'
            context['message'] = data_dict.get(u'log_message', u'')
            data_dict['users'] = [{u'name': c.user, u'capacity': u'admin'}]
            group = _action(u'group_create')(context, data_dict)

        except (NotFound, NotAuthorized) as e:
            log.info("GROUP NOT FOUN HERE")
            abort(404, _(u'Group not found'))
        except dict_fns.DataError:
            base.abort(400, _(u'Integrity Error'))
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return self.get(group_type, is_organization,
                            data_dict, errors, error_summary)

        return h.redirect_to(group['type'] + u'.read', id=group['name'])

    def get(self, group_type, is_organization,
            data=None, errors=None, error_summary=None):
        log.info("GROUP VIEW NEW")
        extra_vars = {}
        set_org(is_organization)
        context = self._prepare()
        data = data or clean_dict(
            dict_fns.unflatten(
                tuplize_dict(
                    parse_params(request.args, ignore_keys=CACHE_PARAMETERS)
                )
            )
        )

        if not data.get(u'image_url', u'').startswith(u'http'):
            data.pop(u'image_url', None)
        errors = errors or {}
        error_summary = error_summary or {}
        extra_vars = {
            u'data': data,
            u'errors': errors,
            u'error_summary': error_summary,
            u'action': u'new',
            u'group_type': group_type
        }
        _setup_template_variables(
            context, data, group_type=group_type)
        form = base.render(
            _get_group_template(u'group_form', group_type), extra_vars)

        # TODO: Remove
        # ckan 2.9: Adding variables that were removed from c object for
        # compatibility with templates in existing extensions
        c.form = form

        extra_vars["form"] = form
        return base.render(
            _get_group_template(u'new_template', group_type), extra_vars)


class MembersGroupView(MethodView):
    u'''New members group view'''

    def _prepare(self, id=None):
        context = {
            u'model': model,
            u'session': model.Session,
            u'user': g.user
        }
        try:
            _check_access(u'group_member_create', context, {u'id': id})
        except NotAuthorized:
            base.abort(403,
                       _(u'Unauthorized to create group %s members') % u'')

        return context

    def post(self, group_type, is_organization, id=None):
        set_org(is_organization)
        context = self._prepare(id)
        data_dict = clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.form))))
        data_dict['id'] = id

        email = data_dict.get(u'email')

        if email:
            user_data_dict = {
                u'email': email,
                u'group_id': data_dict['id'],
                u'role': data_dict['role']
            }
            del data_dict['email']

            try:
                user_dict = _action(u'user_invite')(context, user_data_dict)
            except ValidationError as e:
                for _, error in e.error_summary.items():
                    h.flash_error(error)
                return h.redirect_to(
                    u'{}.member_new'.format(group_type), id=id)

            data_dict['username'] = user_dict['name']

        try:
            group_dict = _action(u'group_member_create')(context, data_dict)

            full_group_dict = _action(u'group_show')(context, data_dict)
            is_coordinator = request.form.get('is_coordinator')

            coordinator_exists = ed_model.is_coordinator(
                data_dict['username'], full_group_dict['name']
            )

            if is_coordinator == "True" and not coordinator_exists:
                ed_model.update_coordinator(
                    data_dict['username'], full_group_dict['name']
                )
            else:
                ed_model.remove_coordinator(
                    data_dict['username'], full_group_dict['name']
                )
        except NotAuthorized:
            base.abort(403, _(u'Unauthorized to add member to group %s') % u'')
        except NotFound:
            base.abort(404, _(u'Group not found'))
        except ValidationError as e:
            for _, error in e.error_summary.items():
                h.flash_error(error)
            return h.redirect_to(u'{}.member_new'.format(group_type), id=id)

        # TODO: Remove
        g.group_dict = group_dict

        return h.redirect_to(u'{}.members'.format(group_type), id=id)

    def get(self, group_type, is_organization, id=None):
        extra_vars = {}
        set_org(is_organization)
        context = self._prepare(id)
        user = request.params.get(u'user')
        data_dict = {u'id': id}
        data_dict['include_datasets'] = False
        group_dict = _action(u'group_show')(context, data_dict)
        roles = _action(u'member_roles_list')(context, {
            u'group_type': group_type
        })
        is_coordinator = False

        if user:
            user_dict = get_action(u'user_show')(context, {u'id': user})
            user_role =\
                authz.users_role_for_group_or_org(id, user) or u'member'

            is_coordinator = ed_model.is_coordinator(
                user_dict.get('name'), group_dict.get('name')
            )

            # TODO: Remove
            g.user_dict = user_dict
            extra_vars["user_dict"] = user_dict
        else:
            user_role = u'member'

        # TODO: Remove
        g.group_dict = group_dict
        g.roles = roles
        g.user_role = user_role
        extra_vars.update({
            u"group_dict": group_dict,
            u"roles": roles,
            u"user_role": user_role,
            u"group_type": group_type,
            u"is_coordinator": is_coordinator
        })
        return base.render(_replace_group_org(u'group/member_new.html'),
                           extra_vars)

def member_delete(id, group_type, is_organization):
    extra_vars = {}
    set_org(is_organization)

    if u'cancel' in request.params:
        return h.redirect_to(u'{}.members'.format(group_type), id=id)

    context = {u'model': model, u'session': model.Session, u'user': g.user}

    try:
        _check_access(u'group_member_delete', context, {u'id': id})
    except NotAuthorized:
        base.abort(403, _(u'Unauthorized to delete group %s members') % u'')

    try:
        user_id = request.params.get(u'user')

        if request.method == u'POST':
            _action(u'group_member_delete')(context, {
                u'id': id,
                u'user_id': user_id
            })
            h.flash_notice(_(u'Group member has been deleted.'))

            full_group_dict = _action(u'group_show')(context, {'id': id})
            full_user_dict = _action(u'user_show')(context, {'id': user_id})
            is_coordinator = ed_model.is_coordinator(
                full_user_dict['name'], full_group_dict.get('name')
            )

            if is_coordinator:
                ed_model.remove_coordinator(
                    full_user_dict['name'], full_group_dict.get('name')
                )

            return h.redirect_to(u'{}.members'.format(group_type), id=id)

        user_dict = _action(u'group_show')(context, {u'id': user_id})

        # TODO: Remove
        # ckan 2.9: Adding variables that were removed from c object for
        # compatibility with templates in existing extensions
        g.user_dict = user_dict
        g.user_id = user_id
        g.group_id = id

    except NotAuthorized:
        base.abort(403, _(u'Unauthorized to delete group %s members') % u'')
    except NotFound:
        base.abort(404, _(u'Group not found'))
    extra_vars = {
        u"user_id": user_id,
        u"user_dict": user_dict,
        u"group_id": id
    }
    return base.render(_replace_group_org(u'group/confirm_delete_member.html'),
                       extra_vars)


organization_blueprint.add_url_rule(
    u'/new',
    methods=[u'GET', u'POST'],
    view_func=CreateGroupView.as_view(str(u'new')))
organization_blueprint.add_url_rule(
    u'/member_new/<id>',
    view_func=MembersGroupView.as_view(str(u'member_new')),
    methods=[u'GET', u'POST'])
organization_blueprint.add_url_rule(u'/<id>', methods=[u'GET'], view_func=read)
organization_blueprint.add_url_rule(u'/', view_func=index, strict_slashes=False)
organization_blueprint.add_url_rule(
    u'/member_delete/<id>',
    methods=[u'GET', u'POST'],
    view_func=member_delete
)
