import ast
import cgi
import json
import logging
import re
from flask import Blueprint

from six import text_type

from ckan import logic
from ckan import model
from ckan.lib import base
from ckan.common import _, request, c, config

import ckan.plugins as p
import ckan.lib.helpers as h
import ckan.lib.navl.dictization_functions as dict_fns
import ckan.lib.datapreview as datapreview
from ckan.lib.render import TemplateNotFound
from ckan.views.dataset import (
    lookup_package_plugin, _setup_template_variables, _tag_string_to_list,
    search, follow, unfollow, followers, activity, changes, changes_multiple,
    history, LazyView, authz, collaborator_delete, collaborators_read,
    CollaboratorEditView, CACHE_PARAMETERS
)

from ckanext.ed.helpers import get_dataset_collections


NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError

clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict

check_access = logic.check_access
get_action = logic.get_action
parse_params = logic.parse_params

abort = base.abort
render = base.render

log = logging.getLogger(__name__)

ed_documentation_blueprint = Blueprint(
    'ed_documentation',
    __name__,
    url_prefix='/documentation',
    url_defaults={'package_type': u'documentation'}
)


package_types = ['documentation']

def _guess_package_type(package_type):
    return 'documentation'

def _new_template(package_type):
    return lookup_package_plugin(package_type).new_template()

def _edit_template(package_type):
    return lookup_package_plugin(package_type).edit_template()

def _read_template(package_type):
    return lookup_package_plugin(package_type).read_template()

def _package_form(package_type=None):
    return lookup_package_plugin(package_type).package_form()

def _resource_form(package_type):
    # backwards compatibility with plugins not inheriting from
    # DefaultDatasetPlugin and not implmenting resource_form
    plugin = lookup_package_plugin(package_type)
    if hasattr(plugin, 'resource_form'):
        result = plugin.resource_form()
        if result is not None:
            return result
    return lookup_package_plugin().resource_form()

def _resource_template(package_type):
    # backwards compatibility with plugins not inheriting from
    # DefaultDatasetPlugin and not implmenting resource_template
    plugin = lookup_package_plugin(package_type)
    if hasattr(plugin, 'resource_template'):
        result = plugin.resource_template()
        if result is not None:
            return result
    return lookup_package_plugin().resource_template()

def new(package_type=None, data=None, errors=None, error_summary=None):

    if data and 'type' in data:
        package_type = data['type']
    else:
        package_type = _guess_package_type(True)

    if request.form is False or (len(request.form) == 0):
        context = {'model': model, 'session': model.Session,
                    'user': c.user, 'auth_user_obj': c.userobj,
                    'origin': 'origin' in request.params,
                    'origin_id': 'origin_id' in request.params,
                    'save': 'save' in request.params}
    else:        
        context = {'model': model, 'session': model.Session,
                    'user': c.user, 'auth_user_obj': c.userobj,
                    'origin': 'origin' in request.form,
                    'origin_id': 'origin_id' in request.form,
                    'save': 'save' in request.form}

    # Package needs to have a organization group in the call to
    # check_access and also to save it
    try:
        check_access('package_create', context)
    except NotAuthorized:
        abort(403, _('Unauthorized to create a package'))

    if context['save'] and not data and request.method == 'POST':
        return _save_new(context, package_type=package_type)

    data = data or clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
        request.params, ignore_keys=CACHE_PARAMETERS))))
    c.resources_json = h.json.dumps(data.get('resources', []))
    # convert tags if not supplied in data
    if data and not data.get('tag_string'):
        data['tag_string'] = ', '.join(
            h.dict_list_reduce(data.get('tags', {}), 'name'))

    errors = errors or {}
    error_summary = error_summary or {}
    # in the phased add dataset we need to know that
    # we have already completed stage 1
    stage = ['complete', 'active']
    # if data.get('state', '').startswith('draft'):
    #     stage = ['completed', 'active']

    # if we are creating from a group then this allows the group to be
    # set automatically
    data['group_id'] = request.form.get('group') or \
        request.form.get('groups__0__id')

    # new documentation visibility default set to public
    data['private'] = False

    form_snippet = _package_form(package_type=package_type)
    form_vars = {'data': data, 'errors': errors,
                    'error_summary': error_summary,
                    'action': 'new', 'stage': stage,
                    'dataset_type': package_type,
                    }
    c.errors_json = h.json.dumps(errors)

    _setup_template_variables(context, {},
                                    package_type=package_type)

    new_template = _new_template(package_type)

    extra_vars = {
        'form_vars': form_vars,
        'form_snippet': form_snippet,
        'dataset_type': package_type
    }

    from_button = request.params.get(
        'from_button',
        request.args.get(
            'from_button',
            False
        )
    )

    if from_button:
        extra_vars['from_button'] = True

    return render(
        new_template,
        extra_vars=extra_vars
    )


def _save_new(context, package_type=None):
    # The staged add dataset used the new functionality when the dataset is
    # partially created so we need to know if we actually are updating or
    # this is a real new.
    is_an_update = False
    ckan_phase = request.form.get('_ckan_phase')

    from_button = request.params.get(
        'from_button',
        request.args.get(
            'from_button',
            request.form.get(
                'from_button',
                False
            )
        )
    )
    new_doc_post_wizard = request.form.get(
        'new_doc_post_wizard',
        request.args.get(
            'new_doc_post_wizard',
            request.params.get(
                'new_doc_post_wizard'
            )
        )
    )

    from ckan.lib.search import SearchIndexError

    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))

        # Skip saving and show disabled form if nothing was filled in
        if not data_dict['name'] \
            and not data_dict['title']\
            and not data_dict['notes']:
            vars = {}
            vars['stage'] = ['complete', 'complete', 'active']
            template = 'documentation/new_resource_disabled.html'
            return render(template, extra_vars=vars)

        if ckan_phase:
            # prevent clearing of groups etc
            context['allow_partial_update'] = True
            # sort the tags
            if 'tag_string' in data_dict:
                data_dict['tags'] = _tag_string_to_list(
                    data_dict['tag_string'])
            if data_dict.get('pkg_name'):
                is_an_update = True
                # This is actually an update not a save
                data_dict['id'] = data_dict['pkg_name']
                del data_dict['pkg_name']
                # we need this dataset to be active
                data_dict['state'] = 'active'
                # this is actually an edit not a save
                pkg_dict = get_action('package_update')(context, data_dict)

                if request.params['save'] == 'go-metadata':
                    # redirect to add metadata
                    url = h.url_for('ed_documentation.new',
                                    id=pkg_dict['name'])
                elif from_button:
                    # redirect to add dataset resources
                    url = h.url_for(
                        'ed_documentation.new_resource',
                        id=pkg_dict['name'],
                        from_button=from_button
                    )
                else:
                    # redirect to add dataset resources
                    url = h.url_for('ed_documentation.new_resource',
                                    id=pkg_dict['name'])
                return h.redirect_to(url)
            # allow the state to be changed
            context['allow_state_change'] = True

        origin_id = request.form.get('origin_id')
        origin_type = request.form.get('origin_id')

        data_dict['type'] = package_type
        data_dict['parent'] = origin_id
        context['message'] = data_dict.get('log_message', '')

        if request.form.get('origin') in ['collection', 'master_collection']:
            data_dict['groups'] = [{'name': origin_id}]

        pkg_dict = get_action('package_create')(context, data_dict)

        if request.form.get('origin') == 'dataset':
            try:
                r1 = logic.get_action('package_relationship_create')(context, {
                    'subject': origin_id,
                    'object': pkg_dict['id'],
                    'type': 'parent_of'})
                r2 = logic.get_action('package_relationship_create')(context, {
                    'subject': pkg_dict['id'],
                    'object': origin_id,
                    'type': 'child_of'})
            except:
                log.debug('Could not save documentation - dataset relationship!')

        if not pkg_dict:
            pkg_dict = {}

        if ckan_phase:
            if from_button:
                if new_doc_post_wizard:
                    # redirect to add metadata
                    url = h.url_for(
                        'ed_documentation.new_resource',
                        id=pkg_dict.get('name', origin_id),
                        from_button=from_button,
                        origin=request.form.get('origin'),
                        origin_id=request.form.get('origin_id'),
                        new_doc_post_wizard=new_doc_post_wizard
                    )
                else:
                    # redirect to add dataset resources
                    url = h.url_for(
                        'ed_documentation.new_resource',
                        id=pkg_dict.get('name', origin_id),
                        from_button=from_button,
                        origin=request.form.get('origin'),
                        origin_id=request.form.get('origin_id')
                    )
            else:
                # redirect to add dataset resources
                url = h.url_for('ed_documentation.new_resource',
                                origin=request.form.get('origin'),
                                origin_id=request.form.get('origin_id'),
                                id=pkg_dict.get('name', origin_id))
            return h.redirect_to(url)

        _form_save_redirect(pkg_dict.get('name', origin_id), 'new',
                                   package_type=package_type)
    except NotAuthorized:
        abort(403, _('Unauthorized to read package %s') % '')
    except NotFound as e:
        abort(404, _('Dataset not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except SearchIndexError as e:
        try:
            exc_str = text_type(repr(e.args))
        except Exception:  # We don't like bare excepts
            exc_str = text_type(str(e))
        abort(500, _(u'Unable to add package to search index.') + exc_str)
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        if is_an_update:
            # we need to get the state of the dataset to show the stage we
            # are on.
            pkg_dict = get_action('package_show')(context, data_dict)
            data_dict['state'] = pkg_dict['state']
            return edit(data_dict['id'], data_dict,
                                errors, error_summary)
        data_dict['state'] = 'none'
        return new(data_dict, errors, error_summary)


def edit(id, package_type, data=None, errors=None, error_summary=None):
    package_type = _get_package_type(id)

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj,
                'save': 'save' in request.form}

    from_button = False
    origin = None
    origin_id = None
    new_doc_post_wizard = False

    from_button = from_button or request.args.get(
        'from_button',
        request.params.get(
            'from_button',
            False
        )
    )

    new_doc_post_wizard = new_doc_post_wizard or request.form.get(
        'new_doc_post_wizard',
        request.args.get(
            'new_doc_post_wizard',
            request.params.get(
                'new_doc_post_wizard'
            )
        )
    )
    origin = origin or request.form.get(
        'origin',
        request.args.get(
            'origin'
        )
    )
    origin_id = origin_id or request.form.get(
        'origin_id',
        request.args.get(
            'origin_id'
        )
    )

    if context['save'] and not data and request.method == 'POST':
        return _save_edit(id, context, package_type=package_type)
    try:
        c.pkg_dict = get_action('package_show')(dict(context,
                                                        for_view=True),
                                                {'id': id})
        context['for_edit'] = True
        old_data = get_action('package_show')(context, {'id': id})
        # old data is from the database and data is passed from the
        # user if there is a validation error. Use users data if there.
        if data:
            old_data.update(data)
        data = old_data
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))
    # are we doing a multiphase add?
    if data.get('state', '').startswith('draft'):
        c.form_action = h.url_for('ed_dataset.new')
        c.form_style = 'new'
        return new(data=data, errors=errors,
                        error_summary=error_summary)

    c.pkg = context.get("package")
    c.resources_json = h.json.dumps(data.get('resources', []))

    try:
        check_access('package_update', context)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))
    # convert tags if not supplied in data
    if data and not data.get('tag_string'):
        data['tag_string'] = ', '.join(h.dict_list_reduce(
            c.pkg_dict.get('tags', {}), 'name'))
    errors = errors or {}
    form_snippet = _package_form(package_type=package_type)
    form_vars = {'data': data, 'errors': errors,
                    'error_summary': error_summary, 'action': 'edit',
                    'dataset_type': package_type,
                    }
    c.errors_json = h.json.dumps(errors)

    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)

    # we have already completed stage 1
    form_vars['stage'] = ['active']
    if data.get('state', '').startswith('draft'):
        form_vars['stage'] = ['active', 'complete']

    edit_template = _edit_template(package_type)

    extra_vars = {
        'form_snippet': form_snippet,
        'dataset_type': package_type
    }

    origin_name = None

    if request.params:
        origin_name = request.params.get('origin_name')

    if origin_id and origin:
        form_vars['origin'] = origin
        form_vars['origin_id'] = origin_id
        extra_vars['origin'] = origin
        extra_vars['origin_id'] = origin_id

    if origin_name:
        form_vars['origin_name'] = origin_name
        extra_vars['origin_name'] = origin_name

    if from_button:
        form_vars['from_button'] = True
        extra_vars['from_button'] = True

    if new_doc_post_wizard:
        form_vars['new_doc_post_wizard'] = True
        extra_vars['new_doc_post_wizard'] = True

    extra_vars['form_vars'] = form_vars

    return render(
        edit_template,
        extra_vars=extra_vars
    )


def _get_package_type(id):
    """
    Given the id of a package this method will return the type of the
    package, or 'dataset' if no type is currently set
    """
    pkg = model.Package.get(id)
    if pkg:
        return pkg.type or 'dataset'
    return None


def _save_edit(name_or_id, context, package_type=None):

    from ckan.lib.search import SearchIndexError
    log.debug('Package save request name: %s POST: %r',
                name_or_id, request.form)

    data_dict = request.args.get(
        'data',
        request.params.get(
            'data',
            request.form.get(
                'data'
            )
        )
    )

    from_button = False
    origin = None
    origin_id = None
    new_doc_post_wizard = False
    origin_name = None

    if data_dict:
        try:
            data_dict = ast.literal_eval(data_dict)
            origin = data_dict.get('origin')
            origin_id = data_dict.get('origin_id')
            from_button = data_dict.get('from_button')
            new_doc_post_wizard = data_dict.get('new_doc_post_wizard')
        except Exception as e:
            log.info('Could not read data_dict: %s', e)


    from_button = request.args.get(
        'from_button',
        request.params.get(
            'from_button',
            from_button
        )
    )
    origin_name = request.args.get(
        'origin_name',
        request.params.get(
            'origin_name',
            origin_name
        )
    )
    origin = request.args.get(
        'origin',
        request.params.get(
            'origin',
            origin
        )
    )
    origin_id = request.args.get(
        'origin_id',
        request.params.get(
            'origin_id',
            origin_id
        )
    )
    new_doc_post_wizard = request.args.get(
        'new_doc_post_wizard',
        request.params.get(
            'new_doc_post_wizard',
            new_doc_post_wizard
        )
    )

    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        if '_ckan_phase' in data_dict:
            # we allow partial updates to not destroy existing resources
            context['allow_partial_update'] = True
            if 'tag_string' in data_dict:
                data_dict['tags'] = _tag_string_to_list(
                    data_dict['tag_string'])
            del data_dict['_ckan_phase']
            del data_dict['save']
        context['message'] = data_dict.get('log_message', '')
        data_dict['id'] = name_or_id
        package = logic.get_action('package_show')(context, {'id': name_or_id})
        if package['groups']:
            data_dict['groups'] = package['groups']

        pkg = get_action('package_update')(context, data_dict)
        c.pkg = context['package']
        c.pkg_dict = pkg

        collections = logic.get_action('collection_list')(context, {})

        if 'groups' in data_dict.keys():
            collection = [coll['name'] for coll in data_dict['groups'] if coll['name'] in collections]
        else:
            collection = None

        if from_button and (origin_id or origin_name) and origin != 'dataset':
            return h.redirect_to(
                'ed_collection.documentation_read',
                id=origin_id or origin_name
            )

        if collection and not from_button and origin and origin_id:
            return h.redirect_to('ed_documentation.new_resource', id=name_or_id, origin_id=origin_id, origin=origin)
        if collection:
            return h.redirect_to('ed_collection.read', id=collection[0])

        if not from_button and origin == 'dataset':
            return h.redirect_to(
                'ed_documentation.new_resource',
                id=name_or_id,
                origin=origin,
                origin_id=origin_id
            )
        if new_doc_post_wizard and origin and origin_id:
            return h.redirect_to(
                'ed_documentation.new_resource',
                id=name_or_id,
                new_doc_post_wizard=new_doc_post_wizard,
                origin=origin,
                origin_id=origin_id,
                from_button=from_button
            )

        return _form_save_redirect(
            pkg['name'], 'edit',
            package_type=package_type
        )
    except NotAuthorized:
        abort(403, _('Unauthorized to read package %s') % name_or_id)
    except NotFound as e:
        abort(404, _('Dataset not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except SearchIndexError as e:
        try:
            exc_str = text_type(repr(e.args))
        except Exception:  # We don't like bare excepts
            exc_str = text_type(str(e))
        abort(500, _(u'Unable to update search index.') + exc_str)
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return edit(name_or_id, data_dict, errors, error_summary)


def _form_save_redirect(pkgname, action, package_type=None):
    '''This redirects the user to the CKAN package/read page,
    unless there is request parameter giving an alternate location,
    perhaps an external website.
    @param pkgname - Name of the package just edited
    @param action - What the action of the edit was
    '''
    assert action in ('new', 'edit')
    url = request.form.get('return_to') or \
        config.get('package_%s_return_url' % action)

    if url:
        url = url.replace('<NAME>', pkgname)
    else:
        if package_type is None or package_type == 'dataset':
            url = h.url_for('ed_dataset.read_description', id=pkgname)
        else:
            url = h.url_for('{0}_read'.format(package_type), id=pkgname)

    return h.redirect_to(url)


def edit_view(id, package_type, resource_id, view_id=None):
    package_type = _get_package_type(id.split('@')[0])
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}

    # update resource should tell us early if the user has privilages.
    try:
        check_access('resource_update', context, {'id': resource_id})
    except NotAuthorized as e:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))

    # get resource and package data
    try:
        c.pkg_dict = get_action('package_show')(context, {'id': id})
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))
    try:
        c.resource = get_action('resource_show')(context,
                                                    {'id': resource_id})
    except (NotFound, NotAuthorized):
        abort(404, _('Resource not found'))

    data = {}
    errors = {}
    error_summary = {}
    view_type = None
    to_preview = False

    if request.method == 'POST':
        request.POST.pop('save', None)
        to_preview = request.POST.pop('preview', False)
        if to_preview:
            context['preview'] = True
        to_delete = request.POST.pop('delete', None)
        data = clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
            request.params, ignore_keys=CACHE_PARAMETERS))))
        data['resource_id'] = resource_id

        try:
            if to_delete:
                data['id'] = view_id
                get_action('resource_view_delete')(context, data)
            elif view_id:
                data['id'] = view_id
                data = get_action('resource_view_update')(context, data)
            else:
                data = get_action('resource_view_create')(context, data)
        except ValidationError as e:
            # Could break preview if validation error
            to_preview = False
            errors = e.error_dict
            error_summary = e.error_summary
        except NotAuthorized:
            # This should never happen unless the user maliciously changed
            # the resource_id in the url.
            abort(403, _('Unauthorized to edit resource'))
        else:
            if not to_preview:
                h.redirect_to(controller='dataset',
                                action='resource_views',
                                id=id, resource_id=resource_id)

    # view_id exists only when updating
    if view_id:
        try:
            old_data = get_action('resource_view_show')(context,
                                                        {'id': view_id})
            data = data or old_data
            view_type = old_data.get('view_type')
            # might as well preview when loading good existing view
            if not errors:
                to_preview = True
        except (NotFound, NotAuthorized):
            abort(404, _('View not found'))

    view_id = None

    try:
        view_id = request.GET.get('view_type')
    except:
        view_id = request.args.get(
            'view_type',
            request.params.get(
                'view_type'
            )
        )

    view_type = view_type
    data['view_type'] = view_type
    view_plugin = datapreview.get_view_plugin(view_type)
    if not view_plugin:
        abort(404, _('View Type Not found'))

    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)

    data_dict = {'package': c.pkg_dict, 'resource': c.resource,
                    'resource_view': data}

    view_template = view_plugin.view_template(context, data_dict)
    form_template = view_plugin.form_template(context, data_dict)

    vars = {'form_template': form_template,
            'view_template': view_template,
            'data': data,
            'errors': errors,
            'error_summary': error_summary,
            'to_preview': to_preview,
            'datastore_available': p.plugin_loaded('datastore')}
    vars.update(
        view_plugin.setup_template_variables(context, data_dict) or {})
    vars.update(data_dict)

    if view_id:
        return render('documentation/edit_view.html', extra_vars=vars)

    return render('documentation/new_view.html', extra_vars=vars)


def groups(id, package_type=None):
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj, 'use_cache': False}
    data_dict = {'id': id}
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        dataset_type = c.pkg_dict['type'] or 'dataset'
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    if request.method == 'POST':
        new_group = request.POST.get('group_added')
        if new_group:
            data_dict = {"id": new_group,
                            "object": id,
                            "object_type": 'package',
                            "capacity": 'public'}
            try:
                get_action('member_create')(context, data_dict)
            except NotFound:
                abort(404, _('Group not found'))

        removed_group = None
        for param in request.POST:
            if param.startswith('group_remove'):
                removed_group = param.split('.')[-1]
                break
        if removed_group:
            data_dict = {"id": removed_group,
                            "object": id,
                            "object_type": 'package'}

            try:
                get_action('member_delete')(context, data_dict)
            except NotFound:
                abort(404, _('Group not found'))
        h.redirect_to('ed_dataset.groups', id=id)

    context['is_member'] = True
    users_groups = get_action('group_list_authz')(context, data_dict)

    pkg_group_ids = set(group['id'] for group
                        in c.pkg_dict.get('groups', []))
    user_group_ids = set(group['id'] for group
                            in users_groups)

    c.group_dropdown = [[group['id'], group['display_name']]
                        for group in users_groups if
                        group['id'] not in pkg_group_ids]

    for group in c.pkg_dict.get('groups', []):
        group['user_member'] = (group['id'] in user_group_ids)

    return render('package/group_list.html',
                    {'dataset_type': dataset_type})


def resources(id, package_type=None):
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}

    try:
        check_access('package_update', context, data_dict)
    except NotFound:
        abort(404, _('Dataset not found'))
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))
    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    package_type = c.pkg_dict['type'] or 'dataset'
    _setup_template_variables(
        context,
        {'id': id},
        package_type=package_type
    )

    origin_name = request.args.get('origin_name', request.params.get('origin_name'))
    origin = request.args.get('origin', request.params.get('origin'))
    origin_id = request.args.get('origin_id', request.params.get('origin_id'))
    from_button = request.args.get('from_button', request.params.get('from_button'))

    if origin_name:
        extra_vars = {
            'dataset_type': package_type,
            'origin_name': origin_name
        }
    elif origin and origin_id:
        extra_vars = {
            'dataset_type': package_type,
            'origin': origin,
            'origin_id': origin_id
        }
    else:
        extra_vars = {
            'dataset_type': package_type
        }

    if from_button:
        extra_vars['from_button'] = True

    return render(
        'documentation/resources.html',
        extra_vars=extra_vars
    )


def new_resource(id, data=None, errors=None, error_summary=None, package_type=None):
    ''' FIXME: This is a temporary action to allow styling of the
    forms. '''

    save_action = request.form.get('save')
    origin = request.form.get(
        'origin',
        request.params.get(
            'origin',
            request.args.get(
                'origin'
            )
        )
    )
    origin_id = request.form.get(
        'origin_id',
        request.params.get(
            'origin_id',
            request.args.get(
                'origin_id'
            )
        )
    )
    origin_name = request.form.get(
        'origin_name',
        request.params.get(
            'origin_name',
            request.args.get(
                'origin_name',
                origin_id
            )
        )
    )

    from_button = request.form.get(
        'from_button',
        request.params.get(
            'from_button',
            request.args.get(
                'from_button'
            )
        )
    )

    new_doc_post_wizard = request.form.get(
        'new_doc_post_wizard',
        request.params.get(
            'new_doc_post_wizard',
            request.args.get(
                'new_doc_post_wizard'
            )
        )
    )

    #origin_dict = {}
    origin = None if origin == 'None' else origin
    origin_id = origin_name or None if origin_id == 'None' else origin_id
    origin_name = None

    if data:
        origin_name = data.get('origin_name')
        origin_name = origin_id if origin_name is None else origin_name

    if request.method == 'POST' and not data:
        data = data or \
            clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
                request.form))))
        data.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))
        # we don't want to include save as it is part of the form
        del data['save']
        resource_id = data['id']
        del data['id']

        try:
            del data['origin']
            del data['origin_id']
        except:
            pass

        context = {'model': model, 'session': model.Session,
                    'user': c.user, 'auth_user_obj': c.userobj}

        # see if we have any data that we are trying to save
        data_provided = False
        for key, value in data.items():
            if ((value or isinstance(value, cgi.FieldStorage))
                    and key != 'resource_type'):
                data_provided = True
                break

        if not data_provided and save_action != "go-dataset-complete":
            if origin == 'dataset' and save_action == 'go-dataset' and not from_button:
                return h.redirect_to('ed_dataset.edit', id=id, origin=origin, origin_id=origin_id, from_button=from_button)
            if save_action == 'go-dataset' and origin == 'collection' and not from_button:
                return h.redirect_to('ed_documentation.edit', id=id, origin=origin, origin_id=origin_id)
            if save_action == 'go-dataset':
                # go to final stage of adddataset
                return h.redirect_to('ed_dataset.read_description', id=id)
            # see if we have added any resources
            try:
                data_dict = get_action('package_show')(context, {'id': id})
            except NotAuthorized:
                abort(403, _('Unauthorized to update dataset'))
            except NotFound:
                abort(404, _('The dataset {id} could not be found.'
                            ).format(id=id))
            if not len(data_dict['resources']):
                # no data so keep on page
                msg = _('You must add at least one data resource')
                # On new templates do not use flash message

                if p.toolkit.asbool(config.get('ckan.legacy_templates')):
                    h.flash_error(msg)
                    return h.redirect_to('ed_documentation.new_resource', id=id)
                else:
                    errors = {}
                    error_summary = {_('Error'): msg}
                    return new_resource(id, data, errors,
                                                error_summary)
            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            get_action('package_update')(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))

            if origin == 'dataset' and origin_id:
                return h.redirect_to('ed_dataset.read_description', id=origin_id)

            return h.redirect_to('ed_dataset.read_description', id=id)

        data['package_id'] = id

        try:
            if resource_id:
                data['id'] = resource_id
                get_action('resource_update')(context, data)
            elif data.get('url'):
                get_action('resource_create')(context, data)
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return new_resource(id, data, errors, error_summary)
        except NotAuthorized:
            abort(403, _('Unauthorized to create a resource'))
        except NotFound:
            abort(404, _('The dataset {id} could not be found.'
                        ).format(id=id))

        if save_action == 'go-metadata':
            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            get_action('package_update')(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))

            #if origin_name and origin == 'collection':
            #    return h.redirect_to('ed_collection.read', id=origin_name)
            #elif 'origin_name' in request.params and request.params.get('origin') == 'collection':
            #    origin_name = request.params['origin_name']
            #    return h.redirect_to('ed_collection.read', id=origin_name)
            #elif 'origin_name' in request.form and request.form.get('origin') == 'collection':
            #    origin_name = request.form['origin_name']
            #    return h.redirect_to('ed_collection.read', id=origin_name)

            if origin == 'collection' and origin_id:
                if new_doc_post_wizard:
                    return h.redirect_to('ed_collection.documentation_read', id=origin_id)

                return h.redirect_to('ed_collection.read', id=origin_id)
            elif origin == 'dataset' and (origin_id or origin_name):
                if new_doc_post_wizard:
                    return h.redirect_to('ed_dataset.read_docs', id=origin_id or origin_name)
                return h.redirect_to('ed_dataset.read_description', id=origin_id or origin_name)
            else:
                parent_name = None
                edit_origin = request.form

                try:
                    parent_id = data_dict[
                        'relationships_as_subject'
                    ][0]['__extras']['object_package_id']
                    parent = get_action('package_show')(
                        context, {'id': parent_id}
                    )
                    parent_name = parent['name']
                except:
                    # No parent, redirect to documentation
                    pass

                if parent_name and edit_origin.get('origin') == None:
                    return h.redirect_to(
                        'ed_dataset.read_docs', id=parent_name
                    )
                elif not origin_name:
                    return h.redirect_to('ed_documentation.read', id=id)
                else:
                    return h.redirect_to('ed_collection.read', id=origin_name)
        elif save_action == 'go-dataset' and origin == 'dataset':
            # go to first stage of add dataset
            return h.redirect_to('ed_documentation.edit', data=data, id=id, origin=origin, origin_id=origin_id, from_button=from_button, new_doc_post_wizard=new_doc_post_wizard)
        elif save_action == 'go-dataset' and new_doc_post_wizard and origin and origin_id:
            # go to first stage of add dataset
            return h.redirect_to('ed_dataset.edit', id=id, origin=origin, origin_id=origin_id, new_doc_post_wizard=new_doc_post_wizard, from_button=True)
        elif save_action == 'go-dataset':
            # go to first stage of add dataset
            return h.redirect_to('ed_dataset.edit', id=id, origin=origin, origin_id=origin_id, from_button=from_button)
        elif save_action == 'go-dataset-complete' and origin != 'collection':
            # go to new docs
            return h.redirect_to('ed_dataset.read_docs', id=origin_id)
        elif save_action == 'go-dataset-complete' and (origin == 'collection'):
            # go to new docs
            return h.redirect_to('ed_collection.documentation_read', id=origin_id)
        elif save_action == 'again':
            if 'origin_name' in request.form or origin == 'collection':
                if new_doc_post_wizard and origin and origin_id and from_button:
                    # add more resources
                    return h.redirect_to(
                        'ed_documentation.new_resource',
                        id=id,
                        origin=origin,
                        origin_id=origin_id,
                        new_doc_post_wizard=new_doc_post_wizard,
                        from_button=from_button
                    )
                else:
                    # add more resources
                    return h.redirect_to(
                        'ed_documentation.new_resource',
                        id=id,
                        origin=origin,
                        origin_id=origin_id,
                        origin_name=origin_name
                    )
            elif origin and origin_id:
                # add more resources
                return h.redirect_to(
                    'ed_documentation.new_resource',
                    id=id,
                    new_doc_post_wizard=new_doc_post_wizard,
                    from_button=from_button,
                    origin_id=origin_id,
                    origin=origin
                )
        elif save_action == 'go-dataset-docs' and origin_id and origin == 'dataset':
            # go to new docs
            return h.redirect_to('ed_dataset.read_docs', id=origin_id)
        elif from_button and origin == 'collection' and origin_id:
            return h.redirect_to('ed_collection.documentation_read', id=origin_id)
        else:
            # add more resources
            return h.redirect_to('ed_documentation.new_resource', id=id)

    # get resources for sidebar
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj}
    try:
        pkg_dict = get_action('package_show')(context, {'id': id})
    except NotFound:
        abort(404, _('The dataset {id} could not be found.').format(id=id))
    try:
        check_access(
            'resource_create', context, {"package_id": pkg_dict["id"]})
    except NotAuthorized:
        abort(403, _('Unauthorized to create a resource for this package'))

    package_type = pkg_dict['type'] or 'dataset'

    errors = errors or {}
    error_summary = error_summary or {}

    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'new',
            'resource_form_snippet': _resource_form(package_type),
            'dataset_type': package_type}
    vars['pkg_name'] = id
    # required for nav menu
    vars['pkg_dict'] = pkg_dict
    template = 'documentation/new_resource_not_draft.html'
    vars['stage'] = ['complete', 'complete', 'active']
    if pkg_dict['state'].startswith('draft') or not from_button:
        vars['stage'] = ['complete', 'complete', 'active']
        template = 'documentation/new_resource.html'

    if from_button:
        vars['from_button'] = True

    if new_doc_post_wizard:
        vars['new_doc_post_wizard'] = True

    if origin == 'collection' and (origin_id or origin_name):
        vars['origin'] = 'collection'
        vars['origin_id'] = origin_name or origin_id
    elif origin == 'dataset' and (origin_id or origin_name):
        vars['origin'] = 'dataset'
        vars['origin_id'] = origin_name or origin_id

    return render(template, extra_vars=vars)


def resource_read(id, resource_id, package_type=None):
    context = {'model': model, 'session': model.Session,
                'user': c.user,
                'auth_user_obj': c.userobj,
                'for_view': True}

    try:
        c.package = get_action('package_show')(context, {'id': id})
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    for resource in c.package.get('resources', []):
        if resource['id'] == resource_id:
            c.resource = resource
            break
    if not c.resource:
        abort(404, _('Resource not found'))

    # required for nav menu
    c.pkg = context['package']
    c.pkg_dict = c.package
    dataset_type = c.pkg.type or 'dataset'

    # get package license info
    license_id = c.package.get('license_id')
    try:
        c.package['isopen'] = model.Package.\
            get_license_register()[license_id].isopen()
    except KeyError:
        c.package['isopen'] = False

    # Deprecated: c.datastore_api - use h.action_url instead
    c.datastore_api = '%s/api/action' % \
        config.get('ckan.site_url', '').rstrip('/')

    # TODO: replace resource_preview as it is deprecated
    #c.resource['can_be_previewed'] = _resource_preview(
    #    {'resource': c.resource, 'package': c.package})

    resource_views = get_action('resource_view_list')(
        context, {'id': resource_id})
    c.resource['has_views'] = len(resource_views) > 0

    current_resource_view = None
    view_id = None

    try:
        view_id = request.GET.get('view_id')
    except:
        view_id = request.args.get(
            'view_id',
            request.params.get(
                'view_id'
            )
        )

    if c.resource.get('can_be_previewed') and not view_id:
        current_resource_view = None
    elif c.resource['has_views']:
        if view_id:
            current_resource_view = [rv for rv in resource_views
                                        if rv['id'] == view_id]
            if len(current_resource_view) == 1:
                current_resource_view = current_resource_view[0]
            else:
                abort(404, _('Resource view not found'))
        else:
            current_resource_view = resource_views[0]

    vars = {'resource_views': resource_views,
            'current_resource_view': current_resource_view,
            'dataset_type': dataset_type}

    template = _resource_template(dataset_type)
    return h.redirect_to(h.url_for('ed_dataset.read', id=id, resource_id=resource_id))
    #return render(template, extra_vars=vars)


def resource_edit(id, resource_id=None, package_type=None, data=None, errors=None,
                    error_summary=None):

    context = {'model': model, 'session': model.Session,
                'api_version': 3, 'for_edit': True,
                'user': c.user, 'auth_user_obj': c.userobj}
    data_dict = {'id': id}

    try:
        check_access('package_update', context, data_dict)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))

    if request.method == 'POST' and not data:
        data = data or \
            clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
                                                        request.POST))))
        # we don't want to include save as it is part of the form
        del data['save']

        data['package_id'] = id
        try:
            if resource_id:
                data['id'] = resource_id
                get_action('resource_update')(context, data)
            else:
                get_action('resource_create')(context, data)
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return resource_edit(id, resource_id, data,
                                        errors, error_summary)
        except NotAuthorized:
            abort(403, _('Unauthorized to edit this resource'))
        return h.redirect_to('ed_documentation.resource_read', id=id,
                        resource_id=resource_id)

    pkg_dict = get_action('package_show')(context, {'id': id})
    if pkg_dict['state'].startswith('draft'):
        # dataset has not yet been fully created
        resource_dict = get_action('resource_show')(context,
                                                    {'id': resource_id})
        return new_resource(id, data=resource_dict)
    # resource is fully created
    try:
        resource_dict = get_action('resource_show')(context,
                                                    {'id': resource_id})
    except NotFound:
        abort(404, _('Resource not found'))
    c.pkg_dict = pkg_dict
    c.resource = resource_dict
    # set the form action
    c.form_action = h.url_for('ed_documentation.resource_edit',
                                resource_id=resource_id,
                                id=id)
    if not data:
        data = resource_dict

    package_type = pkg_dict['type'] or 'dataset'

    errors = errors or {}
    error_summary = error_summary or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'edit',
            'resource_form_snippet': _resource_form(package_type),
            'dataset_type': package_type}
    return render('package/resource_edit.html', extra_vars=vars)


def resource_view(id, resource_id, view_id=None, package_type=None):
    '''
    Embedded page for a resource view.

    Depending on the type, different views are loaded. This could be an
    img tag where the image is loaded directly or an iframe that embeds a
    webpage or a recline preview.
    '''
    context = {'model': model,
                'session': model.Session,
                'user': c.user,
                'auth_user_obj': c.userobj}

    try:
        package = get_action('package_show')(context, {'id': id})
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    try:
        resource = get_action('resource_show')(
            context, {'id': resource_id})
    except (NotFound, NotAuthorized):
        abort(404, _('Resource not found'))

    view = None
    if request.form.get('resource_view', ''):
        try:
            view = json.loads(request.form.get('resource_view', ''))
        except ValueError:
            abort(409, _('Bad resource view data'))
    elif view_id:
        try:
            view = get_action('resource_view_show')(
                context, {'id': view_id})
        except (NotFound, NotAuthorized):
            abort(404, _('Resource view not found'))

    if not view or not isinstance(view, dict):
        abort(404, _('Resource view not supplied'))

    return h.rendered_resource_view(view, resource, package, embed=True)


def resource_views(id, resource_id, package_type=None):
    package_type = _get_package_type(id.split('@')[0])
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}
    data_dict = {'id': id}

    try:
        check_access('package_update', context, data_dict)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))
    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    try:
        c.resource = get_action('resource_show')(context,
                                                    {'id': resource_id})
        c.views = get_action('resource_view_list')(context,
                                                    {'id': resource_id})

    except NotFound:
        abort(404, _('Resource not found'))
    except NotAuthorized:
        abort(403, _('Unauthorized to read resource %s') % id)

    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)

    return render('package/resource_views.html')


def resource_datapreview(id, resource_id, package_type=None):
    '''
    Embedded page for a resource data-preview.

    Depending on the type, different previews are loaded.  This could be an
    img tag where the image is loaded directly or an iframe that embeds a
    webpage, or a recline preview.
    '''
    context = {
        'model': model,
        'session': model.Session,
        'user': c.user,
        'auth_user_obj': c.userobj
    }

    try:
        c.resource = get_action('resource_show')(context,
                                                    {'id': resource_id})
        c.package = get_action('package_show')(context, {'id': id})

        data_dict = {'resource': c.resource, 'package': c.package}

        preview_plugin = datapreview.get_preview_plugin(data_dict)

        if preview_plugin is None:
            abort(409, _('No preview has been defined.'))

        preview_plugin.setup_template_variables(context, data_dict)
        c.resource_json = json.dumps(c.resource)
        dataset_type = c.package['type'] or 'dataset'
    except (NotFound, NotAuthorized):
        abort(404, _('Resource not found'))
    else:
        return render(preview_plugin.preview_template(context, data_dict),
                        extra_vars={'dataset_type': dataset_type})


def read(id, package_type=None):
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}

    # interpret @<revision_id> or @<date> suffix
    split = id.split('@')
    if len(split) == 2:
        data_dict['id'], revision_ref = split
        if model.is_id(revision_ref):
            context['revision_id'] = revision_ref
        else:
            try:
                date = h.date_str_to_datetime(revision_ref)
                context['revision_date'] = date
            except TypeError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
            except ValueError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
    elif len(split) > 2:
        abort(400, _('Invalid revision format: %r') %
                'Too many "@" symbols')

    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    # check if it has a parent (dataset documented by it)
    try:
        parent_id = c.pkg_dict['relationships_as_subject'][0]['__extras']['object_package_id']
        c.parent = get_action('package_show')(context, {'id': parent_id})
    except:
        abort(404, _('No dataset found for this documentation'))

    # used by disqus plugin
    c.current_package_id = c.pkg.id

    # can the resources be previewed?
    for resource in c.pkg_dict['resources']:
        # Backwards compatibility with preview interface
        # TODO: replace resource_preview as it is deprecated
        #resource['can_be_previewed'] = _resource_preview(
        #    {'resource': resource, 'package': c.pkg_dict})

        resource_views = get_action('resource_view_list')(
            context, {'id': resource['id']})
        resource['has_views'] = len(resource_views) > 0

    package_type = c.pkg_dict['type'] or 'dataset'
    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)

    template = _read_template(package_type)
    try:
        return render(template,
                        extra_vars={'dataset_type': package_type})
    except TemplateNotFound as e:
        msg = _(
            "Viewing datasets of type \"{package_type}\" is "
            "not supported ({file_!r}).".format(
                package_type=package_type,
                file_=e.message
            )
        )
        abort(404, msg)

    assert False, "We should never get here"


def delete(id, dataset_id, package_type=None, origin=None):
    origin = request.args.get('origin', request.params.get('origin'))
    origin_id = request.args.get('origin_id', request.params.get('origin_id'))

    if 'cancel' in request.params:
        return h.redirect_to('ed_documentation.edit', id=id)

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj, 'ignore_auth': True}
    pkg_dict = {'id': dataset_id}
    doc_to_delete = get_action('package_show')(context, {'id': id})

    try:
        if request.method == 'POST':
            if origin == 'collection':
                get_action('package_delete')(context, {'id': id})
                h.flash_notice(_('Collection Documentation has been deleted.'))
                return h.redirect_to('ed_collection.read', id=origin_id or dataset_id)

            elif dataset_id:
              get_action('package_delete')(context, {'id': id})
              h.flash_notice(_('Data Profile Documentation has been deleted.'))
              return h.redirect_to('ed_dataset.read_docs', id=origin_id or dataset_id)

        c.pkg_dict = get_action('package_show')(context, {'id': dataset_id})
        dataset_type = c.pkg_dict['type'] or 'dataset'
        pkg_dict = c.pkg_dict
    except NotAuthorized:
        abort(403, _('Unauthorized to delete package %s') % '')
    except NotFound:
        abort(404, _('Dataset not found'))

    return render(
        'package/confirm_delete.html',
        extra_vars={
            'dataset_type': dataset_type,
            'pkg_dict': pkg_dict
        }
    )


#def register_documentation_plugin_rules(blueprint: Blueprint):
ed_documentation_blueprint.add_url_rule(u'/', view_func=search, strict_slashes=False)
ed_documentation_blueprint.add_url_rule(u'/new', view_func=new, methods=['GET', 'POST'])
ed_documentation_blueprint.add_url_rule(u'/<id>', view_func=read)
ed_documentation_blueprint.add_url_rule(u'/resources/<id>', view_func=resources)
ed_documentation_blueprint.add_url_rule(
    u'/edit/<id>', view_func=edit,
    methods=['GET', 'POST']
)
ed_documentation_blueprint.add_url_rule(
    u'/delete/<id>/<dataset_id>',
    view_func=delete,
    methods=['GET', 'POST']
)
ed_documentation_blueprint.add_url_rule(
    u'/follow/<id>', view_func=follow, methods=(u'POST', )
)
ed_documentation_blueprint.add_url_rule(
    u'/unfollow/<id>', view_func=unfollow, methods=(u'POST', )
)
ed_documentation_blueprint.add_url_rule(u'/followers/<id>', view_func=followers)
ed_documentation_blueprint.add_url_rule(
    u'/groups/<id>', view_func=groups
)
ed_documentation_blueprint.add_url_rule(u'/activity/<id>', view_func=activity)
ed_documentation_blueprint.add_url_rule(u'/activity/<id>/<offset>', view_func=activity)
ed_documentation_blueprint.add_url_rule(u'/changes/<id>', view_func=changes)
ed_documentation_blueprint.add_url_rule(u'/<id>/history', view_func=history)

ed_documentation_blueprint.add_url_rule(u'/changes_multiple', view_func=changes_multiple)

# Duplicate resource create and edit for backward compatibility. Note,
# we cannot use resource.CreateView directly here, because of
# circular imports
ed_documentation_blueprint.add_url_rule(
    u'/new_resource/<id>',
    view_func=new_resource,
    methods=['GET', 'POST']
)

### Ed endpoints
ed_documentation_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>',
    view_func=resource_read
)
ed_documentation_blueprint.add_url_rule(
    u'/<id>/resource_edit/<resource_id>',
    view_func=resource_edit
)
ed_documentation_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>/preview',
    view_func=resource_datapreview
)
ed_documentation_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>/views',
    view_func=resource_views
)

if authz.check_config_permission(u'allow_dataset_collaborators'):
    ed_documentation_blueprint.add_url_rule(
        rule=u'/collaborators/<id>',
        view_func=collaborators_read,
        methods=['GET', ]
    )

    ed_documentation_blueprint.add_url_rule(
        rule=u'/collaborators/<id>/new',
        view_func=CollaboratorEditView.as_view(str(u'new_collaborator')),
        methods=[u'GET', u'POST', ]
    )

    ed_documentation_blueprint.add_url_rule(
        rule=u'/collaborators/<id>/delete/<user_id>',
        view_func=collaborator_delete, methods=['POST', ]
    )

#register_documentation_plugin_rules(ed_documentation_blueprint)
