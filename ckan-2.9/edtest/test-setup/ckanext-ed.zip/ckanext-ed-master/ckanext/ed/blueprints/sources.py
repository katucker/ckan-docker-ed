import logging
import re
from collections import OrderedDict

import six
from six import string_types
from six.moves.urllib.parse import urlencode

import ckan.lib.base as base
import ckan.lib.helpers as h
import ckan.lib.navl.dictization_functions as dict_fns
import ckan.logic as logic
import ckan.lib.search as search
import ckan.model as model
import ckan.authz as authz
import ckan.lib.plugins as lib_plugins
import ckan.plugins as plugins
from ckan.common import g, config, request, _
from ckan.views.home import CACHE_PARAMETERS
from ckan.views.dataset import _get_search_details

from flask import Blueprint
from flask.views import MethodView
from ckan.views.group import ( CreateGroupView, EditGroupView,
                               register_group_plugin_rules, set_org )

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
check_access = logic.check_access
get_action = logic.get_action
tuplize_dict = logic.tuplize_dict
clean_dict = logic.clean_dict
parse_params = logic.parse_params

log = logging.getLogger(__name__)

lookup_group_plugin = lib_plugins.lookup_group_plugin
lookup_group_controller = lib_plugins.lookup_group_controller
lookup_group_blueprint = lib_plugins.lookup_group_blueprints

is_org = False

# source_blueprint = Blueprint(u'ed_source', __name__, url_prefix=u'/ed_source',
#                   url_defaults={u'group_type': u'ed_source',
#                                 u'is_organization': False})


def post(self, group_type, is_organization):
    set_org(is_organization)
    context = self._prepare()
    try:
        data_dict = clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.form))))
        data_dict.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))
        data_dict['type'] = group_type or u'group'
        context['message'] = data_dict.get(u'log_message', u'')
        data_dict['users'] = [{u'name': g.user, u'capacity': u'admin'}]

        package_names = data_dict.get('source_packages', None)
        if package_names and type(package_names) == unicode:
            names_list = package_names.split(',')
            data_dict['source_packages'] = names_list
        
        group = get_action(u'group_create')(context, data_dict)

    except (NotFound, NotAuthorized) as e:
        base.abort(404, _(u'Group not found'))
    except dict_fns.DataError:
        base.abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return self.get(group_type, is_organization,
                        data_dict, errors, error_summary)

    return h.redirect_to(group['type'] + u'.read', id=group['name'])


def edit_post(self, group_type, is_organization, id=None):
        set_org(is_organization)
        context = self._prepare(id, is_organization)
        try:
            data_dict = clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.form))))
            data_dict.update(clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
            ))
            context['message'] = data_dict.get(u'log_message', u'')
            data_dict['id'] = context['id']
            context['allow_partial_update'] = True
            group = get_action(u'group_update')(context, data_dict)
            if id != group['name']:
                _force_reindex(group)

        except (NotFound, NotAuthorized) as e:
            base.abort(404, _(u'Group not found'))
        except dict_fns.DataError:
            base.abort(400, _(u'Integrity Error'))
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return self.get(id, group_type, is_organization,
                            data_dict, errors, error_summary)
        return h.redirect_to(group[u'type'] + u'.read', id=group[u'name'])


CreateGroupView.post = post
EditGroupView.post = edit_post

# register_group_plugin_rules(source_blueprint)
