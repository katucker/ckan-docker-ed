import logging

from flask import Blueprint

from ckan import model
from ckan.common import _
from ckan.lib import base
from ckan.logic import NotFound
from ckan.plugins import toolkit

log = logging.getLogger(__name__)

ed_workflow_activity_blueprint = Blueprint(
    u'ed_workflow_activity',
    __name__,
    url_prefix=u'/'
)


def list_activities(id):
    '''Render package's workflow activity stream page.'''

    context = {
        u'model': model, u'session': model.Session, u'user': toolkit.c.user,
        u'for_view': True, u'auth_user_obj': toolkit.c.userobj
    }
    data_dict = {u'id': id}

    try:
        toolkit.check_access(u'package_update', context, data_dict)
        toolkit.c.pkg_dict = toolkit.get_action(
            u'package_show')(context, data_dict)
        toolkit.c.pkg = context[u'package']
        toolkit.c.package_activity_stream = toolkit.get_action(
            u'package_activity_list_html')(
            context, {
                u'id': toolkit.c.pkg_dict[u'id'],
                u'get_workflow_activities': True
            })
        dataset_type = toolkit.c.pkg_dict[u'type'] or u'dataset'
    except NotFound:
        base.abort(404, _(u'Dataset not found'))
    except toolkit.NotAuthorized:
        base.abort(403, _(u'Unauthorized to read dataset %s') % id)

    return base.render(
        u'package/activity.html',
        {u'dataset_type': dataset_type}
    )


ed_workflow_activity_blueprint.add_url_rule(
    u'/dataset/workflow/<id>',
    methods=[u'GET', u'POST'],
    view_func=list_activities
)
