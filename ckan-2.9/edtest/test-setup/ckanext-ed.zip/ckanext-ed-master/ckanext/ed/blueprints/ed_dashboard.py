from curses import flash
from flask import Blueprint
from ckan.common import _, g, request, config
from ckan.views.user import _extra_template_variables
import ckan.lib.base as base
from ckan import model, logic
import ckan.lib.helpers as h
import logging
from six import string_types, text_type
import json
import ckan.lib.navl.dictization_functions as dict_fns
from urllib.parse import urlencode
from ckan.views.dataset import  _tag_string_to_list
from ckanext.ed.actions import ValidationError, package_update,  data_dictionary_upload
from ckanext.ed import helpers
from ckanext.ed.mailer import mail_package_publish_request_to_admins
from ckan.plugins.toolkit import enqueue_job
from ckan.config.middleware import make_app
from ckan.common import config
from copy import deepcopy

log = logging.getLogger(__name__)
get_action = logic.get_action
abort = base.abort
clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict
parse_params = logic.parse_params
ed_dashboard = Blueprint(u'ed_dashboard', __name__, url_prefix=u'/dashboard')

def draft_func(data_dict):
    fields = ['title', 'notes', 'tags', 'owner_org',
             'author', 'author_email', 'access_level', 'program_code']

    contains_all = all([data_dict.get(x) not in [None, [], ''] for x in fields])
    return not contains_all


def set_relationships(pkg_dict, data_dict, rtype):
    if rtype == "relationship_dependency_of":
        rdata =  helpers.get_relationship_dependencies_of(pkg_dict)
    elif rtype == "relationship_derives_from":
        rdata =  helpers.get_relationship_derives_from(pkg_dict)
    elif rtype == "relationship_parent":
        rdata =  helpers.get_relationship_parent_identifiers(pkg_dict)

    if rdata:
        rdata = json.loads(rdata)
        rdata = [dep['id'] for dep in rdata]
        rdata = ",".join(rdata)
    else:
        rdata = ""

    if data_dict.get(rtype) and rdata:
        return rdata + "," + data_dict.get(rtype)
    elif data_dict.get(rtype):
        return data_dict.get(rtype)
    else:
        return rdata

def datasets(drafts=None, hidden=None):
    context = {u'for_view': True, u'user': g.user, u'auth_user_obj': g.userobj}
    data_dict = {u'user_obj': g.userobj, u'include_datasets': True}
    extra_vars = _extra_template_variables(context, data_dict)
    datasets = []
    if drafts:
        for dataset in extra_vars['user_dict']['datasets']:
            if "indraft" in dataset:
                if dataset['indraft'] in [True, 'true']:
                    datasets.append(dataset)
        extra_vars['user_dict']['datasets'] = datasets
        extra_vars['indraft'] = True
    elif hidden:
        for dataset in extra_vars['user_dict']['datasets']:
            if dataset.get('private') is True:
                datasets.append(dataset)
        extra_vars['user_dict']['datasets'] = datasets
        extra_vars['hidden'] = True

    return base.render(u'user/dashboard_datasets.html', extra_vars)


def _encode_params(params):
    return [(k, v.encode('utf-8') if isinstance(v, string_types) else str(v))
            for k, v in params]


def url_with_params(url, params):
    params = _encode_params(params)
    return url + u'?' + urlencode(params)

def search_url(params, package_type=None):
    if not package_type or package_type == 'dataset':
        url = h.url_for('ed_dashboard.bulk_update_dataprofile')
    else:
        url = h.url_for('{0}_search'.format(package_type))
    return url_with_params(url, params)

def bulk_update_dataprofile():
    from ckan.lib.search import SearchError, SearchQueryError
    """
    List all datasets a user is able to edit
    """
    q = g.q = request.params.get('q', u'')
    select_all = request.params.get('select_all', False)
    owner_org = request.params.get('owner_org', False)
    g.query_error = False
    page = h.get_page_number(request.params)

    limit = int(config.get('ckan.datasets_per_page', 20))
    params_nopage = [(k, v) for k, v in request.params.items()
                    if k != 'page']
    def drill_down_url(alternative_url=None, **by):
        return h.add_url_param(alternative_url=alternative_url,
                                controller='dataset', action='bulk_update_dataprofile',
                                new_params=by)
    g.drill_down_url = drill_down_url

    def remove_field(key, value=None, replace=None):
        return h.remove_url_param(key, value=value, replace=replace,
                                    controller='dataset', action='search',
                                    alternative_url="dataset")
    g.remove_field = remove_field
    sort_by = request.params.get('sort', None)
    params_nosort = [(k, v) for k, v in params_nopage if k != 'sort']

    def _sort_by(fields):
        """
        Sort by the given list of fields.

        Each entry in the list is a 2-tuple: (fieldname, sort_order)

        eg - [('metadata_modified', 'desc'), ('name', 'asc')]

        If fields is empty, then the default ordering is used.
        """
        params = params_nosort[:]

        if fields:
            sort_string = ', '.join('%s %s' % f for f in fields)
            params.append(('sort', sort_string))
        return search_url(params, "dataset")

    g.sort_by = _sort_by
    if not sort_by:
        g.sort_by_fields = []
    else:
        g.sort_by_fields = [field.split()[0]
                            for field in sort_by.split(',')]

    def pager_url(q=None, page=None):
        params = list(params_nopage)
        params.append(('page', page))
        return search_url(params, "dataset")

    g.search_url_params = urlencode(_encode_params(params_nopage))
    
    #check if user is admin and return all data profile
    if g.userobj.sysadmin:
        data_dict = {
            'q': q,
            'rows': limit,
            'start': (page - 1) * limit,
            'sort': sort_by,
            'fq': 'state:active organization:'+owner_org if owner_org and owner_org != "False" else 'state:active'
        }
    else:

        if (not owner_org or owner_org == 'False') :
            #fetch all organization user is an editor or admin
            user_orgs = get_action('organization_list_for_user')(
                {'ignore_auth': True}, {'id':g.userobj.id, 'permission': 'update_dataset'})
            
            #  get organization name from user_orgs
            org_names = [org['name'] for org in user_orgs]
            # create fq query from org_names
            fq = 'organization:(' + ' OR '.join(org_names) + ')'
        else:
            fq = 'organization:' + owner_org


        data_dict = {
            'q': q,
            'rows': limit,
            'start': (page - 1) * limit,
            'sort': sort_by,
            'fq': fq
        }

    context = {'model': model, 'session': model.Session,
                'user': g.user, 'for_view': True}
    query = get_action('package_search')({}, data_dict)
    g.sorted_by_selected = query['sort']
    g.page = h.Page(
        collection=query['results'],
        page=page,
        url=pager_url,
        item_count=query['count'],
        items_per_page=limit
    )
    g.facets = query['search_facets']
    g.search_facets_limits = {}
    g.page.items = query['results']
    g.page.search_dict = query['search_dict']
    for facet in g.facets.keys():
        try:
            limit = int(request.params.get('_%s_limit' % facet,
                        int(config.get('search.facets.default', 10))))
        except ValueError:
            abort(400, _('Parameter "{parameter_name}" is not '
                            'an integer').format(
                    parameter_name='_%s_limit' % facet))
        g.search_facets_limits[facet] = limit
    context = {u'for_view': True, u'user': g.user, u'auth_user_obj': g.userobj}
    data_dict = {u'user_obj': g.userobj, u'include_datasets': True}
    extra_vars = _extra_template_variables(context, data_dict)
    extra_vars['user_dict']['datasets'] = query['results']
    extra_vars['owner_org'] = owner_org
    extra_vars['total_datasets'] = query['count']
    
    if owner_org and owner_org != "False":
        owner_org_dict = get_action('organization_show')(context, {'id':owner_org})
        extra_vars['owner_org_title'] = owner_org_dict['title']

    return base.render('user/bulk_update_dataset.html', extra_vars=extra_vars)


def background_job_email(context,bulk_mail_dict,  field_map, event, capacity):
    edited_items = bulk_mail_dict['items_edited']

    if edited_items:
        for item in edited_items:
            if item[0] == 'data_store_values':
                bulk_mail_dict['items_edited'].remove(item)

    bulk_mail_dict['items_edited'] = list(map(lambda x: [field_map.get(x[0], x[0]), x[1]], bulk_mail_dict['items_edited']))
    app = make_app(config) # set up flask app

    with app._wsgi_app.test_request_context():
        mail_package_publish_request_to_admins(context, bulk_mail_dict, 
                                            event=event, capacity=capacity)

def deepcopy_dict(data_dict):
    r_dict = {}
    for key, value in data_dict.items():
        if isinstance(value, dict):
            r_dict[key] = deepcopy_dict(value)
        elif isinstance(value, list) or isinstance(value, str):
            r_dict[key] = deepcopy(value)
        else:
            r_dict[key] = value   
    return r_dict

    
# load form page for bulk update
def bulk_package_update(errors=None, error_summary=None, datavalues=None):
    # CHECK IF request is a post request

    datavalues = datavalues or clean_dict(dict_fns.unflatten(
                tuplize_dict(parse_params(request.form))))

    if request.method == 'POST' and errors==None and 'datavalues' not in datavalues:
        try:
            
            data_original = clean_dict(dict_fns.unflatten(
                tuplize_dict(parse_params(request.form))))
            data_original.update(clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
            ))

            data_store_values = data_original.get('data_store_values', None)

            pkg_name = json.loads(data_original['data_values'])
            owner_orgs  = []

            context = {
                'model': model, 'session': model.Session,
                'user': g.user, 'auth_user_obj': g.userobj, 'save': 'save'
            }

            data_dictionary_upload(context, data_original, 'package')

            # loop through pkg_name and update the dataset
            # and set to draft if dcat is not valid
            for pkg_i, pkg in enumerate(pkg_name):
                pkg = pkg[0]
                data_dict = deepcopy_dict(data_original)
                save_data_dict = deepcopy_dict(data_original)
                save_data_dict = {k:v for k, v in save_data_dict.items() if v}
                save_data_dict = {k:v for k, v in save_data_dict.items() if v != 'None'}
                pkg_dict = get_action('package_show')(context, {'id': pkg})

                if pkg_i == 0:
                    filter_field = ["data_dep_set", "data_derive_set", "tag_set", "data_values", "level_set",
                                    "program_set", "collection_set", "private", "access_level_radios"]

                    clone_data_dict = deepcopy_dict(save_data_dict)
                    updated_fields = [[k, ",".join(v) if isinstance(v, list) else v] for k , v in clone_data_dict.items() if k not in filter_field]


                if data_dict.get('data_dep_set') == 'preserve':
                    save_data_dict['relationship_dependency_of'] = set_relationships(pkg_dict, data_dict, 'relationship_dependency_of')
                else:
                    save_data_dict['relationship_dependency_of'] = data_dict['relationship_dependency_of']
                    
                if data_dict.get('data_derive_set') == 'preserve':
                    save_data_dict['relationship_derives_from'] = set_relationships(pkg_dict, data_dict, 'relationship_derives_from')
                else:
                    save_data_dict['relationship_derives_from'] = data_dict['relationship_derives_from']


                if 'tag_string' in data_dict:
                    data_dict['tags'] = _tag_string_to_list(
                        data_dict['tag_string'])

                    if data_dict.get("tag_set") == "preserve":
                        save_data_dict['tags'] = data_dict['tags'] +  pkg_dict['tags']
                    else:
                        save_data_dict['tags'] = data_dict['tags']

                if data_dict.get("program_set") == "preserve":
                    if 'program_code' in data_dict and pkg_dict['program_code'] != '':
                        program_code = pkg_dict['program_code'].replace('{', '').replace('}', '').split(',')
                        if type(data_dict['program_code']) == list:
                            save_data_dict['program_code'] += program_code
                        else:
                            save_data_dict['program_code'] = program_code
                        save_data_dict['program_code'] = list(set(save_data_dict['program_code']))
                else:
                    save_data_dict['program_code'] = data_dict.get('program_code', '')
                
                if data_dict.get("level_set") == "preserve":
                    if type(pkg_dict.get('level_of_data')) is list:
                        if type(data_dict.get('level_of_data')) is list:
                            save_data_dict['level_of_data'] += pkg_dict.get('level_of_data')
                        else:
                            if data_dict.get('level_of_data'):
                                save_data_dict['level_of_data'] =[data_dict['level_of_data']] + pkg_dict.get('level_of_data')
                    else:
                        save_data_dict['level_of_data'] += [pkg_dict.get('level_of_data')]
                else:
                    save_data_dict['level_of_data'] = data_dict.get("level_of_data") or ''


                ## check collection_set and if preserve, get the collection from the dataset
                if data_dict.get("collection_set") == "preserve":
                    collections = helpers.get_dataset_collections(pkg_dict.get('name'))
                    if 'collections' in data_dict:
                        if collections:
                            save_data_dict['collections'] = collections
                            if data_dict.get('collections') is list:
                                save_data_dict['collections'] += data_dict['collections']
                            else:
                                save_data_dict['collections'] += [data_dict['collections']]
                        else:
                            save_data_dict['collections'] = data_dict['collections']
                else:
                    save_data_dict['collections'] = data_dict.get("collections", u'')

                # set data dictionary format and mimetype
                if data_dict.get('format', ''):
                    # set format and mimetype based on the format field
                    save_data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(data_dict.get('format', '')) 
                    fake_url = 'any_filename' + '.' + data_dict.get('format', '').lower()
                    mimetype = helpers.guess_mimetypes(fake_url)
                    save_data_dict['data_dictionary_pkg_mimetype'] = mimetype
                else:
                    # set format and mimetype based on the file extension
                    data_dictionary_url = data_dict.get('data_dictionary_pkg', '')
                    save_data_dict['data_dictionary_pkg_mimetype'] = helpers.guess_mimetypes(data_dictionary_url)
                    splitted = data_dictionary_url.split('.')
                    if splitted:
                        save_data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(splitted[-1])

                if pkg_dict.get('groups'):
                    save_data_dict['groups'] = pkg_dict.get('groups')

                old_pkg = pkg_dict.copy()
                pkg_dict.update(save_data_dict)
                # ensuring pkg_dict is thesame format as wehn using the edit page
                values = [
                    'access_level','amended_by_user','author',
                    'author_email','bureau_code', 'currently_in_draft','data_dictionary_pkg',
                    'data_quality', 'ed_source','end_date','field-clear-data-dict',
                    'format','license_id','maintainer','maintainer_email','name','notes',
                    'owner_org','pkg_name','primary_it_investment_uii','private',
                    'record_schedule','relationship_dependency_of','relationship_derives_from',
                    'relationship_parent','rights','scraped_from','spatial','start_date','system_of_records',
                    'title','update_frequency','url','extras','tags','id',
                    'data_dictionary_pkg_mimetype','data_dictionary_pkg_format','indraft',
                    'state', 'level_of_data', 'program_code', 'groups', 'collections'
                ]
                pkg_dict = {k:v for k, v in pkg_dict.items() if k in values}

                pkg_dict['indraft'] = draft_func(pkg_dict)
                if pkg_dict['indraft'] not in [False, 'false']:
                    pkg_dict['private'] = True
                pkg_new = package_update(context, pkg_dict)
                owner_orgs.append(old_pkg['owner_org'])


                if pkg_new.get('indraft') in [False, 'false'] and pkg_new.get('approval_status') != 'approved' and pkg_new.get('private') in [True, 'true']:
                    contextp = {'user': '', 'ignore_auth': True }
                    enqueue_job(mail_package_publish_request_to_admins, [contextp, pkg_new, 'ready', ['coordinator']], 
                                title=f'Mail Package Publish Request to Admins {pkg_new.get("id")}', queue='ckan_mailer')

            if updated_fields:
                bulk_mail_dict = {
                    'creator_user_id': g.userobj.id,
                    'owner_orgs': owner_orgs,
                    'items_edited' : updated_fields,
                    'pkg_names': pkg_name,
                }

                # send mail to all coordinators using enqueue_job
                context_email = {'user': '', 'ignore_auth': True }
                event = "bulk_update"
                capacity = ["coordinator"]

                # data profile field map to form field
                field_map = {
                    'tag_string': 'Tags',
                    'owner_org': 'Organization',
                    'spatial': 'Spatial',
                    'data_quality': 'Data Quality',
                    'level_of_data': 'Level of Data',
                    'ed_source': "Add Data Profile to Source",
                    "relationship_dependency_of": "Dependencies of this Data Profile",
                    "relationship_parent": "Parent Data Profile",
                    "relationship_derives_from": "Data Profile(s) this data derives from",
                    "maintainer_email": "Helpdesk Email Contact",
                    "author": "Data Steward Name",
                    "author_email": "Data Steward Email",
                    "maintainer": "Helpdesk Contact Name",
                    "access_level": "Access Level",
                    "rights": "Rights",
                    "system_of_records": "System of Records URL",
                    "update_frequency": "Update Frequency",
                    "record_schedule": "Record Schedule",
                    "program_code": "Program Code",
                    "primary_it_investment_uii": "Primary IT Unique Investment Identifier (UII)",
                    "license_id": "License",
                    "start_date": "Data Representation Period - Start Date",
                    "end_date": "Data Representation Period - End Date",
                    "data_dictionary_pkg": "Data Dictionary",
                    "format": "Data Dictionary Format",
                    "collections": "Collections"
                }
 

                enqueue_job(background_job_email,[context_email, bulk_mail_dict, field_map, event, capacity], title=f'bulk_update_dataset-{bulk_mail_dict["creator_user_id"]}')
            
            # redirect to bulk update page
            url = h.url_for(controller='ed_dashboard', action='bulk_update_dataprofile')
            h.flash_success(_('Data Profile(s) have been bulk updated'))
            return h.redirect_to(url)
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            datavalues = {
                'datavalues': data_store_values
            }
            return bulk_package_update(errors, error_summary, datavalues)
            
    else:
        data = datavalues.get('datavalues', False);

        if not data and errors==None:
            url = h.url_for(controller='ed_dashboard', action='bulk_update_dataprofile')
            h.flash_error(_('No Data Profile selected'))
            return h.redirect_to(url)
        
        data_json = json.loads(data)
        data_values = []
        for value in data_json.values():
            data_values += value

        context = {u'for_view': True, u'user': g.user, u'auth_user_obj': g.userobj}
        data_dict = {u'user_obj': g.userobj, u'include_datasets': True}
        extra_vars = _extra_template_variables(context, data_dict)
        users_default = datavalues.get('default', False)
        
        pkg_data = {}
        if users_default:
            if users_default == 'True':
                user_id = g.userobj.id
                rslt = get_action(u'get_user_default_fields')(context, {u'user_id': user_id})
                pkg_data = json.loads(rslt) if rslt else {}
                pkg_data['default'] = True
                h.flash_success(_('Default values have been loaded'))
            else:
                pkg_data['default'] = False
                h.flash_success(_('Default values have been cleared'))

        extra_vars['data'] = pkg_data
        extra_vars['errors'] = errors or {}
        extra_vars['error_summary'] = error_summary or {}
        extra_vars['data_values'] = json.dumps(data_values)
        extra_vars['data_store_values'] = data
        extra_vars['list_data_values'] = data_values
        h.flash_error('NOTE that you are about to perform a bulk update on the selected data profile(s). Please ensure that you have selected the correct data profile before proceeding')
        return base.render('user/bulk_update_dataset_form.html', extra_vars=extra_vars)


ed_dashboard.add_url_rule(u'/datasets', view_func=datasets)
ed_dashboard.add_url_rule(u'/datasets/<drafts>', view_func=datasets)
ed_dashboard.add_url_rule(u'/datasets/h/<hidden>', view_func=datasets)
ed_dashboard.add_url_rule(u'/bulk_update_dataprofile', view_func=bulk_update_dataprofile)
ed_dashboard.add_url_rule(u'/bulk_package_update', view_func=bulk_package_update, methods=['GET', 'POST'])