import datetime
import logging
import string
import random
import json
from .ed_forgot_password import request_reset
from ckanext.ed.actions import ValidationError, data_dictionary_upload

from flask import Blueprint, redirect, url_for

import ckan.lib.base as base
import ckan.lib.helpers as h
import ckan.lib.mailer as ckan_mailer
import ckan.model as model
import ckan.plugins as plugins
from ckan.common import c, g, request, _, config
from ckan.views.user import (_extra_template_variables, index, me,
            EditView, RegisterView, logged_in, logout, logged_out,
            logged_out_page, delete, generate_apikey, activity, RequestResetView,
            PerformResetView, follow, unfollow, followers, _get_repoze_handler)
import ckan.authz as authz
from ckan import logic
import ckan.lib.navl.dictization_functions as dict_fns
import ckan.lib.plugins as lib_plugins

from ckanext.ed.helpers import is_admin
#from ckanext.ed.controllers import package as ed_package
from ckanext.ed import helpers as ed_helpers
from .ed_group_admin import _replace_group_owner
from .ed_package import change_package_owner

log = logging.getLogger(__name__)
clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict
parse_params = logic.parse_params

ed_user_blueprint = Blueprint(u'ed_user', __name__, url_prefix=u'/user')

_get_action = plugins.toolkit.get_action
#_ed_package_controller = ed_package.Controller()

new_user_form = u'user/add_user.html'


def add_user():
    if is_admin(g.user) is False:
        base.abort(403, _(u'Not authorized to see this page'))

    if request.method == u'POST':
        password_letters = list(string.ascii_letters)
        password_digits = list(string.digits)
        password_special = list(u"!@#$%^&*()")
        random.shuffle(password_letters)
        random.shuffle(password_digits)
        random.shuffle(password_special)
        password = [random.choice(password_letters) for i in range(4)] \
            + [random.choice(password_digits) for i in range(4)] \
            + [random.choice(password_special) for i in range(2)]
        random.shuffle(password)
        password = u''.join(password)

        email = request.form.get(u'email')
        user = request.form.get(u'name')

        if user is not None:
            user = user.lower()

        organization = request.form.get(u'user-organization')
        organization_role = request.form.get(u'user-organization-role')

        field_values = {
            u'name': user,
            u'email': email,
            u'organization': organization,
            u'organization_role': organization_role
        }

        missing_value_msg = u'Missing value(s): '
        missing_values = []

        for x, y in field_values.items():
            if y is None:
                missing_values.append(
                    u'{}: {}'.format(
                        u' '.join(x.split(u'_')).title(), y))

        if len(missing_values) > 0:
            h.flash_error(
                u'Missing value(s): {}'
                .format(', '.join(missing_values))
            )

            return base.render(
                new_user_form,
                extra_vars={
                    u'data': request.form,
                    u'errors': {}
                }
            )

        try:
            _get_action(u'user_create')(
                {u'ignore_auth': True},
                {u'name': user, u'email': email, u'password': password}
            )
            _get_action(u'organization_member_create')(
                {u'ignore_auth': True},
                {
                    u'id': organization,
                    u'username': user,
                    u'role': organization_role
                }
            )

            organization_dict = _get_action(u'organization_show')(
                {u'ignore_auth': True}, {u'id': organization}
            )
            user_obj = model.User.by_name(user)

            ckan_mailer.send_invite(
                user_obj, organization_dict, organization_role
            )

            h.flash_success(u'Successfully created user: {}'.format(user))

            return h.redirect_to(u'/user')
        except Exception as e:
            h.flash_error(e)

    return base.render(new_user_form, extra_vars={u'data': {}, u'errors': {}})


def change_owner_delete():
    if is_admin(c.user) is False:
        base.abort(403, _(u'Not authorized to see this page'))

    if request.method == u'POST':
        try:
            context = {u'ignore_auth': True}
            owners = json.loads(request.data)
            old_owner = owners.get(u'old_owner')
            new_owner = owners.get(u'new_owner')
            current_date = datetime.datetime.today().strftime(u'%m%d%Y%H%M%S')

            old_owner_dict = _get_action(u'user_show')(
                context,
                {u'id': old_owner, u'include_datasets': True}
            )

            new_owner_dict = _get_action(u'user_show')(
                context,
                {u'id': new_owner}
            )

            old_owner_datasets = old_owner_dict.get(u'datasets', [])
            old_owner_id = old_owner_dict.get(u'id')
            new_owner_id = new_owner_dict.get(u'id')
            old_owner_groups = ed_helpers.get_all_user_groups(old_owner_id)
            old_owner_updated_name = u'{}_deleted_{}'.format(
                old_owner, current_date
            )
            old_owner_updated_email = u'{}@deleted'.format(
                old_owner_updated_name
            )
            old_owner_dict[u'name'] = old_owner_updated_name
            old_owner_dict[u'email'] = old_owner_updated_email

            for dataset in old_owner_datasets:
                change_package_owner(
                    dataset[u'id'], new_owner_id
                )

            for group in old_owner_groups:
                _replace_group_owner(
                    context, group[u'id'], old_owner_id, new_owner_id
                )

            old_owner_dict[u'plugin_extras'] = {
                u'saml2auth': {
                    u'saml_id': None
                }
            }

            _get_action(u'user_update')(
                context,
                old_owner_dict
            )

            _get_action(u'user_delete')(
                context,
                {u'id': old_owner_id}
            )

        except Exception as e:
            log.error(e)
            return {u'error': str(e)}, 424, {u'ContentType': u'application/json'}

        return {u'success': True}, 200, {u'ContentType': u'application/json'}


def change_owner_delete_success(user):
    if user:
        h.flash_success(u'Successfully deleted user: {}'.format(user))
    else:
        h.flash_error(u'User not found.')

    return h.redirect_to(u'/user')


def change_owner_delete_failure(error):
    h.flash_error(u'Error: {}'.format(error))

    return h.redirect_to(u'/user')


def read(id, drafts=None, hidden=None):
    #   Verify if the user that is requesting the 
    #   resource has the necessary privileges
    is_authenticated = g.user
    if not is_authenticated:
        base.abort(403, _(u'Not authorized to see this page'))

    #   Verify if user exists
    user = model.User.get(id)
    if not user:
        base.abort(404, _(u'User not found'))

    context = {
        u'model': model,
        u'session': model.Session,
        u'user': g.user,
        u'auth_user_obj': g.userobj,
        u'for_view': True
    }
    data_dict = {
        u'id': id,
        u'user_obj': g.userobj,
        u'include_datasets': True,
        u'include_num_followers': True
    }
    g.fields = []

    org_context =  {'model': model, 'session': model.Session}

    if g.user != id and not authz.is_sysadmin(g.user):
        orgs =set([ org['name'] for org in _get_action('organization_list_for_user')(
            org_context, {'id': id}
            )  ])

        orgs_user =set([ org['name'] for org in _get_action('organization_list_for_user')(
            org_context, {'id': g.user}
            )  ])

        if orgs & orgs_user:
            context['user'] = id

    extra_vars = _extra_template_variables(context, data_dict)
    if extra_vars is None:
        return h.redirect_to(u'user.login')

    datasets = []
    creator_id = extra_vars['user_dict']['id']

    existing_datasets = [
        dp for dp in extra_vars['user_dict']['datasets']
        if dp.get('creator_user_id') == creator_id
    ]

    extra_vars['user_dict']['datasets'] = []

    if drafts:
        for dataset in existing_datasets[:]:
            if "indraft" in dataset:
                if dataset['indraft'] in [True, 'true']:
                    datasets.append(dataset)
                    existing_datasets.remove(dataset)

        extra_vars['user_dict']['datasets'] = datasets
        extra_vars['user_dict']['datasets'] += existing_datasets
        extra_vars['indraft'] = True
    elif hidden:
        for dataset in existing_datasets[:]:
            if dataset.get('private') is True:
                datasets.append(dataset)
                existing_datasets.remove(dataset)

        extra_vars['user_dict']['datasets'] = datasets
        extra_vars['user_dict']['datasets'] += existing_datasets
        extra_vars['hidden'] = True

    if not extra_vars['user_dict']['datasets']:
        extra_vars['user_dict']['datasets'] = existing_datasets

    return base.render(u'user/read.html', extra_vars)


def logged_in():
    # redirect if needed
    came_from = request.params.get(u'came_from', u'')
    if h.url_is_local(came_from) and came_from not in ['\x00']:
        return h.redirect_to(str(came_from))
    if g.user:
        return me()
    else:
        err = _(u'Login failed.')
        h.flash_error(err)
        return login()


def default_package_field(id, error=None, error_summary=None):

    #   Verify if the user that is requesting the 
    #   resource has the necessary privileges
    is_authenticated = g.user
    if not is_authenticated:
        base.abort(403, _(u'Not authorized to see this page'))

    #   Verify if user exists
    user = model.User.get(g.user)
    if not user:
        base.abort(404, _(u'User not found'))

    if request.method == u'POST' and error==None:
        try:
            data_original = clean_dict(dict_fns.unflatten(
                    tuplize_dict(parse_params(request.form))))
            data_original.update(clean_dict(
                dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
            ))

            context = {
                'model': model, 'session': model.Session,
                'user': g.user, 'auth_user_obj': g.userobj, 'save': 'True'
            }
            data_dictionary_upload(context, data_original, 'package')

            data_original['spatial'] = data_original['spatial'].split(",")
            if 'data_dictionary_pkg_file' in data_original:
                del data_original[u'data_dictionary_pkg_file']

            list_fields = ['relationship_dependency_of', 'relationship_derives_from']

            for field in list_fields:
                if field in data_original:
                    data_original[field] = data_original[field].split(',')


            filter_field = ["data_dep_set", "data_derive_set", "tag_set", "data_values", "level_set",
                                    "program_set", "collection_set", "private", "access_level_radios"]
            
            data_original = {k: v for k, v in data_original.items() if k not in filter_field}

            if not data_original.get('level_of_data'):
                data_original['level_of_data'] = ''

            if not data_original.get('program_code'):
                data_original['program_code'] = ''

            if 'data_quality' in data_original:
                if data_original['data_quality']:
                    if data_original['data_quality'] == 'True':
                        data_original['data_quality'] = True
                    else:
                        data_original['data_quality'] = False

            package_plugin = lib_plugins.lookup_package_plugin("dataset")
            schema = package_plugin.create_package_schema()
            if 'api_version' not in context:
                check_data_dict = getattr(package_plugin, 'check_data_dict', None)
                if check_data_dict:
                    try:
                        package_plugin.check_data_dict(data_dict, schema)
                    except TypeError:
                        # Old plugins do not support passing the schema so we need
                        # to ensure they still work.
                        package_plugin.check_data_dict(data_dict)

            # add name and notes just for the schema to pas
            data_original['name'] = 'name'
            data_original['notes'] = 'notes'

            _, errors = lib_plugins.plugin_validate(
                package_plugin, context, data_original, schema, 'package_create')

            if errors:
                raise ValidationError(errors)

            del data_original['name']
            del data_original['notes']

            prev_rslt = _get_action(u'get_user_default_fields')({'model': model}, {u'user_id': id})

            prev_rslt = json.loads(prev_rslt) if prev_rslt else {}
            prev_rslt.update(data_original)
            data_dict = {
                'user_id': id,
                'fields': json.dumps(prev_rslt)
            }
            
            _get_action(u'create_user_default_fields')({'model': model}, data_dict=data_dict)
            h.flash_success('User default fields updated successfully')
            return h.redirect_to(h.url_for(u'ed_user.read', id=id))
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return default_package_field(id, errors, error_summary)
        pass

    context = {
        u'model': model,
        u'session': model.Session,
        u'user': g.user,
        u'auth_user_obj': g.userobj,
        u'for_view': True
    }
    data_dict = {
        u'id': g.user,
        u'user_obj': g.userobj,
        u'include_datasets': False,
        u'include_num_followers': True
    }
    g.fields = []

    extra_vars = _extra_template_variables(context, data_dict)
    if extra_vars is None:
        return h.redirect_to(u'user.login')

    user_id = extra_vars['user_dict']['id']
    rslt = _get_action(u'get_user_default_fields')(context, {u'user_id': user_id})
    extra_vars['data'] = json.loads(rslt) if rslt else {}
    extra_vars['errors'] = error or {}
    extra_vars['error_summary'] = error_summary or  {}

    return base.render(u'user/default_fields.html', extra_vars)


def login():
    # Do any plugin login stuff
    for item in plugins.PluginImplementations(plugins.IAuthenticator):
        response = item.login()
        if response:
            return response

    extra_vars = {}
    if g.user:
        return base.render(u'user/logout_first.html', extra_vars)

    came_from = request.params.get(u'came_from')
    if not came_from:
        came_from = h.url_for(u'user.logged_in')
    g.login_handler = h.url_for(
        _get_repoze_handler(u'login_handler_path'), came_from=came_from)
    return base.render(u'user/login.html', extra_vars)


ed_user_blueprint.add_url_rule(
    u'add_user',
    methods=[u'GET', u'POST'],
    view_func=add_user
)

ed_user_blueprint.add_url_rule(
    u'change_owner_delete',
    methods=[u'POST', u'GET'],
    view_func=change_owner_delete
)

ed_user_blueprint.add_url_rule(
    u'change_owner_delete_success/<user>',
    methods=[u'GET', u'POST'],
    view_func=change_owner_delete_success
)

ed_user_blueprint.add_url_rule(
    u'change_owner_delete_failure/<error>',
    methods=[u'GET', u'POST'],
    view_func=change_owner_delete_failure
)

ed_user_blueprint.add_url_rule(u'/', view_func=index, strict_slashes=False)
ed_user_blueprint.add_url_rule(u'/me', view_func=me)

_edit_view = EditView.as_view(str(u'edit'))
ed_user_blueprint.add_url_rule(u'/edit', view_func=_edit_view)
ed_user_blueprint.add_url_rule(u'/edit/<id>', view_func=_edit_view)

ed_user_blueprint.add_url_rule(
    u'/register', view_func=RegisterView.as_view(str(u'register')))

ed_user_blueprint.add_url_rule(u'/login', view_func=login, methods=(u'GET', u'POST'))
ed_user_blueprint.add_url_rule(u'/logged_in', view_func=logged_in)
ed_user_blueprint.add_url_rule(u'/_logout', view_func=logout)
ed_user_blueprint.add_url_rule(u'/logged_out', view_func=logged_out)
ed_user_blueprint.add_url_rule(u'/logged_out_redirect', view_func=logged_out_page)

ed_user_blueprint.add_url_rule(u'/delete/<id>', view_func=delete, methods=(u'POST', ))

ed_user_blueprint.add_url_rule(
    u'/generate_key', view_func=generate_apikey, methods=(u'POST', ))
ed_user_blueprint.add_url_rule(
    u'/generate_key/<id>', view_func=generate_apikey, methods=(u'POST', ))

ed_user_blueprint.add_url_rule(u'/activity/<id>', view_func=activity)
ed_user_blueprint.add_url_rule(u'/activity/<id>/<int:offset>', view_func=activity)

ed_user_blueprint.add_url_rule(
    u'/reset', view_func=request_reset)
ed_user_blueprint.add_url_rule(
    u'/reset/<id>', view_func=PerformResetView.as_view(str(u'perform_reset')))

ed_user_blueprint.add_url_rule(u'/follow/<id>', view_func=follow, methods=(u'POST', ))
ed_user_blueprint.add_url_rule(u'/unfollow/<id>', view_func=unfollow, methods=(u'POST', ))
ed_user_blueprint.add_url_rule(u'/followers/<id>', view_func=followers)
ed_user_blueprint.add_url_rule(u'/<id>', view_func=read, strict_slashes=True)
ed_user_blueprint.add_url_rule(u'/<id>/r/<drafts>', view_func=read)
ed_user_blueprint.add_url_rule(u'/<id>/h/<hidden>', view_func=read)
ed_user_blueprint.add_url_rule(u'/<id>/default_fields', view_func=default_package_field, methods=['GET', 'POST'])
