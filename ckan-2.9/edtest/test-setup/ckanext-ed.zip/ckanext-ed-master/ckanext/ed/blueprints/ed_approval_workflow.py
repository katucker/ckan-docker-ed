import logging
import time
import uuid

from flask import Blueprint
from ckan.lib import base
from ckan import model, logic
from ckan.common import request, c, _
from ckan.plugins import toolkit
import ckan.lib.helpers as h
from ckanext.ed.core_activity_streams import activity_list_to_html
import ckan.lib.dictization.model_dictize as model_dictize

import ckanext.ed.mailer as mailer
from ckanext.ed import activity_streams as ed_activity_streams
import ckanext.ed.helpers as ed_helpers

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized

abort = base.abort

log = logging.getLogger(__name__)

config = toolkit.config

ed_approval_workflow_blueprint = Blueprint(
    'approval_dashboard', __name__, url_prefix='/dashboard/approval'
)


def _raise_not_authz():
    '''Raises NotAuthorized if user is not a sysadmin
    '''
    if not c.userobj:
        abort(403, _('Unauthorized to see this page.'))

    is_admin = c.userobj.sysadmin
    if not any(role for role in [is_admin, ed_helpers.is_coordinator(c.user)]):
        abort(403, _('Unauthorized to see this page.'))


def index(id=None, offset: int = 0):
    '''Render approval dashboard activity stream page.'''
    _raise_not_authz()

    context = {
        'model': model, 'session': model.Session, 'user': toolkit.c.user,
        'for_view': True, 'auth_user_obj': toolkit.c.userobj
    }
    extra_vars = {
        'isApprovalWorkflow': True,
        'id': toolkit.c.userobj.id,
        'offset': offset,
    }

    activity_stream = _approval_dashboard_activity_stream()
    dashboard_activity_stream = activity_list_to_html(
        context, activity_stream, extra_vars
    )
    extra_vars = {
        'dashboard_activity_stream': dashboard_activity_stream,
        'user_dict': c.user
    }

    return base.render('approval_workflow/dashboard.html', extra_vars)


def resource_approval_index():
    _raise_not_authz()

    context = {
        'model': model, 'session': model.Session, 'user': toolkit.c.user,
        'for_view': True, 'auth_user_obj': toolkit.c.userobj
    }
    data_dict = {
        'query': 'approval_status:approval_pending',
        'include_private': True
    }
    response = logic.get_action('resource_search')(context, data_dict)
    results = response.get('results', [])

    # Filter list again, since the search function still
    # returns resources that were translated from XLSX
    results = [
        resource for resource in results if
        resource.get('approval_status') == 'approval_pending'
    ]

    extra_vars = {
        'user_dict': c.user,
        'count': len(results),
        'resources': results
    }

    return base.render('approval_workflow/resource_approval.html', extra_vars)


def resource_approval_item(id):
    _raise_not_authz()

    context = {
        'model': model, 'session': model.Session,
        'user': c.user, 'auth_user_obj': c.userobj
    }

    data_dict = {
        'id': id
    }
    resource = {}
    package = {}
    owner_package = {}

    try:
        resource = logic.get_action('resource_show')(context, data_dict)
        package = logic.get_action('package_show')(
            context, {"id": resource['package_id']}
        )

        if package.get('type') == 'documentation':
            relationships = package.get('relationships_as_subject')

            if relationships:
                rel_extras = relationships[0].get('__extras')
                rel_object = rel_extras.get('object_package_id')

                if rel_object:
                    owner_package = logic.get_action('package_show')(
                        context, {'id': rel_object}
                    )

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Resource not found'))

    extra_vars = {}
    extra_vars['res'] = resource
    extra_vars['pkg'] = package
    extra_vars['owner_pkg'] = owner_package

    template = 'approval_workflow/snippets/resource_item_approval.html'
    return base.render(template, extra_vars=extra_vars)


def resource_approve(id, bulk=False):
    _raise_not_authz()

    context = {
        'model': model, 'session': model.Session,
        'user': c.user, 'auth_user_obj': c.userobj,
        'for_edit': True, 'action': 'approval'
    }

    data_dict = {
        'id': id,
        'approval_status': 'approved'
    }

    try:
        # Get the activity because that is the only place the user who changed
        # the resource is being stored.
        activity = model.Session.query(model.Activity).filter_by(
            activity_type='changed resource', object_id=id
        ).order_by(model.Activity.timestamp.desc()).first()

        resource = logic.get_action('resource_patch')(context, data_dict)

        if activity:
            user_creator = activity.user_id
        else:
            pkg_dict = toolkit.get_action('package_show')(
                {}, {'id': resource.get('package_id')}
            )

            user_creator = model.User.get(pkg_dict.get('creator_user_id', '')).id

        #create activity
        ed_activity_streams.workflow_activity_create(
            'resource_approved', 'resource',
            resource, c.user
        )

        if not bulk:
            #send email
            mailer.mail_resource_to_user(
                resource, 'approval', user_creator=user_creator
            )

            #flash message
            h.flash_success('Resource approved successfully.')

            #redirect
            return h.redirect_to('approval_dashboard.resource_approval_index')
        else:
            return resource, user_creator

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Resource not found'))


def resource_reject(id, bulk=False, feedback=u''):
    _raise_not_authz()

    context = {
        'model': model, 'session': model.Session,
        'user': c.user, 'auth_user_obj': c.userobj,
        'for_edit': True, 'action': 'reject'
    }

    data_dict = {
        'id': id,
        'approval_status': 'rejected'
    }

    try:
        # Get the activity because that is the only place the user who changed
        # the resource is being stored.
        activity = model.Session.query(model.Activity).filter_by(
            activity_type='changed resource', object_id=id
        ).order_by(model.Activity.timestamp.desc()).first() 

        resource = logic.get_action('resource_patch')(context, data_dict)

        if activity:
            user_creator = activity.user_id
        else:
            pkg_dict = toolkit.get_action('package_show')(
                {}, {'id': resource.get('package_id')}
            )
            user_creator = model.User.get(pkg_dict.get('creator_user_id', '')).id

        if not bulk:
            # get feedback
            feedback = request.params.get('feedback', u'')

        #create activity
        ed_activity_streams.workflow_activity_create(
            'resource_rejected', 'resource',
            resource, c.user, feedback
        )

        if not bulk:
            #send email
            mailer.mail_resource_to_user(
                resource, 'reject', user_creator, feedback
            )

            #flash message
            h.flash_success('Resource rejected successfully.')

            #redirect
            return h.redirect_to('approval_dashboard.resource_approval_index')
        else:
            return resource, user_creator

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Resource not found'))


def bulk_resource_approval(approval_type='approve'):
    resource_ids = []
    feedback = None
    job_title = u'Bulk resource approval email notifications for type: {}-{}'\
        .format(approval_type, uuid.uuid4())

    is_approval = approval_type == 'approve'
    approval_action = 'approval' if is_approval else 'reject'
    approval_status = 'approved' if is_approval else 'rejected'

    if approval_type == 'approve':
        resource_ids = request.params.get('ids', u'')

        if resource_ids != '':
            resource_ids = resource_ids.split(',')
        else:
            resource_ids = None

        if resource_ids:
            resources_and_creators = {}

            for i, id in enumerate(resource_ids):
                resource, creator_name = resource_approve(id, True)
                creator = model.User.get(creator_name)

                notification_enabled = ed_helpers.get_notf_preference('resource_approval_process', creator.id)

                if notification_enabled:
                    resources_and_creators.update({
                        i: {
                            'resource': resource,
                            'creator_name': creator_name,
                            'creator': creator
                        }
                    })

            toolkit.enqueue_job(
                bulk_resource_email_job, [
                    resources_and_creators,
                    approval_action,
                    approval_status
                ], title=job_title
            )

            #flash message
            h.flash_success('Resource(s) approved successfully.')

            #redirect
            return h.redirect_to('approval_dashboard.resource_approval_index')

    if approval_type == 'reject':
        feedback = request.params.get('feedback', u'')
        resource_ids = request.params.get('ids', u'')

        if resource_ids != '':
            resource_ids = resource_ids.split(',')
        else:
            resource_ids = None

        if resource_ids:
            resources_and_creators = {}

            for i, id in enumerate(resource_ids):
                resource, creator_name = resource_reject(
                    id, True, feedback
                )
                creator = model.User.get(creator_name)

                notification_enabled = ed_helpers.get_notf_preference('resource_approval_process', creator.id)

                if notification_enabled:
                    resources_and_creators.update({
                        i: {
                            'resource': resource,
                            'creator_name': creator_name,
                            'creator': creator
                        }
                    })

            toolkit.enqueue_job(
                bulk_resource_email_job, [
                    resources_and_creators,
                    approval_action,
                    approval_status,
                    feedback
                ], title=job_title
            )

            #flash message
            h.flash_success('Resource(s) rejected successfully.')

            #redirect
            return h.redirect_to('approval_dashboard.resource_approval_index')

    h.flash_error(
        'Please select the resource(s) you\'d like to approve or reject.'
    )
    return h.redirect_to('approval_dashboard.resource_approval_index')


def _approval_dashboard_activity_stream(filter_type=None, offset=0):
    '''Return the approval dashboard activity stream of the current user.

    :param filter_type: the type of thing to filter by
    :type filter_type: string

    :returns: an activity stream as an HTML snippet
    :rtype: string

    '''       
    context = {
        'model': model, 'session': model.Session, 'user': toolkit.c.user,
        'for_view': True, 'auth_user_obj': toolkit.c.userobj
    }

    data_dict = {}
    
    try:
        activity_list = model.Session.query(model.Activity).filter(
            model.Activity.data.like('%workflow_activity%')).all()
        activity_dicts = model_dictize.activity_list_dictize(
            activity_list, context, include_data=True)

        activity_dicts.sort(key=lambda x: x['timestamp'], reverse=True)

    except NotFound:
        base.abort(404, _('Activity not found'))
    except toolkit.NotAuthorized:
        base.abort(403, _('Unauthorized to access resource') % id)

    return activity_dicts


def bulk_resource_email_job(resources_and_creators, approval_action,
                            approval_status, feedback=None):

    for k, resource in resources_and_creators.items():
        # Avoid rate limits
        time.sleep(2)

        mailer.mail_resource_to_user(
            resource['resource'],
            approval_action,
            resource['creator_name'],
            feedback,
            resource['creator']
        )

def data_profile_approval():
    context = {'model': model, 'session': model.Session,
               'user': c.user, 'auth_user_obj': c.userobj}

    user_orgs = ed_helpers.get_coordinator_orgs(c.user)
    private_datasets = ed_helpers.get_private_packages(c.user, user_orgs)
    user_dict = c.user

    data_dict = {
        'all_fields': True,
        'include_extras': True
    }

    vars = {}
    vars['data_dict'] = data_dict
    vars['user_dict'] = user_dict
    vars['count'] = len(private_datasets)
    vars['private_datasets'] = private_datasets

    template = 'approval_workflow/data_profile_approval.html'
    return base.render(template, extra_vars=vars)


# Register Blueprints
ed_approval_workflow_blueprint.add_url_rule(
    '/',
    view_func=index, strict_slashes=False,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/<id>/<int:offset>',
    view_func=index,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/resources',
    view_func=resource_approval_index,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/resource/<id>',
    view_func=resource_approval_item,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/resource/<id>/approve',
    view_func=resource_approve,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/resource/<id>/reject',
    view_func=resource_reject,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/resources/bulk/<approval_type>',
    view_func=bulk_resource_approval,
    methods=['GET', 'POST']
)

ed_approval_workflow_blueprint.add_url_rule(
    '/data-profiles',
    view_func=data_profile_approval,
    methods=['GET', 'POST']
)
