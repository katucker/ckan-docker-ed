from csv import excel
import logging
from urllib.parse import urlencode
from six import string_types
from collections import OrderedDict

from flask import Blueprint
import ckan.model as model
import ckan.logic as logic
import ckan.lib.base as base
import ckan.lib.helpers as h
import ckan.lib.search as search
from ckan.lib.plugins import lookup_group_controller
from ckan.common import _, request, c, config, g
import ckan.lib.navl.dictization_functions as dict_fns
from ckan.views.group import (
    _guess_group_type, _setup_template_variables, _get_group_template,
    _check_access, _db_to_form_schema, _update_facet_titles,
    _render_template, index, set_org, activity, about, members,
    BulkProcessView, MembersGroupView, member_delete, history, followers,
    follow, unfollow, admins
)
from ckanext.ed.blueprints.utils import _ensure_controller_matches_group_type

from ckanext.ed.helpers import render_markdown


ed_collections_blueprint = Blueprint(
    'ed_collection', __name__,
    url_prefix='/collection',
    url_defaults={
        'group_type': 'collection',
        'is_organization': False
    }
)

log = logging.getLogger(__name__)

render = base.render
abort = base.abort

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
check_access = logic.check_access
get_action = logic.get_action
tuplize_dict = logic.tuplize_dict
clean_dict = logic.clean_dict
parse_params = logic.parse_params
flatten_to_string_key = logic.flatten_to_string_key

group_types = ['collection']


def new(group_type='collection', is_organization=False, data=None, errors=None, error_summary=None):
    if data:
        data['type'] = group_type

    context = {'model': model, 'session': model.Session,
                'user': c.user,
                'save': 'save' in request.form,
                'parent': request.form.get('parent', None)}

    try:
        _check_access('group_create', context)
    except NotAuthorized:
        abort(403, _('Unauthorized to create a group'))

    if context['save'] and not data and request.method == 'POST':
        return _save_new(context, group_type)

    data = data or {}
    if not data.get('image_url', '').startswith('http'):
        data.pop('image_url', None)

    # in the phased add collection we need to know that
    # we have already completed stage 1
    stage = ['active']

    if data.get('state', '').startswith('draft'):
        stage = ['active', 'complete']

    errors = errors or {}
    error_summary = error_summary or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'new',
            'group_type': group_type, 'stage': stage,}

    _setup_template_variables(context, data, group_type=group_type)
    form = base.render(
        _get_group_template(u'group_form', group_type), vars)

    c.form = form

    vars["form"] = form
    return base.render(
        _get_group_template(u'new_template', group_type), vars)


def _save_new(context, group_type=None):
    ckan_phase = request.form.get('_ckan_phase')
    save = context['save']

    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        data_dict['type'] = group_type or 'group'
        context['message'] = data_dict.get('log_message', '')
        data_dict['users'] = [{'name': c.user, 'capacity': 'admin'}]

        package_names = data_dict.get('collection_packages', None)
        if package_names and type(package_names) == str:
            names_list = package_names.split(',')
            data_dict['collection_packages'] = names_list

        group = get_action('group_create')(context, data_dict)

        if save == True:
            return h.redirect_to('ed_documentation.new', origin='collection', origin_id=group['name'])

        # Redirect to the appropriate _read route for the type of group
        return h.redirect_to(group['type'] + '.read', id=group['name'])
    except (NotFound, NotAuthorized) as e:
        abort(404, _('Group not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return new(group_type, False, data_dict, errors, error_summary)


def read(id, group_type='collection', is_organization=False, limit=20):
        group_type = _ensure_controller_matches_group_type(
            id.split('@')[0], group_type)

        context = {'model': model, 'session': model.Session,
                   'user': c.user,
                   'schema': _db_to_form_schema(group_type=group_type),
                   'for_view': True}
        data_dict = {'id': id, 'type': group_type}

        # unicode format (decoded from utf8)
        c.q = request.form.get('q', '')

        try:
            # Do not query for the group datasets when dictizing, as they will
            # be ignored and get requested on the controller anyway
            data_dict['include_datasets'] = False

            # Do not query group members as they aren't used in the view
            data_dict['include_users'] = False

            c.group_dict = get_action('group_show')(context, data_dict)
            c.group = context['group']
        except (NotFound, NotAuthorized):
            abort(404, _('Group not found'))

        # if the user specified a group id, redirect to the group name
        if data_dict['id'] == c.group_dict['id'] and \
                data_dict['id'] != c.group_dict['name']:
            return h.redirect_to(controller=group_type, action='read',
                          id=c.group_dict['name'])

        _read(id, limit, group_type)

        extra_vars={'group_type': group_type}

        return base.render(_get_group_template(
            u'read_template', group_type), extra_vars)

def _read(id, limit, group_type):
    ''' This is common code used by both read and bulk_process'''
    context = {
        'model': model, 'session': model.Session,
        'user': c.user,
        'schema': _db_to_form_schema(group_type=group_type),
        'for_view': True, 'extras_as_string': True
    }

    q = c.q = request.form.get('q', '')
    # Search within group
    if c.group_dict.get('is_organization'):
        fq = 'owner_org:"%s"' % c.group_dict.get('id')
    else:
        fq = 'groups:"%s"' % c.group_dict.get('name')

    c.description_formatted = \
        render_markdown(c.group_dict.get('description'))

    context['return_query'] = True

    page = h.get_page_number(request.params)

    # most search operations should reset the page counter:
    params_nopage = [(k, v) for k, v in request.form.items()
                        if k != 'page']
    sort_by = request.form.get('sort', None)

    def search_url(params):
        controller = lookup_group_controller(group_type)
        action = 'bulk_process' if c.action == 'bulk_process' else 'read'
        url = h.url_for(controller=controller, action=action, id=id)
        params = [(k, v.encode('utf-8') if isinstance(v, string_types)
                    else str(v)) for k, v in params]
        return url + u'?' + urlencode(params)

    def drill_down_url(**by):
        return h.add_url_param(alternative_url=None,
                                controller='group', action='read',
                                extras=dict(id=c.group_dict.get('name')),
                                new_params=by)

    c.drill_down_url = drill_down_url

    def remove_field(key, value=None, replace=None):
        controller = lookup_group_controller(group_type)
        return h.remove_url_param(key, value=value, replace=replace,
                                    controller=controller, action='read',
                                    extras=dict(id=c.group_dict.get('name')))

    c.remove_field = remove_field

    def pager_url(q=None, page=None):
        params = list(params_nopage)
        params.append(('page', page))
        return search_url(params)

    try:
        c.fields = []
        c.fields_grouped = {}
        search_extras = {}
        for (param, value) in request.form.items():
            if param not in ['q', 'page', 'sort'] \
                    and len(value) and not param.startswith('_'):
                if not param.startswith('ext_'):
                    c.fields.append((param, value))
                    q += ' %s: "%s"' % (param, value)
                    if param not in c.fields_grouped:
                        c.fields_grouped[param] = [value]
                    else:
                        c.fields_grouped[param].append(value)
                else:
                    search_extras[param] = value

        facets = OrderedDict()

        default_facet_titles = {'organization': _('Organizations'),
                                'groups': _('Groups'),
                                'tags': _('Tags'),
                                'res_format': _('Formats'),
                                'license_id': _('Licenses')}

        for facet in h.facets():
            if facet in default_facet_titles:
                facets[facet] = default_facet_titles[facet]
            else:
                facets[facet] = facet

        # Facet titles
        _update_facet_titles(facets, group_type)

        c.facet_titles = facets

        data_dict = {
            'q': q,
            'fq': fq,
            'include_private': True,
            'facet.field': [facet for facet in facets.keys()],
            'rows': limit,
            'sort': sort_by,
            'start': (page - 1) * limit,
            'extras': search_extras
        }

        context_ = dict((k, v) for (k, v) in context.items()
                        if k != 'schema')
        query = get_action('package_search')(context_, data_dict)

        c.page = h.Page(
            collection=query['results'],
            page=page,
            url=pager_url,
            item_count=query['count'],
            items_per_page=limit
        )

        c.group_dict['package_count'] = query['count']

        c.search_facets = query['search_facets']
        c.search_facets_limits = {}
        for facet in c.search_facets.keys():
            limit = int(request.form.get('_%s_limit' % facet,
                        config.get('search.facets.default', 10)))
            c.search_facets_limits[facet] = limit
        c.page.items = query['results']

        c.sort_by_selected = sort_by

    except search.SearchError as se:
        log.error('Group search error: %r', se.args)
        c.query_error = True
        c.page = h.Page(collection=[])

    _setup_template_variables(context, {'id': id},
                                    group_type=group_type)


def documentation_read(id, group_type=None, is_organization=False, limit=20):
    group_type = _ensure_controller_matches_group_type(
        id.split('@')[0], group_types)

    context = {'model': model, 'session': model.Session,
                'user': c.user,
                'schema': _db_to_form_schema(group_type=group_type),
                'for_view': True}
    data_dict = {'id': id, 'type': group_type}

    # unicode format (decoded from utf8)
    c.q = request.form.get('q', '')

    try:
        # Do not query for the group datasets when dictizing, as they will
        # be ignored and get requested on the controller anyway
        data_dict['include_datasets'] = False
        c.group_dict = get_action('group_show')(context, data_dict)
        c.group = context['group']
    except (NotFound, NotAuthorized):
        abort(404, _('Group not found'))

    _read(id, limit, group_type)
    _documentation_read(id, limit, group_type)
    # return render(._read_template(c.group_dict['type']),
    #               extra_vars={'group_type': group_type})
    return render('collection/documentation_read.html',
                    {'group_type': group_type})


def _documentation_read(id, limit, group_type):
    ''' This is common code used by both read and bulk_process'''
    context = {
        'model': model, 'session': model.Session,
        'user': c.user,
        'schema': _db_to_form_schema(group_type=group_type),
        'for_view': True, 'extras_as_string': True
    }

    if c.group_dict.get('is_organization'):
        fq = 'owner_org:"%s"' % c.group_dict.get('id')
    else:
        fq = 'groups:"%s"' % c.group_dict.get('name')

    context['return_query'] = True

    page = 1

    # most search operations should reset the page counter:
    params_nopage = [(k, v) for k, v in request.form.items()
                        if k != 'page']
    sort_by = request.form.get('sort', None)

    def search_url(params):
        controller = lookup_group_controller(group_type)
        action = 'bulk_process' if c.action == 'bulk_process' else 'read'
        url = h.url_for(controller=controller, action=action, id=id)
        params = [(k, v.encode('utf-8') if isinstance(v, string_types)
                    else str(v)) for k, v in params]
        return url + u'?' + urlencode(params)

    def drill_down_url(**by):
        return h.add_url_param(alternative_url=None,
                                controller='group', action='read',
                                extras=dict(id=c.group_dict.get('name')),
                                new_params=by)


    def remove_field(key, value=None, replace=None):
        controller = lookup_group_controller(group_type)
        return h.remove_url_param(key, value=value, replace=replace,
                                    controller=controller, action='read',
                                    extras=dict(id=c.group_dict.get('name')))


    try:
        data_dict = {
            'q': '',
            'fq': fq,
            'type': 'documentation',
            'include_private': True,
        }
        context_ = dict((k, v) for (k, v) in context.items()
                        if k != 'schema')
        query = get_action('package_search')(context_, data_dict)
        c.doc_page = h.Page(
            collection=query['results'],
            page=page,
            item_count=query['count'],
            items_per_page=limit
        )

        c.doc_page.items = query['results']

    except search.SearchError as se:
        log.error('Group search error: %r', se.args)

    _setup_template_variables(context, {'id': id},
                                    group_type=group_type)


def edit(id, group_type=None, is_organization=False, data=None, errors=None, error_summary=None):
    group_type = _ensure_controller_matches_group_type(
        id.split('@')[0], group_types)

    context = {
        'model': model, 'session': model.Session,
        'user': c.user,
        'save': 'save' in request.form,
        'for_edit': True,
        'parent': request.form.get('parent', None)
    }
    data_dict = {'id': id, 'include_datasets': False}

    if context['save'] and not data and request.method == 'POST':
        return _save_edit(id, context)

    try:
        data_dict['include_datasets'] = False
        old_data = get_action('group_show')(context, data_dict)
        c.grouptitle = old_data.get('title')
        c.groupname = old_data.get('name')
        data = data or old_data
    except (NotFound, NotAuthorized):
        abort(404, _('Group not found'))

    group = context.get("group")
    c.group = group
    c.group_dict = get_action('group_show')(context, data_dict)

    try:
        _check_access('group_update', context)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))

    errors = errors or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'edit',
            'group_type': group_type}

    _setup_template_variables(context, data, group_type=group_type)
    form = base.render(
            _get_group_template(u'group_form', group_type), vars)
    c.form = form
    vars["form"] = form
    return base.render(
        _get_group_template(u'edit_template', group_type), vars)


def _save_edit(id, context):
    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))

        context['message'] = data_dict.get('log_message', '')
        data_dict['id'] = id
        context['allow_partial_update'] = True

        if not data_dict.get('scraped_from', None):
            data_dict['scraped_from'] = u''

        if not data_dict.get('source_url', None):
            data_dict['source_url'] = u''

        package_names = data_dict.get('collection_packages', None)
        if package_names and type(package_names) == str:
            names_list = package_names.split(',')
            data_dict['collection_packages'] = names_list

        group = get_action('group_update')(context, data_dict)

        #try:
            # FIXME: first save doesn't work, after first attempt it gets an id, then it works
        #    group = ._action('group_update')(context, data_dict)
        #except:
        #    group = ._action('group_update')(context, data_dict)
        #if id != group['name']:
        #    ._force_reindex(group)

        return h.redirect_to('%s.read' % group['type'], id=group['name'])
    except (NotFound, NotAuthorized) as e:
        abort(404, _('Group not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return edit(id, data_dict, errors, error_summary)


def delete(id, group_type, is_organization):
    group_type = _ensure_controller_matches_group_type(id, group_types)
    if 'cancel' in request.params:
        return h.redirect_to(group_type + '.edit', id=id)

    context = {'model': model, 'session': model.Session,
                'user': c.user}

    try:
        _check_access('group_delete', context, {'id': id})
    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s') % '')

    try:
        if request.method == 'POST':
            get_action('group_delete')(context, {'id': id})
            if group_type == 'organization':
                h.flash_notice(_('Organization has been deleted.'))
            elif group_type == 'group':
                h.flash_notice(_('Group has been deleted.'))
            else:
                h.flash_notice(_('%s has been deleted.')
                                % _(group_type.capitalize()))
            return h.redirect_to(group_type + '.index')
        c.group_dict = get_action('group_show')(context, {'id': id})
    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s') % '')
    except NotFound:
        abort(404, _('Group not found'))
    except ValidationError as e:
        h.flash_error(e.error_dict['message'])
        return h.redirect_to(controller='organization', action='read', id=id)
    return _render_template('collection/confirm_delete.html', group_type)

#def register_collection_plugin_rules(blueprint: Blueprint):
actions = [
    u'member_delete', u'history', u'followers', u'follow',
    u'unfollow', u'admins', u'activity'
]
ed_collections_blueprint.add_url_rule(u'/', view_func=index, strict_slashes=False)
ed_collections_blueprint.add_url_rule(
    u'/new',
    methods=[u'GET', u'POST'],
    view_func=new)
ed_collections_blueprint.add_url_rule(u'/<id>', methods=[u'GET', u'POST'], view_func=read)
ed_collections_blueprint.add_url_rule(
    u'/edit/<id>', view_func=edit, methods=[u'GET', u'POST'])
ed_collections_blueprint.add_url_rule(
    u'/activity/<id>/<int:offset>', methods=[u'GET'], view_func=activity)
ed_collections_blueprint.add_url_rule(u'/about/<id>', methods=[u'GET'], view_func=about)
ed_collections_blueprint.add_url_rule(
    u'/members/<id>', methods=[u'GET', u'POST'], view_func=members)
ed_collections_blueprint.add_url_rule(
    u'/member_new/<id>',
    view_func=MembersGroupView.as_view(str(u'member_new')))
ed_collections_blueprint.add_url_rule(
    u'/bulk_process/<id>',
    view_func=BulkProcessView.as_view(str(u'bulk_process')))
ed_collections_blueprint.add_url_rule(
    u'/delete/<id>',
    methods=[u'GET', u'POST'],
    view_func=delete)
ed_collections_blueprint.add_url_rule(
    u'/documentation/<id>', view_func=documentation_read
)
for action in actions:
    ed_collections_blueprint.add_url_rule(
        u'/{0}/<id>'.format(action),
        methods=[u'GET', u'POST'],
        view_func=globals()[action])

#register_collection_plugin_rules(ed_collections_blueprint)
