from ckan.common import _, request, c
import ckan.lib.helpers as h
import ckan.logic as logic
from flask import Blueprint

get_action = logic.get_action

ed_user_blueprint = Blueprint(
    'ed_user', __name__, url_prefix='/user'
)

def logged_in():
    # redirect if needed
    came_from = request.form.get('came_from', '')
    if h.url_is_local(came_from):
        h.redirect_to(str(came_from))

    if c.user:
        context = None
        data_dict = {'id': c.user}

        user_dict = get_action('user_show')(context, data_dict)

        return me()
    else:
        err = _('Sign in failed. Bad username or password. ' 
            'Please contact the ODP helpdesk if the error persists.')
        
        h.flash_error(err)
        return h.redirect_to(controller='user',
                             action='login', came_from=came_from)

def me(locale=None):
    if not c.user:
        return h.redirect_to(
            locale=locale, controller='user',
            action='login', id=None
        )
    user_ref = c.userobj.get_reference_preferred_for_uri()
    return h.redirect_to(locale=locale, controller='dashboard', action='index')


ed_user_blueprint.add_url_rule('/logged_in', view_func=logged_in)