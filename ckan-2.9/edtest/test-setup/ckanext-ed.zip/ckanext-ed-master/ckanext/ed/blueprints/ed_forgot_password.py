from flask import Blueprint
from hashlib import md5
import logging

from ckan.common import request, c, _
from ckan import model, logic
import ckan.lib.helpers as h
from ckan.lib import base, mailer as ckan_mailer

log = logging.getLogger(__name__)

ed_forgot_password_blueprint = Blueprint(
    u'ed_forgot_password',
    __name__,
    url_prefix=u'/'
)

abort = base.abort
render = base.render

get_action = logic.get_action
NotFound = logic.NotFound


def request_reset():
    if request.method == 'POST':
        id = request.form.get('user')
        email = request.form.get('email')

        if not id:
            h.flash_error(_('You must enter a username'))

        if not email:
            h.flash_error(_('You must enter an email address'))

        email_hash = ''
        is_valid_email = False

        if email:
            try:
                logic.validators.email_validator(email, {})
                is_valid_email = True
            except Exception:
                h.flash_error(
                    _('"{}" is not a valid email format'.format(email)))
            email_hash = email.strip().lower().encode('utf8')
            email_hash = md5(email_hash).hexdigest()    # nosec

        context = {
            'model': model,
            'session': model.Session,
            'user': c.user,
            'ignore_auth': True
        }

        data_dict = {
            'id': id,
            'email': email,
            'email_hash': email_hash
        }

        user_dict = {}

        try:
            user_dict = get_action('user_show')(context, data_dict)
            user_obj = context['user_obj']
        except NotFound:
            pass

        if is_valid_email:
            if not user_dict or (
               user_dict and user_dict.get('email_hash') != email_hash):
                h.flash_success(
                    _('Please check your inbox for a reset code.'))
                h.redirect_to('/')
            else:
                if user_obj:
                    try:
                        ckan_mailer.send_reset_link(user_obj)
                        h.flash_success(_('Please check your inbox for '
                                          'a reset code.'))
                        h.redirect_to('/')
                    except ckan_mailer.MailerException as e:
                        h.flash_error(_('Could not send reset link: %s') % e)

    return render('user/request_reset.html')


ed_forgot_password_blueprint.add_url_rule(
    u'/user/reset',
    methods=[u'POST'],
    view_func=request_reset
)
