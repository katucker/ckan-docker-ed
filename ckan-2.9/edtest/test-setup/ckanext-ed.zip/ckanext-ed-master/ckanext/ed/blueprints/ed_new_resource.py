import cgi
import ckan
import logging

from ckan import model, logic
from ckan.common import _, request, c, config
#from paste.deploy.converters import asbool

from ckan.lib import base
from ckan.plugins import toolkit
import ckan.lib.helpers as h
import ckan.lib.navl.dictization_functions as dict_fns
from ckan.lib.plugins import lookup_package_plugin

abort = base.abort
render = base.render
render_snippet = base.render_snippet

clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict
parse_params = logic.parse_params
check_access = logic.check_access
get_action = logic.get_action

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError

log = logging.getLogger(__name__)


def new_resource(id, data=None, errors=None, error_summary=None):
    '''Controller for regular resources - does exactly the same as core new_resoruce controller
    With slight modification to differenciate it from documentations
    '''
    save_action = request.form.get('save')
    is_doc = 'from-doc' in save_action if save_action else False
    return _new_resource(id, data=data, errors=errors, error_summary=error_summary, is_doc=is_doc)

def new_doc(id, data=None, errors=None, error_summary=None, is_doc=True):
    '''Controller for regular resources - does exactly the same as core new_resoruce controller
    But adds the flag that this is a documentation
    '''
    return _new_resource(id, data=data, errors=errors, error_summary=error_summary, is_doc=True)

def _new_resource(id, data=None, errors=None, error_summary=None, is_doc=False):
    '''Core function to prepare metadata for resource and documentation controllers.
    Does different things depending on `is_doc` is True or False
    '''
    if request.method == 'POST' and not data:
        save_action = request.form.get('save')
        data = data or \
            clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
                                                        request.POST)))) 
        # we don't want to include save as it is part of the form
        del data['save']
        resource_id = data['id']
        del data['id']

        context = {
            'model': model,
            'session': model.Session,
            'user': c.user,
            'auth_user_obj': c.userobj,
            'is_doc': is_doc
        }

        # see if we have any data that we are trying to save
        data_provided = False
        for key, value in data.iteritems():
            if ((value or isinstance(value, cgi.FieldStorage))
                    and key != 'resource_type'):
                data_provided = True
                break

        if not data_provided and "go-dataset-complete" not in save_action:
            if save_action == 'go-dataset':
                # go to final stage of adddataset
                h.redirect_to(controller='package', action='edit', id=id)
            # see if we have added any resources
            try:
                data_dict = get_action('package_show')(context, {'id': id})
            except NotAuthorized:
                abort(403, _('Unauthorized to update dataset'))
            except NotFound:
                abort(404, _('The dataset {id} could not be found.'
                                ).format(id=id))
            require_resources = toolkit.asbool(
                config.get('ckan.dataset.create_on_ui_requires_resources',
                            'False')
            )
            if require_resources and not len(data_dict['resources']):
                # no data and configured to require resource: stay on page
                msg = _('You must add at least one data resource')
                # On new templates do not use flash message

                if toolkit.asbool(config.get('ckan.legacy_templates')):
                    h.flash_error(msg)
                    h.redirect_to(controller='package',
                                    action='new_resource', id=id)
                else:
                    errors = {}
                    error_summary = {_('Error'): msg}
                    return new_resource(id, data, errors,
                                                error_summary)
            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            get_action('package_update')(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))
            h.redirect_to(controller='package', action='read', id=id)

        data['package_id'] = id
        try:
            if resource_id:
                data['id'] = resource_id
                get_action('resource_update')(context, data)
            else:
                get_action('resource_create')(context, data)
        except (ValidationError, ckan.logic.ValidationError) as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return new_resource(id, data, errors, error_summary)
        except NotAuthorized:
            abort(403, _('Unauthorized to create a resource'))
        except NotFound:
            abort(404, _('The dataset {id} could not be found.'
                            ).format(id=id))
        if save_action == 'go-metadata-from-doc':
            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            get_action('package_update')(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))
            h.redirect_to(controller='package', action='read', id=id)
        elif save_action == 'go-dataset':
            # go to first stage of add dataset
            h.redirect_to(controller='package', action='edit', id=id)
        elif 'go-dataset-complete' in save_action:
            # go to first stage of add dataset
            h.redirect_to(controller='package', action='read', id=id)
        elif save_action == 'docs' or save_action == 'doc-again-from-doc':
            h.redirect_to('/dataset/new_doc/{id}'.format(id=id))
        else:
            # add more resources
            h.redirect_to(controller='EdPackageController', action='new_resource',
                            id=id)

    # get resources for sidebar
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj, 'is_doc': is_doc}
    try:
        pkg_dict = get_action('package_show')(context, {'id': id})
    except NotFound:
        abort(404, _('The dataset {id} could not be found.').format(id=id))
    try:
        check_access(
            'resource_create', context, {"package_id": pkg_dict["id"]})
    except NotAuthorized:
        abort(403, _('Unauthorized to create a resource for this package'))

    package_type = pkg_dict['type'] or 'dataset'

    errors = errors or {}
    error_summary = error_summary or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'new',
            'resource_form_snippet': _resource_form(package_type),
            'dataset_type': package_type}
    vars['pkg_name'] = id
    vars['is_doc'] = is_doc
    # required for nav menu
    # logging.error(pkg_dict)
    vars['pkg_dict'] = pkg_dict
    template = 'package/new_resource_not_draft.html'
    if pkg_dict['state'].startswith('draft'):
        vars['stage'] = ['complete', 'active']
        if is_doc:
            vars['stage'] = ['complete', 'complete', 'active']
        template = 'package/new_resource.html'
    return render_snippet(template, data=vars)

def _resource_form(package_type):
    # backwards compatibility with plugins not inheriting from
    # DefaultDatasetPlugin and not implmenting resource_form
    plugin = lookup_package_plugin(package_type)
    if hasattr(plugin, 'resource_form'):
        result = plugin.resource_form()
        if result is not None:
            return result
    return lookup_package_plugin().resource_form()
