from flask import Blueprint
import logging

from ckan.common import request, c, _
from ckan import model, logic
import ckan.lib.helpers as h
from ckan.lib import base
from ckan.views.user import _extra_template_variables

log = logging.getLogger(__name__)

ed_tags_blueprint = Blueprint(u'ed_tags', __name__, url_prefix=u'/')

abort = base.abort
render = base.render

get_action = logic.get_action
NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError


def _tag_string_to_list(tag_string):
    ''' This is used to change tags from a sting to a list of dicts '''

    out = []

    for tag in tag_string.split(','):
        tag = tag.strip()

        if tag:
            out.append({
                'name': tag,
                'state': 'active'
            })

    return out


def update_tags():
    context = {
        u'for_view': True,
        u'user': c.user,
        u'auth_user_obj': c.userobj
    }

    if request.method == 'POST':
        context = {
            u'user': c.user,
            u'auth_user_obj': c.userobj,
            'model': model,
            'session': model.Session,
            'save': True
        }
        tags = _tag_string_to_list(request.form.get('tag_string'))
        dataset = [
            d.strip() for d in request.form.get('data_profiles').split(u',')
        ]

        context['allow_partial_update'] = True

        for id in dataset:
            data_dict = {}
            
            # Check that the package exists
            try:
                data_dict = get_action('package_show')(context, {'id':id})
            except NotFound:
                log.warn("The package {} does not exist".format(id))
                continue
            except NotAuthorized as e:
                log.warn(e)
                continue

            data_dict['tags'] += tags

            try:
                pkg = get_action('package_update')(context, data_dict)
            except NotAuthorized:
                log.warn("The user {} is not authorized to edit the data \
                    profile: {}".format(context['user'], data_dict['title']))
                continue
            except ValidationError as e:
                h.flash_error(_(e))
                continue
            h.flash_success(
                _('Data Profile: "{}" has been updated'.format(pkg['title']))
            )

    data_dict = {u'user_obj': c.userobj, u'include_datasets': True}
    extra_vars = _extra_template_variables(context, data_dict)

    return base.render(u'user/dashboard_tags.html', extra_vars)


ed_tags_blueprint.add_url_rule(
    u'/dashboard/tags',
    view_func=update_tags,
    methods=[u'GET',u'POST']
)
