import cgi
from crypt import methods
import json
import ckan
import logging
from urllib.parse import urlencode

import tempfile
import urllib.request
import ckan.lib.uploader as uploader
from flask import Blueprint

from six import string_types, text_type
from collections import OrderedDict
from werkzeug.datastructures import FileStorage
from io import BytesIO

from ckan import model, logic
from ckan.lib import base
import ckan.plugins as p
import ckan.lib.helpers as h
import ckan.lib.navl.dictization_functions as dict_fns
from ckan.common import _, request, c, config, g
from ckan.lib.uploader import ResourceUpload
from ckan.views.dataset import (
    _setup_template_variables, lookup_package_plugin, _tag_string_to_list,
    CACHE_PARAMETERS, _get_package_type, authz, resources, follow, unfollow,
    followers, activity, changes, history, changes_multiple, LazyView,
    CollaboratorEditView, collaborator_delete, collaborators_read
)

from ckan.views.resource import (
    _get_pkg_template, CreateView, MethodView
)

from ckanext.ed import helpers, model as ed_model
from ckanext.ed.actions import csv_to_tags, package_create, package_update, data_dictionary_upload
from ckanext.ed.activity_streams import workflow_activity_create
from ckanext.ed.mailer import mail_package_publish_request_to_admins

log = logging.getLogger(__name__)

abort = base.abort
render = base.render

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError

get_action = logic.get_action
check_access = logic.check_access
parse_params = logic.parse_params
clean_dict = logic.clean_dict
tuplize_dict = logic.tuplize_dict

ed_dataset_blueprint = Blueprint(
    'ed_dataset',
    __name__,
    url_prefix='/dataset',
    url_defaults={'package_type': u'dataset'}
)


def draft_func(data_dict, is_pkg=None):
    fields = ['title', 'notes', 'owner_org', 'tags',
            'author', 'author_email', 'access_level', 'program_code']

    if is_pkg:
        fields = ['title', 'notes', 'tag_string', 'owner_org',
             'author', 'author_email', 'access_level', 'program_code']

    contains_all = all([data_dict.get(x) not in [None, [], ''] for x in fields])
    return not contains_all

    

def _encode_params(params):
    return [(k, v.encode('utf-8') if isinstance(v, string_types) else str(v))
            for k, v in params]


def url_with_params(url, params):
    params = _encode_params(params)
    return url + u'?' + urlencode(params)


def search_url(params, package_type=None):
    if not package_type or package_type == 'dataset':
        url = h.url_for('ed_dataset.search')
    else:
        url = h.url_for('{0}_search'.format(package_type))
    return url_with_params(url, params)

def _new_template(package_type):
    return lookup_package_plugin(package_type).new_template()

def _edit_template(package_type):
    return lookup_package_plugin(package_type).edit_template()

def _search_template(package_type):
    return lookup_package_plugin(package_type).search_template()

def _read_template(package_type):
    return lookup_package_plugin(package_type).read_template()

def _package_form(package_type=None):
    return lookup_package_plugin(package_type).package_form()

def _resource_form(package_type):
    # backwards compatibility with plugins not inheriting from
    # DefaultDatasetPlugin and not implmenting resource_form
    plugin = lookup_package_plugin(package_type)
    if hasattr(plugin, 'resource_form'):
        result = plugin.resource_form()
        if result is not None:
            return result
    return lookup_package_plugin().resource_form()

def _guess_package_type(expecting_name=False):
    """
        Guess the type of package from the URL handling the case
        where there is a prefix on the URL (such as /data/package)
    """

    # Special case: if the rot URL '/' has been redirected to the package
    # controller (e.g. by an IRoutes extension) then there's nothing to do
    # here.
    if request.path == '/':
        return 'dataset'

    parts = [x for x in request.path.split('/') if x]

    idx = -1
    if expecting_name:
        idx = -2

    pt = parts[idx]
    if pt == 'package':
        pt = 'dataset'

    return pt

def read(id, package_type=None):
    '''Overrifing base packe read controller. https://github.com/ckan/ckan/blob/f43d6a572838c792193f3239827d04f9ffea9206/ckan/controllers/package.py#L360

    Does exectly the same exapt it also includes info about resource selected.
    '''
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}

    # interpret @<revision_id> or @<date> suffix
    split = id.split('@')

    if len(split) == 2:
        data_dict['id'], revision_ref = split
        if model.is_id(revision_ref):
            context['revision_id'] = revision_ref
        else:
            try:
                date = h.date_str_to_datetime(revision_ref)
                context['revision_date'] = date
            except TypeError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
            except ValueError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
    elif len(split) > 2:
        abort(400, _('Invalid revision format: %r') %
              'Too many "@" symbols')

    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        base.abort(404, _('Dataset not found'))

    if type(c.pkg_dict['relationships_as_subject']) == list and c.pkg_dict['type'] != 'dataset':
        for relationship in c.pkg_dict['relationships_as_subject']:
            if relationship['type'] == 'child_of':
                abort(404, _('Dataset not found'))

    resource_id = request.form.get('resource', request.params.get('resource'))

    for resource in c.pkg_dict['resources']:
        resource_views = get_action('resource_view_list')(
            context, {'id': resource['id']})
        resource['has_views'] = len(resource_views) > 0
        # Backwards compatibility with preview interface
        resource['can_be_previewed'] = bool(len(resource_views))

        if not resource_id and resource.get('resource_type') != 'doc':
            resource_id = resource['id']

    package_type = c.pkg_dict['type'] or 'dataset'
    _setup_template_variables(context, {'id': id},
                              package_type=package_type)

    template = _read_template(package_type)

    vars = {'dataset_type': package_type}

    if resource_id:
        vars = _resource_read(c.pkg_dict, resource_id, context=context)

    c.current_package_id = c.pkg.id
    c.current_resource_id = resource_id

    try:
        return render(template, extra_vars=vars)
    except ckan.lib.render.TemplateNotFound as e:
        msg = _(
            "Viewing datasets of type \"{package_type}\" is "
            "not supported ({file_!r}).".format(
                package_type=package_type,
                file_=e.message
            )
        )
        abort(404, msg)

    assert False, "We should never get here"

def _resource_read(package, resource_id, context={}):
    '''Same as resource_read() from PackageController https://github.com/ckan/ckan/blob/f43d6a572838c792193f3239827d04f9ffea9206/ckan/controllers/package.py#L1083

    Does exactly the same except this returns data instead of rendering
    '''
    c.package = package

    for resource in c.package.get('resources', []):
        if resource['id'] == resource_id:
            c.resource = resource
            break
    if not c.resource:
        abort(404, _('Resource not found'))

    dataset_type = c.pkg.type or 'dataset'

    # get package license info
    license_id = c.package.get('license_id')
    try:
        c.package['isopen'] = model.Package.\
            get_license_register()[license_id].isopen()
    except KeyError:
        c.package['isopen'] = False

    # Deprecated: c.datastore_api - use h.action_url instead
    c.datastore_api = '%s/api/action' % \
        config.get('ckan.site_url', '').rstrip('/')

    resource_views = get_action('resource_view_list')(
        context, {'id': resource_id})
    c.resource['has_views'] = len(resource_views) > 0

    c.resource['can_be_previewed'] = bool(len(resource_views))

    current_resource_view = None
    view_id = request.args.get('view_id')

    if c.resource['has_views']:
        if view_id:
            current_resource_view = [rv for rv in resource_views
                                        if rv['id'] == view_id]
            if len(current_resource_view) == 1:
                current_resource_view = current_resource_view[0]
            else:
                abort(404, _('Resource view not found'))
        else:
            current_resource_view = resource_views[0]
    elif c.resource['can_be_previewed'] and not view_id:
        current_resource_view = None

    vars = {'resource_views': resource_views,
            'current_resource_view': current_resource_view,
            'dataset_type': dataset_type,
            'resource_id': resource_id}
    return vars


def new(package_type=None, data=None, errors=None, error_summary=None):
    request_data = request.form

    currently_in_draft = False
    if request.form.get(
        'currently_in_draft',
        request.args.get(
            'currently_in_draft',
            request.params.get(
                'currently_in_draft'
            )
        )
    ):
        currently_in_draft = True

    if len(request.params) > 0:
        if any('copy-relationship-choice' in item
               for item in request.params.items()) and len(request.form) == 0:
            request_data = request.params

    if data and 'type' in data:
        package_type = data['type']
    else:
        package_type = _guess_package_type(True)

    context = {'model': model, 'session': model.Session,
               'user': c.user, 'auth_user_obj': c.userobj,
               'save': 'save' in request_data}

    # Package needs to have a organization group in the call to
    # check_access and also to save it
    try:
        check_access('package_create', context)
    except NotAuthorized:
        abort(403, _('Unauthorized to create a package'))

    if context['save'] and not data and request.method == 'POST':
        return _save_new(context, package_type=package_type)

    data = data or clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
        request_data, ignore_keys=CACHE_PARAMETERS))))
    c.resources_json = h.json.dumps(data.get('resources', []))

    # convert tags if not supplied in data
    if data and not data.get('tag_string'):
        data['tag_string'] = ', '.join(
            h.dict_list_reduce(data.get('tags', {}), 'name'))

    
    user_default  = request.params.get('user_default', False)

    if user_default:
        if user_default == 'True':
            data['default'] = True
            user_id = g.userobj.id
            rslt = get_action(u'get_user_default_fields')(context, {u'user_id': user_id})
            pkg_data = json.loads(rslt) if rslt else {}
            data.update(pkg_data)
            h.flash_success(_("User's defined Default fields loaded"))
        else:
            h.flash_success(_("User's defined Default fields removed"))
            data['default'] = False

    errors = errors or {}
    error_summary = error_summary or {}
    # in the phased add dataset we need to know that
    # we have already completed stage 1
    stage = ['active']

    if data.get('state', '').startswith('draft'):
        stage = ['active']

    # if we are creating from a group then this allows the group to be
    # set automatically
    data['group_id'] = request_data.get('group') or \
        request_data.get('groups__0__id')

    form_snippet = _package_form(package_type=package_type)
    form_vars = {'data': data, 'errors': errors,
                 'error_summary': error_summary,
                 'action': 'new', 'stage': stage,
                 'dataset_type': package_type,
                 }
    c.errors_json = h.json.dumps(errors)

    _setup_template_variables(context, {},
                              package_type=package_type)

    new_template = _new_template(package_type)

    return render(new_template,
                  extra_vars={'form_vars': form_vars,
                              'form_snippet': form_snippet,
                              'dataset_type': package_type})


def _save_new(context, package_type=None):
    # The staged add dataset used the new functionality when the dataset is
    # partially created so we need to know if we actually are updating or
    # this is a real new.
    is_an_update = False
    ckan_phase = request.form.get('_ckan_phase')
    origin_id = request.form.get('origin_id')

    from ckan.lib.search import SearchIndexError

    currently_in_draft = False
    if request.form.get(
        'currently_in_draft',
        request.args.get(
            'currently_in_draft',
            request.params.get(
                'currently_in_draft'
            )
        )
    ):
        currently_in_draft = True

    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        data_dict['name_or_id'] = request.form.get('name')

        if ckan_phase:
            # prevent clearing of groups etc
            context['allow_partial_update'] = True
            # sort the tags
            if 'tag_string' in data_dict:
                data_dict['tags'] = _tag_string_to_list(
                    data_dict['tag_string'])

            # assign a default bureau code value
            #data_dict['bureau_code'] = '018:00'
            data_dict['bureau_code'] = helpers.bureau_code_auto_lookup(
                data_dict.get('owner_org')
            )

            if data_dict.get('pkg_name'):
                is_an_update = True
                # This is actually an update not a save
                data_dict['id'] = data_dict['pkg_name']
                del data_dict['pkg_name']
                # don't change the dataset state
                data_dict['state'] = 'draft'
                # this is actually an edit not a save
                pkg_dict = get_action('package_update')(context, data_dict)

                if request.form['save'] == 'go-metadata':
                    # redirect to add metadata
                    url = h.url_for('ed_dataset.new',
                                    id=pkg_dict['name'])
                else:
                    # redirect to add dataset resources
                    url = h.url_for('ed_dataset.new_resource',
                                    id=pkg_dict['name'], groups=data_dict['groups'],
                                    draft=True, currently_in_draft=currently_in_draft)

                return h.redirect_to(url)

            # Make sure we don't index this dataset
            if request.form['save'] not in ['go-resource',
                                            'go-metadata']:
                data_dict['state'] = 'draft'
            # allow the state to be changed
            context['allow_state_change'] = True

        data_dict['type'] = package_type
        context['message'] = data_dict.get('log_message', '')

        if origin_id:
            data_dict['groups'] = [{'id': origin_id}]

        data_dict['indraft'] = draft_func(data_dict)
        if data_dict['indraft'] not in [False, 'false']:
            data_dict['private'] = True
        data_dict['state'] = 'active'
        pkg_dict = package_create(context, data_dict)

        if pkg_dict.get('indraft') in [False, 'false'] and pkg_dict.get('private') is True \
           and pkg_dict.get('approval_status') != 'approved':
            mail_package_publish_request_to_admins(context, pkg_dict, 
                                    event='ready', capacity=['coordinator'])

        if ckan_phase:
            # redirect to add dataset resources
            url = h.url_for('ed_dataset.new_resource',
                            id=pkg_dict['name'], draft=True,
                            currently_in_draft=currently_in_draft)
            return h.redirect_to(url)

        _form_save_redirect(pkg_dict['name'], 'new',
                            package_type=package_type)

    except NotAuthorized:
        abort(403, _('Unauthorized to read package %s') % '')
    except NotFound as e:
        abort(404, _('Dataset not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except SearchIndexError as e:
        try:
            exc_str = text_type(repr(e.args))
        except Exception:  # We don't like bare excepts
            exc_str = text_type(str(e))
        abort(500, _(u'Unable to add package to search index.') + exc_str)
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary

        if is_an_update:
            # we need to get the state of the dataset to show the stage we
            # are on.
            pkg_dict = get_action('package_show')(context, data_dict)
            data_dict['state'] = pkg_dict['state']

            return edit(data_dict['id'], data_dict,
                        errors, error_summary)
        data_dict['state'] = 'none'

        return new(package_type, data_dict, errors, error_summary)


def new_resource(id, package_type=None, data=None, errors=None, error_summary=None):

    currently_in_draft = False
    if request.form.get(
        'currently_in_draft',
        request.args.get(
            'currently_in_draft',
            request.params.get(
                'currently_in_draft'
            )
        )
    ):
        currently_in_draft = True

    if request.method == 'POST' and not data:
        save_action = request.form.get('save')
        data = data or \
            clean_dict(dict_fns.unflatten(tuplize_dict(parse_params(
                                                       request.form))))
        data.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))
        # we don't want to include save as it is part of the form
        del data['save']
        resource_id = data['id']
        del data['id']

        context = {'model': model, 'session': model.Session,
                   'user': c.user, 'auth_user_obj': c.userobj}

        # see if we have any data that we are trying to save
        data_provided = False
        for key, value in data.items():
            if ((value or isinstance(value, cgi.FieldStorage))
                and key != 'resource_type'):
                data_provided = True
                break

        if not data_provided and save_action != "go-dataset-complete":
            if save_action == 'go-dataset':
                # go to final stage of adddataset
                return h.redirect_to('ed_dataset.edit', id=id)
            if save_action == 'go-documentation':
                data_dict = get_action('package_show')(context, {'id': id})
                package_update(
                    dict(context, allow_state_change=True),
                    dict(data_dict, state='active'))
                return h.redirect_to('ed_documentation.new',
                                     origin='dataset',
                                     origin_id=id)
            # see if we have added any resources
            try:
                data_dict = get_action('package_show')(context, {'id': id})
            except NotAuthorized:
                abort(403, _('Unauthorized to update dataset'))
            except NotFound:
                abort(404, _('The dataset {id} could not be found.'
                                ).format(id=id))
            if not len(data_dict['resources']):
                # no data so keep on page
                msg = _('You must add at least one data resource')
                # On new templates do not use flash message

                if p.toolkit.asbool(config.get('ckan.legacy_templates')):
                    h.flash_error(msg)

                    return h.redirect_to('ed_dataset.new_resource', id=id)
                else:
                    errors = {}
                    error_summary = {_('Error'): msg}

                    return new_resource(id, data, errors, error_summary)

            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            package_update(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))

            return h.redirect_to('ed_dataset.read_description', id=id)

        # upload resource data dictionary
        data_dictionary_upload(context, data, origin='resource')

        # set data dictionary format and mimetype
        if data.get('data-dictionary-format', ''):
            # set format and mimetype based on the format field
            data['data_dictionary_res_format'] = h.unified_resource_format(data.get('data-dictionary-format', '')) 
            fake_url = 'any_filename' + '.' + data.get('data-dictionary-format', '').lower()
            mimetype = helpers.guess_mimetypes(fake_url)
            data['data_dictionary_res_mimetype'] = mimetype
        else:
            # set format and mimetype based on the file extension
            data_dictionary_url = data.get('data_dictionary_res', '')
            data['data_dictionary_res_mimetype'] = helpers.guess_mimetypes(data_dictionary_url)
            splitted = data_dictionary_url.split('.')
            if splitted:
                data['data_dictionary_res_format'] = h.unified_resource_format(splitted[-1])

        # remove form fields that don't belong to the schema
        if data.get('data-dictionary-format'):
            del data['data-dictionary-format']
        
        if data.get('data_dictionary_res_file'):
            del data['data_dictionary_res_file']

        if data.get('field-clear-data-dict'):
            del data['field-clear-data-dict']

        data['package_id'] = id

        if data.get('resource_set') == 'indirect':
            if data.get('access_url'):
                data['url'] = data.get('access_url')
                data['resource_type'] = 'access_url'
            elif data.get('api_url'):
                data['url'] = data.get('api_url')
                data['resource_type'] = 'api_url'
                data['format'] = 'API'

        try:
            if resource_id:
                data['id'] = resource_id
                get_action('resource_update')(context, data)
                
            elif data.get('url'):
                resource_dict = get_action('resource_create')(context, data)
                data_dict = get_action('package_show')(context, {'id': id})
                
                if not data.get('data_dictionary_res'):
                    if not data.get('name'):
                        # update package and set indraft to true
                        data_dict = get_action('package_show')(context, {'id': id})
                        resource_index  = data_dict.get('resource_index', '')
                        resource_indraft = data_dict.get('resources_indraft', '')

                        if resource_index:
                            resource_index += ',{}'.format(resource_dict.get('id'))
                            data_dict['resource_index'] = resource_index
                        else:
                            data_dict['resource_index'] = ''

                        if resource_indraft:
                            resource_indraft += ',{}'.format(True)
                            data_dict['resources_indraft'] = resource_indraft
                        else:
                            data_dict['resources_indraft'] = ''
                        
                        data_dict['indraft'] = True
                        data_dict['private'] = True
                        get_action('package_update')(context, data_dict)

        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return new_resource(id, data, errors, error_summary)
        except NotAuthorized:
            abort(403, _('Unauthorized to create a resource'))
        except NotFound:
            abort(404, _('The dataset {id} could not be found.'
                         ).format(id=id))

        if save_action == 'go-metadata':
            # XXX race condition if another user edits/deletes
            data_dict = get_action('package_show')(context, {'id': id})
            package_update(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))
            return h.redirect_to('ed_dataset.read_description', id=id)
        elif save_action == 'go-dataset':
            # go to first stage of add dataset
            return h.redirect_to('ed_dataset.edit', id=id, currently_in_draft=currently_in_draft)
        elif save_action == 'go-dataset-complete':
            # go to new resource
            return h.redirect_to("ed_dataset.read", id=id)
        if save_action == 'go-documentation':
            data_dict = get_action('package_show')(context, {'id': id})
            data_dict['save_relationship'] = True
            data_dict['preserve_collection'] = True
            package_update(
                dict(context, allow_state_change=True),
                dict(data_dict, state='active'))

            return h.redirect_to('ed_documentation.new',
                                 origin='dataset',
                                 origin_id=id)
        else:
            # add more resources
            return h.redirect_to('ed_dataset.new_resource',
                                 id=id, draft=True, currently_in_draft=currently_in_draft)

    # get resources for sidebar
    context = {'model': model, 'session': model.Session,
               'user': c.user, 'auth_user_obj': c.userobj}
    try:
        pkg_dict = get_action('package_show')(context, {'id': id})
    except NotFound:
        abort(404, _('The dataset {id} could not be found.').format(id=id))
    try:
        check_access(
            'resource_create', context, {"package_id": pkg_dict["id"]})
    except NotAuthorized:
        abort(403, _('Unauthorized to create a resource for this package'))

    package_type = pkg_dict['type'] or 'dataset'

    errors = errors or {}
    error_summary = error_summary or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'new',
            'resource_form_snippet': _resource_form(package_type),
            'dataset_type': package_type}
    vars['pkg_name'] = id
    vars['pkg_title'] = pkg_dict['title']
    # required for nav menu
    vars['pkg_dict'] = pkg_dict
    if currently_in_draft:
        vars['currently_in_draft'] = True

    template = 'package/new_resource_not_draft.html'
    draft = request.params.get('draft', False)
    if (pkg_dict['state'].startswith('active') and draft) or currently_in_draft:
        vars['stage'] = ['complete', 'active']
        template = 'package/new_resource.html'

    return render(template, extra_vars=vars)


def edit(package_type, id, data=None, errors=None, error_summary=None):
    package_type = _get_package_type(id)
    context = {'model': model, 'session': model.Session,
               'user': c.user, 'auth_user_obj': c.userobj,
               'save': 'save' in request.form}

    currently_in_draft = False
    if request.form.get(
        'currently_in_draft',
        request.args.get(
            'currently_in_draft',
            request.params.get(
                'currently_in_draft'
            )
        )
    ):
        currently_in_draft = True

    from_button = request.args.get(
        'from_button',
        request.params.get(
            'from_button',
            False
        )
    )
    new_doc_post_wizard = request.form.get(
        'new_doc_post_wizard',
        request.args.get(
            'new_doc_post_wizard'
        )
    )
    origin = request.form.get(
        'origin',
        request.args.get(
            'origin'
        )
    )
    origin_id = request.form.get(
        'origin_id',
        request.args.get(
            'origin_id'
        )
    )

    if context['save'] and not data and request.method == 'POST':
        return _save_edit(id, context, package_type=package_type)
    try:
        c.pkg_dict = get_action('package_show')(
            dict(context, for_view=True), {'id': id})
        context['for_edit'] = True
        # to force the dataset to be read by the updated package_show schema
        context['use_cache'] = False

        old_data = get_action('package_show')(context, {'id': id})

        # old data is from the database and data is passed from the
        # user if there is a validation error. Use users data if there.
        if data:
            old_data.update(data)
        data = old_data
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))
    # are we doing a multiphase add?
    if data.get('state', '').startswith('draft'):
        c.form_action = h.url_for('ed_dataset.new')
        c.form_style = 'new'

        return new(data=data, errors=errors,
                   error_summary=error_summary)

    c.pkg = context.get("package")
    c.resources_json = h.json.dumps(data.get('resources', []))

    try:
        check_access('package_update', context)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))
    # convert tags if not supplied in data
    cpd = c.pkg_dict
    if data and not data.get('tag_string'):
        data['tag_string'] = ', '.join(h.dict_list_reduce(
            [ x for x in cpd.get('tags') if x['vocabulary_id'] is None ], 'name'))
    errors = errors or {}
    form_snippet = _package_form(package_type=package_type)
    form_vars = {'data': data, 'errors': errors,
                 'error_summary': error_summary, 'action': 'edit',
                 'dataset_type': package_type
                 }
    c.errors_json = h.json.dumps(errors)

    _setup_template_variables(context, {'id': id},
                              package_type=package_type)

    # we have already completed stage 1
    form_vars['stage'] = ['active']

    if data.get('state', '').startswith('draft'):
        form_vars['stage'] = ['active', 'complete']

    if origin and origin_id and new_doc_post_wizard and from_button:
        form_vars['origin'] = origin
        form_vars['origin_id'] = origin_id
        form_vars['new_doc_post_wizard'] = new_doc_post_wizard
        form_vars['from_button'] = from_button

    edit_template = _edit_template(package_type)

    if currently_in_draft:
        c.form_action = h.url_for('ed_dataset.new')
        c.form_style = 'new'

        return new(data=data, errors=errors,
                   error_summary=error_summary)

    user_default  = request.params.get('user_default', False)
    
    if user_default:
        if user_default == 'True':
            form_vars['data']['default'] = True
            user_id = g.userobj.id
            rslt = get_action(u'get_user_default_fields')(context, {u'user_id': user_id})
            pkg_data = json.loads(rslt) if rslt else {}
            form_vars['data'].update(pkg_data)
            h.flash_success(_("User's defined Default fields loaded"))
        else:
            h.flash_success(_("User's defined Default fields removed"))
            form_vars['data']['default'] = False

    return render(edit_template,
                  extra_vars={'form_vars': form_vars,
                              'form_snippet': form_snippet,
                              'dataset_type': package_type})

def _save_edit(name_or_id, context, package_type=None):
    from ckan.lib.search import SearchIndexError
    log.debug('Package save request name: %s POST: %r',
              name_or_id, request.form)
    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))
        ))
        data_dict.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))
        if '_ckan_phase' in data_dict:
            # we allow partial updates to not destroy existing resources
            context['allow_partial_update'] = True
            if 'tag_string' in data_dict:
                data_dict['tags'] = _tag_string_to_list(
                    data_dict['tag_string'])
            #     data_dict['spatial'] = _tag_string_to_list(
            #         data_dict['spatial'])
            #     data_dict['level_of_data'] = _tag_string_to_list(
            #         data_dict['level_of_data'])
            del data_dict['_ckan_phase']
            del data_dict['save']
        context['message'] = data_dict.get('log_message', '')
        data_dict['id'] = name_or_id
        # import ipdb; ipdb.set_trace()
        
        # data dictionary upload
        # FIXME get the mimetype from the upload object called in the data_dictionary_upload
        data_dictionary_upload(context, data_dict, 'package')

        # set data dictionary format and mimetype
        if data_dict.get('format', ''):
            # set format and mimetype based on the format field
            data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(data_dict.get('format', '')) 
            fake_url = 'any_filename' + '.' + data_dict.get('format', '').lower()
            mimetype = helpers.guess_mimetypes(fake_url)
            data_dict['data_dictionary_pkg_mimetype'] = mimetype
        else:
            # set format and mimetype based on the file extension
            data_dictionary_url = data_dict.get('data_dictionary_pkg', '')
            data_dict['data_dictionary_pkg_mimetype'] = helpers.guess_mimetypes(data_dictionary_url)
            splitted = data_dictionary_url.split('.')
            if splitted:
                data_dict['data_dictionary_pkg_format'] = h.unified_resource_format(splitted[-1])
        
        #bureau_code update
        data_dict['bureau_code'] = helpers.bureau_code_auto_lookup(
            data_dict.get('owner_org'))
        pkg_old_dict = get_action('package_show')(
            dict(context, for_view=True),
            {'id': name_or_id})
        if pkg_old_dict.get('groups'):
            data_dict['groups'] = pkg_old_dict.get('groups')

        data_dict['indraft'] = draft_func(data_dict)
        if data_dict['indraft'] not in [False, 'false']:
            data_dict['private'] = True
        data_dict['state'] = 'active'
        pkg = package_update(context, data_dict)

        currently_in_draft = request.form.get('currently_in_draft', False)

        if pkg.get('indraft') in [False, 'false'] and currently_in_draft and pkg.get('approval_status') != 'approved':
            contextp = {'model': model, 'session': model.Session}
            mail_package_publish_request_to_admins(contextp, pkg, 
                                    event='ready', capacity=['coordinator'])
        c.pkg = context['package']
        c.pkg_dict = pkg

        from_button = request.params.get(
            'from_button',
            request.args.get(
                'from_button'
            )
        )
        origin = request.params.get(
            'origin',
            request.args.get(
                'origin'
            )
        )
        origin_id = request.params.get(
            'origin_id',
            request.args.get(
                'origin_id'
            )
        )
        new_doc_post_wizard = request.params.get(
            'new_doc_post_wizard',
            request.args.get(
                'new_doc_post_wizard'
            )
        )

        if from_button and origin and origin_id and new_doc_post_wizard:
            return h.redirect_to(
                'ed_documentation.new_resource',
                id=name_or_id,
                origin=origin,
                origin_id=origin_id,
                new_doc_post_wizard=new_doc_post_wizard,
                from_button=from_button
            )

        if not from_button and origin and origin_id:
            return h.redirect_to(
                'ed_documentation.new_resource',
                id=name_or_id,
                origin=origin,
                origin_id=origin_id
            )

        return _form_save_redirect(pkg['name'], 'edit',
                                   package_type=package_type)
    except NotAuthorized:
        abort(403, _('Unauthorized to read package %s') % id)
    except NotFound as e:
        abort(404, _('Dataset not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except SearchIndexError as e:
        try:
            exc_str = text_type(repr(e.args))
        except Exception:  # We don't like bare excepts
            exc_str = text_type(str(e))
        abort(500, _(u'Unable to update search index.') + exc_str)
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        data_dict['spatial'] = csv_to_tags(data_dict['spatial'])
        # data_dict['level_of_data'] = csv_to_tags(data_dict['level_of_data'])
        return edit(package_type, name_or_id, data_dict, errors, error_summary)

def groups(id, package_type=None):
    context = {'model': model, 'session': model.Session,
               'user': c.user, 'for_view': True,
               'auth_user_obj': c.userobj, 'use_cache': False}
    data_dict = {'id': id}

    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        dataset_type = c.pkg_dict['type'] or 'dataset'
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    if type(c.pkg_dict['relationships_as_subject']) == list and c.pkg_dict['type'] != 'dataset':
        for relationship in c.pkg_dict['relationships_as_subject']:
            if relationship['type'] == 'child_of':
                abort(404, _('Dataset not found'))

    if request.method == 'POST':
        new_group = request.args.get('group_added')
        if new_group:
            data_dict = {"id": new_group,
                         "object": id,
                         "object_type": 'package',
                         "capacity": 'public'}
            try:
                get_action('member_create')(context, data_dict)
            except NotFound:
                abort(404, _('Group not found'))

        removed_group = None
        for param in request.args:
            if param.startswith('group_remove'):
                removed_group = param.split('.')[-1]
                break
        if removed_group:
            data_dict = {"id": removed_group,
                            "object": id,
                            "object_type": 'package'}

            try:
                get_action('member_delete')(context, data_dict)
            except NotFound:
                abort(404, _('Group not found'))

        return h.redirect_to('ed_dataset.groups', id=id)

    context['is_member'] = True
    users_groups = get_action('group_list_authz')(context, data_dict)

    pkg_group_ids = set(group['id'] for group
                        in c.pkg_dict.get('groups', []))
    user_group_ids = set(group['id'] for group
                         in users_groups)

    collections = helpers.get_collections()
    sources = helpers.get_sources()
    data_explorers = [de.get('name') for de in helpers.get_data_explorers()]

    c.group_dropdown = [[group['id'], group['display_name']]
                        for group in users_groups if
                        group['id'] not in pkg_group_ids and
                        group['name'] not in collections and
                        group['name'] not in sources and
                        group['name'] not in data_explorers]

    for group in c.pkg_dict.get('groups', []):
        group['user_member'] = (group['id'] in user_group_ids)

    return render('package/group_list.html',
                  {'dataset_type': dataset_type})


def search(package_type=None):
    from ckan.lib.search import SearchError, SearchQueryError

    package_type = _guess_package_type()

    try:
        context = {'model': model, 'user': c.user,
                    'auth_user_obj': c.userobj}
        check_access('site_read', context)
    except NotAuthorized:
        abort(403, _('Not authorized to see this page'))

    # unicode format (decoded from utf8)
    q = c.q = request.params.get('q', u'')
    c.query_error = False
    page = h.get_page_number(request.params)

    limit = int(config.get('ckan.datasets_per_page', 20))

    # most search operations should reset the page counter:
    params_nopage = [(k, v) for k, v in request.params.items()
                        if k != 'page']

    def drill_down_url(alternative_url=None, **by):
        return h.add_url_param(alternative_url=alternative_url,
                                controller='dataset', action='search',
                                new_params=by)

    c.drill_down_url = drill_down_url

    def remove_field(key, value=None, replace=None):
        return h.remove_url_param(key, value=value, replace=replace,
                                    controller='dataset', action='search',
                                    alternative_url=package_type)

    c.remove_field = remove_field

    sort_by = request.params.get('sort', None)
    params_nosort = [(k, v) for k, v in params_nopage if k != 'sort']

    def _sort_by(fields):
        """
        Sort by the given list of fields.

        Each entry in the list is a 2-tuple: (fieldname, sort_order)

        eg - [('metadata_modified', 'desc'), ('name', 'asc')]

        If fields is empty, then the default ordering is used.
        """
        params = params_nosort[:]

        if fields:
            sort_string = ', '.join('%s %s' % f for f in fields)
            params.append(('sort', sort_string))
        return search_url(params, package_type)

    c.sort_by = _sort_by
    if not sort_by:
        c.sort_by_fields = []
    else:
        c.sort_by_fields = [field.split()[0]
                            for field in sort_by.split(',')]

    def pager_url(q=None, page=None):
        params = list(params_nopage)
        params.append(('page', page))
        return search_url(params, package_type)

    c.search_url_params = urlencode(_encode_params(params_nopage))


    try:
        c.fields = []
        # List of collections to show if a master collection was selected (this will deactivate all other filters)
        only_collections = []
        # c.fields_grouped will contain a dict of params containing
        # a list of values eg {'tags':['tag1', 'tag2']}
        c.fields_grouped = {}
        search_extras = {}
        fq = ' '
        for (param, value) in request.params.items():
            if param not in ['q', 'page', 'sort'] \
                    and len(value) and not param.startswith('_'):
                if not param.startswith('ext_'):
                    if param == 'master_collections':
                        pass
                        # TODO change this if statement to remove master_collection
                        #only_collections.extend(helpers.get_collections_for_master_collections([value]))
                    else:
                        c.fields.append((param, value))
                        fq += ' %s:"%s"' % (param, value)
                        if param not in c.fields_grouped:
                            c.fields_grouped[param] = [value]
                        else:
                            c.fields_grouped[param].append(value)
                else:
                    search_extras[param] = value

        if only_collections:
            fq = 'groups:('
            for collection in only_collections:
                fq += '"%s" OR ' % collection['name']
            fq = fq[0:-3] + ')'

        context = {'model': model, 'session': model.Session,
                    'user': c.user, 'for_view': True,
                    'auth_user_obj': c.userobj}

        # Unless changed via config options, don't show other dataset
        # types any search page. Potential alternatives are do show them
        # on the default search page (dataset) or on one other search page
        search_all_type = config.get(
                                'ckan.search.show_all_types', 'dataset')
        search_all = False

        try:
            # If the "type" is set to True or False, convert to bool
            # and we know that no type was specified, so use traditional
            # behaviour of applying this only to dataset type
            search_all = p.toolkit.asbool(search_all_type)
            search_all_type = 'dataset'
        # Otherwise we treat as a string representing a type
        except ValueError:
            search_all = True

        if not package_type:
            package_type = 'dataset'

        if not search_all or package_type != search_all_type:
            # Only show datasets of this particular type
            fq += ' +dataset_type:{type}'.format(type=package_type)

        facets = OrderedDict()

        default_facet_titles = {
            'organization': _('Organizations'),
            'groups': _('Groups'),
            'tags': _('Tags'),
            'res_format': _('Formats'),
            'license_id': _('Licenses'),
            }

        for facet in h.facets():
            if facet in default_facet_titles:
                facets[facet] = default_facet_titles[facet]
            else:
                facets[facet] = facet

        # Facet titles
        for plugin in p.PluginImplementations(p.IFacets):
            facets = plugin.dataset_facets(facets, package_type)

        c.facet_titles = facets

        if sort_by and 'private' in sort_by:
            fq += ' +private:true'

        data_dict = {
            'q': q,
            'fq': fq.strip(),
            'facet.field': [facet for facet in facets.keys()],
            'rows': limit,
            'start': (page - 1) * limit,
            'sort': sort_by,
            'extras': search_extras,
            'type': package_type,
            'include_private': p.toolkit.asbool(config.get(
                'ckan.search.default_include_private', True)),
        }

        query = get_action('package_search')(context, data_dict)
        c.sort_by_selected = query['sort']

        if 'indraft' in c.sort_by_selected:
            query['results'] = sorted(
                query['results'], key=lambda d: d.get('indraft') in [True, 'true'], reverse=True
            )

        c.page = h.Page(
            collection=query['results'],
            page=page,
            url=pager_url,
            item_count=query['count'],
            items_per_page=limit
        )
        c.search_facets = query['search_facets']
        c.page.items = query['results']
        c.page.search_dict = query['search_dict']
    except SearchQueryError as se:
        # User's search parameters are invalid, in such a way that is not
        # achievable with the web interface, so return a proper error to
        # discourage spiders which are the main cause of this.
        log.info('Dataset search query rejected: %r', se.args)
        abort(400, _('Invalid search query: {error_message}')
                .format(error_message=str(se)))
    except SearchError as se:
        # May be bad input from the user, but may also be more serious like
        # bad code causing a SOLR syntax error, or a problem connecting to
        # SOLR
        log.error('Dataset search error: %r', se.args)
        c.query_error = True
        c.search_facets = {}
        c.page = h.Page(collection=[])
    except NotAuthorized:
        abort(403, _('Not authorized to see this page'))

    c.search_facets_limits = {}
    for facet in c.search_facets.keys():
        try:
            limit = int(request.params.get('_%s_limit' % facet,
                        int(config.get('search.facets.default', 10))))
        except ValueError:
            abort(400, _('Parameter "{parameter_name}" is not '
                            'an integer').format(
                    parameter_name='_%s_limit' % facet))
        c.search_facets_limits[facet] = limit

    _setup_template_variables(context, {},
                                    package_type=package_type)

    return render(_search_template(package_type),
                    extra_vars={'dataset_type': package_type})


def read_docs(id, package_type=None):
    context = {'model': model, 'session': model.Session, 'user': c.user, 'for_view': True, 'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}
    dataset_dict = get_action('package_show')(context, data_dict)
    c.parent = dataset_dict

    if type(dataset_dict['relationships_as_subject']) == list and dataset_dict['type'] != 'dataset':
        for relationship in dataset_dict['relationships_as_subject']:
            if relationship['type'] == 'child_of':
                abort(404, _('Dataset not found'))

    doc_data_dict = helpers.get_package_documentation(id)

    if not doc_data_dict:
        return render('package/documentation_not_found.html',
                        extra_vars={ 'pkg_dict': dataset_dict, 'doc_dict': doc_data_dict })

    # interpret @<revision_id> or @<date> suffix
    split = id.split('@')
    if len(split) == 2:
        doc_data_dict['id'], revision_ref = split
        if model.is_id(revision_ref):
            context['revision_id'] = revision_ref
        else:
            try:
                date = h.date_str_to_datetime(revision_ref)
                context['revision_date'] = date
            except TypeError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
            except ValueError as e:
                abort(400, _('Invalid revision format: %r') % e.args)
    elif len(split) > 2:
        abort(400, _('Invalid revision format: %r') %
                'Too many "@" symbols')

    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, doc_data_dict)
        c.pkg = context['package']
    except NotFound:
        base.abort(404, _('Dataset not found'))
    except NotAuthorized:
        abort(403, _('Unauthorized to read documentation for %s') % dataset_dict['title'])

    resource_id = request.params.get('resource')

    if not len(c.pkg_dict['resources']):
        return render('package/documentation_not_found.html',
                        extra_vars={ 'pkg_dict': dataset_dict, 'doc_dict': doc_data_dict })

    for resource in c.pkg_dict['resources']:
        resource_views = get_action('resource_view_list')(
            context, {'id': resource['id']})
        resource['has_views'] = len(resource_views) > 0
        # Backwards compatibility with preview interface
        resource['can_be_previewed'] = bool(len(resource_views))

        if not resource_id and resource.get('resource_type') != 'doc':
            resource_id = resource['id']

    package_type = c.pkg_dict['type'] or 'dataset'
    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)

    template = _read_template(package_type)


    vars = {'dataset_type': package_type}
    if resource_id:
        vars = _resource_read(c.pkg_dict, resource_id, context=context)
    c.current_package_id = c.pkg.id
    c.current_resource_id = resource_id
    c.dataset_dict = dataset_dict
    try:
        return render(template, extra_vars=vars)
    except ckan.lib.render.TemplateNotFound as e:
        msg = _(
            "Viewing datasets of type \"{package_type}\" is "
            "not supported ({file_!r}).".format(
                package_type=package_type,
                file_=e.message
            )
        )
        abort(404, msg)

    assert False, "We should never get here"

def read_description(id, package_type=None):
    context = {'model': model, 'session': model.Session, 'user': c.user, 'for_view': True, 'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}

    try:
        dataset_dict = get_action('package_show')(context, data_dict)
    except NotFound:
        abort(404, _('Dataset not found'))
    except NotAuthorized:
        abort(403, _('Unauthorized to read the dataset'))

    if type(dataset_dict['relationships_as_subject']) == list and dataset_dict['type'] != 'dataset':
        for relationship in dataset_dict['relationships_as_subject']:
            if relationship['type'] == 'child_of':
                abort(404, _('Dataset not found'))


    return render('package/description.html',
                    extra_vars={ 'pkg_dict': dataset_dict})

def delete(id, package_type=None):

    if 'cancel' in request.params:
        h.redirect_to(controller='dataset', action='edit', id=id)

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'auth_user_obj': c.userobj}

    try:
        if request.method == 'POST':
            get_action('package_delete')(context, {'id': id})
            h.flash_notice(_('Dataset has been deleted.'))
            h.redirect_to(controller='dataset', action='search')
        c.pkg_dict = get_action('package_show')(context, {'id': id})
        dataset_type = c.pkg_dict['type'] or 'dataset'
    except NotAuthorized:
        abort(403, _('Unauthorized to delete package %s') % '')
    except NotFound:
        abort(404, _('Dataset not found'))
    return render('package/confirm_delete.html',
                    extra_vars={'dataset_type': dataset_type,
                                'pkg_dict': c.pkg_dict })


def collections(id):
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj, 'use_cache': False}
    data_dict = {'id': id}
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        dataset_type = c.pkg_dict['type'] or 'dataset'
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    if request.method == 'POST':
        new_group = request.POST.get('group_added')
        if new_group:
            data_dict = {"id": new_group,
                            "object": id,
                            "object_type": 'package',
                            "capacity": 'public'}
            try:
                get_action('member_create')(context, data_dict)
            except NotFound:
                abort(404, _('Group not found'))

        removed_group = None
        for param in request.POST:
            if param.startswith('group_remove'):
                removed_group = param.split('.')[-1]
                break
        if removed_group:
            data_dict = {"id": removed_group,
                            "object": id,
                            "object_type": 'package'}

            try:
                get_action('member_delete')(context, data_dict)
            except NotFound:
                abort(404, _('Collection not found'))
        return h.redirect_to('ed_dataset.groups', id=id)

    context['is_member'] = True
    users_groups = get_action('group_list_authz')(context, data_dict)

    pkg_group_ids = set(group['id'] for group
                        in c.pkg_dict.get('groups', []))
    user_group_ids = set(group['id'] for group
                            in users_groups)

    c.collection_dropdown = [[group['id'], group['display_name']]
                        for group in users_groups if
                        (group['id'] not in pkg_group_ids and group['type'] == 'collection')]

    for group in c.pkg_dict.get('groups', []):
        group['user_member'] = (group['id'] in user_group_ids)

    return render('package/collection_list.html',
                    {'dataset_type': dataset_type})

def _read_resource_file(resource):
    # Let's create, populate and return a temporary file
    tmp_file = tempfile.NamedTemporaryFile("w+b")
    content_type = ''
    # get the resource uploader instance
    upload = uploader.get_resource_uploader(resource)

    try:
        # get file content from local storage
        filepath = upload.get_path(resource.get('id'))
        if not filepath:
            return None

        with open(filepath, 'rb') as input_file:
            content = input_file.read()
            tmp_file.write(content)
            tmp_file.seek(0)

    except:
        # get file content from resource url
        url = resource.get('url')

        # getting default user to make a download request
        context = {"ignore_auth": True}
        default_user = get_action("get_site_user")(context, {})

        # creating an authenticated request
        try:
            req = urllib.request.Request(url)
            req.add_header('X-CKAN-API-KEY', default_user.get('apikey'))
            file_content = urllib.request.urlopen(req).read()
        except Exception as e:
            log.info('Error: %s', e)
            return None, content_type

        # save the content type, we will need to return it
        content_type = req.headers.get('Content-Type','')

        # if it's HTML, don't even bother downloading the chunks
        if 'html' in content_type.lower():
            return (None, content_type)

        tmp_file.write(file_content)
        tmp_file.seek(0)

    return tmp_file, content_type

def move_resource(id, resource_id, package_type=None):
    origin_id = id
    move_to_id = request.params.get('move_to')
    # check if there is more then one dataset in the move_to field
    if len(move_to_id.split(',')) > 1:
        base.abort(404, _('You can only set a single dataset to move the resource.'))
    
    context = {
        'model': model, 'session': model.Session,
        'user': c.user, 'auth_user_obj': c.userobj, 
        'use_cache': False
    }
    data_dict = {
        'id' : move_to_id
    }

    # check if target package exists
    try:
        pkg_dict = get_action('package_show')(context, data_dict)
    except (NotFound):
        base.abort(404, _('Dataset not found'))
    except (NotAuthorized):
        base.abort(403, _('Not Authorized to see this dataset'))

    # get resource metadata
    try:
        resource = get_action('resource_show')(context, {'id': resource_id})
    except (NotFound):
        base.abort(404, _('Resource not found'))
    except (NotAuthorized):
        base.abort(403, _('Not Authorized to see this resource'))

    # copy resource metadata
    new_resource = resource

    # change urls
    if resource.get('url_type') in ['upload']:
        resource_id = resource.get('id')
        resource_url = resource.get('url')

        #read resource file
        tmp_file, content_type = _read_resource_file(resource)
        if not tmp_file or content_type == 'html':
            log.info('Resource file not found - resource id: %s', resource_id)
            base.abort(404, _('Resource not found'))

        # CKAN only accepts this kind of object here...
        stream = BytesIO(open(tmp_file.name, "rb").read())
        fname = resource_url.split('/')[-1]
        file_obj = FileStorage(filename=fname, content_type=content_type, stream=stream)

        new_resource['url_type'] = None
        new_resource['url'] = ''
        new_resource['upload'] = file_obj

    # delete ids
    moved_resource_id = resource.get('id')
    del new_resource['id']
    try:
        del new_resource['revision_id']
    except KeyError as k:
        log.warn(k)

    #change package
    new_resource['package_id'] = pkg_dict.get('id')

    #create new resource
    try:
        new_resource = get_action('resource_create')(context, new_resource)
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return new_resource(id, new_resource, errors, error_summary)
    except NotAuthorized:
        abort(403, _('Unauthorized to create a resource'))

    # Get an uploader instance
    uploader = ResourceUpload(new_resource)
    try:
        # ...and upload the file!
        uploader.upload(resource_id, 107374187500) # 100 GiB
    except Exception as e:
        print('Cannot upload file for resource with ID {}. Error was: {}'.format(resource_id, e))

    # delete translated files from moved resource
    try:
        origin_data_dict = {
            'id' : origin_id
        }
        # get origin package
        origin_pkg_dict = get_action('package_show')(context, origin_data_dict)
    except (NotFound):
        base.abort(404, _('Dataset not found'))
    except (NotAuthorized):
        base.abort(403, _('Not Authorized to see this dataset'))

    resources = origin_pkg_dict.get('resources')
    for res in resources:
        res_translated_from = res.get('translated_from')
        if res_translated_from:
            res_dict = json.loads(res_translated_from)
            if res_dict.get(u'id') == moved_resource_id:
                try:
                    get_action('resource_delete')(context, {'id' : res.get('id')})
                except NotAuthorized:
                    abort(403, _('Unauthorized to delete a resource'))
                except NotFound:
                    abort(404, _('The resource {id} could not be found.'
                                    ).format(id=res.get('id')))

    # delete moved resource
    try:
        resource['id'] = moved_resource_id
        resource = get_action('resource_delete')(context, resource)
    except NotAuthorized:
        abort(403, _('Unauthorized to delete a resource'))
    except NotFound:
        abort(404, _('The resource {id} could not be found.'
                        ).format(id=resource.get('id')))
                        
    url = h.url_for(controller='dataset',
                    action='resources',
                    id=origin_pkg_dict.get('name'))
                
    return h.redirect_to(url)

def _form_save_redirect(pkgname, action, package_type=None):
    '''This redirects the user to the CKAN package/read page,
    unless there is request parameter giving an alternate location,
    perhaps an external website.
    @param pkgname - Name of the package just edited
    @param action - What the action of the edit was
    '''
    assert action in ('new', 'edit')
    url = request.form.get('return_to') or \
        config.get('package_%s_return_url' % action)

    if url:
        url = url.replace('<NAME>', pkgname)
    else:
        if package_type is None or package_type == 'dataset':
            url = h.url_for(controller='dataset', action='read',
                            id=pkgname)
        else:
            url = h.url_for('{0}_read'.format(package_type), id=pkgname)
    return h.redirect_to(url)


def child_list(id, package_type):
    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj}
    data_dict = {'id': id, 'include_tracking': True}

    try:
        check_access('package_update', context, data_dict)
    except NotFound:
        abort(404, _('Dataset not found'))
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))
    # check if package exists
    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        c.pkg = context['package']
    except (NotFound, NotAuthorized):
        abort(404, _('Dataset not found'))

    pkg_id = c.pkg_dict.get('id')
    data_dict = {
        'id': pkg_id
    }
    child = get_action('package_relationship_list_db')(context,data_dict)
    child = list(filter(lambda c: c['type'] == "parent_of", child))
    child_order = helpers.check_order(child)
    package_type = c.pkg_dict['type'] or 'dataset'
    _setup_template_variables(context, {'id': id},
                                    package_type=package_type)
    return render('package/relationship.html',
                    extra_vars={'childs': child, 'child_order': child_order})

def change_package_owner(id, new_user_id):
    pkg_doc = helpers.get_package_documentation(id)
    ed_model.update_package_owner(new_user_id, id)
    if pkg_doc:
        ed_model.update_package_owner(new_user_id, pkg_doc['id'])

def package_admin(id, package_type=None):

    context = {'model': model, 'session': model.Session,
                'user': c.user, 'for_view': True,
                'auth_user_obj': c.userobj, 'use_cache': False}
    data_dict = {'id': id}

    if request.method == 'POST':
        new_user_id = request.form.get('new_owner')

        try:
            user_dict = get_action('user_show')(context, {'id': new_user_id})
            logic.check_access('package_update', context, data_dict)
        except NotFound:
            abort(404, _('Not found'))
        except NotAuthorized:
            abort(403, _('Not authorized to see this page'))

        try:
            change_package_owner(id, new_user_id)
            h.flash_success(_('The Data profile owner has been changed to \
                {}.'.format(user_dict['display_name'])))
        except Exception as e:
            h.flash_error("Unable to change Data profile owner to {}".format(
                user_dict['display_name']))
            log.error("Error occured while trying to change data profile owner")
            log.error(e)

    try:
        c.pkg_dict = get_action('package_show')(context, data_dict)
        user_list = helpers.get_users_with_ownership_permission(id)

        if not helpers.is_admin(c.user, office=c.pkg_dict['organization']['id']):
            raise NotAuthorized
    except NotFound:
        abort(404, _('Dataset not found'))
    except NotAuthorized:
        abort(403, _('Not authorized to see this page'))

    extra_vars = {
        'pkg_dict': c.pkg_dict,
        'user_list': user_list
    }

    return render('package/admin.html', extra_vars)

def bulk_package_owner_change(id, package_type=None):

    if not helpers.is_admin(c.user, office=id):
        abort(403, _('Not authorized to see this page'))

    if request.method == 'POST':
        body = request.json
        success = 0
        failed = 0
        for pkg_id in body.get('packageList'):
            try:
                change_package_owner(pkg_id, body.get('new_owner'))
                success += 1
            except Exception as e:
                failed += 1
                log.error("Error occured while trying to change data profile owner")
                log.error(e)

        if success > 0:
            h.flash_success(_('The owner of {} data profiles has been changed to \
                    {}'.format(success, body.get('new_owner_name'))))
        if failed > 0:
            h.flash_error("{} data profiles failed to change ownership to {}".format(
                    failed, body.get('new_owner_name')))

    return h.url_for('organization.read', id=id)

def ed_resources(id, resource_id, package_type):
    return resources(package_type, id)


def visibility_toggle(id, package_type):
    pkg_dict = get_action('package_show')(context={'ignore_auth': True}, data_dict={'id': id})
    is_private = pkg_dict.get('private', False)

    if is_private:
        pkg_dict['private'] = False
    else:
        pkg_dict['private'] = True

    get_action('package_patch')(context={'ignore_auth': True}, data_dict=pkg_dict)

    h.flash_success(_('Data Profile is now {}.'.format('publicly visible' if is_private else 'hidden')))

    return h.redirect_to('ed_dataset.read_description', id=id)



def edit_resource(id, resource_id, package_type=None, data=None, errors=None, error_summary=None):
    context = {
            u'model': model,
            u'session': model.Session,
            u'api_version': 3,
            u'for_edit': True,
            u'user': g.user,
            u'auth_user_obj': g.userobj
        }
    try:
        check_access(u'package_update', context, {u'id': id})
    except NotAuthorized:
        return base.abort(
            403,
            _(u'User %r not authorized to edit %s') % (g.user, id)
        )
    if request.method == 'POST':
        data = clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.form)))
        )
        data.update(clean_dict(
            dict_fns.unflatten(tuplize_dict(parse_params(request.files)))
        ))

        # we don't want to include save as it is part of the form
        del data[u'save']

        data[u'package_id'] = id
        try:
            
            if resource_id:
                data[u'id'] = resource_id
                get_action(u'resource_update')(context, data)
                data_dict = get_action('package_show')(context, {'id': id})
                
                if not (data.get('api_url') or data.get('access_url')):
                    if not data.get('name'):
                        ## update package and set indraft to true
                        resource_index  = data_dict.get('resource_index', '').split(',')
                        resource_indraft = data_dict.get('resources_indraft', '').split(',')

                        if data.get('id') in resource_index:
                            r_index = resource_index.index(resource_id)
                            resource_indraft[r_index] = str(True)
                        else:
                            resource_indraft += [str(True)]
                            resource_index += [data.get('id')]

                        data_dict['resources_indraft'] = ','.join(resource_indraft)
                        data_dict['resource_index'] = ','.join(resource_index)
                        data_dict['indraft'] = True
                        data_dict['private'] = True
                        get_action('package_update')(context, data_dict)
                    else:
                        ## update package and set indraft to true
                        resource_index  = data_dict.get('resource_index', '').split(',')
                        resource_indraft = data_dict.get('resources_indraft', '').split(',')

                        if resource_id in resource_index:
                            r_index = resource_index.index(resource_id)
                            resource_index.pop(r_index)
                            resource_indraft.pop(r_index)

                        data_dict['resources_indraft'] = ','.join(resource_indraft)
                        data_dict['resource_index'] = ','.join(resource_index)

                        if not len(resource_indraft) or resource_indraft != {} and (draft_func(data_dict, is_pkg=True) or draft_func(data_dict)):
                            data_dict['indraft'] = False
                        else:
                            data_dict['indraft'] = True
                            data_dict['private'] = True

                        get_action('package_update')(context, data_dict)
            else:
                get_action(u'resource_create')(context, data)
        except ValidationError as e:
            errors = e.error_dict
            error_summary = e.error_summary
            return edit_resource(id, resource_id, package_type, data, errors, error_summary)
        except NotAuthorized:
            return base.abort(403, _(u'Unauthorized to edit this resource'))
        return h.redirect_to(
            u'{}_resource.read'.format(package_type),
            id=id, resource_id=resource_id
        )

    pkg_dict = get_action(u'package_show')(context, {u'id': id})

    try:
        resource_dict = get_action(u'resource_show')(
            context, {
                u'id': resource_id
            }
        )
    except NotFound:
        return base.abort(404, _(u'Resource not found'))

    if pkg_dict[u'state'].startswith(u'draft'):
        return CreateView().get(package_type, id, data=resource_dict)

    # resource is fully created
    resource = resource_dict
    # set the form action
    form_action = h.url_for(
        u'{}_resource.edit'.format(package_type),
        resource_id=resource_id, id=id
    )

    if not data:
        data = resource_dict

    package_type = pkg_dict[u'type'] or package_type

    errors = errors or {}
    error_summary = error_summary or {}
    extra_vars = {
        u'data': data,
        u'errors': errors,
        u'error_summary': error_summary,
        u'action': u'edit',
        u'resource_form_snippet': _get_pkg_template(
            u'resource_form', package_type
        ),
        u'dataset_type': package_type,
        u'resource': resource,
        u'pkg_dict': pkg_dict,
        u'form_action': form_action
    }

    return base.render(u'package/resource_edit.html', extra_vars)


#def register_dataset_plugin_rules(blueprint: Blueprint):
ed_dataset_blueprint.add_url_rule(u'/', view_func=search, strict_slashes=False)
ed_dataset_blueprint.add_url_rule(u'/new', view_func=new, methods=['GET', 'POST'])
ed_dataset_blueprint.add_url_rule(u'/<id>', view_func=read_description)
ed_dataset_blueprint.add_url_rule(u'/<id>/resources', view_func=read)
ed_dataset_blueprint.add_url_rule(u'/docs/<id>', view_func=read_docs)
ed_dataset_blueprint.add_url_rule(u'/resources/<id>', view_func=resources)
ed_dataset_blueprint.add_url_rule(
    u'/edit/<id>', view_func=edit,
    methods=['GET', 'POST']
)
ed_dataset_blueprint.add_url_rule(
    u'/delete/<id>', view_func=delete
)
ed_dataset_blueprint.add_url_rule(
    u'/follow/<id>', view_func=follow, methods=(u'POST', )
)
ed_dataset_blueprint.add_url_rule(
    u'/unfollow/<id>', view_func=unfollow, methods=(u'POST', )
)
ed_dataset_blueprint.add_url_rule(u'/followers/<id>', view_func=followers)
ed_dataset_blueprint.add_url_rule(
    u'/groups/<id>', view_func=groups
)
ed_dataset_blueprint.add_url_rule(u'/activity/<id>', view_func=activity)
ed_dataset_blueprint.add_url_rule(u'/changes/<id>', view_func=changes)
ed_dataset_blueprint.add_url_rule(u'/<id>/history', view_func=history)

ed_dataset_blueprint.add_url_rule(u'/changes_multiple', view_func=changes_multiple)

# Duplicate resource create and edit for backward compatibility. Note,
# we cannot use resource.CreateView directly here, because of
# circular imports
ed_dataset_blueprint.add_url_rule(
    u'/new_resource/<id>',
    view_func=new_resource,
    methods=['GET', 'POST']
)

ed_dataset_blueprint.add_url_rule(
    u'/<id>/resource_edit/<resource_id>',
    view_func=LazyView(
        u'ckan.views.resource.EditView', str(u'edit_resource')
    )
)

### Ed endpoints
ed_dataset_blueprint.add_url_rule(
    u'/docs/<id>',
    view_func=read_docs,
    methods=['GET', 'POST']
)
ed_dataset_blueprint.add_url_rule(
    u'/admin/<id>',
    methods=['GET', 'POST'],
    view_func=package_admin
)
ed_dataset_blueprint.add_url_rule(
    u'/admin/bulk/<id>',
    view_func=bulk_package_owner_change,
    methods=['POST']
)
ed_dataset_blueprint.add_url_rule(
    u'/child/<id>',
    view_func=child_list
)
ed_dataset_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>',
    view_func=ed_resources
)
ed_dataset_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>/edit', view_func=edit_resource,
    methods=[u'GET', u'POST']
)

ed_dataset_blueprint.add_url_rule(
    u'/<id>/resource/<resource_id>/move_resource',
    view_func=move_resource
)
ed_dataset_blueprint.add_url_rule(
    u'/visibility_toggle/<id>',
    view_func=visibility_toggle,
    methods=['POST']
)

if authz.check_config_permission(u'allow_dataset_collaborators'):
    ed_dataset_blueprint.add_url_rule(
        rule=u'/collaborators/<id>',
        view_func=collaborators_read,
        methods=['GET', ]
    )

    ed_dataset_blueprint.add_url_rule(
        rule=u'/collaborators/<id>/new',
        view_func=CollaboratorEditView.as_view(str(u'new_collaborator')),
        methods=[u'GET', u'POST', ]
    )

    ed_dataset_blueprint.add_url_rule(
        rule=u'/collaborators/<id>/delete/<user_id>',
        view_func=collaborator_delete, methods=['POST', ]
    )

#register_dataset_plugin_rules(ed_dataset_blueprint)
