import logging

import ckan.model as model
import ckan.logic as logic
import ckan.lib.base as base
import ckan.lib.helpers as h
from ckan.common import _, request, c
import ckan.lib.navl.dictization_functions as dict_fns
import ckan.authz as authz
from ckan.views.group import (
    _get_group_template, _setup_template_variables, _guess_group_type,
    _check_access, _force_reindex, index, read, activity, about, history,
    followers, follow, unfollow, admins, BulkProcessView
)
from flask import Blueprint
from ckanext.ed.blueprints.utils import _ensure_controller_matches_group_type

log = logging.getLogger(__name__)

render = base.render
abort = base.abort

NotFound = logic.NotFound
NotAuthorized = logic.NotAuthorized
ValidationError = logic.ValidationError
check_access = logic.check_access
get_action = logic.get_action
tuplize_dict = logic.tuplize_dict
clean_dict = logic.clean_dict
parse_params = logic.parse_params
flatten_to_string_key = logic.flatten_to_string_key

group_types = ['ed_source'] 

ed_source_blueprint = Blueprint(
    'ed_source_bp', __name__,
    url_prefix='/ed_source',
    url_defaults={
        'group_type': 'ed_source',
        'is_organization': False
    }
)


def _save_new(context, group_type=None):
    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        data_dict['type'] = group_type or 'group'
        context['message'] = data_dict.get('log_message', '')
        data_dict['users'] = [{'name': c.user, 'capacity': 'admin'}]
        package_names = data_dict.get('source_packages', None)

        if package_names and type(package_names) == str:
            names_list = package_names.split(',')
            data_dict['source_packages'] = names_list

        group = get_action('group_create')(context, data_dict)

        # Redirect to the appropriate _read route for the type of group
        return h.redirect_to(group_type + '.read', id=group['name'])

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Group not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary
        return new(data_dict, errors, error_summary)


def new(data=None, errors=None, error_summary=None,
        group_type=None, is_organization=False):
    if group_type is not None:
        group_type = group_type
    elif data and 'type' in data:
        group_type = data['type']
    else:
        group_type = _guess_group_type(True)

    if data:
        data['type'] = group_type

    is_save = 'save' in request.params or 'save' in request.form

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user,
        'save': is_save,
        'parent': request.form.get('parent', None)
    }

    try:
        _check_access('group_create', context)
    except NotAuthorized:
        abort(403, _('Unauthorized to create a group'))

    if is_save and not data and request.method == 'POST':
        return _save_new(context, group_type)

    data = data or {}

    if not data.get('image_url', '').startswith('http'):
        data.pop('image_url', None)

    errors = errors or {}
    error_summary = error_summary or {}
    vars = {
        'data': data,
        'errors': errors,
        'error_summary': error_summary,
        'action': 'new',
        'group_type': group_type
    }

    _setup_template_variables(context, data, group_type=group_type)

    form = base.render(
        _get_group_template(u'group_form', group_type), vars
    )

    c.form = form
    vars["form"] = form

    return render(
        _get_group_template(u'new_template', group_type), vars)


def edit(id, data=None, errors=None, error_summary=None,
         group_type=None, is_organization=False):
    group_type = _ensure_controller_matches_group_type(
        id.split('@')[0], group_types)

    context = {'model': model, 'session': model.Session,
                'user': c.user,
                'save': 'save' in request.params,
                'for_edit': True,
                'parent': request.form.get('parent', None)
                }
    data_dict = {'id': id, 'include_datasets': False}

    if context['save'] and not data and request.method == 'POST':
        return _save_edit(id, context)

    try:
        data_dict['include_datasets'] = False
        old_data = get_action('group_show')(context, data_dict)
        c.grouptitle = old_data.get('title')
        c.groupname = old_data.get('name')
        data = data or old_data
    except (NotFound, NotAuthorized):
        abort(404, _('Group not found'))

    group = context.get("group")
    c.group = group
    c.group_dict = get_action('group_show')(context, data_dict)

    try:
        _check_access('group_update', context)
    except NotAuthorized:
        abort(403, _('User %r not authorized to edit %s') % (c.user, id))

    errors = errors or {}
    vars = {'data': data, 'errors': errors,
            'error_summary': error_summary, 'action': 'edit',
            'group_type': group_type}

    _setup_template_variables(context, data, group_type=group_type)
    form = base.render(
        _get_group_template(u'group_form', group_type), vars)

    c.form = form

    vars["form"] = form
    return render(
        _get_group_template(u'edit_template', group_type), vars)


def _save_edit(id, context):
    try:
        data_dict = clean_dict(dict_fns.unflatten(
            tuplize_dict(parse_params(request.form))))
        context['message'] = data_dict.get('log_message', '')
        data_dict['id'] = id
        context['allow_partial_update'] = True
        package_names = data_dict.get('source_packages', None)

        if package_names and type(package_names) == str:
            names_list = package_names.split(',')
            data_dict['source_packages'] = names_list

        group = get_action('group_update')(context, data_dict)

        if id != group['name']:
            _force_reindex(group)

        return h.redirect_to('group.read', id=group['name'])

    except (NotFound, NotAuthorized) as e:
        abort(404, _('Group not found'))
    except dict_fns.DataError:
        abort(400, _(u'Integrity Error'))
    except ValidationError as e:
        errors = e.error_dict
        error_summary = e.error_summary

        return edit(id, data_dict, errors, error_summary)


def delete(id, group_type=None, is_organization=False):
    if group_type is None:
        group_type = _ensure_controller_matches_group_type(id, group_types)

    if 'cancel' in request.params:
        return h.redirect_to(group_type + '.edit', id=id)

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user
    }

    try:
        _check_access('group_delete', context, {'id': id})
    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s') % '')

    try:
        if request.method == 'POST':
            get_action('group_delete')(context, {'id': id})

            if group_type == 'organization':
                h.flash_notice(_('Organization has been deleted.'))
            elif group_type == 'group':
                h.flash_notice(_('Group has been deleted.'))
            elif group_type == 'ed_source':
                h.flash_notice(_('Source has been deleted.'))
            else:
                h.flash_notice(_('%s has been deleted.')
                                % _(group_type.capitalize()))

            return h.redirect_to(group_type + '.index')

        c.group_dict = get_action('group_show')(context, {'id': id})

    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s') % '')
    except NotFound:
        abort(404, _('Group not found'))
    except ValidationError as e:
        h.flash_error(e.error_dict['message'])

        return h.redirect_to(group_type + '.read', id=id)

    return render(
        'ed_source/confirm_delete.html',
        extra_vars={'group_type': group_type}
    )


def members(id, group_type=None, is_organization=False):
    if group_type is None:
        group_type = _ensure_controller_matches_group_type(id, group_types)

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user
    }

    data_dict = {'id': id}

    try:
        check_access('group_edit_permissions', context, data_dict)
    except NotAuthorized:
        abort(
            403,
            _('User %r not authorized to edit members of %s') % (c.user, id)
        )
    try:
        c.members = get_action('member_list')(
            context, {'id': id, 'object_type': 'user'}
        )
        data_dict['include_datasets'] = False
        c.group_dict = get_action('group_show')(context, data_dict)
    except NotFound:
        abort(404, _('Group not found'))

    return render(
        group_type + '/members.html',
        extra_vars={'group_type': group_type}
    )


def member_new(id, group_type=None, is_organization=False):
    if group_type is None:
        group_type = _ensure_controller_matches_group_type(id, group_types)

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user
    }

    try:
        _check_access('group_member_create', context, {'id': id})
    except NotAuthorized:
        abort(403, _('Unauthorized to create group %s members') % '')

    try:
        data_dict = {'id': id}
        data_dict['include_datasets'] = False
        c.group_dict = get_action('group_show')(context, data_dict)
        c.roles = get_action('member_roles_list')(
            context, {'group_type': group_type}
        )

        if request.method == 'POST':
            data_dict = clean_dict(dict_fns.unflatten(
                tuplize_dict(parse_params(request.params))))
            data_dict['id'] = id

            email = data_dict.get('email')

            if email:
                user_data_dict = {
                    'email': email,
                    'group_id': data_dict['id'],
                    'role': data_dict['role']
                }
                del data_dict['email']
                user_dict = get_action('user_invite')(
                    context, user_data_dict)
                data_dict['username'] = user_dict['name']

            c.group_dict = get_action('group_member_create')(
                context, data_dict)

            return h.redirect_to(group_type + '.members', id=id)

        else:
            user = request.form.get('user')

            if user:
                c.user_dict = \
                    get_action('user_show')(context, {'id': user})
                c.user_role = \
                    authz.users_role_for_group_or_org(id, user) or 'member'
            else:
                c.user_role = 'member'

    except NotAuthorized:
        abort(403, _('Unauthorized to add member to group %s') % '')
    except NotFound:
        abort(404, _('Group not found'))
    except ValidationError as e:
        h.flash_error(e.error_summary)
    return render(
        'ed_source/member_new.html',
        extra_vars={'group_type': group_type}
    )


def member_delete(id, group_type=None, is_organization=False):
    if group_type is None:
        group_type = _ensure_controller_matches_group_type(id, group_types)

    if 'cancel' in request.params:
        return h.redirect_to(group_type + '.members', id=id)

    context = {
        'model': model,
        'session': model.Session,
        'user': c.user
    }

    try:
        _check_access('group_member_delete', context, {'id': id})
    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s members') % '')

    try:
        user_id = request.form.get('user')

        if request.method == 'POST':
            get_action('group_member_delete')(
                context, {'id': id, 'user_id': user_id})
            h.flash_notice(_('Group member has been deleted.'))

            return h.redirect_to(group_type + '.members', id=id)

        c.user_dict = get_action('user_show')(context, {'id': user_id})
        c.user_id = user_id
        c.group_id = id

    except NotAuthorized:
        abort(403, _('Unauthorized to delete group %s members') % '')
    except NotFound:
        abort(404, _('Group not found'))
    return render(
        'ed_source/confirm_delete_member.html',
        extra_vars={'group_type': group_type}
    )


#def register_source_plugin_rules(blueprint: Blueprint):
actions = [
    u'member_delete', u'history', u'followers', u'follow',
    u'unfollow', u'admins', u'activity'
]
ed_source_blueprint.add_url_rule(u'/', view_func=index, strict_slashes=False)
ed_source_blueprint.add_url_rule(
    u'/new',
    methods=[u'GET', u'POST'],
    view_func=new)
ed_source_blueprint.add_url_rule(u'/<id>', methods=[u'GET'], view_func=read)
ed_source_blueprint.add_url_rule(
    u'/edit/<id>', view_func=edit)
ed_source_blueprint.add_url_rule(
    u'/activity/<id>/<int:offset>', methods=[u'GET'], view_func=activity)
ed_source_blueprint.add_url_rule(
    u'/about/<id>',
    methods=[u'GET'],
    view_func=about
)
ed_source_blueprint.add_url_rule(
    u'/members/<id>', methods=[u'GET', u'POST'], view_func=members)
ed_source_blueprint.add_url_rule(
    u'/member_new/<id>',
    view_func=member_new)
ed_source_blueprint.add_url_rule(
    u'/bulk_process/<id>',
    view_func=BulkProcessView.as_view(str(u'bulk_process')))
ed_source_blueprint.add_url_rule(
    u'/delete/<id>',
    methods=[u'GET', u'POST'],
    view_func=delete)
for action in actions:
    ed_source_blueprint.add_url_rule(
        u'/{0}/<id>'.format(action),
        methods=[u'GET', u'POST'],
        view_func=globals()[action])

#register_source_plugin_rules(ed_source_blueprint)
