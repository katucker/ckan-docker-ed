try:
    from collections import OrderedDict  # 2.7
except ImportError:
    from sqlalchemy.util import OrderedDict

UPDATE_FREQUENCIES = OrderedDict([
    ('Irregular', 'irregular'),
    ('Decennial', 'R/P10Y'),
    ('Quadrennial', 'R/P4Y'),
    ('Annual', 'R/P1Y'),
    ('Bimonthly (every two months)', 'R/P2M'),
    ('Semiweekly', 'R/P3.5D'),
    ('Daily', 'R/P1D'),
    ('Biweekly (every two weeks)', 'R/P2W'),
    ('Biweekly (twice a week)', 'R/P0.5W'),
    ('Semiannual', 'R/P6M'),
    ('Biennial', 'R/P2Y'),
    ('Triennial', 'R/P3Y'),
    ('Three times a week', 'R/P0.33W'),
    ('Three times a month', 'R/P0.33M'),
    ('Continuously updated', 'R/PT1S'),
    ('Monthly', 'R/P1M'),
    ('Quarterly', 'R/P3M'),
    ('Semimonthly (or bimonthly)', 'R/P0.5M'),
    ('Three times a year', 'R/P4M'),
    ('Weekly', 'R/P1W'),
    ('Hourly', 'R/PT1H')
])
