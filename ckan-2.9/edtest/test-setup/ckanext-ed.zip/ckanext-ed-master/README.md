# ckanext-ed

[![Build Status](https://travis-ci.org/CivicActions/ckanext-ed.svg?branch=master)](https://travis-ci.org/CivicActions/ckanext-ed)

This is the main repo for the US Department of Education ckan-based project. This documentation covers all of the development aspects.

## Table of contents

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Getting started](#getting-started)
  - [Requirements](#requirements)
  - [Setup environment](#setup-environment)
  - [GitHub Branch Protection](#github-branch-protection)
  - [Start development server](#start-development-server)
- [Software lifecycle](#software-lifecycle)
  - [Security impact analysis](#security-impact-analysis)
    - [`Security Considerations` field](#security-considerations-field)
      - [Content Template](#content-template)
    - [`ISSO Approval Disposition` field](#isso-approval-disposition-field)
- [Development](#development)
  - [Cypress integration testing](#cypress-integration-testing)
    - [Requirements](#requirements-1)
    - [Setting up the test environment variables](#setting-up-the-test-environment-variables)
    - [Running the automated tests](#running-the-automated-tests)
  - [Working with static files](#working-with-static-files)
  - [Working with i18n](#working-with-i18n)
  - [Testing email notifications](#testing-email-notifications)
  - [Generating data.json](#generating-datajson)
  - [Log into the container](#log-into-the-container)
  - [Updating docker images](#updating-docker-images)
  - [Stop service containers](#stop-service-containers)
  - [Removing stopped service containers](#removing-stopped-service-containers)
  - [Resetting docker](#resetting-docker)
  - [Generating TOC](#generating-toc)
- [Troubleshooting](#troubleshooting)
  - [The admin credentials don't work](#the-admin-credentials-dont-work)
- [References](#references)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Getting started

### Requirements

Please follow installation instructions of the software below if needed. The following steps require:
- `docker`
- `docker-compose`
- `nvm/Node.js` (optional)
- `/etc/hosts` contains the `127.0.0.1 ckan-dev` line

### Setup environment

Clone the `docker-ckan-ed` repository (assuming that we're inside our `projects` directory):

```bash
$ git clone git@github.com:CivicActions/docker-ckan-ed.git
$ cd docker-ckan-ed
```

This is a docker compose setup for local development. It's designed to support live development of extensions which are stored inside the `src` directory.

Clone the `ckanext-ed` repository to the `src` folder (we also can create a symbolic link back to the `projects` directory):

```bash
$ cd src
$ git clone git@github.com:CivicActions/ckanext-ed.git
$ cd ckanext-ed
```

Now we have cloned all the required repositories and we're located in our main working directory `docker-ckan-ed/src/ckanext-ed`

### GitHub Branch Protection

Suggestions: Define Branch Protection Rules to

1. disable force pushing
2. prevent branches from being deleted 
3. require status checks before merging

click on settings (in the upper right side) of the github repo

click on Branches (on the left)

The 'Branch Protection Rules" for the default branch will be displayed. (an "Edit/Delete" button will be on the right)
If there are no rules for the branch you can add rules. (An Add button will be on the right)

When adding a rule you will be asked to enter the Pattern to use for matching against branch names.
Since this rule set is specifically for the master branch, "master" was entered.

Following are the options you are presented with:

1. Require pull request reviews before merging (currently set)

  It is required that one or more other team members sign off on the pull request before it's allowed to be merged.
  This theoretically at least ensures that the changes have been reviewed by at least 1 (or n) other team member(s).
  Which is a great way to both improve code quality and disseminate understanding of the codebase among the whole team.

2. Require status checks to pass before merging (currently set)

  The required status check is set to:
  Require branches to be up to date before merging (currently set)

  the dev will have to make sure the branch being merged is up to date with repect to its parent.

3. Require signed commits (no)

4. Require linear history (currently set)

  required to maintain a linear master branch.  commits in that branch cannot have more than one parent.

5. Include administrators (currently set)

  Rules apply to everyone including administrators

6. Restrict who can push to matching branches (currently set)
  currently four datopian users are allowed.

7. Allow force pushes (no)

8. Allow deletions (no)


### Start development server

> Take a look inside `package.json` to understand what's going on under the hood. Or if you don't have Node.js installed.

To start a development server, we have to build docker images:

```bash
$ make build
```

Let's start the development server:

> For live development the first option is recommended to be launched in another terminal window

```bash
$ make start
```

You can work on the `ckanext-ed` codebase having it running. On every change to the codebase, the server will be reloaded automatically. It's important to mention that the ckan configuration and other things like `cron/patches/etc` are managed inside the `docker-ckan-ed` repo. If you want to update it you have to restart the server.

Now we can visit our local ckan instance at:

```
http://ckan-dev:5000/
```

To log in as an admin:
- user: `ckan_admin`
- pass: `test1234`

## Software lifecycle

- Releases should list all Jira issues in scope.
- Releases should not deploy to production until
  all Jira issues in scope have reached the `Move to Production` workflow stage

### Security impact analysis

Per the [CM-4](https://nvd.nist.gov/800-53/Rev4/control/CM-4) security control,
all changes to the information system must be analyzed to determine potential security impacts prior to change implementation.

In our case that means that this assessment must occur before deployment to production.

Specifically, prior to promoting a Jira issue to the `Tech Review` workflow stage,
we should fill the `Security Considerations` and `ISSO Approval Disposition` fields.

#### `Security Considerations` field

Bulleted list of all of the security considerations of any changes being made pursuant to the active Jira issue.

> Security impact analysis may include, for example, reviewing security plans to understand security control requirements and reviewing system design documentation to understand control implementation and how specific changes might affect the controls. Security impact analyses may also include assessments of risk to better understand the impact of the changes and to determine if additional security controls are required. Security impact analyses are scaled in accordance with the security categories of the information systems."

##### Content Template

1.  Copy the following template into the `Security Considerations` field.

    ```
    Changes in this issue impact the following aspects of the system marked '[X]':

    - [ ] Privacy
    - [ ] Authentication and/or authorization
    - [ ] Logging and audit
    - [ ] Cryptography
    - [ ] Use of external systems
    - [ ] Configuration management
    - [ ] System integrity
    - [ ] Risk assessment
    - [ ] Other
    ```

1.  Replace `[ ]` with `[X]` where relevant
1.  Add sub-bullets with details about specific categories and/or
    paragraph-form commentary on the overall
1.  If no categories are checked and you have no overall commentary,
    append a new line reading 'N/A' to the field to be unambiguous.

#### `ISSO Approval Disposition` field

Radio-button indicator of whether the change needs ISSO Approval prior to deployment.

## Development

### Cypress integration testing

See the [Cypress documentation](https://docs.cypress.io/guides/overview/why-cypress) for more information on how to write tests.

#### Requirements

- `Node v14.20.0` _(recommended, but other versions might work as well)_ - Can be downloaded [here](https://nodejs.org/en/download/releases/)
- `Cypress 5.6.0` - Can be installed with: `npm install cypress@5.6.0 --global`, but this will be installed via `npm i`. (see below)
- `Chrome 106.0.5249.103` _(other recent versions should work as well)_
- Node dependencies. (see below)

The main required node dependencies are:

- `cypress ^5.6.0`
- `cypress-tests git+https://github.com/datopian/ckan-integration-tests.git`
- `dotenv ^8.2.0`
- `mochawesome ^7.1.3`
- `mochawesome-merge ^4.2.0`
- `mochawesome-report-generator ^6.2.0`

_`^` means it would also support higher versions_

Dependencies can be installed by:

1. Navigating to the `tests` directory 
2. Running `npm i`.

#### Setting up the test environment variables

Inside the `tests` directory a file named `.env.example` can be found. This file contains an example of an environment configuration, just like the following:

```
CYPRESS_API_KEY=ffffffff-ffff-ffff-ffff-ffffffffffff
CYPRESS_BASE_URL=https://us-ed-testing.ckan.io/
CYPRESS_CKAN_PASSWORD=bar
CYPRESS_CKAN_USERNAME=foo
CYPRESS_CKAN_DISPLAY_NAME=Example Display Name
CYPRESS_FRONTEND_URL=https://us-ed-testing.ckan.io/
```

For Cypress to read the variables from our file, you must:

1. Navigate to `tests`
2. Duplicate the `.env.example` file in the same directory
3. Rename one of the copies to `.env`
4. Open the `.env` file in a text editor
5. Change the values for the keys according to the table below

Environment variables:

| Key                                                 | Description                                                                                                                                                                                                                                                                                                                                                                                                         |
| --------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `CYPRESS_API_KEY`                                   | This value can be found by accessing CKAN, signing in as an user with high-privileges (i.e. a sysadmin) and going to the user profile. At the left side of the page there should be an `API Key` field. If this field does not contain an associated value, go to the user settings and click on `Regenerate API Key`. Note that this API Key is used by the automated tests to perform authenticated API requests. |
| `CYPRESS_BASE_URL`                                  | This value should point to the current address of the CKAN instance that's meant to be tested.                                                                                                                                                                                                                                                                                                                      |
| `CYPRESS_CKAN_USERNAME` and `CYPRESS_CKAN_PASSWORD` | These values should be filled with the credentials for a sysadmin user currently registered in the CKAN instance.                                                                                                                                                                                                                                                                                                   |
| `CYPRESS_FRONTEND_URL`                              | This value should point to the address of the CKAN front end that must be tested. In the majority of the scenarios it's going to have the same value as the second item in this table.                                                                                                                                                                                                                              |

#### Running the automated tests

In order to run the tests, simply:

1. Navigate to `tests`
2. Run `node test chrome`

> **NOTE**: If `node test chrome` fails because it can't find your browser, you can pass the full path to it. All you need to do is replace `chrome` with the full path, for example:
>
>```
>node test '/usr/bin/google-chrome-stable'
>```


#### Testing accessibility
This project uses [cypress-axe](https://www.npmjs.com/package/cypress-axe) for UI accessibility tests. To do an accessibility check up on a page, simple add `cy.injectAxe()` after a page is visited with `cy.visit(...)` and run `cy.checkA11y(null, {runOnly: { type: 'tag', values: ['section508']}})` at any point. It's recommended to add `cy.checkA11y()` right after the page loads and also after interactions that cause UI changes (e.g. the opening of a dialog window).
  
### Working with static files

Put your scripts/fonts/etc inside the `ckanext/ed/assets` folder and images inside the `ckanext/ed/public` folder. It can be used as usual ckan `assets` and `public` contents.

At the same time, we use CSS preprocessor (LESS) to build our styles. Put your styles inside the `ckanext/ed/less` and build it:

```bash
$ npm run static:build # Option 1: one-time build
$ npm run static:watch # Option 2: build on every change
```

Processed styles will be put to the `ckanext/ed/assets/css` folder.

### Working with i18n

To extract i18n messages and compile the catalog we have to have our development server running.

In another terminal window run these commands:

```
$ make i18n_extract
$ make i18n_compile
```

See CKAN documentation for more on i18n management.

### Testing email notifications

We use a fake SMTP server to test email notifications:

- log into https://mailtrap.io/inboxes
- select `Demo Inbox`
- copy SMTP credentials
- past to `docker-ckan-ed:.env` (mail service connection section)
- restart the development server

Now all email sent by `from ckan.lib.mailer import mail_user` should be sent to the `Demo Inbox` at Mailtrap.

### Generating data.json

See the "Open Data" reference:
https://project-open-data.cio.gov/v1.1/schema/

See the metadata analysis regarding the project:
https://docs.google.com/spreadsheets/d/1ZPRXxKCMST-z5Exvvuf0MxDVjE2l-4jC1oKWOnpDz9M/edit#gid=44728761

We generate `data.json` using our fork of `ckanext-datajson` at https://github.com/okfn/ckanext-datajson/tree/ed (the `ed` branch).

To update the translation map (`package -> data.json`) edit `export_map/export.map.json`. It uses a self-explanatory structure. Our focus is mostly on `field` and `extra` fields. We use `ckanext-scheming` so `extra` should be `false` for all relevant fields.

### Log into the container

To issue commands inside a running container (after `$ make start`):

```
$ make bash
```

Now you can tweak the running `ckan-dev` docker container from inside. Please take into account that all changes will be lost after the next container restart.

### Updating docker images

Sometimes we need to update the base docker images `ckan/ckan-dev`. We can do it using:

```bash
$ make pull
$ make build
```

### Stop service containers

Stop all service containers

```
$ make stop
```

Stop specific service container

```
$ make SERVICE=ckan-dev stop
```

### Removing stopped service containers

Remove all service containers

```
$ make remove
```

Remove specific service container

```
$ make SERVICE=ckan-dev remove
```

### Resetting docker

If you want to start everything from scratch there is a way to prune your docker environment:

> It will destroy all your projects inside docker!!!

```
$ docker system prune -a --volumes
```

### Generating TOC

To update this readme table of contents run:

```bash
$ make readme
```

## Troubleshooting

### The admin credentials don't work

There had been a bug in `ckan-dev` that was fixed. Run the following commands to update your ckan image:

```bash
$ make pull
$ make build
```

## References

- CKAN Documentation - https://docs.ckan.org/en/2.8/
- Deploying staging/production - see the corresponding documentation on GitLab
