# 3.9.9.1 February 15, 2024

## Changes

- Fix documentation appearing in hierarchy
- Fix `isPartOf` output in data.json
- Skip harvesting of invalid `{extent:computeSpatialProperty}` values
- Remove Google Analytics

## Tickets closed

- OD-1617 - identifier and isPartOf set to same value in data.json
- OD-1633 - Remove Google Analytics Extension
- OD-1638 - CKAN Harvester not capturing packages in Production

# 3.9.9 November 29, 2023

## Changes

- Fix `theme` (categories/groups) in data.json

## Tickets closed

- OD-1626 - Mapping of theme field is inconsistent

# 3.9.8 October 9, 2023

## Changes

- Fix login with Dept of Education account (allows logging in with both login methods)

## Tickets closed

- OD-1618 - Account email case sensitive

# 3.9.7 July 10, 2023

## Changes

- Fix config page field error when saving
- Fix "not authorized" redirect when logging in with login.gov

## Tickets closed

- OD-1608 Fix CSS issues created with CKAN update (footer, popup)
- OD-1609 Landing page for login.gov to ODP brings you to a "not authenticated" page

# 3.9.6 June 9, 2023

## Changes

- Re-implement v3.9.4 changes
- Reduced default user permissions. Users outside of organizations can no longer view other user profiles (roles, organizations, etc.)
- Allow organization Admins and Editors to manage relationships in the UI

## Tickets closed

- OD-1554 - Default user permissions - reduce privileges
- OD-1575 - Relationships feature - user permissions
- OD-1589 - Dependabot: Server-Side Request Forgery in Request #62

# 3.9.5 June 5, 2023

## Changes

- Bump CKAN version to 2.9.9
- Fix tests
- Minor refactoring
- Revert v3.9.4 changes to release CKAN 2.9.9 with less uncertainty

## Tickets closed

- OD-1603 - [WebInspect scan] Critical CKAN Vulnerability

# 3.9.4 May 24, 2023

## Changes

- Reduced default user permissions. Users outside of organizations can no longer view other user profiles (roles, organizations, etc.)
- Allow organization Admins and Editors to manage relationships in the UI
- Resolved harvesting issues (no code changes)

## Tickets closed

- OD-1554 - Default user permissions - reduce privileges
- OD-1575 - Relationships feature - user permissions
- OD-1589 - Dependabot: Server-Side Request Forgery in Request #62
- OD-1593 - data.json harvesting does not work

# 3.9.3 April 10, 2023

## Changes

- Always redirect to login.gov instead of `/user/login` when `ckanext.saml2auth.enable_ckan_internal_login` is False
- Fix data.json harvesting when extras exist in schema

## Tickets closed

- OD-1585 - Redirect to login.gov after warning banner when internal login is disabled
- OD-1593 - data.json harvesting does not work

# 3.9.2 March 20, 2023

## Changes

- Fix data.json output for "language" and "references" when brackets are present
- Always redirect to login.gov instead of `/user/login` when `ckanext.saml2auth.enable_ckan_internal_login` is False

## Tickets closed

- OD-1579 - JSON Field "Language" formatted incorrectly
- OD-1585 - Redirect to login.gov after warning banner when internal login is disabled

# 3.9.0 January 20, 2023

## Changes

- Fixed login.gov integration issues (not redirecting to Dashboard; changing user display name to email address)
- Added bulk update pagination
- Fixed data.json internal endpoint config
- Fixed toggle visibility while using high contrast modes
- Updated SQL statements to parameterize queries to prevent potential SQL injection

## Tickets closed

- OD-1278 - Login.gov implementation details
- OD-1534 - Bulk Update pagination
- OD-1547 - data.json internal endpoint config does not appear to work
- OD-1550 - Upgrade to CKAN 2.9.7
- OD-1553 - Visibility toggle not visible for users utilizing higher contrast
- OD-1556 - Clarify email hash purpose
- OD-1557 - Parameterize SQL statements
- OD-1560 - SPIKE: Enable Follow functionality for login.gov users
- OD-1569 - Deploy 3.9.0 (including login.gov!) to Stage
- OD-1570 - Deploy 3.9.0 (including login.gov!) to Production

## Documentation

### [OD-1547](https://open-data-ed.atlassian.net/browse/OD-1547) data.json internal endpoint config does not appear to work

This variable allows moving the path of the live data.json endpoint to a different path. You can then point your cached data.json to `/data.json`. Only set this if you're going to enable caching per the [`ckanext-datajson` docs](https://github.com/datopian/ckanext-datajson/tree/dev/py3-upgrade#caching-the-response) (I know there's already a workaround live on the portal, but once we're ready to switch, enable this). To do this, add the following to your `ckan.ini`:

```
ckanext.datajson.path = /internal/data.json
```

# 3.8.0 January 6, 2023

## Changes

- 508 accessibility:
  - Add screen reader support to select2 fields and dropdowns
  - Fix select2 duplicated labels with screen readers
  - Add/fix Cypress tests for accessibility
  - Associate element labels with their respective form elements on bulk action pages
  - Associate toggle labels with their respective form elements
  - Fix link color contrast
  - Fix duplicate element IDs
  - Fix list structures
  - Fix logout button color contrast
- Re-enable Data Previews
- Make resource titles required (when uploading a resource—ignore when no resource present)
- Update DB revision table CLI to fix purging
- Bump dev dependencies
- Fix coordinator role assignment on member addition
- Remove vulnerable Python requirement, `future` (deprecated)

## Tickets closed

- OD-806 - integrate/implement our data preview solution for the ODP
- OD-1109 - Resource title should be a required field when adding resources
- OD-1409 - Purge functionality broken
- OD-1506 - Select 2 Issues: Form Label
- OD-1509 - Dropdown values are read twice
- OD-1514 - Fix integration tests for Cypress Axe Testing
- OD-1523 - Dependabot: (High) Alert #56 minimatch ReDoS vulnerability
- OD-1525 - Dependabot: (Low) Alert #58 decode-uri-component vulnerable to DoS
- OD-1527 - Labels: Bulk management (Keyboard users)
- OD-1528 - 508 Compliance Toggle Issues
- OD-1531 - Dependabot: (High) Alert #60 qs vulnerable to Prototype Pollution
- OD-1533 - Adding member to an organization defaults to coordinator
- OD-1535 - [Colour contrast] Ambiguous link styling
- OD-1536 - Duplicated IDs
- OD-1538 - Lists: \<li\> Elements & List Structure
- OD-1539 - [Colour contrast] Logout button

## Documentation

### [OD-806](https://open-data-ed.atlassian.net/browse/OD-806) integrate/implement our data preview solution for the ODP

To re-enable Data Previews, you'll need to need to add the following to `plugins` in your `ckan.ini` (if any/all are missing):

```
datastore xloader dataexplorer_view dataexplorer_table_view dataexplorer_chart_view dataexplorer_map_view
```

These should come immediately after the first plugin (`saml2auth`):

```
ckan.plugins = saml2auth datastore xloader dataexplorer_view dataexplorer_table_view dataexplorer_chart_view dataexplorer_map_view ... OTHER PLUGINS
```

### CKAN Core Select2 508 Patch

A patch is required to fix select2 accessibility issues. It can be found in the `docker-ckan-ed` repo, here: [select2_508sr.patch](https://raw.githubusercontent.com/CivicActions/docker-ckan-ed/master/ckan/2.9/setup/patches/ckan/select2_508sr.patch)

To apply, either follow the steps in your SOP (if it's been updated), or:

1. Copy the patch file to the `src/ckan/ckan/` directory.
2. While in `src/ckan/ckan/`, run `patch -p1 < select2_508sr.patch` or `git apply --verbose --ignore-whitespace select2_508sr.patch`.

To confirm that the changes are present, you can run:

```
less /PATH/TO/src/ckan/ckan/public/base/vendor/select2/select2.js | grep 'isDeletion'
```

And the output should be:

```
        open: function (isDeletion) {
            if (isDeletion != true) {
        selectChoice: function (choice, isDeletion) {
                    if (isDeletion != true) {
            var isDeletion = false;
                        isDeletion = false;
                        isDeletion = false;
                            isDeletion = true;
                            isDeletion = true;
                        isDeletion = false;
                    this.selectChoice(selectedChoice, isDeletion);
                        this.open(isDeletion);
                this.open(isDeletion);
                this.open(isDeletion);
        opening: function (isDeletion) {
```

# 3.7.0 December 9, 2022

## Changes

- 508 accessibility:
  - Fixed color contrast issues
  - Fixed modal pop-up focus and tab order issues
  - Fixed focus on screen flash messages and added screen reader support
  - Fixed file input screen reader descriptions (resource and data dictionary)
  - Fixed empty links (added aria-labels or aria-hidden as needed)
  - Added aria labels to miscellaneous button icons (search magnifying glass, etc.)
  - Added role attributes to user role selection on the new user page
  - Fixed empty table headers
- Resolved UTF-8 encoding issues with Data Store
- Improved UX for Data Profile hierarchies (hierarchy backend API calls are now direct DB queries to improve speed; hierarchy loads after page load)

## Tickets closed

- OD-1420 - Unicode UTF-8 files not pushed to Data Store
- OD-1479 - Optimizing the loading speed of the hierarchy
- OD-1489 - Color Contrast
- OD-1499 - Modal focus order
- OD-1504 - User, About, Stats, Deadoralive, Login, FAQ, Harvest & Source: color contrast
- OD-1508 - Screen flash messages (success and failure)
- OD-1510 - File inputs have duplicated ids, causing screen readers to read wrong label when input is focused
- OD-1511 - Category & CKAN Admin: Colour Contrast
- OD-1513 - Close buttons on multi-select elements are showing up as empty links
- OD-1516 - Magnifying glass (Button) Related Issues
- OD-1517 - Role Attributes
- OD-1521 - Empty  Headers

# 3.6.0 November 28, 2022

## Changes

- 508 accessibility:
  - Combo box labels are associated and support screen readers
  - Group labels are associated and support screen readers
  - Collections selection box supports keyboard navigation
  - Upload button focuses properly on tab navigation
  - Required fields support screen readers
  - Required field error messages support screen readers
  - Off-screen links hidden from screen readers
  - Data Profile pages (view, edit, etc.) meet color contrast requirements

## Tickets closed

- OD-1490 - Combo box labels not associated
- OD-1491 - Group labels not programmatically associated
- OD-1492 - Multi Select List Box
- OD-1493 - Upload control receives twice focus
- OD-1494 - Required field
- OD-1495 - Required field inline errors
- OD-1496 - Off screen links missing accessible name
- OD-1498 - Labels not associated
- OD-1503 - Dataset: color contrast et al

# 3.5.0 November 14, 2022

## Changes

- Added the option to add and use default values for Data Profile creation and editing. This can be found at `https://<BASE_URL>/user/<USER_NAME>/default_fields`
- Added email notifications for Bulk Data Profiles, sent to coordinators
- Added Data Profile titles/hyperlinks to the left panel of the Bulk Data Profile form

## Tickets closed

- OD-918 - Default Settings associated with a user
- OD-997 - Mockup UI for Versioning support
- OD-1354 - Bulk changes to public/published entries should generate a notification email
- OD-1464 - Reproduce all existing Cypress tests (on Dev) to Stage
- OD-1478 - Dependabot issues review
- OD-1485 - Add titles of data profiles being bulk edited on the far left column on the bulk editing wizard

## Documentation

### [OD-918](https://open-data-ed.atlassian.net/browse/OD-918) Default Settings associated with a user

This feature requires initialization in the DB. To do this, run this command in the CKAN Python virtual environment (only required one time):

```
ckan -c /PATH/TO/ckan.ini edcli add-bulk-preference
```

### [OD-1354](https://open-data-ed.atlassian.net/browse/OD-1354) Bulk changes to public/published entries should generate a notification email

This feature requires initialization in the DB. To do this, run this command in the CKAN Python virtual environment (only required one time):

```
ckan -c /PATH/TO/ckan.ini edcli add-user-package-fields
```

# 3.4.0 October 28, 2022

## Changes

- Added bulk Data Profile updates for data stewards, found on the dashboard at `/dashboard/bulk_update_dataprofile`
- Fixed the handling of empty date range metadata in Solr re-indexing (no longer outputting false errors—empty values are fine here)
- Added user controls to disable/enable each email notification (approval workflows, publishing requests, etc.)
- Fixed purging Data Profiles with relationships with:
    - Added `ckan` CLI command to clean up deprecated relationship revision table 
- Updated invalid URL and login error messages to be less specific for security (e.g. "Login failed. Bad username or password." -> "Login failed.")

## Tickets closed

- OD-934 - Bulk update capability for data stewards
- OD-1310 - Solr re-index: start / end date is not valid
- OD-1323 - User Control over Notification Subscriptions
- OD-1409 - Purge functionality broken
- OD-1463 - WebInspect Found: 'Web Server Misconfiguration: Server Error Message' (Vuln ID: 10932) (LOW)

## Documentation

### [OD-1323](https://open-data-ed.atlassian.net/browse/OD-1323) User Control over Notification Subscriptions

Notification preferences require a custom table in the DB. To initialize it, run the following command (this is only required once—run this before starting up CKAN after the release is installed):

```
ckan -c /PATH/TO/ckan.ini edcli init-notf-preferences
```

### [OD-1409](https://open-data-ed.atlassian.net/browse/OD-1409) Purge functionality broken

When there's data in the table `package_relationship_revision` (and there currently is on Stage and Prod), any Data Profiles involved will cause an error when you attepmt to purge them. This table is deprecated and is supposed to be cleaned/removed by a CKAN DB upgrade, but in some cases, data can remain. This command will remove all rows in this table. This will **not** remove any existing Data Profile relationships—only the unused revision data that's stored here. You only need to run this once (and it can be run after the release is installed and CKAN is running—no restart required):

```
ckan -c /PATH/TO/ckan.ini edcli clean-revisions
```

# 3.3.0 October 17, 2022

## Changes

- Added script to validate where Data Profiles meet the minimum DCAT field requirements (and fix any pre-existing Data Profiles that _should_ be in a `hidden` and/or `draft` state)
- Added the ability to disable data preview and xloader integrated code via simply removing their respective plugins
- Updated the password validator to enforce a stronger password policy (e.g. don't allow username, site name, or sequential characters in passwords)

## Tickets closed

- OD-1260 - Cannot create data profile without resources through wizard
- OD-1459 - Data Profile DCAT Requirement Validator script
- OD-1465 - Extract data preview/loader work from 3.1.0 and 3.1.1 releases
- OD-1467 - Implement strong password policy for the ODP

## Documentation

### [OD-1459](https://open-data-ed.atlassian.net/browse/OD-1459) Data Profile DCAT Requirement Validator script

**Note**: As with all of the scripts, this requires the `export` of a few environment variables (Target URL: `export ED_CKAN_URL=https://YOUR_TARGET_PORTAL`; Target URL Admin API key/token: `export ED_CKAN_KEY=ADMIN_API_KEY`). Scripts can be found in `ckanext-ed/ckanext/ed/scripts` and can be run from any machine, as long as the environment variables are set correctly. It's recommended to install the `requirements.txt` found in the `scripts` directory in a clean Python 3 virtual environment, regardless of whether this is being run on the portal server or not.

To set all old Data Profiles that don't meet the minimum DCAT requirements to `draft` state, run the following script:

```
python validate_dcat.py --all
```

There are additional optional arguments:

```
--all - validate all publishers
--publisher PUBLISHER - validate one publisher by name
--file - bulk validation, each line in the file should be a publisher name
--log-output OUTPUT - log output file path
--csv-output OUTPUT - output results as a CSV file
--csv-output-changes OUTPUT - output changed packages results as a CSV file
--dry-run - do not modify state nor visibility of invalid data profiles
-h, --help - show this help message and exit
```

It's recommended to always run the command with at least `--csv-output` (outputs Data Profiles that don't meet the DCAT minimum requirements) and `--csv-output-changes` (outputs the Data Profiles that were "fixed", e.g. Data Profiles that don't meet the requirements, but are not set to `draft` state):

```
python validate_dcat.py --all --csv-output OUTPUT_FILE_NAME.csv --csv-output-changes OUTPUT_CHANGES_FILE_NAME.csv
```

For additional information about this script, see [the documentation](https://github.com/CivicActions/ckanext-ed/blob/master/ckanext/ed/docs/scripts.md#validate-if-data-profiles-are-according-to-the-dcat-standard).

### [OD-1465](https://open-data-ed.atlassian.net/browse/OD-1465) Extract data preview/loader work from 3.1.0 and 3.1.1 releases

The only step required is the removal of the following plugins from `plugins` in `ckan.ini`:

```
datastore xloader dataexplorer_view dataexplorer_table_view dataexplorer_chart_view dataexplorer_map_view
```

## 3.2.0 October 2, 2022

#### Changes/Fixes

- Add email notifications for sysadmins and coordinators when Data Profiles are out of draft state and ready for review, along with a CLI command to send email notifications for when they've been pending for _x_ days.
- Fixed the records schedule command/scraper.
- Added draft Data Profile (including resources) states when the minimum DCAT metadata requirements haven't been reached.
- Add Coordinator roles, allowing only sysadmins or any user in an organization with the Coordinator role to toggle Data Profile visibility from "Hidden" to "Public" (if the Data Profile is out of draft state).

#### Tickets Closed

- OD-64 - Appropriate alerts if entities are "stuck" in the approval workflow
- OD-1254 - Records schedule URL has changed
- OD-1309 - Hide Draft Data Profiles
- OD-1362 - Additional user role - Coordinator role

## 3.1.1 September 2, 2022

#### Changes/Fixes

- Fixed Data Explorer approval 500 error
- Fixed Collection edit 504 error
- Fixed intermittent 404 on viewing Collections
- Fixed deletion of Data Explorers
- Updated Data Explorer count text (from "Data Profiles" to "Data Explorers")
- Fixed intermittent "0 Data Explorers found"
- Fixed Stats page 500 error
- Fixed XLS to CSV auto-conversion
- Removed DataStore option for unsupported file types
- Fixed intermittent 500 error on viewing Sources
- Fixed "Previous" button creating an empty unnamed resource if form is empty

#### Tickets Closed

- OD-1355 - Extensions for Elastic Search from British Natural History museum - Investigate
- OD-1416 - Approval of data explorer - 500 error
- OD-1427 - 504 error -editing collections
- OD-1428 - Error - Category Not Found
- OD-1429 - 500 Error - Deleting Data Explorer
- OD-1430 - Data Explorers Reporting 0 Data Profiles Found
- OD-1431 - Statistics page - Internal Server Error - 500 Error
- OD-1432 - XLS file does not convert to CSV after upload
- OD-1433 - Remove ability to push unsupported file formats to the data store
- OD-1435 - Source page - public facing 500 error
- OD-1436 - Internal Server Error on Imaginary OMB Form
- OD-1442 - Unnamed documentation resources after using the "Previous" button

## 3.1.0 August 19, 2022

#### Changes/Fixes

- Added SSO support via login.gov
- Added a description of each DCAT required schema field in the Data Profile and Resource forms, available on hover of the "DCAT" icon next to the field name
- Removed requirement constraint for DCAT schema fields, allowing incremental updates of metadata
- Fixed Data Profile and Collection creation wizard redirects ("Previous", "Save & add another", etc.)
- Fixed resource pushes to datastore for all supported formats (CSV, XLS, XLSX, etc.)

#### Tickets Closed

- OD-1278 - Login.gov implementation details
- OD-1370 - Create Accounts based on specific emails using ckanext-saml2auth
- OD-1400 - Identify schema required fields
- OD-1403 - Data profile creation wizard error at documentation stage
- OD-1420 - Unicode UTF-8 files not pushed to Data Store

## 3.0.1 August 5, 2022

#### Changes/Fixes

- Added Data Previews (charts, tables, and maps)
- Added footer info (markdown supported text and enable/disable) options to the admin page

#### Tickets Closed

- OD-806 - Integrate/implement our data preview solution for the ODP
- OD-1367 - Config changes are not applied
- OD-1373 - WebInspect Found: 'Cookie Security: Persistent Cookie' (Vuln ID: 4728)
- OD-1419 - deadoralive extension implementing compatibility with python 3.6

## 3.0.0 July 22, 2022

#### Changes/Fixes

- **All** Python 3 code changes have been merged to the main branch and are ready for deployment!
- Data Profile parent/child relationship hierarchy now uses filtering in the API call to speed up retrieval.
- Moving resources between Data Profiles has been fixed.

#### Tickets Closed

- OD-1324 - Investigate slow Data Profile loading on CKAN 2.9+
- OD-1332 - Migrate Test env to support python 3
- OD-1342 - Python 3 Upgrade: Integrate all ODP extensions and test for compatibility
- OD-1402 - Move Resource results in internal server error

## 2.9.0-nc July 9, 2022

#### Changes/Fixes

**Note**: No code changes (`nc`) to `master` branch. All work done in this sprint/release (and all previous Python 3 migration work) is currently on this branch: [dev/python3-OD-1349-fixes](https://github.com/CivicActions/ckanext-ed/tree/dev/python3-OD-1349-fixes).

The tickets closed in this sprint wrap up the Python 3 changes required for the `ckanext-ed` extension itself, but they won't be merged until the following Python 3 migration tickets are resolved:

- OD-1332 - Migrate (Datopian) Test env to support Python 3
- OD-1342 - Python 3 Upgrade: Integrate all ODP extensions and test for compatibility

This will allow us to more easily handle a potential mid-sprint release, in the case that anything on production or staging needs to be fixed/implemented.

#### Tickets Closed

- OD-1349 - [Implementation] ckanext-ed Python 3 compatibility
- OD-1359 - [Implementation] ckanext-ed Python 3 Compatibility Update documentation
- OD-1360 - [Implementation] ckanext-ed Python 3 Compatibility Integration Tests

## 2.8.4.1 June 30, 2022

#### Changes/Fixes

- Fixes additional issues with statistics (incorrect counts, user permissions, etc.).

#### Tickets Closed

- OD-1365 (reopened) - Statistics link in footer causes internal server error

## 2.8.4 June 28, 2022

#### Changes/Fixes

- The statistics page is now rendering and displaying accurate stats.

#### Tickets Closed

- OD-1312 - Confirm access to login.gov dev sandbox (for Michael)
- OD-1350 - [Implementation] ckanext-ed Controller.py Python 3 Compatibility
- OD-1351 - [Implementation] ckanext-ed Controller Directory Python 3 Compatibility
- OD-1353 - [Implementation] ckanext-ed Python 3 compatibility Harvest
- OD-1356 - Testing of all controllers
- OD-1358 - [Implementation] ckanext-ed Python 3 Compatibility: Format converter
- OD-1365 - Statistics link in footer causes internal server error

## 2.8.3 June 17, 2022

#### Changes/Fixes

- Metadata displayed in "Data Profile Information" have been reordered by usefulness, and only the most useful are shown by default
- Private Data Profiles in the relationship hierarchy, dependencies, and derivations, are aren't visible for public users

#### Tickets Closed

- OD-1348 - Display these fields above the "show more" link in Data profiles
- OD-1363 - Non-public Data Profiles are visible in the hierarchy for public users
- OD-1366 - Wrong URL for User Help Guide

## 2.8.2-nc June 10, 2022

**Note**: No code changes (`nc`) to `master` branch.

#### Tickets Closed

- OD-1352 - [implementation] ckanext-ed Python 3 compatibility CLI commands
- OD-1357 - [Implementation] ckanext-ed Python 3 Compatibility scripts

## 2.8.1-nc May 27, 2022

**Note**: No code changes (`nc`) to `master` branch.

#### Tickets Closed

- OD-1341 - Python 3 Upgrade: [INVESTIGATION] ckanext-ed compatibility
- OD-1346 - Python 3 Upgrade: [IMPLEMENTATION] ckanext-datajson compatibility

## 2.8.0 May 13, 2022

#### Changes/Fixes

- Usernames and emails can be reused after deleting a user
- Deleting a user requires new owner selection, to inherit roles for organizations, and objects for Data Profiles and groups (Collections, Sources, Data Explorers)

#### Tickets Closed

- OD-1286 - Enable purging of user accounts.
- OD-1331 - Migrate Dev enviroment to support Python 3
- OD-1336 - Python 3 Upgrade: ckanext-envvars compatibility
- OD-1337 - Python 3 Upgrade: ckanext-deadoralive / deadoralive compatibility
- OD-1339 - Python 3 Upgrade: [INVESTIGATION] ckanext-datajson compatibility

## 2.7.0 April 29, 2022

#### Changes/Fixes

- Add the ability for sysadmins and admins to change the owner for group type objects
- Add a list of useful hyperlinks (previously only accessible manually via direct URL path) to the admin page
- Newly created resources appear at the top of the resource list now, instead of the bottom

#### Tickets Closed

- OD-1265 - Implement change ownership for CKAN Group objects
- OD-1277 - Table of Useful Links
- OD-1287 - Ordering resources
- OD-1313 - Estimating work for Python upgrade
- OD-1330 - Identify and analyze current extensions on ODP
- OD-1335 - Install extensions that are already Python 3 compatible

## 2.6.0 April 15, 2022

#### Changes/Fixes

- Add CLI command to import new OMB numbers as Sources (to be run with cron or systemd timer)
- Add "User list" button to dashboard
- Add "Add User" button to user list page, allowing sysadmins/admins to create new users
- Fix redundant "About" headings on documentation pages

#### Tickets Closed

- OD-1266 - Automate approved OMB control number and instrument Source creation
- OD-1275 - Allow admins to create user accounts from user list vs organization page
- OD-1305 - Investigate the "About" link repeating in Left Nav

## 2.5.0 April 1, 2022

#### Changes/Fixes

- Add functionality to allow sysadmins and org admins to change Data Profile (and documentation) owners
- Add bulk resource approval and rejection
- Add EDI data.json compatibility

#### Tickets Closed

- OD-1264 - Implement change ownership for data profiles and documentation objects
- OD-1293 - Admin Workflow - Bulk Approval of Resources (and Data Profiles)
- OD-1299 - EDI JSON harvest compatibility implementation
- OD-1304 - Have an architectural review of CKAN / DB's / etc with PIVOT

## 2.4.0 March 18, 2022

#### Changes/Fixes

- Fixed resource approval emails displaying the Data Profile creator name instead of the resource creator/editor
- Added additional info to resource approvals (link to Data Profile, description, etc)
- Fixed markdown anchor links in all descriptions

#### Tickets Closed

- OD-1297 - Resource approval - "Request for approval by"
- OD-1298 - Need more information in resource approval dashboard
- OD-1300 - Create a table/spreadsheet of feature per version release
- OD-1307 - Investigate Anchor Links Issue

## 2.3.2 March 4, 2022

#### Changes/Fixes

- /blog now redirects to http://blog.ed.gov/
- Fixed resource reordering
- Fixed popup cookie
- Updated integration tests for CKAN 2.9.5
- Fixed approval_pending resource filtering resulting in 'missing' resources for CKAN 2.9.5

#### Tickets Closed

- OD-525 - Investigate and remediate CKAN response to /blog
- OD-1115 - Investigate/Remediate persistent cookie
- OD-1288 - Investigate Edge Browser issues
- OD-1289 - Reordering resources - icon vs text problems
- OD-1292 - CKAN 2.9.5 Investigation & Testing
- OD-1295 - Trial integration of EDI JSON
- OD-1296 - 618 part c hierarchy missing

## 2.3.0 February 4, 2022

#### Changes/Fixes

- Added ordering for Data Profile children (a-z, z-a, custom)
- Sysadmins can now edit usernames
- Added link to help page to the footer (uses same env variable that the link on FAQ uses in case the URL of the help page changes)

#### Tickets Closed

- OD-804 - investigate the current data preview functionality and the 508 compliance requirements
- OD-1210 - [Implementation] ordering of child data profiles
- OD-1274 - Allow admins to change user names
- OD-1276 - Help link on every screen (not just within FAQ)

## 2.1.0 January 21, 2022

#### Changes/Fixes

- Added "Organization Roles" tab to user page to list roles
- User roles are now displayed for each or listed in "My Organizations" tab in the Dashboard
- When visiting a Data Profile from a search with facets, there's now a "Return to Search Results" button, which will prevent losing your search facets
- Data Explorer pagination is fixed. Previously, if a Data Explorer was pending approval, there would be a blank spot where that Data Explorer would fall in the list
- Bulk tag update is now available in the Tags tab on the Dashboard

#### Tickets Closed

- OD-657 - Account profile doesn't indicate user role
- OD-658 - No one-click method to return to filtered search results
- OD-914 - Search bar - capitalization recognition
- OD-978 - Fix Data Explorer Pagination
- OD-1226 - Bulk tag creation
- OD-1269 - Reset all passwords and API keys

## 2.0.1 January 07, 2022

#### Changes/Fixes

- Item list highlighted boxes are now clickable for navigation instead of only the titles (Data Profiles, Resources, Organizations, etc)
- Script added to set invalid program codes to 018:000
- `accrualPeriodicity` script now contains a `remove` argument
- Added prevention of duplicate themes in data.json
- Added prevention of duplicate Categories (themes in data.json) creation to harvest source parser

#### Tickets Closed

- OD-633 - Confusing Selection of Resources
- OD-994 - Investigate importing OMB Information collection requests from https://www.reginfo.gov
- OD-1003 - Discovery: Change object ownership
- OD-1224 - Clean up invalid program codes
- OD-1225 - Invalid entries in the field that maps to the “accrualPeriodicity”
- OD-1234 - Duplicate entries in the field that maps to the “theme” key are possible

## 2.0.0 January 04, 2022

#### Changes/Fixes

- Announcement Popup is now configurable from the admin config page, supports enabling/disabling and markdown
- Purge errors resolved
- Added script to fix invalid program codes
- Added removal option to accrualPeriodicity script
- Fix Cypress (integration) tests for compatibility with CKAN 2.9.4

#### Environment Changes

- Environments now use XLoader
- Upgraded ckanext-googleanalytics for compatibility with CKAN 2.9.4
- Updated ckanext-ed for compatibility with CKAN 2.9.4
- Migrated dev and test environments to CKAN 2.9.4
- Upgrade ckanext-harvest for compatibility with CKAN 2.9.4

#### Tickets Closed

- OD-992 - Update Popup Feature to be Fully Configurable
- OD-1157 - implement XLoader
- OD-1177 - Purge failures/impediments
- OD-1201 - fix ckanext-googleanalytics incompatibility with CKAN 2.9
- OD-1211 - fix ckanext-ed incompatibility with CKAN 2.9
- OD-1224 - Clean up invalid program codes
- OD-1225 - Invalid entries in the field that maps to the “accrualPeriodicity”
- OD-1246 - test integrate the ckanext-google-analytics AND ckanext-showcase extensions with the Dev Environment
- OD-1248 - Preliminary work for CKAN 2.9 Upgrade in the Test Env
- OD-1255 - fix CKAN Harvester for CKAN2.9 migration
- OD-1256 - Fix all cypress tests on CKAN2.9 migration

## 1.13.2 December 10, 2021

#### Changes

- Fix postgresql boolean error for packages

## 1.13.1 December 10, 2021

#### Changes

- Avoid using previously filled list in Data Profile hierarchy API call

#### Tickets Closed

- OD-1251 - Long load times for hierarchy pages (?)

## 1.13.0 October 29, 2021

#### Changes

- Full Data Profile hierarchy is now displayed in the left panel on the Data Profile page
- `isPartOf` is now mapped to parent Data Profiles in the data.json and harvesting creates parent/child relationships
- `references` is now mapped to Data Profile documentation in the data.json and harvesting creates documentation
- Dev environment migrated to CKAN 2.9.4 (with `ckanext-ed` and `ckanext-googleanalytics` disabled while in progress)
- `ckanext-showcase` has been switch from `keitaroinc` to `ckan` and now supports CKAN 2.9

#### Tickets Closed

- OD-1166 - Display full data profile hierarchy in left panel
- OD-1200 - detailed investigation on ckanext-ed incompatibility with CKAN 2.9
- OD-1208 - fix ckanext-showcase incompatibility with CKAN 2.9
- OD-1209 - Migrate to CKAN 2.8.8 to 2.9 in the DEV environment
- OD-1219 - Implement Documentation Export in ODP and references import in ED JSON harvester
- OD-1220 - Fix isPartOf handling in ED JSON harvester

## 1.12.0 October 15, 2021

#### Changes

- Add Sources (Sources backend, UI navigation and pages, add to Source from Data Profile and resource forms, environment variable to enable/disable, etc)
- Add Sources integration tests
- Fix data.json validation integration test for large data.json output

#### Tickets Closed

- OD-1213 - Implement the backend changes required to create the "New Sources" Model in the ODP
- OD-1214 - implement the new Sources UI/UX on the ODP Part.1
- OD-1215 - implement the new Sources UI/UX on the ODP Part.2

## 1.11.4 October 6, 2021

#### Changes

- Switch from Keitaro `ckanext-pages` to CKAN `ckanext-pages`
- Add env variable for new link on FAQs page for Help Page
- Update `download_resource.py` to download Documentation types

#### Tickets Closed

- OD-1227 - User Help page

## 1.11.3 September 28, 2021

#### Changes

- Remove deprecated environment variable checks for Data Explorers and Master Collections, change beta banner to announcement banner
- Descriptions are now expanded by default
- Add link to ODP marketing video in the announcement banner

#### Tickets Closed

- OD-1078 - Investigate whether Sources need to be associated with both Data Profiles and Resources
- OD-1204 - Implementation: Removing flags/environment variables for stable or deprecated features
- OD-1212 - Investigate the backend changes required to implement the "New Sources" Model in the ODP
- OD-1217 - Description expanded by default
- OD-1218 - Add ODP marketing video

## 1.11.2 September 17, 2021

#### Changes

- Display Data Profile name on resources page and resource edit form page
- Enable rights field based on Access Level selection
- Display rights field in data.json
- Add bureau code field to the Organization edit form
- Add validation integration test for data.json using the data.gov validator
- Add docs for new (CKAN 2.8.7+) organization_list environment variable

#### Fixes

- Fix output of organization_list?all_fields=True

#### Tickets Closed

- OD-916 - Add Resource Page - Name of Profile being edited
- OD-939 - Discovery: estimate work / risk to upgrade to CKAN 2.8.8 and CKAN 2.9
- OD-1084 - Investigate: Removing flags/environment variables for stable features
- OD-1099 - Enable Rights field based on the Access Level value
- OD-1135 - Add bureau code field to the Organization form
- OD-1156 - [Investigation] ordering of child data profiles
- OD-1161 - Investigate: Validate data.json within integration tests
- OD-1197 - organization_list?all_fields=True doesn't output all orgs on CKAN 2.8.8
- OD-1198 - Organization list getting truncated to 10 publishers [staging, prod]
- OD-1203 - Implementation: Validate data.json within integration tests

## 1.11.1 September 7, 2021

#### Changes

- Change cypress to output 0 (passing) or 1 (failing) to allow blocking PRs
- Add associate records schedule field to the Data Profile form, with a paster command to update values and populate the dropdown

#### Bug Fixes

- Fix markdown in descriptions for resources
- Fix purging of data profiles with relationships
- Fix copying of data profiles with an excessive size of metadata
- Fix harvesting of sources with organizations or tags/vocabularies improperly formatted

#### Tickets Closed

- OD-1114 - Create/modify cypress test entrypoint to report a non-zero exit code
- OD-1144 - Associate records schedule for a data profile
- OD-1155 - Markdown does not render in Resource description
- OD-1177 - Purge failures/impediments
- OD-1186 - Copy Data Profile feature failing on some data profiles
- OD-1190 - Harvesting certain sources breaks data.json

## 1.11.0 August 20, 2021

#### Changes

- CKAN upgraded to 2.8.8
- Replace "Helpdesk Phone Contact" field with "Helpdesk Contact Name"
- Only show relevant resource types based on "Access Level"
- Reorder "Update Frequency" options to have "Annual" as first option 

#### Bug Fixes

- Check for `None` in `owner_org` before creating tags

#### Tickets Closed

- OD-1139 - Changes on the Helpdesk phone contact field
- OD-1141 - Change the Data Profile resource types based on the Access Level field
- OD-1142 - UI changes on the data profile Update Frequency field
- OD-1174 - OSEP Ingestion Issues / Harvesting Issue
- OD-1179 - Upgrade Dev Environments to CKAN 2.8.8
- OD-1180 - Upgrade Test Environment to CKAN 2.8.8
- OD-1181 - Upgrade Staging Environment to CKAN 2.8.8
- OD-1183 - Create a CKAN 2.8.8 docker image

## 1.10.4 August 6, 2021

#### Changes

- Autocomplete is now disabled for the login username field
- Change "URL of page containing all resources" info text to "URL of an overview webpage for the data resources (if external to this site)"
- Change input fields max-width on the data profiles form
- Data Profile relationship fields are now hidden by default, revealed by a clickable button
- Data Profile visibility is now a toggle instead of a dropdown
- Helpdesk email info text updated to be more clear
- Data Profile access level selection now uses radio buttons instead of a dropdown

#### New Features

- Display Data Profile dependency relationships in the left panel instead of in "Data Profile Information"
- Display Data Profile derivation relationships in the left panel instead of in "Data Profile Information"
- Data Profile collection selection now uses a popup slush bucket
- Script to add publisher/organization acronyms as tags to existing Data Profiles

#### Tickets Closed

- OD-569 - Investigate/Remediate Privacy Violation: Autocomplete vulnerability (WebInspect scan 3/17/2020)
- OD-1094 - Display dependencies in left navigation bar
- OD-1095 - Display derivations in left navigation bar
- OD-1129 - Updates on URL of page containing all Resources field
- OD-1132 - Make UI changes on the Add Data Profile to Collection field
- OD-1133 - Make UI changes on the Relationship fields of the Data Profile form
- OD-1136 - Change Data Profile Visibility field to a toggle switch
- OD-1137 - Change info text on the Helpdesk email contact field
- OD-1140 - Make UI changes on the Access level data profile field
- OD-1167 - Script to add publisher acronym tags to existing Data Profiles

## 1.10.3 July 23, 2021

#### Changes

- Change data profile relationship design on the data profile left side page
- Automatically add a tag to the Data Profile that contains the Organization acronym
- Data Dictionary fields moved to the bottom of the data profiles form
- Change input fields max-width on the data profiles form
- Sources plugin (master collections) was completely removed

#### New Features

- Add Copy Data Profile feature. It copies the data profile metadata to a new data profile and opens it in the form for the Data Steward confirmation.
- Add Move Resource feature. It moves a resource and its file to a different data profile.

#### Tickets Closed

- OD-1079 - Remove Source plugin and all its references
- OD-1089 - Copy a data profile from current
- OD-1091 - Move Resources between Data Profiles
- OD-1128 - Auto generate acronym tag for the publishing organization's office
- OD-1130 - UI changes on Level of data text box
- OD-1131 - Set a maximum width for the Data Profile form fields
- OD-1134 - Move Data Dictionaries Fields to the bottom of the Data Profile form
- OD-1146 - Use tree lines for relationships hierarchy views

## 1.10.2 July 09, 2021

#### Changes

- Seeds file for Organization ingestion updated

#### New Features

- Parent/child relationships are now displayed on the left side of the data profile pages
- Integrations tests for checking parent/child relationships on the data profile pages 

#### Bug Fixes

- Fix for Data Profile updates with blank values

#### Tickets Closed

- OD-1001 - Investigate automated versions in ckanext-versioning
- OD-1002 - Investigate support for groups in ckanext-versioning
- OD-1043 - Fix Data Profile updates with blank values
- OD-1057 - Enable Data Store (without visualization) in prod
- OD-1093 - Display parent-child relationships in left navigation bar
- OD-1123 - Add publishers / orgs to Seed Data

## 1.10.1 June 25, 2021

#### Changes

- Improve integrations tests for resources

#### New Features

- Broken link email reports

#### Tickets Closed

- OD-1082 - Increase integration tests coverage around resource operations
- OD-926 - Checking for dead links & sending notifications
- OD-1098 - Investigate format issue with XLSX files on Datopian's testing environment
- OD-1052 - Correct OCR links

## 1.10.0 June 11, 2021

#### Changes

- Resources added to private(hidden) Data Profiles can be now translated
- The resource approval workflow is now complete:
  - Sysadmins users can reject resources on the Approval Dashboard and provide some feedback to the resource creator
  - Any resource type is now submitted for the Approval workflow

#### New Features

- New derivation relationship is available for Data Profiles
- New types of Resource are now available:
  - Access URL type: provides indirect access to a resource via an HTML page or a graphical interface
  - API URL type: provides indirect access to a resource via API
  - These two resource types export the `accessURL` field on the `/data.json`

#### Bug Fixes

- Fix scrolling on error for Data Profile required fields
- Fix remove button on the resource upload field

#### Tickets Closed

- OD-982  - Test Migration CKAN 2.8.2 to 2.8.8 in the DEV environment
- OD-1011 - Enable derivation relationships between data profiles
- OD-1024 - Enable API Resources
- OD-1037 - Resource Approval Workflow - part 2
- OD-1068 - Enable format translation in private data profiles and non-approved resources

## 1.9.2 May 28, 2021

#### Changes

- Add documentation for the ckanext-ed custom Plugins
- Improve integrations tests for Data Profile operations

#### New Features

- New script to update wrong Resource URLs
- Add new dependency relationship for Data Profiles
- New integration tests for Data Profile relationships

#### Bug Fixes

- Fix Primary IT Unique Investment Identifier (UII) and System of Records auto scrool error

#### Tickets Closed

- OD-1010 - Enable dependency relationships between data profiles
- OD-1052 - Correct OCR links
- OD-1070 - Per-Sprint Test Coverage Ticket (Discovery & Organization)
- OD-1073 - Create documentation to describe Ed extension plugins
- OD-1081 - Increase Integration Tests coverage around Data Profile operations

## 1.9.1 May 14, 2021

#### Changes

- Add more options to the data profiles update frequency dropdown selection
- Data profile bureau codes are now set based on the data profile organization
- The reset password feature now asks for the user name and the user email before sending an email with instructions to reset the password
- Add a new tab to the Approval Dashboard to show resources pending approval

#### New Features

- Translated resources are now submitted for an approval process. Only sysadmin users can approve the resources
- New script to update data profiles accrual-periodicity (update frequency)
- New script to update data profiles bureau code based on the Organization

#### Bug Fixes

- Fix data explorers approval email sender

#### Tickets Closed

- OD-961 - Resource Approval Workflow - part 1
- OD-971 - Reset Password Feature Security Improvements
- OD-1016 - Fix missing bureau codes
- OD-1041 - accrualPeriodicity errors in data.json - Data update frequency "other"

## 1.9.0.1 April 30, 2021

#### Changes

- Cypreess integration tests improved for data profile operations

#### Bug Fixes

- Fix Organization Hierarchy when deleting a parent organization using the `organization_delete` API call

#### Tickets Closed

- OD-995 - Update docker-ckan-ed repo with the extension's current setup
- OD-996 - Generate a requirements file with all dependencies based on current state of testing environment
- OD-1049 - Define/investigate key areas of the project that should be covered by integration tests
- OD-1055 - Fix Organization Hierarchy when deleting a parent org using API calls
- OD-1056 - Improve integration tests for data profile operations

## 1.9.0 April 23, 2021

#### Changes

- The Organization tree now contains the whole Department of Education department/sub-department hierarchy

#### New Features

- New fields added to the data profiles form and to the `data.json` :
    - data quality
    - system of records
    - IT investment
- New scripts added to the repository:
    - download resources - download resources from resource links based on the organization name or the harvest source id
    - change data profiles organization - moves data profiles from one organization to another organization
    - delete organization - deletes an organization

#### Bug Fixes

- Fix the download resources command for non-file resource URLs. 

#### Tickets Closed

- OD-1023 - Add Data Quality attribute
- OD-1025 - Enable System of Records Notice reference
- OD-1026 - Enable IT Investment association
- OD-1040 - Resolve duplicate publishers
- OD-1042 - Include the whole Dept. of Ed. Organization hierarchy to the ODP
- OD-1046 - Update the download_resources command to call only API endpoints
- OD-1051 - Resource download failure: KeyError 'content-type'

## 1.8.6.1 April 16, 2021

#### Bug Fixes

- Fix data profiles survey issue when there is no info popup enabled

#### Tickets Closed

- OD-967 - Have You Used this Data? 2-3 question survey

## 1.8.6 April 09, 2021

#### Changes

- New ODP logo added to the pages
- Added description meta tag for search engines with the description text set by an environment variable
- Data Profile parent relationship added to data.json
- Data Profile program code field is now a required field

#### New Features

- Data Profile program codes values can be selected from a list
- Add Data Dictionary field for Data Profiles
- Add Data Dictionary field for Resources
- Data Dictionary fields mapped to data.json using `describedBy` and `describedByType` fields

#### Bug Fixes

- Fix robots meta tag syntax

#### Tickets Closed

- OD-972 - Specify a data dictionary
- OD-973 - Associate a data dictionary with a Resource
- OD-1004 - Identify the system as the Open Data Platform
- OD-1015 - Map relationships to data.json
- OD-1017 - Selection list for program codes

## 1.8.5 March 26, 2021

#### Changes

- Display original file from which a translated resource has been generated
- Translated resources are listed in a notification email, including errors

#### New Features

- Add a short survey on every data profile page to capture feedback for data profiles
- Add notification emails to data profile creator about resource translation results
- Script to export all resources from the ODP to a CSV file

#### Bug Fixes

- Fix wrong documentation for parent data profiles
- Fix documentation disappearing when updating it

#### Tickets Closed

- OD-967 - Have You Used this Data? 2-3 question survey
- OD-1009 - Script to generate list of resources linked in ODP
- OD-1012 - Show users which resources were created via translation
- OD-1013 - Notify Data stewards when resources do not properly translate

## 1.8.4 March 15, 2021

#### Changes

- Add new fields to the `data.json` export route:
  - `license` for manually added datasets
  - `temporal`
  - `theme`
  - `@id` - in the catalog fields
- Add the whole Dept. of Ed's Organization Hierarchy to the publisher field on the `data.json` export route
- Bring back the default Info Popup - Beta Site Info
- Automatic Resource translation now can handle files with multiple sheets (XLS and XLSX)
  - One Resource is created for each sheet
- Remove `future` Python2 package dependency

#### New Features

- Add relationships to the Data Profiles:
  - Parent relationship
  - Add option to set a Parent on the Data Profile form
  - Data Profile page displays Parent, Siblings, and Children
- Automatic Resource translation of XLS files

#### Bug Fixes

- Fix `accrual_periodicity` field on the `data.json` export route

#### Tickets Closed

- OD-933 - Discovery: Discuss the data versioning system and agree on a course of action
- OD-940 - map all compatible ODP Data Profile metadata fields to the datajson schema
- OD-944 - Enable parent/child relationships between data profiles
- OD-974 - Incorporate organization hierarchy in DCAT-US publisher field
- OD-986 - Add XLS to CSV format translation to the current background system
- OD-987 - translate multi-sheet xlsx and xls resource files to corresponding csv file
- OD-1008 - Revert Info Popup Changes

## 1.8.3 March 02, 2021

#### Changes

- Change ODP's main page Info Popup text to invite users to the live chat on March 5 2021

#### Tickets Closed

- OD-989 - Update Popup for Live Chat

## 1.8.2 Feb 26, 2021

#### Changes

- New plugin added to enable Resource Format Translations
- Approval Dashboard now renders much faster
- `requirements.txt` file added to install new ckanext-ed dependencies

#### New Features

- XLSX files can be automatically translated 
- Upload image for Data explorers enabled
- Configuration variable added to switch on/off email notifications about Resource Translation 

#### Bug Fixes

- Fix Data Explorer link in the News Feed activities
- New exceptions added to the `download_resources` paster command

#### Tickets Closed

- OD-962 - Fix Harvest fetch stage for https://www2.ed.gov/data.json ingestion
- OD-963 - Data Explorer Approval Improvements
- OD-862 - download_resources for harvest source fails with multiple batches
- OD-923 - Improve the look and feel of the data explorer page
- OD-930 - Put new xlsx document in a translation queue when a new resource is created


## 1.8.1 Feb 12, 2021

#### Changes

- Batch Translation script can iterate over all resources found in the ODP
- New Approval Dashboard design
- Data Explorer approval workflow enhancement
- Upload Image for Data Explorers Removed

#### New Features

- New features to the Batch Translation script: 
  - Timeout for all parallel translations 
  - Option that lists all remote xlsx files for translation added
  - Translation acceptable file format improved  
- Info gutters added to the dashboard pages
- Universal Federated Analytics added

#### Bug Fixes

- Fix the timeout error when approving or rejecting a Data Explorer
- Fix email sender error when approving or rejecting a Data Explorer
- Fix duplicated approval activities

#### Tickets Closed

- OD-932 - Script for batch CSV translation processing
- OD-898 - Digital Analytics Program participation
- OD-949 - Define, create & implement a design for the new Approval Dashboard
- OD-950 - Data Profile and/or Resource Validation Workflow with XLSX to CSV Translation (& create implementation ticket)


## 1.8.0 Feb 01, 2021

#### Changes

- Data Profile Source URL field now is labeled as URL of page containing all Resources, and it can be updated for all types of Data Profiles (scraped or manually added)
- Data Profile field - URL of page containing all Resources - is mapped to `landingPage` in the `data.json` export action
- Reset Password request is enabled

#### New Features

- New Approval Dashboard `/dashboard/approval`
- News Feed for the Approval Dashboard
- Reject action for the Data Explorer Approval Workflow with feedback
- Approval Workflow Email Notifications
- Display `Add Documentation` button for Data Profiles without any documentation

#### Bug Fixes

- Data Explorer view page for non-logged users
- Data Explorer logos adjusted for different screen sizes

#### Tickets Closed

- OD-895 - Approve Data Explorer changes
- OD-917 - Documentation button
- OD-943 - Add landing page metadata field
- OD-945 - Password Creation and Reset Via ODP email

## 1.7.4 Jan 15, 2021

#### Changes

- Publisher Administrators can now create and update Data Explorers

#### New Features

- Add a basic workflow for Data Explorers approval (only the Approve flow for now)
- Add the Digital Analytics Program tracking code
- Add a new script to translate XLSX files into CSV files
- Add a new script to delete Groups by type

#### Bug Fixes

- Fix Google Analytics tracking of Resource downloads
- Fix Google Analytics data load script 

#### Tickets Closed

- OD-872 - Investigate non-changing "trending" data profiles on the home page
- OD-898 - Digital Analytics Program participation
- OD-924	- Discuss and come to an agreement on a framework for translating resources to CSV
- OD-925 - Create a basic translator for getting resource to CSV

## 1.7.3 Dec 21, 2020

#### Changes

- Add a new plugin for Data Explorers `ed_data_explorers`
- Source URL metadata field is available for new data profiles
- `/data.json` export now contains the Landing Page field 
- Update bulk process for making data profiles public or private

#### New Features

- Source URL metadata field is available while creating or updating new data profiles
- Helpdesk Email prefilled with ODP@ed.gov when creating or updating a data profile
- Add bulk process to update empty Helpdesk Email
- Add Data Explorers create, update and delete operations
- Includes Source URL in the /data.json export map as Landing Page
- Add missing documentation on commands, scripts, configuration, and data
- Add integrations tests for category create operations.

#### Bug Fixes

- Fix Category list on the Data Profile Add Category Page
- Fix update for data profile extra fields (Update Frequency and Program Code)
- Fix Publisher and Organization changes for data profiles
- Fix Harvest Source page pagination
- Fix `fix_extras` script

#### Tickets Closed

- OD-902: Add source URL metadata field for new profiles
- OD-882: Fix Category list on the Data Profile Add Category Page
- OD-892: Frequency metadata element becomes stuck 
- OD-888: Can't change the publisher of a data profile.
- OD-903: Auto-populate metadata field help desk with ODP@ed.gov
- OD-887: Investigate way to bulk-change non-public data profiles to public (for OESE)
- OD-894: Ability to add to the Data Explorers list

## 1.7.2 Nov 16, 2020

#### Changes

- Downloading resources now checks `Content-Type` header instead of file contents

#### New Features

- Create a FAQ page
- XLS export is now configurable
- Configurable showing/hiding Sources in templates
- Configurable showing/hiding Beta notices in templates

#### Bug Fixes

- Fix copy paste artifact in download_resources
- Remove debugging code that broke categories
- Fix pager links in Publisher pages
- Empty list of harvest sources does not break the template anymore
- Fix API action `package_update` removing `extras` fields

#### Tickets Closed

- OD-548: Create FAQ for Public ODP Users
- OD-869: Server Error when adding profile to a category
- OD-874: Duplicate Identifiers in the IES scraped data.
- OD-873: Publisher pages stuck on page 1
- OD-875: Create a full metadata spreadsheet for FSA
- OD-876: Make Configurable the Beta message popup modal & beta banner message
- OD-862: download_resources for harvest source fails with multiple batches
- OD-871: Investigate missing source URL for OCR profiles
- OD-877: Change "Sources" banner navigation link to "Collections"


## 1.7.1 Oct 19, 2020
#### Changes

- Make resource download not react to HTML targets
- Merge Collections extension into ED extension code base
- Change plugin names:
  - `collections` became `ed_collections`
  - `master_collections` became `ed_master_collections`

#### New Features

- Add automated UAT suite powered by Node.js / Cypress
- Harvest source templates now show hidden datasets too
- Add deployment environment details + script to automate versions checking for 
  Python packages

#### Bug Fixes

- Amended documentation string for resource downloader
- Fix typo in function call in the resource downloader

#### Tickets Closed

- OD-858: Perform a new comparison of EDI vs ODP inventory
- OD-861: Amend IES data.json to default to "hidden"
- OD-591: [devops] Lock down dependencies for running the portal
- OD-862: `download_resources` for harvest source fails with multiple batches
- OD-856: Merge `ckanext-collections` into `ckanext-ed`


## 1.7.0 Oct 02, 2020
#### Bug Fixes

- Fix wrong case sensitive sorting for home page tags 
- Deal with broken code imports
- Fix broken Delete button in Publisher member admin page

#### Changes

- Users cannot change their email address anymore
- Tags are not lowercased on display anymore

#### New Features

- Add a restore feature to the resources download script
- Add a "No Organization" filter facet value for Data Profiles
- Static and computed defaults for data.json data export
- Link Harvest Sources to Collections and Sources
  - List all harvested Collections in Harvest Source pages
  - List all harvested Sources in Harvest Source pages
  - When clearing a Harvest Source, also remove harvested Collections and Sources
- Add a configurable `robots` meta tag in the main layout

#### Tickets closed

- OD-587: Align Dept Ed data.json schema with data.gov schema
- OD-852: Investigate impact of load balancer configuration (1 hr time box)
- OD-314: Any user can change their Email ID, disable this
- OD-610: When clearing a harvest source's results, also clear the harvested Collections / Sources
- OD-611: When visiting a harvest source, also display harvested Collections / Sources
- OD-819: Wrong Totals in Scraping Dashboard Insights
- OD-829: Investigate and resolve the "I" tag showing at top of tag list
- OD-831: Data profile spatial field bug when form validation fails
- OD-832: deleting a user from a Publisher role using the edit option fails
- OD-842: Create back-out script to purge ingested data files "just in case"
- OD-848: Create a "No Organization" value for the Organizations search facet
- OD-854: Remove robots.txt; use "robots" meta tag instead


## 1.6.2 Sep 16, 2020
#### New Features

- Display all publishing entities in the /publishers page
- Dismiss blank or underscore tags while indexing
- Add hierarchy aware Publisher and Organization drop downs in Collection and Source forms
- Provide data profile search by Organization in all site areas

#### Bug Fixes

- Amend data.json output schema to match DCAT
- Fix missing `suborganization` type package membership
- Exclude Organizations from Publishers facet values
- Fix wrong totals in the API endpoint for scraping dashboard

#### Changes

- If by any chance an Organization is passed as Publisher, or any other invalid combinations, the Data Profile will record the correct Publisher and Organization according to the defined hierarchy
- Cleared useless facets in Source page side bar
- Support hidden packages in XLS exporter script

#### Tickets closed

- OD-828: Investigate and remove "blank" tags on data profiles
- OD-811: Provide search for data profile by organisations
- OD-814: Publisher page / organisations pages do not list anything, as they are linked to their parents instead
- OD-818: Missing publishers full name in the Scraping Dashboard
- OD-833: Display accurate data profile counts for all publishers in the publishers list
- OD-834: Source form: organizations dropdown should only list children of selected publisher
- OD-835: Collection form: organizations dropdown should only list children of selected publisher
- OD-836: Source form: publisher dropdown should not list organizations
- OD-837: Collections form: publisher dropdown should not list organizations
- OD-838: Refresh/cleanup the side description/gutter for Sources page


## 1.6.1 Sep 02, 2020
#### New Features

* Make harvester optionally download resources (new config option)
* Command to download resources now operates on both Publisher and Harvest Source level
* [Data Profile form] On selecting / changing Publisher, the Organization list gets updated
* XLS exporter now supports exporting hidden packages

#### Changes

* Permissions updated for access to Add Collection / Add Source (only editor+ users)
* Change Categories forms to follow US ED design guidelines and terminology
* [Housekeeping] Refactored `paster` commands

#### Bug Fixes

* Fix single Spatial item breaking into a list of letter on failed Data Profile form validation
* Fix broken Category Delete action and confirmation message
* Publisher and Organization dropdowns in Data Profile form now show the correct entities

#### Tickets Closed

* OD-743: Publisher members can see the Add Source/Add Collection buttons
* OD-754: Update the harvester to make sure it uploads resources instead of linking to them
* OD-758: Update the forms used to manage categories inline with the Ed standard
* OD-809: Data profile form: organizations dropdown should only list children of selected publisher
* OD-810: Data profile form: publisher dropdown should not list organizations


## 1.6.0 Aug 21, 2020
#### New Features

- Cookie based mini popup alerting about the beta status of the ODP


#### Bug Fixes

- Fix wrong template after updating resources
- Fix 404 on Source > Members > Edit tabs


#### Tickets Closed

- OD-765: Propose solutions for "Beta Site" language to be more prominent, then execute it
- OD-807: updating a resource renders the wrong template
- OD-808: Switching between Members and Edit tabs when managing a Source throws a 404 error
- OD-825: Server error when accessing a Publisher's About page


## 1.5.3 Aug 19, 2020
#### Changes

- Password reset CKAN feature was disabled
- By default, resources are uploads only (unless configured otherwise)


#### New Features

- New configuration option to allow only publishers in a list to add link-type resources
- Add a script to correct missing harvester metadata in harvested datasets
- Add a script to transform resources of a publisher from links to uploads
- Add all the utility scripts we have used (and are using) with CKAN API to the repository
  - Excel downloader
  - Level of data migration script (old format to new format)
  - Utility to hide a publisher's datasets
  - Utility to delete a publisher's datasets


#### Bug Fixes

- Correctly render HTML in package description
- Fix offices seed file (missing offices, wrong parents)
- Removed the old, slow and inaccurate package autocomplete in the Collections form and replaced with a new dedicated API autocomplete endpoint
- Fix wrong confirmation message when deleting Sources
- Fix harvester duplicating data profiles after transforming their resources
- Remove broken debug messages breaking the harvester queues
- Fix harvest queue crashing due to missing config option
- Remove some excessively verbose logging when harvesting Collections / Sources


#### Tickets closed

- OD-704: Script to estimate the size of all resources linked from scraped data profiles
- OD-802: Refine OESE scraped output
- OD-803: Generate Spreadsheet with OESE Data Profiles for data stewards review
- OD-723: Bulk update data profiles to support new harvester features
- OD-603: P5-P17 - Implement Sources and Collections for P5-P17 parsers
- OD-695: Create scraper for dashboard.ed.gov
- OD-696: Create scraper for rems.ed.gov
- OD-697: Update the RAG transformer to capture new metadata fields
- OD-724: Updating the scraping dashboard to track edited data profile metrics
- OD-739: Modify Password Reset functions on site
- OD-750: Automate the download of data profile resources from their external sites to ODP
- OD-751: Ensure that new data profiles being created can only store resources on the ODP
- OD-753: Finish the renaming of Groups / Topics into Categories
- OD-756: update the harvester to ensure resources are not duplicated or overwritten on reharvest
- OD-757: Make data profile dropdown (in the collections form) use the autocomplete api
- OD-749: deleting a Source displays an incorrect confirmation message and success message
- OD-603: P5-P17 - Implement Sources and Collections for P5-P17 parsers


## 1.5.2 Aug 05, 2020
#### Changes

- Add a modal popup for data explorer items
- Improve the display of Collection lists
- Mark data profiles as edited once updated via CKAN
- Enrich the Scraping Dashboard API endpoint data


## 1.5.1 Jul 28, 2020
#### Changes

* Restrict Publisher / Organization options in Data Profile form
* Prevent discarding (internal) extras when saving a Data Profile
* Change the way drop down elements are displayed (show titles instead of IDs)

#### Bug Fixes

* Fix issues with large screens in data explorer page
* Change reference to Dataset -> Data Profile in Publisher pages
* Fix editors not being able to add Documentation to their Publisher's Data Profiles
* Only allow selecting manageable Collections when editing Data Profiles


## 1.5.0 Jul 22, 2020
#### Changes

- Updated text on login page
- Updated layout on Data Explorers page
- Remove "existing tag" error in harvester log
- Hide useless stages when editing existing collections
- Make Collections only point to a single Source at a time


#### Bug Fixes

- Fix search results sorting removing the search query
- Fix crashing Source Members tab
- Avoid removing source_url when saving a dataset
- Change button labels for Save / Add Documentation to their correct values
- Make possible to add missing documentation for collections
- Fix single datasets not being added to collections
- Fix references to datasets in collection documentation forms
- Fix "Previous" button not working when creating a dataset
- Fix custom harvester duplicating all harvested datasets


#### New Features

- When adding a dataset, the documentation publisher is set to match the one in the dataset
- Make Collections and Sources reflect their Publisher memberships (Editors and Admins can "Manage")
- Allow users to create Collections and Sources
- Make it possible to unassign a Source from a Collection
- Hide publishers with no packages from the general public
- Add a toggle to `allow_removing_datasets` for harvest sources


## 1.4.5 Jul 09, 2020
#### Bug Fixes

* Fix flawed data profile documentation user journey (delete / modify redirects and functionality)
* Fix deprecated collections helper text
* Fix positioning of post-delete alert messages
* Fix documentation delete leaving ghost documentations still visible to the user
* Fix crash on data profile add / edit due to `name` property validation

#### Changes

* Level of Data dropdown is now more user friendly and has "instant", no-search options

#### New Features

* Add Data Explorers page


## 1.4.4 Jun 26, 2020
#### Bug Fixes

* Fix package metadata field names for harvested datasets
* Remove collections from list of categories in dataset template
* Fix wrong labels for categories
* Fix delete button not removing documentation
* Fix broken Source URL links for Collections and Sources

#### Changes

* Update sources page info text
* Implement level of data as tags vocabulary (so we can save and use lists of values in extra fields)
* In dataset view, Helpdesk email address is now a clickable link


## 1.4.3 Jun 23, 2020
#### New Features

* Ed Scrapers Harvester now harvests groups from datajson `theme` property
* Bureau code now defaults to `018:00`
* Documentation can be skipped by either leaving it empty or clicking a manual bypass link

#### Bug Fixes

* Fix display differences between harvested data and manually edited data
* Add missing IES offices in the Publisher seed data
* Fix broken link issue between Collections and Data Profiles triggered sometimes when editing Collections

#### Changes

* Removed dependency on `ckanext-datajson` provided mapping file for harvesting from `edscrapers` data
* Aligned fields on edit form / metadata display page


## 1.4.2 Jun 17, 2020
#### Changes

* New metadata labels for Data Profiles, Sources and Collections
* New default configuration for Ed harvester (no need to input custom JSON anymore)

#### Bug Fixes

* Fix crashing Collection / Source creation form
* Fix long names breaking the harvester
* Fix database seed context (no need to run it in a loop anymore)

#### New Features

* New database seed for Publishers
* New metadata fields for harvested Data Profiles


## 1.4.1 Jun 03, 2020
#### Changes

* Removed "extra" fields from Organization (Publisher) forms
* Data Profile default visibility is now Public
* Reworded Data Profile visibility to Public or Hidden

#### Bug Fixes

* Replaced "dataset" with "data profile" in all strings
* Made all references to Sources and Collections be in sentence case
* Fixed 508 (accessibility) issue in admin area navigation


## 1.4.0 May 26, 2020
#### New Features

* New plugins for datajson output and harvester
  * The new plugins need to be added to CKAN's `ini` file: `edharvester eddatajson`
* New Action API endpoint at `api/action/ed_scraping_dashboard` for stats related to the scraping dashboard in `edscrapers.tools` module
* Align data.json output structure to what data.gov expects to harvest


#### Changes

* Add Source URL on Sources metadata

#### Bug fixes

* Fix tags and spatial not rendering correctly in data.json output
* Fix broken imports in `ckanext.ed.helpers`


## 1.3.1 May 04, 2020
#### Changes

* Better metadata defaults for data steward and helpdesk
* Disabled Sources search facet (no direct connection to datasets and confusing behaviour)
* Align dataset / collection / source metadata structure and forms
* Drop "help" field from metadata (deprecated in favor of documentation packages)
* Change default visibility to "public" for all forms

#### New Features

* New tooltip on long publisher names in dataset search page

#### Bug Fixes

* Fix collections search facet not being populated properly or breaking search
* Fix 508 issues with color contrast
* Fix program code and bureau code not saving / displaying


## 1.3.0 Apr 09, 2020
#### Changes:

* remove the package schema validation on backend
* add package schema validation on frontend

#### New features:

* add `scraped_from` property to packages to identify the source for scraped data

#### Bugfixes:

* better metadata defaults for datasets
* remove machine readable tick for harvested TXT files
* fix accessibility issues on bootstrap modals (trap keyboard focus once opened)


## 1.2.8 Mar 19, 2020
#### Changes

* add new `source_url` property to package schema
* remove requirements for mandatory fields for packages


## 1.2.7 Feb 07, 2020
#### Bug Fixes

* Removed wrong helper text in dataset form / frequency field


## 1.2.6 Feb 07, 2020
### Changes

* Changed default visibility for dataset documentation to Public

### New Features

* New "Description" tab in dataset page
* Hierarchy among organizations - "publishers" can now have "organizations" (in CKAN terminology it's going to be organizations and suborganizations)
* The new default view for dataset is the Description tab
* New dataset metadata fields: organization and update frequency
  * "organization" is `suborg_owner` and it's chosen from all the "children" organization in the hierarchy tree
  * `update_frequency` reuses a helper from ckanext-collections to ensure the list of options is consistent with the one available for collections

### Bug Fixes

* Clearing one filter in dataset search does not clear all filters anymore
* Fixed having quotes in collection/sources names was breaking the filtering JS
* Fixed styling irregularities on dataset page / metadata table
* Fixed not saving / not displaying `level_of_data` values for datasets


## 1.2.5 Jan 24, 2020
#### Changes:

* Change the way dataset metadata is displayed


## 1.2.4 Jan 24, 2020
#### Bug fixes:

* fix random ordering of JS bundles by fanstatic
* accessibility fixes
* fix spatial validator breaking the harvester


## 1.2.3 Jan 21, 2020
#### Bug Fixes

* Fix Spatial tags harvesting error.

## 1.2.2 Jan 21, 2020

## 1.2.1 Jan 16, 2020
#### Changes

* New validator for spatial tags to ignore tags looking like geographical coordinates
* Throw a 403 error instead of 404 when attempting to visit a private documentation (and not logged in)
* Do not display link to add dataset docs for unauthenticated users

#### Bug Fixes

* Synchronize dataset and dataset documentation top banners


## 1.2.0 Jan 14, 2020
Ready for public release


## 0.6.0 Jan 10, 2020
* Change how spatial tags are automatically created when missing
  * New validator that creates missing tags
  * This is declared at schema level, so it works on any package create/update request, including harvested data


## 0.5.27 Jan 08, 2020

* Add framebusting OWASP clickjacking defense code to each page
* Fixed text wrapping bugs
* Fixed responsiveness issues on add dataset form
* Remove registration link from sign in form


## 0.5.26 Jan 07, 2020
#### Bug Fixes

* Fix Google Analytics tracking code


## 0.5.25 Jan 07, 2020
#### Bug Fixes

* Fix new dataset form not moving forward after adding a resource
* Fix capitalization on about page


## 0.5.24 Dec 21, 2019
#### Bug Fixes

* Fix spatial facet not working in dataset search
* Fix form stage wrapping on smaller viewports
* Remove hardcoded "Master Collection" string from Collection view


## 0.5.23 Dec 20, 2019
#### Bug fixes

* Dataset view: Fix incorrect tags count causing "show more" link to render even when it was not needed
* Dataset view: Make tags wrap, shorter tags now don't show one per line anymore
* Updated footer "Beta" text
* Fix group seed command only adding the last group in the list


## 0.5.22 Dec 19, 2019
#### Changes / new features:

* Changed footer banner text
* New show more/less on long lists of tags in dataset view
* Show list of datasets in a collection's docs page


## 0.5.21 Dec 17, 2019
#### Changes

* About page text
* Changed the way seeding is done, now it's easier to prepopulate the db: `paster --plugin=ckanext-ed ed create_ed_groups` (no path needed, but accepted as an optional parameter for non standard seed locations)
* Removed publisher image from forms and pages

#### New Features

* New seed command to add initial groups to the database

#### Bug Fixes

* Fix adding an empty resource on dataset creation
* Fix login when valid credentials were not working
* 508 (accessibility) fixes:
    * https://github.com/CivicActions/ckanext-ed/issues/233
    * JIRA OD-390:
        * Skip nav link hidden from all users
        * Incorrect use of `role=menubar`
        * List structure issue caused by `role=menubar`
        * data.ed.gov logo missing `alt` text
        * ED logo missing `alt` text
        * Hamburger menu button is missing discernable text
        * Color contrast below minimum
        * Alt text missing for 2 images
        * Search box is missing an associated `<label>`
        * Search button is missing discernable text
        * dropdown menus missing explicit &lt;label&gt; elements
        * Scrollable content is not accessible by the keyboard
        * Checkboxes are selectable by keyboard, but do not function (Blocked)
        * Checkboxes are missing explicit &lt;label&gt; elements
        * `<ul>` elements must only contain `<li>` elements
        * Dropdowns do not show visible focus indicator
        * Color Contrast of Clear All button on focus
        * Dropdown button is missing discernable text
        * Color contrast below minimum
        * `<iframe>` element missing a title attribute
        * Color Contrast below minimum
        * Search button is missing discernable text
        * Unique IDs
        * Unique IDs
        * Color Contrast below minimum
        * Invalid ARIA Value
        * Color Contrast below minimum


## 0.5.20 Dec 16, 2019
#### Changes

* Updated login alert notice
* Renamed Topics / Groups to Categories in all templates


## 0.5.19 Dec 13, 2019
#### New Features

* Add Warning Page before logging in

#### Bug Fixes

* Bring back facets values on the search sidebar


## 0.5.18 Dec 12, 2019
#### New features

* Added sort option on publishers page "By number of datasets"
* Added dataset metadata on "Missing documentation" page
* New "beta" footer banner

#### Bug Fixes

* Publishers page does not reference "organizations" anymore
* Harvester sources not showing up in the sources list
* Harvested datasets not showing up and not being counted
* Fixed harvester duplicating datasets


## 0.5.17 Dec 10, 2019
Harvester and documentation updates.

#### Changes

* Nav bar now links to Sources instead of Collections
* Swapped order of Collections and Sources tabs
* New tag in `spatial` vocabulary: "United States"
    * Rerun `paster --plugin=ckanext-ed ed create_ed_vocabularies /path/to/ckanext-ed/ckanext/ed/seeds/tags` to create it automatically

#### Bug Fixes

* Harvester now saves datasets according to Dept of Ed updated package schema
* Fixed wrong tab bar links on dataset documentation page
* Removed link to Disqus from dataset documentation page
* Fixed displaying wrong dataset metadata when viewing the documentation
* Fixed switching of context from dataset to dataset's documentation package


## 0.5.16 Dec 06, 2019
#### Feature changes

* Master Collections are not Sources in the user interface
* More options for Level of Data field
* Add data profile metadata in the read UI
* Only expose relevant metadata in the UI for resources and documentation
* Trying to access missing documentation for datasets does not throw a 404 error anymore, but presents a link to add one instead
    * Make possible to add dataset documentation after dataset creation
* Rephrase Data Relevance to be more specific

#### Bug Fixes

* Fix collections not being all preselected when editing a Source with multiple children
* Remove collections from the topics facet in search page
* Remove collections from the topics dropdown (in the assign to topic form)
* Update all outdated i18n strings, extract even more strings from templates
* Make Collections and Sources facets depend on each other (filter each other out on selection, just like the other facets)


## 0.5.15 - Nov 22, 2019
Compliance with Section 508.

#### Bug Fixes

* Skip nav link hidden from all users
* Incorrect use of role=menubar
* List structure issue caused by role=menubar
* Hamburger menu button is missing discernable text
* Color contrast below minimum
* Search box is missing an associated &lt;label&gt;
* Search button is missing discernable text
* Scrollable content is not accessible by the keyboard
* Dropdowns do not show visible focus indicator
* Dropdown button is missing discernable text
* Color contrast below minimum
* Color Contrast below minimum
* Search button is missing discernable text
* Color Contrast below minimum
* Invalid ARIA Value
* Color Contrast below minimum
* Data Explorer:
  * <iframe> element missing a title attribute
  * To and From fields are missing associated &lt;label&gt;s
  * Focus order issue with API and Embed modal overlays
  * Modal close button reads as “times”
  * Focus Order issue on filter buttons
  * Buttons lacking friendly text name
  * Labels not associated


## 0.5.14 - Nov 15, 2019

#### Bug fixes

* editing older datasets (before schema changes) does not crash the form anymore
* search facets (tags, publishers, collections and master collections) show up and filter results as expected
* section 508 compliance fixes in templates


## 0.5.13 - Nov 14, 2019

#### Bug fixes
* bring back the hints in the new dataset form
* fix duplicate spatial tags in the dataset edit form
* fix crashing new publisher form
* fix crashing dataset form when adding a single spatial tag

#### Misc
* soft remove Disqus from dataset page
* improve tag handling in dataset UI


## 0.5.12 - Nov 12, 2019
This release adds the new data profile documentation implementation.

#### New features
* Documentation for data profiles implemented the same as for collections

#### Bug fixes
* Validate mandatory data profile fields


## 0.5.11 - Nov 11, 2019

#### Bug fixes

* Fix crashes when entering new collection form
* Fix crashes when entering new master collection form
* Fix broken relationship between collections and spatial tags


## 0.5.10 - Nov 05, 2019
Dataset tags and resources

#### New features
* possibility to add new spatial tags just by entering them
* collections facet in dataset search
* master collections facet in dataset search

#### Bug fixes
* fix `package_show` API response containing spatial in both tags and spatial tags
* fix spatial filter in dataset search

#### Improvements
* search performance improvement
* collection page performance improvement



## 0.5.9 - Oct 31, 2019
New datasets form field for collections. Needs ckanext-collections >= 0.2.x.

#### New features:
* if applicable, display the Master Collection name (with link) a collection is a member of in the collection's metadata table

#### Bug fixes:
* fix searching for datasets in collection form
    * now uses autocomplete API endpoint
    * also searches through private datasets
    * change the way datasets are sent to the collection controller from sending a form list to sending a comma separated list of values.
* fix home page displaying collections as topics
* fix home page displaying documentation in recent datasets
* [master] collection metadata display fixes
    * better formatting for list of tags (with links)
    * format publisher name (with link)
* hide collections from topics facet in dataset search page
* fix saving a new dataset redirecting to publishers index



## 0.5.8 - Oct 29, 2019
Better display of collection metadata

#### Bug fixes:

* format tags (with links) in (master) collection template
* format spatial tags (with links) in (master) collection template
* format timestamps in (master) collection template
* format title for collections


## 0.5.7 - Oct 25, 2019

#### Changes
- editing collections / master collections / documentations / data profiles doesn't remove groups anymore
- editing collection documentation redirects back to collection page
- can edit documentation resources
- strengthened up relationships

#### Bug fixes
* Fix broken relationships between groups after editing collections, master collections or datasets
* Fix corner case where redirect to collection after editing documentation wasn't working


## 0.5.6 - Oct 22, 2019

#### Bug fixes
* Fix position of buttons in collection pages (admin view)
* Fix access to documentation for collections

#### New features
* Link collection and documentation forms and templates
    * Now possible to edit documentation and return to collection
    * Also possible to edit documentation resources


## 0.5.5 - Oct 18, 2019

#### Bug fixes
* Fix dataset assignment in new collection form


## 0.5.4 - Oct 18, 2019

#### Code cleanup:
* Refactor all main controllers into their own modules
* Module imports: remove unused, fix broken, join similar
* Remove scheming artifacts

#### New features
* Implement `package_type` parameter in CKAN `package_search` action
    * Dataset search now doesn't list documentations
    * Dataset search pagination works better due to results being filtered in advance
* Only allow one master collection to be associated with a collection

#### Bug fixes
* Fix wrong terminology around collections / master collections templates
* Remove hardcoded Master Collection metadata, show real values in templates
* Package search fixes in collection view
* Fix program affiliation field not being populated


## 0.5.3 - Oct 16, 2019

#### Bug fixes
* Collection links in dataset view
* Publisher links in dataset view
* Tag list correctly formatted in dataset view
* Do not show spatial tags in the list of normal tags (dataset view)
* Fix button labels when editing
* Fix corner case prepopulating datasets field when adding a new collection
* Fix adding collections to Master Collections
* Fix wrong dataset count in collection view

#### New features
* Display documentation in collection view
* Hide stages when editing documentation
